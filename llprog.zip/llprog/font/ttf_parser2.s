format PE
entry start

include 'win32a.inc'

TTF_HEADER_SIZE     equ 12
TTF_DIR_ENTRY_SIZE  equ 16
READ_COUNT          equ 1

section '.data' data readable writeable
    file_name       db 'c:\WINDOWS\Fonts\CONSOLA.TTF', 0
    mode_read       db 'rb', 0
    fmt_err         db 'Error opening file', 10, 0
    fmt_hdr         db 'sfntVersion: %08X', 10,\
                       'numTables: %u', 10,\
                       'searchRange: %u', 10,\
                       'entrySelector: %u', 10,\
                       'rangeShift: %u', 10, 10, 0
    fmt_thdr        db 'Tag  | CheckSum | Offset   | Length   | Padding', 10,\
                       '-------------------------------------------------', 10, 0
    fmt_trow        db '%c%c%c%c | %08X | %08X | %08X | %u', 10, 0
    fmt_trow2       db '%.*s | %08X | %08X | %08X | %u', 10, 0

    align 4
    ttf_header:
        .sfnt           dd ?
        .numTables      dw ?
        .searchRange    dw ?
        .entrySelector  dw ?
        .rangeShift     dw ?

    align 4
    dir_entry:
        .tag            dd ?
        .checkSum       dd ?
        .offset         dd ?
        .length         dd ?

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc print_header
    movzx eax, word [ttf_header.rangeShift]
    movzx ecx, word [ttf_header.entrySelector]
    movzx edx, word [ttf_header.searchRange]
    cinvoke printf, fmt_hdr, [ttf_header.sfnt], [num_tables],\
            edx, ecx, eax
    ret
endp

proc print_row, [padding]
    cinvoke printf, fmt_trow2, 4, [dir_entry.tag],\
            [dir_entry.checkSum], [dir_entry.offset],\
            [dir_entry.length], [padding]
    ret
endp

proc main uses ebx esi edi
    local file_handle:DWORD, num_tables:DWORD

    cinvoke fopen, file_name, mode_read
    test eax, eax
    jz .err_fopen
    mov [file_handle], eax

    cinvoke fread, ttf_header, READ_COUNT, TTF_HEADER_SIZE, [file_handle]

    mov eax, [ttf_header.sfnt]
    bswap eax
    mov [ttf_header.sfnt], eax

    movzx eax, word [ttf_header.numTables]
    xchg al, ah
    mov word [ttf_header.numTables], ax
    movzx ebx, ax
    mov [num_tables], ebx

    movzx eax, word [ttf_header.searchRange]
    xchg al, ah
    mov word [ttf_header.searchRange], ax

    movzx eax, word [ttf_header.entrySelector]
    xchg al, ah
    mov word [ttf_header.entrySelector], ax

    movzx eax, word [ttf_header.rangeShift]
    xchg al, ah
    mov word [ttf_header.rangeShift], ax

    stdcall print_header

    cinvoke printf, fmt_thdr

    xor esi, esi
.loop:
    cmp esi, [num_tables]
    jae .done

    cinvoke fread, dir_entry, READ_COUNT, TTF_DIR_ENTRY_SIZE, [file_handle]

    mov eax, [dir_entry.checkSum]
    bswap eax
    mov [dir_entry.checkSum], eax

    mov eax, [dir_entry.offset]
    bswap eax
    mov [dir_entry.offset], eax

    mov eax, [dir_entry.length]
    bswap eax
    mov [dir_entry.length], eax

ALIGNMENT_SIZE      equ 4
ALIGNMENT_MASK      equ 3

    mov eax, [dir_entry.length]
    and eax, ALIGNMENT_MASK
    mov ecx, ALIGNMENT_SIZE
    sub ecx, eax
    and ecx, ALIGNMENT_MASK

    stdcall print_row, ecx

    inc esi
    jmp .loop

.err_fopen:
    cinvoke puts, 'err_fopen'
    jmp .exit

.done:
    cinvoke fclose, [file_handle]

.exit:
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            fopen,          'fopen',\
            fread,          'fread',\
            printf,         'printf',\
            fclose,         'fclose'
