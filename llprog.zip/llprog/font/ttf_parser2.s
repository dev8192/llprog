format PE
entry start

include 'win32a.inc'

TTF_HEADER_SIZE     equ 12
TTF_DIR_ENTRY_SIZE  equ 16
ALIGNMENT_SIZE      equ 4
ALIGNMENT_MASK      equ 3
SUCCESS             equ 0
READ_COUNT          equ 1

section '.data' data readable writeable
    file_name       db 'c:\WINDOWS\Fonts\CONSOLA.TTF', 0
    mode_read       db 'rb', 0
    fmt_err         db 'Error opening file', 10, 0
    fmt_hdr         db 'sfntVersion: %08X', 10,\
                       'numTables: %u', 10,\
                       'searchRange: %u', 10,\
                       'entrySelector: %u', 10,\
                       'rangeShift: %u', 10, 10, 0
    fmt_thdr        db 'Tag  | CheckSum | Offset   | Length   | Padding', 10,\
                       '-------------------------------------------------', 10, 0
    fmt_trow        db '%c%c%c%c | %08X | %08X | %08X | %u', 10, 0

    align 4
    ttf_header:
        .sfnt           dd ?
        .numTables      dw ?
        .searchRange    dw ?
        .entrySelector  dw ?
        .rangeShift     dw ?

    align 4
    dir_entry:
        .tag            dd ?
        .checkSum       dd ?
        .offset         dd ?
        .length         dd ?

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, SUCCESS

proc byteswap_16, val:DWORD
    mov eax, [val]
    rol ax, 8
    ret
endp

proc byteswap_32, val:DWORD
    mov eax, [val]
    bswap eax
    ret
endp

proc main uses ebx edi
    local file_handle:DWORD, num_tables:DWORD, i:DWORD

    cinvoke fopen, file_name, mode_read
    test eax, eax
    jz .err_fopen
    mov [file_handle], eax

    cinvoke fread, ttf_header, READ_COUNT, TTF_HEADER_SIZE, [file_handle]

    stdcall byteswap_32, [ttf_header.sfnt]
    mov [ttf_header.sfnt], eax

    movzx eax, word [ttf_header.numTables]
    stdcall byteswap_16, eax
    mov word [ttf_header.numTables], ax
    movzx ebx, ax
    mov [num_tables], ebx

    movzx eax, word [ttf_header.searchRange]
    stdcall byteswap_16, eax
    mov word [ttf_header.searchRange], ax

    movzx eax, word [ttf_header.entrySelector]
    stdcall byteswap_16, eax
    mov word [ttf_header.entrySelector], ax

    movzx eax, word [ttf_header.rangeShift]
    stdcall byteswap_16, eax
    mov word [ttf_header.rangeShift], ax

    movzx eax, word [ttf_header.rangeShift]
    movzx ecx, word [ttf_header.entrySelector]
    movzx edx, word [ttf_header.searchRange]
    cinvoke printf, fmt_hdr, [ttf_header.sfnt], [num_tables],\
            edx, ecx, eax

    cinvoke printf, fmt_thdr

    mov [i], 0

.loop_start:
    mov eax, [i]
    cmp eax, [num_tables]
    jae .loop_end

    cinvoke fread, dir_entry, READ_COUNT, TTF_DIR_ENTRY_SIZE,\
            [file_handle]

    stdcall byteswap_32, [dir_entry.checkSum]
    mov [dir_entry.checkSum], eax

    stdcall byteswap_32, [dir_entry.offset]
    mov [dir_entry.offset], eax

    stdcall byteswap_32, [dir_entry.length]
    mov [dir_entry.length], eax

    mov eax, [dir_entry.length]
    and eax, ALIGNMENT_MASK
    mov ecx, ALIGNMENT_SIZE
    sub ecx, eax
    and ecx, ALIGNMENT_MASK

    movzx eax, byte [dir_entry.tag + 3]
    movzx edx, byte [dir_entry.tag + 2]
    movzx ebx, byte [dir_entry.tag + 1]
    movzx edi, byte [dir_entry.tag + 0]

    cinvoke printf, fmt_trow, edi, ebx, edx, eax,\
            [dir_entry.checkSum], [dir_entry.offset],\
            [dir_entry.length], ecx

    inc [i]
    jmp .loop_start

.err_fopen:
    cinvoke puts, 'err_fopen'
    jmp .exit

.loop_end:
    cinvoke fclose, [file_handle]

.exit:
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            fopen,          'fopen',\
            fread,          'fread',\
            printf,         'printf',\
            fclose,         'fclose'
