format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    filename            db 'c:\WINDOWS\Fonts\CONSOLA.TTF', 0
    hFile               dd ?
    hMap                dd 0
    pMap                dd 0
    fileSize            dd 0
    numTables           dd 0
    headOffset          dd 0
    maxpOffset          dd 0
    locaOffset          dd 0
    glyfOffset          dd 0
    indexToLocFormat    dd 0
    numGlyphs           dd 0
    locaPtr             dd 0
    glyfPtr             dd 0
    glyphStart          dd 0
    glyphEnd            dd 0
    glyphLength         dd 0
    numContours         dd 0
    xMin                dd 0
    yMin                dd 0
    xMax                dd 0
    yMax                dd 0
    strLen              dd 0
    bytesWritten        dd 0
    fmtGlyph            db 'Glyph 0: contours=%d, bbox=(%d,%d)-(%d,%d), size=%d bytes', 10, 0
    fmt_d               db '%d', 10, 0

section '.text' code readable executable
start:
    stdcall parser1
    invoke  ExitProcess, 0

proc parser1
    invoke  CreateFile, filename, GENERIC_READ, FILE_SHARE_READ,\
            0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0
    cmp     eax, INVALID_HANDLE_VALUE
    je      .error
    mov     [hFile], eax
    invoke  GetFileSize, eax, 0
    cinvoke printf, fmt_d, eax
    invoke  CloseHandle, [hFile]
    jmp .exit
.error:
    cinvoke puts, 'error'
.exit:
    ret
endp

proc parser2
    invoke  CreateFile, filename, GENERIC_READ, FILE_SHARE_READ, 0, OPEN_EXISTING, 0, 0
    cmp     eax, INVALID_HANDLE_VALUE
    je      .exit_error
    mov     [hFile], eax

    invoke  GetFileSize, eax, 0
    mov     [fileSize], eax

    invoke  CreateFileMapping, [hFile], 0, PAGE_READONLY, 0, 0, 0
    test    eax, eax
    jz      .exit_error
    mov     [hMap], eax

    invoke  MapViewOfFile, eax, FILE_MAP_READ, 0, 0, 0
    test    eax, eax
    jz      .exit_error
    mov     [pMap], eax

    mov     esi, eax
    mov     eax, [esi]
    cmp     eax, 00010000h
    jne     .exit_error

    movzx   ecx, word [esi+4]
    xchg    cl, ch
    mov     [numTables], ecx
    add     esi, 12
    mov     edi, esi
    xor     ebx, ebx
.scan_tables:
    cmp     ebx, [numTables]
    jge     .tables_ready
    mov     eax, [edi]
    cmp     eax, 0x64616568
    je      .set_head
    cmp     eax, 0x7078616D
    je      .set_maxp
    cmp     eax, 0x61636F6C
    je      .set_loca
    cmp     eax, 0x66796C67
    je      .set_glyf
    jmp     .next_tbl
.set_head:
    mov     eax, [edi+8]
    bswap   eax
    mov     [headOffset], eax
    jmp     .next_tbl
.set_maxp:
    mov     eax, [edi+8]
    bswap   eax
    mov     [maxpOffset], eax
    jmp     .next_tbl
.set_loca:
    mov     eax, [edi+8]
    bswap   eax
    mov     [locaOffset], eax
    jmp     .next_tbl
.set_glyf:
    mov     eax, [edi+8]
    bswap   eax
    mov     [glyfOffset], eax
.next_tbl:
    add     edi, 16
    inc     ebx
    jmp     .scan_tables
.tables_ready:
    mov     esi, [pMap]
    add     esi, [headOffset]
    add     esi, 50
    movzx   eax, word [esi]
    xchg    al, ah
    mov     [indexToLocFormat], eax

    mov     esi, [pMap]
    add     esi, [maxpOffset]
    add     esi, 4
    movzx   eax, word [esi]
    xchg    al, ah
    mov     [numGlyphs], eax

    mov     esi, [pMap]
    add     esi, [locaOffset]
    mov     [locaPtr], esi

    mov     esi, [pMap]
    add     esi, [glyfOffset]
    mov     [glyfPtr], esi

    mov     esi, [locaPtr]
    cmp     [indexToLocFormat], 0
    jne     .loca_long
    movzx   eax, word [esi]
    xchg    al, ah
    shl     eax, 1
    mov     [glyphStart], eax
    add     esi, 2
    movzx   ebx, word [esi]
    xchg    bl, bh
    shl     ebx, 1
    mov     [glyphEnd], ebx
    jmp     .read_glyph
.loca_long:
    mov     eax, [esi]
    bswap   eax
    mov     [glyphStart], eax
    add     esi, 4
    mov     ebx, [esi]
    bswap   ebx
    mov     [glyphEnd], ebx
.read_glyph:
    mov     eax, [glyphEnd]
    sub     eax, [glyphStart]
    mov     [glyphLength], eax
    test    eax, eax
    jle     .print_result

    mov     esi, [glyfPtr]
    add     esi, [glyphStart]
    movzx   eax, word [esi]
    xchg    al, ah
    mov     [numContours], eax
    add     esi, 2
    movzx   ebx, word [esi]
    xchg    bl, bh
    mov     [xMin], ebx
    add     esi, 2
    movzx   ebx, word [esi]
    xchg    bl, bh
    mov     [yMin], ebx
    add     esi, 2
    movzx   ebx, word [esi]
    xchg    bl, bh
    mov     [xMax], ebx
    add     esi, 2
    movzx   ebx, word [esi]
    xchg    bl, bh
    mov     [yMax], ebx
.print_result:
    cinvoke printf, fmtGlyph, [numContours], [xMin], [yMin], [xMax], [yMax], [glyphLength]
    invoke  UnmapViewOfFile, [pMap]
    invoke  CloseHandle, [hMap]
    invoke  CloseHandle, [hFile]
    jmp .exit
.exit_error:
    cinvoke puts, 'error'
.exit:
    ret
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            user32,             'user32.dll',\
            msvcrt,             'msvcrt.dll'
    import  kernel32,\
            CreateFile,         'CreateFileA',\
            GetFileSize,        'GetFileSize',\
            CreateFileMapping,  'CreateFileMappingA',\
            MapViewOfFile,      'MapViewOfFile',\
            UnmapViewOfFile,    'UnmapViewOfFile',\
            CloseHandle,        'CloseHandle',\
            GetStdHandle,       'GetStdHandle',\
            WriteConsoleA,      'WriteConsoleA',\
            ExitProcess,        'ExitProcess'
    import  user32,\
            wsprintfA,          'wsprintfA'
    import  msvcrt,\
            printf,             'printf',\
            puts,               'puts'
