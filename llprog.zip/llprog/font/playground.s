format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt_d    db '%d', 10, 0

section '.text' code readable executable
start:
    stdcall test1
    invoke ExitProcess, 0

proc test1
    stdcall .func, 21   ; 3
    stdcall .func, 22   ; 2
    stdcall .func, 23   ; 1
    stdcall .func, 24   ; 0
    stdcall .func, 25   ; 3
    stdcall .func, 26   ; 2
    stdcall .func, 27   ; 1
    stdcall .func, 28   ; 0
    ret
endp

proc .func, len
ALIGNMENT_SIZE      equ 4
ALIGNMENT_MASK      equ 3

    mov eax, [len]
    and eax, ALIGNMENT_MASK
    mov ecx, ALIGNMENT_SIZE
    sub ecx, eax
    and ecx, ALIGNMENT_MASK

    cinvoke printf, fmt_d, ecx
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
