format PE GUI 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    _class db 'FASMPlayer', 0
    _title db 'FASM MP3 Player', 0
    _btnPlay db 'BUTTON', 0
    _btnStop db 'BUTTON', 0
    _txtPlay db 'Play', 0
    _txtStop db 'Stop', 0

    mciOpen db 'open "music.mp3" type mpegvideo alias mymusic', 0
    mciPlay db 'play mymusic from 0', 0
    mciStop db 'stop mymusic', 0
    mciClose db 'close mymusic', 0

    hwnd dd ?
    inst dd ?
    msg MSG

section '.code' code readable executable
start:
    invoke GetModuleHandle, 0
    mov [inst], eax

    sub esp, sizeof.WNDCLASS
    mov edi, esp
    mov [edi+WNDCLASS.style], 0
    mov [edi+WNDCLASS.lpfnWndProc], window_proc
    mov [edi+WNDCLASS.cbClsExtra], 0
    mov [edi+WNDCLASS.cbWndExtra], 0
    mov eax, [inst]
    mov [edi+WNDCLASS.hInstance], eax
    invoke LoadIcon, 0, IDI_APPLICATION
    mov [edi+WNDCLASS.hIcon], eax
    invoke LoadCursor, 0, IDC_ARROW
    mov [edi+WNDCLASS.hCursor], eax
    mov [edi+WNDCLASS.hbrBackground], COLOR_BTNFACE + 1
    mov [edi+WNDCLASS.lpszMenuName], 0
    mov [edi+WNDCLASS.lpszClassName], _class
    invoke RegisterClass, edi
    add esp, sizeof.WNDCLASS

    invoke CreateWindowEx, 0, _class, _title, WS_VISIBLE + WS_SYSMENU,\
        100, 100, 300, 120, NULL, NULL, [inst], NULL
    mov [hwnd], eax

    invoke mciSendString, mciOpen, 0, 0, 0

msg_loop:
    invoke GetMessage, msg, NULL, 0, 0
    or eax, eax
    jz end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp msg_loop

end_loop:
    invoke ExitProcess, [msg.wParam]

proc window_proc hwnd, wmsg, wparam, lparam
    push ebx esi edi
    cmp [wmsg], WM_DESTROY
    je .on_destroy
    cmp [wmsg], WM_COMMAND
    je .on_command
    cmp [wmsg], WM_CREATE
    je .on_create

.default:
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    jmp .finish

.on_create:
    invoke CreateWindowEx, 0, _btnPlay, _txtPlay, WS_VISIBLE + WS_CHILD + BS_PUSHBUTTON,\
        20, 20, 100, 30, [hwnd], 101, [inst], NULL
    invoke CreateWindowEx, 0, _btnStop, _txtStop, WS_VISIBLE + WS_CHILD + BS_PUSHBUTTON,\
        140, 20, 100, 30, [hwnd], 102, [inst], NULL
    xor eax, eax
    jmp .finish

.on_command:
    mov eax, [wparam]
    cmp ax, 101
    je .play
    cmp ax, 102
    je .stop
    jmp .finish
.play:
    invoke mciSendString, mciPlay, 0, 0, 0
    jmp .finish
.stop:
    invoke mciSendString, mciStop, 0, 0, 0
    jmp .finish

.on_destroy:
    invoke mciSendString, mciClose, 0, 0, 0
    invoke PostQuitMessage, 0
    xor eax, eax

.finish:
    pop edi esi ebx
    ret
endp

section '.idata' import data readable writeable
    library kernel32,               'KERNEL32.DLL',\
            user32,                 'USER32.DLL',\
            winmm,                  'WINMM.DLL'
    import  kernel32,\
            GetModuleHandle,        'GetModuleHandleA',\
            ExitProcess,            'ExitProcess'
    import  user32,\
            RegisterClass,          'RegisterClassA',\
            CreateWindowEx,         'CreateWindowExA',\
            DefWindowProc,          'DefWindowProcA',\
            GetMessage,             'GetMessageA',\
            TranslateMessage,       'TranslateMessage',\
            DispatchMessage,        'DispatchMessageA',\
            LoadIcon,               'LoadIconA',\
            LoadCursor,             'LoadCursorA',\
            PostQuitMessage,        'PostQuitMessage'
    import winmm,\
            mciSendString,          'mciSendStringA'
