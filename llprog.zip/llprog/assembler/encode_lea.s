format PE console
entry start

include 'win32a.inc'

REG_EAX         = 0
REG_ECX         = 1
REG_EDX         = 2
REG_EBX         = 3
REG_ESP         = 4
REG_EBP         = 5
REG_ESI         = 6
REG_EDI         = 7
REG_NONE        = -1

SCALE_1         = 0
SCALE_2         = 1
SCALE_4         = 2
SCALE_8         = 3

OP_LEA          = 8Dh
MOD_NO_DISP     = 00h
MOD_DISP8       = 40h
MOD_DISP32      = 80h

RM_SIB          = 4
RM_DISP32_ONLY  = 5

DISP8_MIN       = -128
DISP8_MAX       = 127

SHIFT_REG       = 3
SHIFT_SCALE     = 6

section '.data' data readable writeable

    fmt_hex     db '%02X ', 0
    fmt_nl      db 10, 0
    fmt_str     db '%s', 10, 0

    msg_t1      db 'LEA EAX, [EBX + 0x10]', 0
    msg_t2      db 'LEA ECX, [ESI + EDI*4 + 0x12345678]', 0
    msg_t3      db 'LEA EDX, [0x11223344]', 0
    msg_t4      db 'LEA EBX, [EBP]', 0
    msg_t5      db 'LEA EAX, [EAX*8]', 0
    msg_t6      db 'LEA EDI, [ESP + 8]', 0

    buf         rb 16

section '.text' code readable executable

start:
    cinvoke printf, fmt_str, msg_t1
    invoke encode_lea, buf, REG_EAX, SCALE_1, REG_NONE, REG_EBX, 10h
    stdcall print_hex, buf, eax

    cinvoke printf, fmt_str, msg_t2
    invoke encode_lea, buf, REG_ECX, SCALE_4, REG_EDI, REG_ESI, 12345678h
    stdcall print_hex, buf, eax

    cinvoke printf, fmt_str, msg_t3
    invoke encode_lea, buf, REG_EDX, SCALE_1, REG_NONE, REG_NONE, 11223344h
    stdcall print_hex, buf, eax

    cinvoke printf, fmt_str, msg_t4
    invoke encode_lea, buf, REG_EBX, SCALE_1, REG_NONE, REG_EBP, 0
    stdcall print_hex, buf, eax

    cinvoke printf, fmt_str, msg_t5
    invoke encode_lea, buf, REG_EAX, SCALE_8, REG_EAX, REG_NONE, 0
    stdcall print_hex, buf, eax

    cinvoke printf, fmt_str, msg_t6
    invoke encode_lea, buf, REG_EDI, SCALE_1, REG_NONE, REG_ESP, 8
    stdcall print_hex, buf, eax

    invoke ExitProcess, 0

proc encode_lea uses ebx edi, buffer, dst, scale, idx, base, disp
    mov edi, [buffer]
    mov al, OP_LEA
    stosb

    mov ebx, [dst]
    shl ebx, SHIFT_REG

    mov ecx, [base]
    mov edx, [idx]

    cmp edx, REG_NONE
    jne .need_sib
    cmp ecx, REG_ESP
    je .need_sib

    cmp ecx, REG_NONE
    jne .has_base_no_sib
    mov al, MOD_NO_DISP
    or al, RM_DISP32_ONLY
    or al, bl
    stosb
    mov eax, [disp]
    stosd
    jmp .done

.has_base_no_sib:
    mov eax, [disp]
    cmp eax, 0
    jne .check_disp8_no_sib
    cmp ecx, REG_EBP
    je .check_disp8_no_sib

    mov al, MOD_NO_DISP
    or al, cl
    or al, bl
    stosb
    jmp .done

.check_disp8_no_sib:
    cmp eax, DISP8_MIN
    jl .disp32_no_sib
    cmp eax, DISP8_MAX
    jg .disp32_no_sib

    mov al, MOD_DISP8
    or al, cl
    or al, bl
    stosb
    mov eax, [disp]
    stosb
    jmp .done

.disp32_no_sib:
    mov al, MOD_DISP32
    or al, cl
    or al, bl
    stosb
    mov eax, [disp]
    stosd
    jmp .done

.need_sib:
    mov al, RM_SIB
    or al, bl
    push eax

    mov eax, [scale]
    shl eax, SHIFT_SCALE
    cmp edx, REG_NONE
    jne .sib_index_ok
    mov edx, REG_ESP
.sib_index_ok:
    shl edx, SHIFT_REG
    or eax, edx

    cmp ecx, REG_NONE
    jne .sib_base_ok
    mov ecx, REG_EBP
.sib_base_ok:
    or eax, ecx
    mov cl, al
    pop eax

    cmp dword [base], REG_NONE
    jne .has_base_sib

    stosb
    mov al, cl
    stosb
    mov eax, [disp]
    stosd
    jmp .done

.has_base_sib:
    mov edx, [disp]
    cmp edx, 0
    jne .check_disp8_sib
    cmp dword [base], REG_EBP
    je .check_disp8_sib

    stosb
    mov al, cl
    stosb
    jmp .done

.check_disp8_sib:
    cmp edx, DISP8_MIN
    jl .disp32_sib
    cmp edx, DISP8_MAX
    jg .disp32_sib

    or al, MOD_DISP8
    stosb
    mov al, cl
    stosb
    mov eax, [disp]
    stosb
    jmp .done

.disp32_sib:
    or al, MOD_DISP32
    stosb
    mov al, cl
    stosb
    mov eax, [disp]
    stosd
    jmp .done

.done:
    mov eax, edi
    sub eax, [buffer]
    ret
endp

proc print_hex uses ebx esi pbuf, len
    mov esi, [pbuf]
    mov ebx, [len]
.loop:
    movzx eax, byte [esi]
    cinvoke printf, fmt_hex, eax
    inc esi
    dec ebx
    jnz .loop
    cinvoke printf, fmt_nl
    ret
endp

section '.idata' import data readable

    library msvcrt, 'MSVCRT.DLL', \
        kernel32, 'KERNEL32.DLL'

    import msvcrt, \
        printf, 'printf'

    import kernel32, \
        ExitProcess, 'ExitProcess'
