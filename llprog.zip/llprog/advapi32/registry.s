format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    subkey      db 'SOFTWARE\Microsoft\Windows\CurrentVersion', 0
    hKey        dd ?
    fmt_d       db '%d', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    cinvoke puts, '*** main1 ***'
    invoke RegOpenKeyEx, HKEY_LOCAL_MACHINE, subkey, 0, KEY_READ, hKey
    cinvoke printf, fmt_d, eax
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    invoke RegOpenKeyEx, HKEY_LOCAL_MACHINE, subkey, 0, KEY_READ, hKey
    test eax, eax
    jnz .not_found
.found:
    invoke RegCloseKey, [hKey]
    cinvoke puts, 'found'
    jmp .exit
.not_found:
    cinvoke puts, 'not found'
.exit:
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            advapi32,       'advapi32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  advapi32,\
            RegOpenKeyEx,   'RegOpenKeyExA',\
            RegCloseKey,    'RegCloseKey'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
