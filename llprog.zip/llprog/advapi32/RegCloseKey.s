format PE
entry start

include 'win32ax.inc'

ERROR_SUCCESS   = 0
LANG_ENGLISH_US = 0x0409

section '.data' data readable writeable
    fmt_success     db 'Success: %x', 10, 0
    fmt_err         db "Error %u (0x%X): '%s'", 10, 0
    buffer          rb 256
    fmt_d           db '%d', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc RegCloseKey_func hKey
    invoke  RegCloseKey, [hKey]
    push    eax
    test    eax, eax
    jnz     .error
    cinvoke printf, fmt_success, eax
    jmp     .done
.error:
    invoke  FormatMessage,\
            FORMAT_MESSAGE_FROM_SYSTEM + FORMAT_MESSAGE_MAX_WIDTH_MASK,\
            0, eax, LANG_ENGLISH_US, buffer, 256, 0
    pop     eax
    cinvoke printf, fmt_err, eax, eax, buffer
.done:
    ret
endp

; -------------------------------------------
; Error 6 (0x6): 'The handle is invalid. '
; -------------------------------------------
proc main
    cinvoke puts, '*** main1 ***'
    stdcall RegCloseKey_func, -1
    stdcall RegCloseKey_func, 0
    stdcall RegCloseKey_func, 123
    ret
endp

; -------------------------------------------
; Error 6 (0x6): 'The handle is invalid. '
; -------------------------------------------
proc main10
    cinvoke puts, '*** main10 ***'
    stdcall RegCloseKey_func, -1
    stdcall RegCloseKey_func, 0
    stdcall RegCloseKey_func, 123
    ret
endp

section '.idata' import data readable
    library kernel32,               'kernel32.dll',\
            msvcrt,                 'msvcrt.dll',\
            advapi32,               'advapi32.dll'
    import  kernel32,\
            FormatMessage,          'FormatMessageA',\
            ExitProcess,            'ExitProcess'
    import  msvcrt,\
            printf,                 'printf',\
            puts,                   'puts'
    import  advapi32,\
            RegCreateKeyEx,         'RegCreateKeyEx',\
            RegCreateKeyTransacted, 'RegCreateKeyTransacted',\
            RegOpenKeyEx,           'RegOpenKeyEx',\
            RegOpenKeyTransacted,   'RegOpenKeyTransacted',\
            RegConnectRegistry,     'RegConnectRegistry',\
            RegCloseKey,            'RegCloseKey'
