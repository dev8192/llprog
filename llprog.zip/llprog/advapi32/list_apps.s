; HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall
; HKEY_LOCAL_MACHINE\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall
; HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Uninstall

format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    subkey_path db 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall', 0
    hKey        dd ?
    dwIndex     dd 0
    name_buf    db 256 dup(0)
    name_size   dd 256
    caption     db 'Installed Programs (Internal Names)', 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    cinvoke puts, '*** main1 ***'
    invoke  RegOpenKeyEx, HKEY_LOCAL_MACHINE, subkey_path, 0,\
            KEY_ENUMERATE_SUB_KEYS or KEY_QUERY_VALUE, hKey
    test eax, eax
    jnz .exit
.enum_loop:
    mov [name_size], 256
    invoke RegEnumKeyEx, [hKey], [dwIndex], name_buf, name_size, 0, 0, 0, 0
    test eax, eax
    jnz .done
    cinvoke printf, fmt_ds, [dwIndex], name_buf
    inc [dwIndex]
    cmp [dwIndex], 20
    jb .enum_loop
.done:
    invoke RegCloseKey, [hKey]
.exit:
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll',\
            advapi32,       'advapi32.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess',\
            lstrcat,        'lstrcatA'
    import  msvcrt,\
            printf,         'printf'
    import  advapi32,\
            RegOpenKeyEx,   'RegOpenKeyExA',\
            RegEnumKeyEx,   'RegEnumKeyExA',\
            RegCloseKey,    'RegCloseKey'
