format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    path        db 'HARDWARE\DESCRIPTION\System\CentralProcessor\0', 0
    val_name    db 'ProcessorNameString', 0
    
    hKey        dd ?
    type        dd ?
    data_size   dd 256
    buffer      db 256 dup(0)
    fmt_s       db '%s', 10, 0
    error_str   db 'Could not read registry.', 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    invoke RegOpenKeyEx, HKEY_LOCAL_MACHINE, path, 0, KEY_READ, hKey
    test eax, eax
    jnz .error
    invoke RegQueryValueEx, [hKey], val_name, 0, type, buffer, data_size
    test eax, eax
    jnz .close_and_error
    cinvoke printf, fmt_s, buffer
    jmp .cleanup
.close_and_error:
    invoke RegCloseKey, [hKey]
.error:
    cinvoke puts, error_str
    ret
.cleanup:
    invoke RegCloseKey, [hKey]
    ret
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            msvcrt,             'msvcrt.dll',\
            advapi32,           'advapi32.dll'
    import  kernel32,\
            ExitProcess,        'ExitProcess'
    import  msvcrt,\
            printf,             'printf',\
            puts,               'puts'
    import  advapi32,\
            RegOpenKeyEx,       'RegOpenKeyExA',\
            RegQueryValueEx,    'RegQueryValueExA',\
            RegCloseKey,        'RegCloseKey'
