format PE GUI 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    main_path   db 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall', 0
    display_val db 'DisplayName', 0
    
    hMainKey    dd ?
    hSubKey     dd ?
    dwIndex     dd 0
    
    subkey_name db 256 dup(0)
    name_len    dd 256
    display_buf db 256 dup(0)
    display_len dd 256
    
    final_list  db 8192 dup(0)
    caption     db 'Installed Programs', 0

section '.code' code readable executable
  start:
    ; Open the master Uninstall key
    invoke RegOpenKeyEx, HKEY_LOCAL_MACHINE, main_path, 0, KEY_READ, hMainKey
    test eax, eax
    jnz .exit

  .loop_apps:
    mov [name_len], 256
    invoke RegEnumKeyEx, [hMainKey], [dwIndex], subkey_name, name_len, 0, 0, 0, 0
    test eax, eax
    jnz .done  ; ERROR_NO_MORE_ITEMS or other error

    ; Open the specific app's subkey
    invoke RegOpenKeyEx, [hMainKey], subkey_name, 0, KEY_READ, hSubKey
    test eax, eax
    jnz .next_app

    ; Query the "DisplayName" string
    mov [display_len], 256
    invoke RegQueryValueEx, [hSubKey], display_val, 0, 0, display_buf, display_len
    test eax, eax
    jnz .close_subkey

    ; Add the found name to our final list
    cinvoke lstrcat, final_list, display_buf
    cinvoke lstrcat, final_list, <13, 10, 0>

  .close_subkey:
    invoke RegCloseKey, [hSubKey]

  .next_app:
    inc [dwIndex]
    jmp .loop_apps

  .done:
    invoke RegCloseKey, [hMainKey]
    invoke MessageBox, 0, final_list, caption, MB_OK

  .exit:
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32,'kernel32.dll',user32,'user32.dll',advapi32,'advapi32.dll'
    import kernel32, ExitProcess,'ExitProcess', lstrcat,'lstrcatA'
    import user32,   MessageBox,'MessageBoxA'
    import advapi32, RegOpenKeyEx,'RegOpenKeyExA', RegEnumKeyEx,'RegEnumKeyExA', \
                     RegQueryValueEx,'RegQueryValueExA', RegCloseKey,'RegCloseKey'
