format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt_max db 'Max: %u', 10, 0
    fmt_min db 'Min: %u', 10, 0
    fmt_log db '%u', 10, 0
    array dd 5, 34, 2, 58, 6, 58, 2
    array_len = ($ - array) / 4

section '.text' code readable executable
start:
    stdcall test20
    invoke ExitProcess, 0

proc test10
    stdcall FindMax
    cinvoke printf, fmt_max, eax
    stdcall FindMin
    cinvoke printf, fmt_min, eax
    ret
endp

proc test20
    local min:DWORD, max:DWORD
    stdcall MinMax, addr min, addr max
    cinvoke printf, fmt_max, [min]
    stdcall FindMin
    cinvoke printf, fmt_min, [max]
    ret
endp

proc MinMax uses ebx esi edi, min, max
    mov esi, dword [array]
    mov edi, dword [array]
    cinvoke printf, fmt_log, esi
    mov ebx, 1
@@:
    cmp ebx, array_len
    jge .finish
    cmp dword [array + ebx * 4], esi
    jg .update_min
    cmp dword [array + ebx * 4], edi
    jl .update_max
    jmp .continue
.update_min:
    mov esi, dword [array + ebx * 4]
    cinvoke printf, fmt_log, esi
    jmp .continue
.update_max:
    mov edi, dword [array + ebx * 4]
    cinvoke printf, fmt_log, esi
.continue:
    inc ebx
    jmp @b
.finish:
    mov [min], esi
    mov [max], edi
    ret
endp

proc FindMax uses ebx esi
    mov esi, dword [array]
    cinvoke printf, fmt_log, esi
    mov ebx, 1
@@:
    cmp ebx, array_len
    jge .finish
    cmp dword [array + ebx * 4], esi
    jle .skip
    mov esi, dword [array + ebx * 4]
    cinvoke printf, fmt_log, esi
.skip:
    inc ebx
    jmp @b
.finish:
    mov eax, esi
    ret
endp

proc FindMin uses ebx esi
    mov esi, dword [array]
    cinvoke printf, fmt_log, esi
    mov ebx, 1
@@:
    cmp ebx, array_len
    jge .finish
    cmp dword [array + ebx * 4], esi
    jge .skip
    mov esi, dword [array + ebx * 4]
    cinvoke printf, fmt_log, esi
.skip:
    inc ebx
    jmp @b
.finish:
    mov eax, esi
    ret
endp

section '.idata' import data readable writeable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            GetTickCount,   'GetTickCount',\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            srand,          'srand',\
            rand,           'rand',\
            printf,         'printf'
