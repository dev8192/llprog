format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_d       db '%d', 10, 0
    fmt_3x      db '%08x %08x %08x', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    stdcall test_min, min_signed_v1, min_unsigned_v1
    ret
endp

proc test_min, min_signed, min_unsigned
    local n1:DWORD, n2:DWORD, n3:DWORD
    cinvoke puts, '*** main1 ***'

    invoke min_signed, 5, 7, addr n1
    invoke min_signed, 0x7FFFFFFF, 0x7FFFFFFE, addr n2
    invoke min_signed, 0x7FFFFFFF, 0x80000000, addr n3
    cinvoke printf, fmt_3x, [n1], [n2], [n3]

    invoke min_unsigned, 5, 7, addr n1
    invoke min_unsigned, 0x7FFFFFFF, 0x7FFFFFFE, addr n2
    invoke min_unsigned, 0x7FFFFFFF, 0x80000000, addr n3
    cinvoke printf, fmt_3x, [n1], [n2], [n3]
    
    ret
endp

proc min_signed_v1, num1, num2, res
    mov eax, [num1]
    mov ecx, [num2]
    cmp eax, ecx
    cmovg eax, ecx   ; If eax > ecx (signed), move ecx into eax
    mov ecx, [res]
    mov [ecx], eax
    ret
endp

proc min_unsigned_v1, num1, num2, res
    mov eax, [num1]
    mov ecx, [num2]
    cmp eax, ecx
    cmova eax, ecx
    mov ecx, [res]
    mov [ecx], eax
    ret
endp

proc .min2, num1, num2
    mov eax, [num1]
    mov ecx, [num2]
    sub eax, ecx
    sbb edx, edx     ; edx = -1 if eax < ecx, else 0
    and eax, edx     ; eax = (eax-ecx) if eax < ecx, else 0
    add eax, ecx     ; eax = max(eax, ecx)
    cinvoke printf, fmt_d, eax
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
