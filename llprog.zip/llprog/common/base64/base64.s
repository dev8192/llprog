format PE console
entry start

include 'win32a.inc'

CRYPT_STRING_BASE64 = 1

section '.data' data readable writeable
    orig_bytes db 'hello', 0, 'world'
    orig_size  = $ - orig_bytes

    pszString    rb 256
    b64_size   dd 256

    pbBinary    rb 256
    pcbBinary   dd 256

    fmt    db '%s', 0

section '.text' code readable executable
start:
    invoke CryptBinaryToString, orig_bytes, orig_size,\
        CRYPT_STRING_BASE64, pszString, b64_size
    cinvoke printf, fmt, pszString

    invoke CryptStringToBinary, pszString, 0,\
        CRYPT_STRING_BASE64, pbBinary, pcbBinary, 0, 0
    cinvoke printf, fmt, pbBinary

    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
        crypt32, 'crypt32.dll',\
        msvcrt, 'msvcrt.dll'

    import kernel32,\
        ExitProcess, 'ExitProcess'

    import crypt32,\
        CryptBinaryToString, 'CryptBinaryToStringA',\
        CryptStringToBinary, 'CryptStringToBinaryA'

    import msvcrt,\
        printf, 'printf'
