
function bytesToBase64(bytes) {
    const binString = Array.from(bytes, (byte) => String.fromCodePoint(byte)).join("")
    console.log(binString)
    return btoa(binString)
}

function base64ToBytes(base64) {
    const binString = atob(base64)
    return Uint8Array.from(binString, (char) => char.codePointAt(0))
}

// "hello\x00world".split('').map(ch => ch.charCodeAt())

const originalBytes = new Uint8Array([
    104, 101, 108, 108, 
    111,   0, 119, 111,
    114, 108, 100
])
const base64Str = bytesToBase64(originalBytes)
const decodedBytes = base64ToBytes(base64Str)

console.log("Base64:", base64Str) // "aGVsbG8Ad29ybGQ="
console.log("Decoded Bytes:", decodedBytes)
