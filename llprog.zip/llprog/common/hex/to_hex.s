format PE console
entry start

include 'win32a.inc'

CRYPT_STRING_HEX = 4
CRYPT_STRING_HEXRAW = 12
CRYPT_STRING_HEXADDR = 0x0000000a
CRYPT_STRING_HEXASCIIADDR = 0x0000000b
CRYPT_STRING_NOCRLF = 0x40000000

; 68656c6c6f00776f726c64
; h e l l o 0 w o r l d
; 68 65 6c 6c 6f 00 77 6f  72 6c 64
section '.data' data readable writeable
    ;pbBinary db 'hello', 0, 'world'
    pbBinary db 'hello world'
    cbBinary  = $ - pbBinary

    pszString  rb 256
    pcchString dd 256

    fmt1  db '"%s"', 10, 0
    fmt2  db '%u', 10, 0
    fmt3  db '%x', 10, 0

section '.text' code readable executable
start:
    ;dwFlags = CRYPT_STRING_HEX
    ;dwFlags = CRYPT_STRING_HEXRAW
    ;dwFlags = CRYPT_STRING_HEX or CRYPT_STRING_NOCRLF
    ;dwFlags = CRYPT_STRING_HEXRAW or CRYPT_STRING_NOCRLF
    dwFlags = CRYPT_STRING_HEXASCIIADDR

    invoke CryptBinaryToString, pbBinary, cbBinary,\
        dwFlags, pszString, pcchString
    cinvoke printf, fmt1, pszString
    cinvoke printf, fmt2, [pcchString]
    cinvoke printf, fmt2, cbBinary
    movzx   eax, [pszString + 24]
    cinvoke printf, fmt3, eax

    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
        crypt32, 'crypt32.dll',\
        msvcrt, 'msvcrt.dll'
    import kernel32,\
        ExitProcess, 'ExitProcess'
    import crypt32,\
        CryptBinaryToString, 'CryptBinaryToStringA'
    import msvcrt,\
        printf, 'printf'
