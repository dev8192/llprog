format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    str1        db 'abc123', 10, 0
    str1_len    = $ - str1
    fmt_hex     db '%02X ', 0
    fmt_nl      db 10, 0

section '.text' code readable executable
start:
    stdcall print_hex, str1, str1_len
    invoke ExitProcess, 0

proc print_hex uses ebx esi, buf, len
    mov esi, [buf]
    mov ebx, [len]
.loop:
    movzx eax, byte [esi]
    cinvoke printf, fmt_hex, eax
    inc esi
    dec ebx
    jnz .loop
    cinvoke printf, fmt_nl
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
