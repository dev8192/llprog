format PE console
entry start
 
include 'win32a.inc'
 
CRYPT_STRING_HEXASCIIADDR equ 0x0000000B
 
section '.rdata' data readable
    msg_stack db "--- Example 1: Stack Allocation ---", 10, 0
    msg_heap1 db 10, "--- Example 2: MSVCRT Heap Allocation ---", 10, 0
    msg_heap2 db 10, "--- Example 3: Kernel32 Heap Allocation ---", 10, 0
 
section '.text' code readable executable
start:
    stdcall main
    invoke  ExitProcess, 0

proc main
    local inputBuf[96]:BYTE
 
    lea     eax, [inputBuf]
    stdcall generate_input, eax
 
    cinvoke printf, msg_stack
    lea     eax, [inputBuf]
    stdcall example1, eax
 
    cinvoke printf, msg_heap1
    lea     eax, [inputBuf]
    stdcall example2, eax
 
    cinvoke printf, msg_heap2
    lea     eax, [inputBuf]
    stdcall example3, eax
 
    ret
endp
 
proc generate_input buffer:DWORD
    mov     edx, [buffer]
    mov     ecx, 96
    mov     al, 0x20
  .fill:
    mov     [edx], al
    inc     edx
    inc     al
    dec     ecx
    jnz     .fill
    ret
endp

proc example1 inPtr:DWORD
    local reqSize:DWORD
    local outPtr:DWORD
 
    lea     eax, [reqSize]
    invoke  CryptBinaryToStringA, [inPtr], 96, CRYPT_STRING_HEXASCIIADDR, 0, eax
 
    mov     eax, [reqSize]
    sub     esp, eax
    and     esp, -4
    mov     [outPtr], esp
 
    lea     eax, [reqSize]
    invoke  CryptBinaryToStringA, [inPtr], 96, CRYPT_STRING_HEXASCIIADDR, [outPtr], eax
 
    cinvoke printf, [outPtr]
 
    ret
endp

proc example2 inPtr:DWORD
    local reqSize:DWORD
    local outPtr:DWORD
 
    lea     eax, [reqSize]
    invoke  CryptBinaryToStringA, [inPtr], 96, CRYPT_STRING_HEXASCIIADDR, 0, eax
 
    cinvoke malloc, [reqSize]
    mov     [outPtr], eax
 
    lea     eax, [reqSize]
    invoke  CryptBinaryToStringA, [inPtr], 96, CRYPT_STRING_HEXASCIIADDR, [outPtr], eax
 
    cinvoke printf, [outPtr]
 
    cinvoke free, [outPtr]
 
    ret
endp

proc example3 inPtr:DWORD
    local reqSize:DWORD
    local outPtr:DWORD
    local hHeap:DWORD
 
    invoke  GetProcessHeap
    mov     [hHeap], eax
 
    lea     eax, [reqSize]
    invoke  CryptBinaryToStringA, [inPtr], 96, CRYPT_STRING_HEXASCIIADDR, 0, eax
 
    invoke  HeapAlloc, [hHeap], 0, [reqSize]
    mov     [outPtr], eax
 
    lea     eax, [reqSize]
    invoke  CryptBinaryToStringA, [inPtr], 96, CRYPT_STRING_HEXASCIIADDR, [outPtr], eax
 
    cinvoke printf, [outPtr]
 
    invoke  HeapFree, [hHeap], 0, [outPtr]
 
    ret
endp

section '.idata' import data readable
 
    library kernel32, 'kernel32.dll',\
            msvcrt, 'msvcrt.dll',\
            crypt32, 'crypt32.dll'
 
    import kernel32,\
           ExitProcess, 'ExitProcess',\
           GetProcessHeap, 'GetProcessHeap',\
           HeapAlloc, 'HeapAlloc',\
           HeapFree, 'HeapFree'
 
    import msvcrt,\
           printf, 'printf',\
           malloc, 'malloc',\
           free, 'free'
 
    import crypt32,\
           CryptBinaryToStringA, 'CryptBinaryToStringA'
