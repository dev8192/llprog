format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    str1    db 'abcd1234', 10, 0
    fmt_num db '%d', 10, 0

section '.text' code readable executable
start:
    stdcall test10
    invoke ExitProcess, 0
    
proc test10
    invoke lstrlen, str1
    cinvoke printf, fmt_num, eax
    cinvoke strlen, str1
    cinvoke printf, fmt_num, eax
    stdcall strlen_custom, str1
    cinvoke printf, fmt_num, eax
    ret
endp

proc strlen_custom uses ebx, str_ptr
    mov     ebx, [str_ptr]
.len_loop:
    cmp     byte [ebx], 0
    je      .len_done
    inc     ebx
    jmp     .len_loop
.len_done:
    sub     ebx, [str_ptr]
    mov     eax, ebx
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            lstrlen,        'lstrlenA',\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            strlen,         'strlen',\
            printf,         'printf'
