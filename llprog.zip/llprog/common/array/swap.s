format PE
entry start

include 'win32a.inc'

; 5, 10, 15, 20   swap, 0, 1
; 10, 5, 15, 20   swap, 1, 2
; 10, 15, 5, 20   swap, 2, 3
; 10, 15, 20, 5   swap, 0, 1
; 15, 10, 20, 5   swap, 1, 2
; 15, 20, 10, 5   swap, 0, 1
; 20, 15, 10, 5   done

section '.data' data readable writeable
    fmt         db 'hello', 10, 0
    swap        dd swap10
    arr1        dd 5, 10, 15, 20
    fmt_item    db '%2d ', 0
    newline     db 10, 0

section '.text' code readable executable
start:
    stdcall print_array, arr1, 4
    ;invoke swap, arr1, 0, 1
    invoke ExitProcess, 0

proc print_array uses ebx, arr, arr_sz
    mov ebx, 8
    mov ecx, [arr]
    cinvoke printf, fmt_item, [ecx + ebx]
    cinvoke printf, newline
    ret
endp

proc swap10 uses ebx, arr, idx1, idx2
    mov eax, [idx1]
    mov ebx, [idx2]
    mov ecx, [arr + eax * 4]
    mov edx, [arr + ebx * 4]
    mov [arr + eax * 4], edx
    mov [arr + ebx * 4], ecx
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
