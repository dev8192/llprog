format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt     db '%s', 10, 0

section '.text' code readable executable
start:
    stdcall print_byte, 1010_1111b
    stdcall print_byte, 1111_0101b
    invoke ExitProcess, 0

proc print_byte uses ebx esi edi, num
    local buf[9]:BYTE
    mov ebx, [num]
    lea edi, [buf]
    mov esi, 8
.bit_loop:
    shl bl, 1
    setc al
    add al, '0'
    mov [edi], al
    inc edi
    dec esi
    jnz .bit_loop
    mov byte [edi], 0
    lea eax, [buf]
    cinvoke printf, fmt, eax
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
