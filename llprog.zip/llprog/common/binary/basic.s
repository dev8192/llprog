format PE console
entry start
include 'win32ax.inc'

section '.data' readable writable
    binary_str  rb 33
    fmt_str     db '"%s"', 10, 0
    fmt_x       db '%x', 10, 0

section '.text' readable executable
start:
    stdcall print_binary, 11110000111100001111000011110000b
    stdcall print_binary, 00001111000011110000111100001111b
    invoke ExitProcess, 0

proc print_binary10, val
    mov eax, [val]
    mov edi, binary_str
    mov ecx, 32
.convert:
    shl eax, 1
    mov byte [edi], '0'
    jnc .next
    mov byte [edi], '1'
.next:
    inc edi
    loop .convert
    mov byte [edi], 0
    cinvoke printf, fmt_str, binary_str
    ret
endp

proc print_binary20 uses edi, val
    mov eax, [val]
    mov edi, binary_str
    mov ecx, 32
.convert:
    shl eax, 1
    setc dl
    add dl, '0'
    mov [edi], dl
    inc edi
    loop .convert
    mov byte [edi], 0
    cinvoke printf, fmt_str, binary_str
    ret
endp

proc print_binary30 uses edi, val
    mov eax, [val]
    mov edi, binary_str
    mov ecx, 32
.convert:
    shl eax, 1
    mov byte [edi], '0'
    adc byte [edi], 0
    inc edi
    loop .convert
    mov byte [edi], 0
    cinvoke printf, fmt_str, binary_str
    ret
endp

proc print_binary40 uses edi, val
    mov edx, [val]
    mov edi, binary_str
    mov ecx, 32
.convert:
    shl edx, 1
    mov al, '0'
    adc al, 0
    stosb
    loop .convert
    mov byte [edi], 0
    cinvoke printf, fmt_str, binary_str
    ret
endp

proc print_binary uses edi, val
    local buf[33]:BYTE
    mov edx, [val]
    lea edi, [buf]
    mov ecx, 32
.convert:
    shl edx, 1
    mov al, '0'
    adc al, 0
    stosb
    loop .convert
    mov byte [edi], 0
    lea eax, [buf]
    cinvoke printf, fmt_str, eax
    ret
endp

section '.idata' import readable
    library msvcrt,'msvcrt.dll', kernel32,'kernel32.dll'
    import msvcrt, printf,'printf'
    import kernel32, ExitProcess,'ExitProcess'
