format PE console
entry start

include 'win32a.inc'

section '.text' code readable executable

start:
    invoke  CreateFile, str_filename, GENERIC_WRITE, 0, 0,\
        CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0
    cmp     eax, INVALID_HANDLE_VALUE
    je      .error
    mov     [hFile], eax

    mov     [high_part], 1
    invoke  SetFilePointer, [hFile], 20000000h, high_part, FILE_BEGIN

    invoke  SetEndOfFile, [hFile]

    invoke  CloseHandle, [hFile]

    cinvoke printf, str_success
    jmp     .done

.error:
    cinvoke printf, str_error

.done:
    invoke  Sleep, 2000
    invoke  ExitProcess, 0

section '.data' data readable writeable

    str_filename db 'huge_4_5_gb_file.dat', 0
    str_success  db 'Successfully created a 4.5 GB file.', 10, 0
    str_error    db 'Failed to create the file.', 10, 0

    hFile        dd ?
    high_part    dd ?

section '.idata' import data readable writeable

    library kernel32, 'KERNEL32.DLL',\
            msvcrt, 'MSVCRT.DLL'

    import kernel32,\
           CreateFile, 'CreateFileA',\
           SetFilePointer, 'SetFilePointer',\
           SetEndOfFile, 'SetEndOfFile',\
           CloseHandle, 'CloseHandle',\
           Sleep, 'Sleep',\
           ExitProcess, 'ExitProcess'

    import msvcrt,\
           printf, 'printf'
