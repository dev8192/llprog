format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    file1       db '0files/months.txt', 0
    file2       db 'c:\WINDOWS\Fonts\CONSOLA.TTF', 0
    szMode      db 'rb', 0
    fmt_u       db '%u', 10, 0

section '.text' code readable executable
start:
    stdcall test1
    invoke  ExitProcess, 0

proc test1
    stdcall get_file_size_c, file2
    stdcall get_file_size_win, file2
    ret
endp

proc get_file_size_c, path
    local   hFile:DWORD
    cinvoke fopen, [path], szMode
    test    eax, eax
    jz      .done
    mov     [hFile], eax
    cinvoke fseek, [hFile], 0, 2
    cinvoke ftell, [hFile]
    cinvoke printf, fmt_u, eax
    cinvoke fclose, [hFile]
.done:
    ret
endp

proc get_file_size_win, path
    local   hFile:DWORD
    invoke  CreateFile, [path], GENERIC_READ, FILE_SHARE_READ,\
        0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0
    cmp     eax, INVALID_HANDLE_VALUE
    je      .done
    mov     [hFile], eax
    invoke  GetFileSize, [hFile], 0
    cinvoke printf, fmt_u, eax
    invoke  CloseHandle, [hFile]
.done:
    ret
endp

section '.idata' import data readable writeable
    library kernel32,       'KERNEL32.DLL',\
            msvcrt,         'MSVCRT.DLL'
    import  kernel32,\
            CloseHandle,    'CloseHandle',\
            CreateFile,     'CreateFileA',\
            ExitProcess,    'ExitProcess',\
            GetFileSize,    'GetFileSize'
    import  msvcrt,\
            fclose,         'fclose',\
            fopen,          'fopen',\
            fseek,          'fseek',\
            ftell,          'ftell',\
            printf,         'printf'
