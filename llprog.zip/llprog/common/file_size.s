format PE Console 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    szFile      db '0files/months.txt', 0
    szMode      db 'rb', 0
    fmt         db '%u', 10, 0

    hFileCRT    dd ?
    hFileWin    dd ?

section '.text' code readable executable
example1:
    cinvoke fopen, szFile, szMode
    test    eax, eax
    jz      .done
    mov     [hFileCRT], eax
    cinvoke fseek, [hFileCRT], 0, 2
    cinvoke ftell, [hFileCRT]
    cinvoke printf, fmt, eax
    cinvoke fclose, [hFileCRT]
.done:
    ret

example2:
    invoke  CreateFile, szFile, GENERIC_READ, FILE_SHARE_READ,\
        0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0
    cmp     eax, INVALID_HANDLE_VALUE
    je      .done
    mov     [hFileWin], eax
    invoke  GetFileSize, [hFileWin], 0
    cinvoke printf, fmt, eax
    invoke  CloseHandle, [hFileWin]
.done:
    ret

start:
    call example1
    call example2
    invoke  ExitProcess, 0

section '.idata' import data readable writeable
    library kernel32,       'KERNEL32.DLL',\
            msvcrt,         'MSVCRT.DLL'
    import  kernel32,\
            CloseHandle,    'CloseHandle',\
            CreateFile,     'CreateFileA',\
            ExitProcess,    'ExitProcess',\
            GetFileSize,    'GetFileSize'
    import  msvcrt,\
            fclose,         'fclose',\
            fopen,          'fopen',\
            fseek,          'fseek',\
            ftell,          'ftell',\
            printf,         'printf'
