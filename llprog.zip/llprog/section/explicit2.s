format PE CONSOLE 4.0
entry start

; --- CODE SECTION ---
section '.text' code readable executable
start:
    ; Manually push arguments (no 'invoke' macro)
    push -11                ; STD_OUTPUT_HANDLE is -11
    call [GetStdHandle]
    mov [stdout], eax

    push 0                  ; Overlapped
    push written            ; Bytes written pointer
    push msg_len            ; Number of bytes
    push msg                ; Buffer address
    push [stdout]           ; File handle
    call [WriteFile]

    push 0                  ; Exit code
    call [ExitProcess]

; --- DATA SECTION ---
section '.data' data readable writeable
    msg      db 'No includes used here!', 10
    msg_len  = $ - msg
    stdout   dd ?
    written  dd ?

section '.idata' import data readable
    dd 0, 0, 0, rva kernel32_name, rva kernel32_table
    dd 0, 0, 0, 0, 0 ; Terminator

    kernel32_table:
        GetStdHandle dd rva _GetStdHandle
        WriteFile    dd rva _WriteFile
        ExitProcess  dd rva _ExitProcess
        dd 0

    kernel32_name db 'KERNEL32.DLL', 0

    _GetStdHandle dw 0
                  db 'GetStdHandle', 0
    _WriteFile    dw 0
                  db 'WriteFile', 0
    _ExitProcess  dw 0
                  db 'ExitProcess', 0
