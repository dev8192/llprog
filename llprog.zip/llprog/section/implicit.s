format PE64 console
include 'win64ax.inc'

.data
    msg db "Hello from implicit sections!", 0

.code
start:
    invoke  GetStdHandle, -11
    mov     rcx, rax
    invoke  WriteConsoleA, rcx, msg, 28, 0, 0
    invoke  ExitProcess, 0

.end start
