format PE console
entry start

include 'win32a.inc'

SHA512_BLOCK_SIZE equ 128
SHA512_ROUNDS equ 80
BIT_SHIFT_MULTIPLIER equ 3

macro ror64_eax_edx shift {
    if shift eq 32
        xchg eax, edx
    else if shift < 32
        mov ebx, eax
        shrd eax, edx, shift
        shrd edx, ebx, shift
    else
        mov ebx, eax
        shrd eax, edx, shift - 32
        shrd edx, ebx, shift - 32
        xchg eax, edx
    end if
}

macro shr64_eax_edx shift {
    if shift eq 32
        mov eax, edx
        xor edx, edx
    else if shift < 32
        shrd eax, edx, shift
        shr edx, shift
    else
        mov eax, edx
        shr eax, shift - 32
        xor edx, edx
    end if
}

macro copy64 dst, src {
    mov eax, [src]
    mov edx, [src+4]
    mov [dst], eax
    mov [dst+4], edx
}

macro calc_Sigma0 val_low, val_high, out_low, out_high {
    push val_high
    push val_low
    mov eax, [esp]
    mov edx, [esp+4]
    ror64_eax_edx 28
    mov esi, eax
    mov edi, edx

    mov eax, [esp]
    mov edx, [esp+4]
    ror64_eax_edx 34
    xor esi, eax
    xor edi, edx

    mov eax, [esp]
    mov edx, [esp+4]
    ror64_eax_edx 39
    xor eax, esi
    xor edx, edi

    mov out_low, eax
    mov out_high, edx
    add esp, 8
}

macro calc_Sigma1 val_low, val_high, out_low, out_high {
    push val_high
    push val_low
    mov eax, [esp]
    mov edx, [esp+4]
    ror64_eax_edx 14
    mov esi, eax
    mov edi, edx

    mov eax, [esp]
    mov edx, [esp+4]
    ror64_eax_edx 18
    xor esi, eax
    xor edi, edx

    mov eax, [esp]
    mov edx, [esp+4]
    ror64_eax_edx 41
    xor eax, esi
    xor edx, edi

    mov out_low, eax
    mov out_high, edx
    add esp, 8
}

macro calc_sigma0_small val_low, val_high, out_low, out_high {
    push val_high
    push val_low
    mov eax, [esp]
    mov edx, [esp+4]
    ror64_eax_edx 1
    mov esi, eax
    mov edi, edx

    mov eax, [esp]
    mov edx, [esp+4]
    ror64_eax_edx 8
    xor esi, eax
    xor edi, edx

    mov eax, [esp]
    mov edx, [esp+4]
    shr64_eax_edx 7
    xor eax, esi
    xor edx, edi

    mov out_low, eax
    mov out_high, edx
    add esp, 8
}

macro calc_sigma1_small val_low, val_high, out_low, out_high {
    push val_high
    push val_low
    mov eax, [esp]
    mov edx, [esp+4]
    ror64_eax_edx 19
    mov esi, eax
    mov edi, edx

    mov eax, [esp]
    mov edx, [esp+4]
    ror64_eax_edx 61
    xor esi, eax
    xor edi, edx

    mov eax, [esp]
    mov edx, [esp+4]
    shr64_eax_edx 6
    xor eax, esi
    xor edx, edi

    mov out_low, eax
    mov out_high, edx
    add esp, 8
}

section '.data' data readable writeable

    test_string db "abc", 0
    test_string_len equ 3

    output_format db "%08x%08x%08x%08x%08x%08x%08x%08x", \
        "%08x%08x%08x%08x%08x%08x%08x%08x", 10, 0

    buffer db 128 dup(0)
    buffer_len dd 0
    total_len_low dd 0
    total_len_high dd 0

    H0_low dd 0
    H0_high dd 0
    H1_low dd 0
    H1_high dd 0
    H2_low dd 0
    H2_high dd 0
    H3_low dd 0
    H3_high dd 0
    H4_low dd 0
    H4_high dd 0
    H5_low dd 0
    H5_high dd 0
    H6_low dd 0
    H6_high dd 0
    H7_low dd 0
    H7_high dd 0

    a_low dd 0
    a_high dd 0
    b_low dd 0
    b_high dd 0
    c_low dd 0
    c_high dd 0
    d_low dd 0
    d_high dd 0
    e_low dd 0
    e_high dd 0
    f_low dd 0
    f_high dd 0
    g_low dd 0
    g_high dd 0
    h_low dd 0
    h_high dd 0

    T1_low dd 0
    T1_high dd 0
    T2_low dd 0
    T2_high dd 0
    tmp_low dd 0
    tmp_high dd 0

    W_array rd 160

    K_array:
        dd 0xd728ae22, 0x428a2f98, 0x23ef65cd, 0x71374491
        dd 0xec4d3b2f, 0xb5c0fbcf, 0x8189dbbc, 0xe9b5dba5
        dd 0xf348b538, 0x3956c25b, 0xb605d019, 0x59f111f1
        dd 0xaf194f9b, 0x923f82a4, 0xda6d8118, 0xab1c5ed5
        dd 0xa3030242, 0xd807aa98, 0x45706fbe, 0x12835b01
        dd 0x4ee4b28c, 0x243185be, 0xd5ffb4e2, 0x550c7dc3
        dd 0xf27b896f, 0x72be5d74, 0x3b1696b1, 0x80deb1fe
        dd 0x25c71235, 0x9bdc06a7, 0xc19bf174, 0xcf692694
        dd 0xe49b69c1, 0x9ef14ad2, 0xefbe4786, 0x384f25e3
        dd 0x0fc19dc6, 0x8b8cd5b5, 0x240ca1cc, 0x77ac9c65
        dd 0x2de92c6f, 0x592b0275, 0x4a7484aa, 0x6ea6e483
        dd 0x5cb0a9dc, 0xbd41fbd4, 0x76f988da, 0x831153b5
        dd 0x983e5152, 0xee66dfab, 0xa831c66d, 0x2db43210
        dd 0xb00327c8, 0x98fb213f, 0xbf597fc7, 0xbeef0ee4
        dd 0xc6e00bf3, 0x3da88fc2, 0xd5a79147, 0x930aa725
        dd 0x06ca6351, 0xe003826f, 0x14292967, 0x0a0e6e70
        dd 0x27b70a85, 0x46d22ffc, 0x2e1b2138, 0x5c26c926
        dd 0x4d2c6dfc, 0x5ac42aed, 0x53380d13, 0x9d95b3df
        dd 0x650a7354, 0x8baf63de, 0x766a0abb, 0x3c77b2a8
        dd 0x81c2c92e, 0x47edaee6, 0x92722c85, 0x1482353b
        dd 0xa2bfe8a1, 0x4cf10364, 0xa81a664b, 0xbc423001
        dd 0xc24b8b70, 0xd0f89791, 0xc76c51a3, 0x0654be30
        dd 0xd192e819, 0xd6ef5218, 0xd6990624, 0x5565a910
        dd 0xf40e3585, 0x5771202a, 0x106aa070, 0x32bbd1b8
        dd 0x19a4c116, 0xb8d2d0c8, 0x1e376c08, 0x5141ab53
        dd 0x2748774c, 0xdf8eeb99, 0x34b0bcb5, 0xe19b48a8
        dd 0x391c0cb3, 0xc5c95a63, 0x4ed8aa4a, 0xe3418acb
        dd 0x5b9cca4f, 0x7763e373, 0x682e6ff3, 0xd6b2b8a3
        dd 0x748f82ee, 0x5defb2fc, 0x78a5636f, 0x43172f60
        dd 0x84c87814, 0xa1f0ab72, 0x8cc70208, 0x1a6439ec
        dd 0x90befffa, 0x23631e28, 0xa4506ceb, 0xde82bde9
        dd 0xbef9a3f7, 0xb2c67915, 0xc67178f2, 0xe372532b
        dd 0xca273ece, 0xea26619c, 0xd186b8c7, 0x21c0c207
        dd 0xeada7dd6, 0xcde0eb1e, 0xf57d4f7f, 0xee6ed178
        dd 0x06f067aa, 0x72be5c74, 0x0a637dc5, 0xa2c898a6
        dd 0x113f9804, 0xbef90dae, 0x1b710b35, 0x131c471b
        dd 0x28db77f5, 0x23047d84, 0x32caab7b, 0x40c72493
        dd 0x3c9ebe0a, 0x15c9bebc, 0x431d67c4, 0x9c100d4c
        dd 0x4cc5d4be, 0xcb3e42b6, 0x597f299c, 0xfc657e2a
        dd 0x5fcb6fab, 0x3ad6faec, 0x6c44198c, 0x4a475817

section '.text' code readable executable

start:
    invoke sha512_init
    invoke sha512_update, test_string, test_string_len
    invoke sha512_final

    cinvoke printf, output_format, \
        [H0_high], [H0_low], [H1_high], [H1_low], \
        [H2_high], [H2_low], [H3_high], [H3_low], \
        [H4_high], [H4_low], [H5_high], [H5_low], \
        [H6_high], [H6_low], [H7_high], [H7_low]

    cinvoke exit, 0

proc sha512_init
    mov [buffer_len], 0
    mov [total_len_low], 0
    mov [total_len_high], 0

    mov [H0_low], 0xf3bcc908
    mov [H0_high], 0x6a09e667
    mov [H1_low], 0x84caa73b
    mov [H1_high], 0xbb67ae85
    mov [H2_low], 0xfe94f82b
    mov [H2_high], 0x3c6ef372
    mov [H3_low], 0x5f1d36f1
    mov [H3_high], 0xa54ff53a
    mov [H4_low], 0xade682d1
    mov [H4_high], 0x510e527f
    mov [H5_low], 0x2b3e6c1f
    mov [H5_high], 0x9b05688c
    mov [H6_low], 0xfb41bd6b
    mov [H6_high], 0x1f83d9ab
    mov [H7_low], 0x137e2179
    mov [H7_high], 0x5be0cd19
    ret
endp

proc sha512_update data_ptr, data_len
    pushad
    mov esi, [data_ptr]
    mov ecx, [data_len]

    mov eax, ecx
    xor edx, edx
    add [total_len_low], eax
    adc [total_len_high], edx

    .update_loop:
    test ecx, ecx
    jz .update_done

    mov eax, [buffer_len]
    lea edi, [buffer + eax]

    mov ebx, SHA512_BLOCK_SIZE
    sub ebx, eax
    cmp ecx, ebx
    jb .copy_rest
    
    push ecx
    mov ecx, ebx
    rep movsb
    pop ecx
    sub ecx, ebx
    
    mov [buffer_len], SHA512_BLOCK_SIZE
    call sha512_transform
    mov [buffer_len], 0
    jmp .update_loop

    .copy_rest:
    rep movsb
    add [buffer_len], ecx
    
    .update_done:
    popad
    ret
endp

proc sha512_final
    pushad
    
    mov eax, [buffer_len]
    mov byte [buffer + eax], 0x80
    inc eax
    
    .fill_1:
    cmp eax, SHA512_BLOCK_SIZE
    je .check_1
    mov byte [buffer + eax], 0
    inc eax
    jmp .fill_1
    
    .check_1:
    mov eax, [buffer_len]
    cmp eax, 112
    jl .insert_len
    
    call sha512_transform
    
    mov eax, 0
    .fill_2:
    cmp eax, 112
    je .insert_len
    mov byte [buffer + eax], 0
    inc eax
    jmp .fill_2
    
    .insert_len:
    mov dword [buffer + 112], 0
    mov dword [buffer + 116], 0
    
    mov eax, [total_len_low]
    mov edx, [total_len_high]
    shld edx, eax, BIT_SHIFT_MULTIPLIER
    shl eax, BIT_SHIFT_MULTIPLIER
    bswap eax
    bswap edx
    mov dword [buffer + 120], edx
    mov dword [buffer + 124], eax
    
    call sha512_transform
    
    popad
    ret
endp

proc sha512_transform
    pushad
    
    mov esi, buffer
    mov edi, W_array
    mov ecx, 16
    .load_W:
    mov eax, [esi]
    mov edx, [esi+4]
    bswap eax
    bswap edx
    mov [edi], edx
    mov [edi+4], eax
    add esi, 8
    add edi, 8
    dec ecx
    jnz .load_W

    mov ecx, 16
    .expand_loop:
    push ecx
    
    mov eax, [esp]
    sub eax, 2
    shl eax, BIT_SHIFT_MULTIPLIER
    add eax, W_array
    calc_sigma1_small [eax], [eax+4], [T1_low], [T1_high]

    mov eax, [esp]
    sub eax, 7
    shl eax, BIT_SHIFT_MULTIPLIER
    add eax, W_array
    mov ebx, [eax]
    mov esi, [eax+4]
    add [T1_low], ebx
    adc [T1_high], esi

    mov eax, [esp]
    sub eax, 15
    shl eax, BIT_SHIFT_MULTIPLIER
    add eax, W_array
    calc_sigma0_small [eax], [eax+4], [T2_low], [T2_high]
    mov ebx, [T2_low]
    mov esi, [T2_high]
    add [T1_low], ebx
    adc [T1_high], esi

    mov eax, [esp]
    sub eax, 16
    shl eax, BIT_SHIFT_MULTIPLIER
    add eax, W_array
    mov ebx, [eax]
    mov esi, [eax+4]
    add [T1_low], ebx
    adc [T1_high], esi

    mov eax, [esp]
    shl eax, BIT_SHIFT_MULTIPLIER
    add eax, W_array
    mov ebx, [T1_low]
    mov esi, [T1_high]
    mov [eax], ebx
    mov [eax+4], esi

    pop ecx
    inc ecx
    cmp ecx, SHA512_ROUNDS
    jb .expand_loop

    copy64 a_low, H0_low
    copy64 b_low, H1_low
    copy64 c_low, H2_low
    copy64 d_low, H3_low
    copy64 e_low, H4_low
    copy64 f_low, H5_low
    copy64 g_low, H6_low
    copy64 h_low, H7_low

    xor ecx, ecx
    .compress_loop:
    push ecx

    copy64 T1_low, h_low

    calc_Sigma1 [e_low], [e_high], [tmp_low], [tmp_high]
    mov eax, [tmp_low]
    mov edx, [tmp_high]
    add [T1_low], eax
    adc [T1_high], edx

    mov eax, [e_low]
    mov edx, [e_high]
    mov ebx, [f_low]
    mov ecx, [f_high]
    and ebx, eax
    and ecx, edx
    not eax
    not edx
    mov esi, [g_low]
    mov edi, [g_high]
    and eax, esi
    and edx, edi
    xor eax, ebx
    xor edx, ecx
    add [T1_low], eax
    adc [T1_high], edx

    mov eax, [esp]
    shl eax, BIT_SHIFT_MULTIPLIER
    add eax, K_array
    mov ebx, [eax]
    mov esi, [eax+4]
    add [T1_low], ebx
    adc [T1_high], esi

    mov eax, [esp]
    shl eax, BIT_SHIFT_MULTIPLIER
    add eax, W_array
    mov ebx, [eax]
    mov esi, [eax+4]
    add [T1_low], ebx
    adc [T1_high], esi

    calc_Sigma0 [a_low], [a_high], [T2_low], [T2_high]

    mov eax, [b_low]
    mov edx, [b_high]
    mov ebx, eax
    mov ecx, edx
    xor eax, [c_low]
    xor edx, [c_high]
    and eax, [a_low]
    and edx, [a_high]
    and ebx, [c_low]
    and ecx, [c_high]
    xor eax, ebx
    xor edx, ecx
    add [T2_low], eax
    adc [T2_high], edx

    copy64 h_low, g_low
    copy64 g_low, f_low
    copy64 f_low, e_low

    mov eax, [d_low]
    mov edx, [d_high]
    add eax, [T1_low]
    adc edx, [T1_high]
    mov [e_low], eax
    mov [e_high], edx

    copy64 d_low, c_low
    copy64 c_low, b_low
    copy64 b_low, a_low

    mov eax, [T1_low]
    mov edx, [T1_high]
    add eax, [T2_low]
    adc edx, [T2_high]
    mov [a_low], eax
    mov [a_high], edx

    pop ecx
    inc ecx
    cmp ecx, SHA512_ROUNDS
    jb .compress_loop

    mov eax, [a_low]
    mov edx, [a_high]
    add [H0_low], eax
    adc [H0_high], edx

    mov eax, [b_low]
    mov edx, [b_high]
    add [H1_low], eax
    adc [H1_high], edx

    mov eax, [c_low]
    mov edx, [c_high]
    add [H2_low], eax
    adc [H2_high], edx

    mov eax, [d_low]
    mov edx, [d_high]
    add [H3_low], eax
    adc [H3_high], edx

    mov eax, [e_low]
    mov edx, [e_high]
    add [H4_low], eax
    adc [H4_high], edx

    mov eax, [f_low]
    mov edx, [f_high]
    add [H5_low], eax
    adc [H5_high], edx

    mov eax, [g_low]
    mov edx, [g_high]
    add [H6_low], eax
    adc [H6_high], edx

    mov eax, [h_low]
    mov edx, [h_high]
    add [H7_low], eax
    adc [H7_high], edx

    popad
    ret
endp

section '.idata' import data readable

    library msvcrt, 'msvcrt.dll'

    import msvcrt, \
        printf, 'printf', \
        exit, 'exit'
