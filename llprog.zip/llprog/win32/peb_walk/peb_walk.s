format PE console
entry start

include 'win32a.inc'

TEB_PEB_OFFSET = 0x30
PEB_LDR_OFFSET = 0x0C
LDR_IN_LOAD_ORDER_OFFSET = 0x0C
LDR_MOD_DLL_BASE_OFFSET = 0x18
LDR_MOD_BASE_DLL_NAME_OFFSET = 0x2C
UNICODE_STRING_BUFFER_OFFSET = 0x04

section '.data' data readable writeable
    fmtString db '0x%08X: %s', 10, 0

section '.text' code readable executable
start:
    mov eax, [fs:TEB_PEB_OFFSET]
    mov eax, [eax + PEB_LDR_OFFSET]
    lea ebx, [eax + LDR_IN_LOAD_ORDER_OFFSET]
    mov esi, [ebx]
    
walk_loop:
    mov eax, [esi + LDR_MOD_BASE_DLL_NAME_OFFSET + UNICODE_STRING_BUFFER_OFFSET]
    test eax, eax
    jz next_module
    
    mov edx, [esi + LDR_MOD_DLL_BASE_OFFSET]
    
    cinvoke printf, fmtString, eax, edx
        
next_module:
    mov esi, [esi]
    cmp esi, ebx
    jne walk_loop
    
    invoke ExitProcess, 0

section '.idata' import data readable writeable

    library msvcrt, 'msvcrt.dll', \
        kernel32, 'kernel32.dll'

    import msvcrt, \
        printf, 'printf'

    import kernel32, \
        ExitProcess, 'ExitProcess'
