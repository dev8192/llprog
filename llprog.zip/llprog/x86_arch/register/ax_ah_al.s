format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt db '%x', 10, 0

section '.text' code readable executable
func1:
    mov eax, -1
    cinvoke printf, fmt, eax

    mov eax, -1
    mov ax, 0
    cinvoke printf, fmt, eax

    mov eax, -1
    mov al, 0
    cinvoke printf, fmt, eax

    mov eax, -1
    mov ah, 0
    cinvoke printf, fmt, eax
    
    ret

func2:
    mov ebx, -1
    mov ax, 0
    movzx ebx, ax
    cinvoke printf, fmt, ebx
    
    mov ebx, -1
    mov al, 0
    movzx ebx, al
    cinvoke printf, fmt, ebx

    mov ebx, -1
    mov ah, 0
    movzx ebx, ah
    cinvoke printf, fmt, ebx

    ret

func3:
    mov ebx, -1
    cinvoke printf, fmt, ebx
    ;mov ax, 0
    ;mov ebx, ax
    mov ebx, fs
    cinvoke printf, fmt, ebx
    ret

start:
    call func3
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
