; -------------------------
; A proper way to print esp
; -------------------------
format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt     db "%x", 10, 0
    fmt2     db "%x", 10, 0

section '.text' code readable executable
func1:
    cinvoke printf, fmt, esp
    ret

func2:
    mov eax, esp
    cinvoke printf, fmt, eax
    ret

func3:
    cinvoke printf, fmt2, esp, 0
    ret

func4:
    mov eax, esp
    cinvoke printf, fmt2, eax, 0
    ret

start:
    call func1 ; dff78
    call func2 ; dff78
    call func3 ; dff70  oops
    call func4 ; dff78
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
