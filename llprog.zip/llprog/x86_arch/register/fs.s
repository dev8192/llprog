format PE console
entry start

include 'win32a.inc'

section '.data' data readable writable
    fmt db '0x%X', 10, 0

section '.text' code readable executable
func1:
    mov eax, fs                 ; 0x53
    cinvoke printf, fmt, eax
    mov eax, [fs:0]             ; 0xDFFCC
    cinvoke printf, fmt, eax
    ret

func2:

    ret

start:
    call func1
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll', \
            msvcrt, 'msvcrt.dll'

    import kernel32, \
           ExitProcess, 'ExitProcess'

    import msvcrt, \
           printf, 'printf'
