format PE Console 4.0
entry start

include 'win32a.inc'

SELECTOR_SIZE              = 8
PAGE_GRANULARITY_SHIFT     = 12
PAGE_GRANULARITY_MASK      = 0xFFF
BASE_MID_SHIFT             = 16
BASE_HI_SHIFT              = 24
LIMIT_HI_SHIFT             = 16
LDT_FLAGS1_DPL_SHIFT       = 5
LDT_FLAGS1_DPL_MASK        = 3
LDT_FLAGS1_S_BIT           = 0x10
LDT_FLAGS1_CODE_BIT        = 0x08
LDT_FLAGS2_LIMIT_HI_MASK   = 0x0F
LDT_FLAGS2_GRANULARITY_BIT = 0x80

struct LDT_ENTRY
    LimitLow dw ?
    BaseLow  dw ?
    BaseMid  db ?
    Flags1   db ?
    Flags2   db ?
    BaseHi   db ?
ends

struct GDTR_REG
    Limit dw ?
    Base  dd ?
ends

section '.data' data readable writeable
    gdtr            GDTR_REG
    ldt_entry       LDT_ENTRY
    hThread         dd ?
    current_sel     dd 0
    desc_base       dd 0
    desc_limit      dd 0
    desc_dpl        dd 0
    desc_type       dd 0

    str_hdr         db 'GDTR Base: %08X, Limit: %04X', 10, 10, 0
    str_fmt         db 'Sel: %04X | Base: %08X | Limit: %08X | DPL: %d | Type: %s', 10, 0
    str_code        db 'Code', 0
    str_data        db 'Data', 0
    str_sys         db 'System', 0

section '.text' code readable executable
start:
    invoke GetCurrentThread
    mov [hThread], eax
    sgdt [gdtr]
    movzx eax, [gdtr.Limit]
    cinvoke printf, str_hdr, [gdtr.Base], eax

    mov [current_sel], 0
    
.loop_start:
    mov eax, [current_sel]
    movzx ecx, [gdtr.Limit]
    cmp eax, ecx
    jg .loop_end

    invoke GetThreadSelectorEntry, [hThread], [current_sel], ldt_entry
    test eax, eax
    jz .next_selector

    movzx eax, [ldt_entry.BaseLow]
    movzx ecx, [ldt_entry.BaseMid]
    shl ecx, BASE_MID_SHIFT
    or eax, ecx
    movzx ecx, [ldt_entry.BaseHi]
    shl ecx, BASE_HI_SHIFT
    or eax, ecx
    mov [desc_base], eax

    movzx eax, [ldt_entry.LimitLow]
    movzx ecx, [ldt_entry.Flags2]
    and ecx, LDT_FLAGS2_LIMIT_HI_MASK
    shl ecx, LIMIT_HI_SHIFT
    or eax, ecx

    test [ldt_entry.Flags2], LDT_FLAGS2_GRANULARITY_BIT
    jz .save_limit
    shl eax, PAGE_GRANULARITY_SHIFT
    or eax, PAGE_GRANULARITY_MASK

.save_limit:
    mov [desc_limit], eax

    movzx eax, [ldt_entry.Flags1]
    mov ecx, eax
    shr ecx, LDT_FLAGS1_DPL_SHIFT
    and ecx, LDT_FLAGS1_DPL_MASK
    mov [desc_dpl], ecx

    test eax, LDT_FLAGS1_S_BIT
    jz .is_sys
    test eax, LDT_FLAGS1_CODE_BIT
    jz .is_data
    mov edx, str_code
    jmp .set_type

.is_data:
    mov edx, str_data
    jmp .set_type

.is_sys:
    mov edx, str_sys

.set_type:
    mov [desc_type], edx

    cinvoke printf, str_fmt, [current_sel], \
        [desc_base], [desc_limit], [desc_dpl], [desc_type]

.next_selector:
    add [current_sel], SELECTOR_SIZE
    jmp .loop_start

.loop_end:
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL', \
        msvcrt, 'MSVCRT.DLL'

    import kernel32, \
        ExitProcess, 'ExitProcess', \
        GetCurrentThread, 'GetCurrentThread', \
        GetThreadSelectorEntry, 'GetThreadSelectorEntry'

    import msvcrt, \
        printf, 'printf'
