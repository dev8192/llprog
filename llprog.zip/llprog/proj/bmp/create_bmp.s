format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable

    fname db '0files/image.bmp', 0
    fmode db 'wb', 0

    header:
        ; ---------- BITMAPFILEHEADER ----------
        db 'BM'         ; bfType
        dd 196662       ; bfSize
        dw 0, 0         ; bfReserved1, bfReserved2
        dd 54           ; bfOffBits
        ; ---------- BITMAPINFOHEADER ----------
        dd 40           ; biSize
        dd 256, 256     ; biWidth, biHeight
        dw 1, 24        ; biPlanes, biBitCount
        dd 0, 196608    ; biCompression, biSizeImage
        dd 0, 0, 0, 0   ; biXPelsPerMeter, biYPelsPerMeter,
                        ; biClrUsed, biClrImportant

section '.bss' readable writeable
    pixels rb 196608

section '.text' code readable executable

start:
    mov edi, pixels
    mov ecx, 65536
    xor eax, eax
.fill:
    mov [edi], al
    mov [edi+1], ah
    mov byte [edi+2], 255
    add edi, 3
    inc eax
    loop .fill

    cinvoke fopen, fname, fmode
    test eax, eax
    jz .exit
    mov ebx, eax

    cinvoke fwrite, header, 1, 54, ebx
    cinvoke fwrite, pixels, 1, 196608, ebx
    cinvoke fclose, ebx

.exit:
    invoke ExitProcess, 0

section '.idata' import data readable

    library kernel32, 'kernel32.dll',\
        msvcrt, 'msvcrt.dll'

    import kernel32,\
        ExitProcess, 'ExitProcess'

    import msvcrt,\
        fopen, 'fopen',\
        fwrite, 'fwrite',\
        fclose, 'fclose'
