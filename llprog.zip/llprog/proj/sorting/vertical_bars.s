format PE
entry start

include 'win32a.inc'

NUM_BARS = 30
BAR_W = 25
BAR_GAP = 10
BAR_STEP = 35
OFFSET_X = 115
BASE_Y = 650
VAL_MIN = 50
VAL_MAX = 600
ANIM_TICKS = 50
TIMER_MS = 20

COLOR_NORMAL = 0x0000C000
COLOR_HIGHLIGHT = 0x000000FF
WS_EX_COMPOSITED = 0x02000000
TIMER_ID = 1

section '.data' data readable writeable
    className db 'SortVisualizer', 0
    windowName db 'Sorting Visualizer', 0

    wc WNDCLASS
    msg MSG
    ps PAINTSTRUCT
    rect_client RECT
    rect_bar RECT
    rect_mem RECT

    array dd NUM_BARS dup(0)
    sel1_idx dd -1
    sel2_idx dd -1
    anim_state dd 0
    anim_progress dd 0

    hBrushNormal dd ?
    hBrushHighlight dd ?
    memDC dd ?
    hBmp dd ?
    hOldBmp dd ?
    bar_x dd ?
    bar_y dd ?

section '.text' code readable executable
start:
    invoke GetModuleHandle, 0
    mov [wc.hInstance], eax
    mov [wc.style], CS_HREDRAW or CS_VREDRAW
    mov [wc.lpfnWndProc], WindowProc
    invoke LoadCursor, 0, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.hbrBackground], COLOR_WINDOW + 1
    mov [wc.lpszClassName], className
    invoke RegisterClass, wc

    invoke CreateWindowEx, WS_EX_COMPOSITED, className, windowName,\
        WS_VISIBLE or WS_OVERLAPPEDWINDOW or WS_MAXIMIZE,\
        CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,\
        0, 0, [wc.hInstance], 0

.msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    cmp eax, 0
    jle .end_loop
    invoke DispatchMessage, msg
    jmp .msg_loop

.end_loop:
    invoke ExitProcess, [msg.wParam]

proc WindowProc uses ebx esi edi, hwnd, wmsg, wparam, lparam
    cmp [wmsg], WM_CREATE
    je .wm_create
    cmp [wmsg], WM_LBUTTONDOWN
    je .wm_lbuttondown
    cmp [wmsg], WM_TIMER
    je .wm_timer
    cmp [wmsg], WM_PAINT
    je .wm_paint
    cmp [wmsg], WM_DESTROY
    je .wm_destroy
.defwindowproc:
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    jmp .finish

.wm_create:
    invoke CreateSolidBrush, COLOR_NORMAL
    mov [hBrushNormal], eax
    invoke CreateSolidBrush, COLOR_HIGHLIGHT
    mov [hBrushHighlight], eax

    invoke GetTickCount
    cinvoke srand, eax

    xor edi, edi
.init_array:
    cmp edi, NUM_BARS
    jge .init_done
    cinvoke rand
    mov ecx, 551
    xor edx, edx
    div ecx
    add edx, VAL_MIN
    mov [array + edi*4], edx
    inc edi
    jmp .init_array
.init_done:
    xor eax, eax
    jmp .finish

.wm_lbuttondown:
    cmp [anim_state], 2
    jge .finish

    movzx eax, word [lparam]
    movzx ebx, word [lparam+2]

    cmp ebx, BASE_Y - VAL_MAX
    jl .finish
    cmp ebx, BASE_Y
    jg .finish

    sub eax, OFFSET_X
    jl .finish

    mov ecx, BAR_STEP
    xor edx, edx
    div ecx
    cmp edx, BAR_W
    jge .finish
    cmp eax, NUM_BARS
    jge .finish

    mov esi, [array + eax*4]
    mov ecx, BASE_Y
    sub ecx, esi
    cmp ebx, ecx
    jl .finish

    cmp [anim_state], 0
    jne .check_state_1
    mov [sel1_idx], eax
    mov [anim_state], 1
    invoke InvalidateRect, [hwnd], 0, FALSE
    jmp .finish

.check_state_1:
    cmp eax, [sel1_idx]
    jne .select_second
    mov [sel1_idx], -1
    mov [anim_state], 0
    invoke InvalidateRect, [hwnd], 0, FALSE
    jmp .finish

.select_second:
    mov [sel2_idx], eax
    mov [anim_state], 2
    mov [anim_progress], ANIM_TICKS
    invoke SetTimer, [hwnd], TIMER_ID, TIMER_MS, 0
    jmp .finish

.wm_timer:
    cmp [anim_state], 2
    jne .timer_state_3
    dec [anim_progress]
    cmp [anim_progress], 0
    jg .timer_update
    mov eax, [sel1_idx]
    mov ebx, [sel2_idx]
    mov ecx, [array + eax*4]
    mov edx, [array + ebx*4]
    mov [array + eax*4], edx
    mov [array + ebx*4], ecx
    mov [anim_state], 3
    jmp .timer_update

.timer_state_3:
    inc [anim_progress]
    cmp [anim_progress], ANIM_TICKS
    jl .timer_update
    mov [sel1_idx], -1
    mov [sel2_idx], -1
    mov [anim_state], 0
    invoke KillTimer, [hwnd], TIMER_ID

.timer_update:
    invoke InvalidateRect, [hwnd], 0, FALSE
    xor eax, eax
    jmp .finish

.wm_paint:
    invoke BeginPaint, [hwnd], ps
    invoke GetClientRect, [hwnd], rect_client
    invoke FillRect, [ps.hdc], rect_client, COLOR_WINDOW + 1

    invoke CreateCompatibleDC, [ps.hdc]
    mov [memDC], eax
    invoke CreateCompatibleBitmap, [ps.hdc], BAR_W, VAL_MAX
    mov [hBmp], eax
    invoke SelectObject, [memDC], [hBmp]
    mov [hOldBmp], eax

    xor edi, edi
.draw_loop:
    cmp edi, NUM_BARS
    jge .draw_done

    mov esi, [array + edi*4]
    mov eax, BAR_STEP
    imul eax, edi
    add eax, OFFSET_X
    mov [bar_x], eax

    mov eax, BASE_Y
    sub eax, esi
    mov [bar_y], eax

    cmp [anim_state], 0
    je .draw_normal

    cmp edi, [sel1_idx]
    je .draw_highlight
    cmp edi, [sel2_idx]
    je .draw_highlight
    jmp .draw_normal

.draw_highlight:
    cmp [anim_state], 1
    je .draw_solid_highlight

    mov [rect_mem.left], 0
    mov [rect_mem.top], 0
    mov [rect_mem.right], BAR_W
    mov [rect_mem.bottom], esi
    invoke FillRect, [memDC], rect_mem, [hBrushHighlight]

    mov eax, [anim_progress]
    imul eax, 255
    mov ecx, ANIM_TICKS
    cdq
    idiv ecx
    shl eax, 16

    invoke AlphaBlend, [ps.hdc], [bar_x], [bar_y], BAR_W, esi,\
        [memDC], 0, 0, BAR_W, esi, eax
    jmp .next_bar

.draw_solid_highlight:
    mov eax, [bar_x]
    mov [rect_bar.left], eax
    add eax, BAR_W
    mov [rect_bar.right], eax
    mov eax, [bar_y]
    mov [rect_bar.top], eax
    add eax, esi
    mov [rect_bar.bottom], eax
    invoke FillRect, [ps.hdc], rect_bar, [hBrushHighlight]
    jmp .next_bar

.draw_normal:
    mov eax, [bar_x]
    mov [rect_bar.left], eax
    add eax, BAR_W
    mov [rect_bar.right], eax
    mov eax, [bar_y]
    mov [rect_bar.top], eax
    add eax, esi
    mov [rect_bar.bottom], eax
    invoke FillRect, [ps.hdc], rect_bar, [hBrushNormal]

.next_bar:
    inc edi
    jmp .draw_loop

.draw_done:
    invoke SelectObject, [memDC], [hOldBmp]
    invoke DeleteObject, [hBmp]
    invoke DeleteDC, [memDC]
    invoke EndPaint, [hwnd], ps
    xor eax, eax
    jmp .finish

.wm_destroy:
    invoke DeleteObject, [hBrushNormal]
    invoke DeleteObject, [hBrushHighlight]
    invoke PostQuitMessage, 0
    xor eax, eax

.finish:
    ret
endp ; WindowProc

section '.idata' import data readable
    library kernel32,               'kernel32.dll',\
            user32,                 'user32.dll',\
            gdi32,                  'gdi32.dll',\
            msimg32,                'msimg32.dll',\
            msvcrt,                 'msvcrt.dll'
    import  kernel32,\
            GetModuleHandle,        'GetModuleHandleA',\
            GetTickCount,           'GetTickCount',\
            ExitProcess,            'ExitProcess'
    import  user32,\
            RegisterClass,          'RegisterClassA',\
            CreateWindowEx,         'CreateWindowExA',\
            GetMessage,             'GetMessageA',\
            TranslateMessage,       'TranslateMessage',\
            DispatchMessage,        'DispatchMessageA',\
            DefWindowProc,          'DefWindowProcA',\
            PostQuitMessage,        'PostQuitMessage',\
            GetClientRect,          'GetClientRect',\
            SetTimer,               'SetTimer',\
            KillTimer,              'KillTimer',\
            InvalidateRect,         'InvalidateRect',\
            BeginPaint,             'BeginPaint',\
            LoadCursor,             'LoadCursorA',\
            EndPaint,               'EndPaint',\
            FillRect,               'FillRect'
    import  gdi32,\
            CreateCompatibleDC,     'CreateCompatibleDC',\
            CreateCompatibleBitmap, 'CreateCompatibleBitmap',\
            SelectObject,           'SelectObject',\
            DeleteObject,           'DeleteObject',\
            DeleteDC,               'DeleteDC',\
            CreateSolidBrush,       'CreateSolidBrush'
    import  msimg32,\
            AlphaBlend,             'AlphaBlend'
    import  msvcrt,\
            srand,                  'srand',\
            rand,                   'rand'
