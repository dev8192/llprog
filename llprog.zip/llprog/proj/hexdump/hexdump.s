format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    argc        dd ?
    argv        dd ?
    hFile       dd ?
    bytesRead   dd ?
    offset      dd 0
    buffer      rb 16

    fmt_offset  db '%08X: ', 0
    fmt_hex     db '%02X ', 0
    fmt_space   db '   ', 0
    fmt_char    db '%c', 0
    fmt_nl      db 10, 0
    fmt_gap     db ' ', 0

section '.text' code readable executable
start:
    invoke  GetCommandLineW
    invoke  CommandLineToArgvW, eax, argc
    mov     [argv], eax

    mov     ebx, [argc]
    cmp     ebx, 2
    jl      .exit

    mov     esi, [argv]
    mov     eax, [esi + 4]

    ;invoke  CreateFileW, eax, GENERIC_READ, FILE_SHARE_READ, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0
    invoke  CreateFileW,\
        eax,\                   ; LPCWSTR lpFileName
        GENERIC_READ,\          ; DWORD dwDesiredAccess
        FILE_SHARE_READ,\       ; DWORD dwShareMode
        0,\                     ; LPSECURITY_ATTRIBUTES lpSecurityAttributes
        OPEN_EXISTING,\         ; DWORD dwCreationDisposition
        FILE_ATTRIBUTE_NORMAL,\ ; DWORD dwFlagsAndAttributes
        0                       ; HANDLE hTemplateFile

    cmp     eax, INVALID_HANDLE_VALUE
    je      .cleanup
    mov     [hFile], eax

.read_loop:
    invoke  ReadFile, [hFile], buffer, 16, bytesRead, 0
    test    eax, eax
    jz      .close_file
    mov     ebx, [bytesRead]
    test    ebx, ebx
    jz      .close_file

    cinvoke printf, fmt_offset, [offset]

    xor     edi, edi
.hex_loop:
    cmp     edi, ebx
    jge     .print_spaces
    movzx   eax, byte [buffer + edi]
    cinvoke printf, fmt_hex, eax
    jmp     .check_gap
.print_spaces:
    cinvoke printf, fmt_space
.check_gap:
    cmp     edi, 7
    jne     .next_hex
    cinvoke printf, fmt_gap
.next_hex:
    inc     edi
    cmp     edi, 16
    jl      .hex_loop

    cinvoke printf, fmt_gap

    xor     edi, edi
.ascii_loop:
    cmp     edi, ebx
    jge     .end_ascii
    movzx   eax, byte [buffer + edi]
    cmp     al, 32
    jl      .dot
    cmp     al, 126
    jg      .dot
    jmp     .print_char
.dot:
    mov     al, '.'
.print_char:
    cinvoke printf, fmt_char, eax
    inc     edi
    jmp     .ascii_loop
.end_ascii:
    cinvoke printf, fmt_nl

    mov     eax, [bytesRead]
    add     [offset], eax
    jmp     .read_loop

.close_file:
    invoke  CloseHandle, [hFile]

.cleanup:
    invoke  LocalFree, [argv]

.exit:
    invoke  ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            shell32, 'shell32.dll',\
            msvcrt, 'msvcrt.dll'

    import  kernel32,\
            GetCommandLineW, 'GetCommandLineW',\
            CreateFileW, 'CreateFileW',\
            ReadFile, 'ReadFile',\
            CloseHandle, 'CloseHandle',\
            LocalFree, 'LocalFree',\
            ExitProcess, 'ExitProcess'

    import  shell32,\
            CommandLineToArgvW, 'CommandLineToArgvW'

    import  msvcrt,\
            printf, 'printf'
