format PE console
entry start

include 'win32a.inc'

; 1773906150758
; 1773906159121

section '.data' data readable writeable
    filetime    dq 0
    msg         db 'Milliseconds since Unix epoch: %llu', 13, 10, 0
    
section '.code' code readable executable

start:
    invoke  GetSystemTimeAsFileTime, filetime
    
    ; FILETIME is 100-nanosecond intervals since January 1, 1601
    ; Unix epoch is January 1, 1970
    ; Difference: 11644473600 seconds = 116444736000000000 (100-ns intervals)
    
    mov     eax, dword [filetime]
    mov     edx, dword [filetime + 4]
    
    ; Subtract the epoch difference (116444736000000000)
    ; Low part:  0x019DB1DED53E8000
    sub     eax, 0xD53E8000
    sbb     edx, 0x019DB1DE
    
    ; Now EDX:EAX contains 100-nanosecond intervals since Unix epoch
    ; Divide by 10000 to get milliseconds
    mov     ecx, 10000
    
    ; EDX:EAX / ECX
    ; First divide high part
    push    eax             ; save low part
    mov     eax, edx        ; high part to eax
    xor     edx, edx        ; clear edx
    div     ecx             ; eax = high quotient, edx = remainder
    mov     ebx, eax        ; save high quotient
    
    pop     eax             ; restore low part
    div     ecx             ; eax = low quotient (with remainder from high)
    
    ; Now EBX:EAX = milliseconds since Unix epoch
    
    cinvoke printf, msg, eax, ebx  
    invoke  ExitProcess, 0

section '.idata' import data readable
    library kernel32,                   'kernel32.dll',\
            msvcrt,                     'msvcrt.dll'
    import  kernel32,\
            GetSystemTimeAsFileTime,    'GetSystemTimeAsFileTime',\
            ExitProcess,                'ExitProcess'
    import  msvcrt,\
            printf,                     'printf'
