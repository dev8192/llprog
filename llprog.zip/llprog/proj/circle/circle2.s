format PE GUI 4.0
entry start

include 'win32a.inc'

section '.text' code readable executable

start:
    invoke  GetModuleHandleA, 0
    mov     [wc.hInstance], eax
    invoke  LoadIconA, 0, IDI_APPLICATION
    mov     [wc.hIcon], eax
    invoke  LoadCursorA, 0, IDC_ARROW
    mov     [wc.hCursor], eax
    invoke  RegisterClassA, wc
    test    eax, eax
    jz      error

    invoke  CreateWindowExA, 0, class_name, title, WS_VISIBLE+WS_CAPTION+WS_SYSMENU+WS_MINIMIZEBOX, 100, 100, 400, 500, NULL, NULL, [wc.hInstance], NULL
    mov     [hwnd], eax

msg_loop:
    invoke  GetMessageA, msg, NULL, 0, 0
    test    eax, eax
    jz      end_loop
    invoke  IsDialogMessageA, [hwnd], msg
    test    eax, eax
    jnz     msg_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessageA, msg
    jmp     msg_loop

error:
end_loop:
    invoke  ExitProcess, [msg.wParam]

proc WindowProc hwnd_w, wmsg, wparam, lparam
    push    ebx esi edi
    cmp     [wmsg], WM_CREATE
    je      .wmcreate
    cmp     [wmsg], WM_COMMAND
    je      .wmcommand
    cmp     [wmsg], WM_PAINT
    je      .wmpaint
    cmp     [wmsg], WM_DESTROY
    je      .wmdestroy
.defwndproc:
    invoke  DefWindowProcA, [hwnd_w], [wmsg], [wparam], [lparam]
    jmp     .finish
.wmcreate:
    invoke  CreateWindowExA, 0, static_class, txt_x, WS_CHILD+WS_VISIBLE,\
        20, 360, 40, 20, [hwnd_w], 0, [wc.hInstance], NULL
    invoke  CreateWindowExA, WS_EX_CLIENTEDGE, edit_class, val_x, WS_CHILD+WS_VISIBLE+WS_BORDER+ES_NUMBER+WS_TABSTOP,\
        60, 360, 60, 20, [hwnd_w], 101, [wc.hInstance], NULL
    mov     [hedit_x], eax

    invoke  CreateWindowExA, 0, static_class, txt_y, WS_CHILD+WS_VISIBLE,\
        140, 360, 40, 20, [hwnd_w], 0, [wc.hInstance], NULL
    invoke  CreateWindowExA, WS_EX_CLIENTEDGE, edit_class, val_y, WS_CHILD+WS_VISIBLE+WS_BORDER+ES_NUMBER+WS_TABSTOP,\
        180, 360, 60, 20, [hwnd_w], 102, [wc.hInstance], NULL
    mov     [hedit_y], eax

    invoke  CreateWindowExA, 0, static_class, txt_r, WS_CHILD+WS_VISIBLE,\
        20, 390, 50, 20, [hwnd_w], 0, [wc.hInstance], NULL
    invoke  CreateWindowExA, WS_EX_CLIENTEDGE, edit_class, val_r, WS_CHILD+WS_VISIBLE+WS_BORDER+ES_NUMBER+WS_TABSTOP,\
        70, 390, 50, 20, [hwnd_w], 103, [wc.hInstance], NULL
    mov     [hedit_r], eax

    invoke  CreateWindowExA, 0, static_class, txt_w, WS_CHILD+WS_VISIBLE,\
        140, 390, 80, 20, [hwnd_w], 0, [wc.hInstance], NULL
    invoke  CreateWindowExA, WS_EX_CLIENTEDGE, edit_class, val_w, WS_CHILD+WS_VISIBLE+WS_BORDER+ES_NUMBER+WS_TABSTOP,\
        220, 390, 60, 20, [hwnd_w], 104, [wc.hInstance], NULL
    mov     [hedit_w], eax

    invoke  SetWindowLongA, [hedit_x], GWL_WNDPROC, EditProc
    mov     [oldEditProc], eax
    invoke  SetWindowLongA, [hedit_y], GWL_WNDPROC, EditProc
    invoke  SetWindowLongA, [hedit_r], GWL_WNDPROC, EditProc
    invoke  SetWindowLongA, [hedit_w], GWL_WNDPROC, EditProc

    xor     eax, eax
    jmp     .finish
.wmcommand:
    mov     eax, [wparam]
    shr     eax, 16
    cmp     ax, EN_CHANGE
    jne     .finish_cmd
    invoke  InvalidateRect, [hwnd_w], NULL, TRUE
.finish_cmd:
    xor     eax, eax
    jmp     .finish
.wmpaint:
    invoke  BeginPaint, [hwnd_w], ps
    mov     [hdc], eax

    invoke  GetWindowTextA, [hedit_x], buffer, 32
    stdcall str2int, buffer
    mov     [val_cx], eax

    invoke  GetWindowTextA, [hedit_y], buffer, 32
    stdcall str2int, buffer
    mov     [val_cy], eax

    invoke  GetWindowTextA, [hedit_r], buffer, 32
    stdcall str2int, buffer
    mov     [val_cr], eax

    invoke  GetWindowTextA, [hedit_w], buffer, 32
    stdcall str2int, buffer
    mov     [val_cw], eax

    invoke  CreatePen, PS_SOLID, [val_cw], 0x00000000
    mov     [hpen], eax
    invoke  SelectObject, [hdc], eax
    mov     [hpenOld], eax

    invoke  GetStockObject, NULL_BRUSH
    invoke  SelectObject, [hdc], eax
    mov     [hbrushOld], eax

    mov     eax, [val_cx]
    sub     eax, [val_cr]
    mov     ebx, [val_cy]
    sub     ebx, [val_cr]
    mov     ecx, [val_cx]
    add     ecx, [val_cr]
    mov     edx, [val_cy]
    add     edx, [val_cr]

    invoke  Ellipse, [hdc], eax, ebx, ecx, edx

    invoke  SelectObject, [hdc], [hpenOld]
    invoke  DeleteObject, [hpen]
    invoke  SelectObject, [hdc], [hbrushOld]

    invoke  EndPaint, [hwnd_w], ps
    xor     eax, eax
    jmp     .finish
.wmdestroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
.finish:
    pop     edi esi ebx
    ret
endp

proc EditProc hwnd_e, wmsg, wparam, lparam
    push    ebx esi edi
    cmp     [wmsg], WM_KEYDOWN
    jne     .default
    cmp     [wparam], VK_UP
    je      .up
    cmp     [wparam], VK_DOWN
    je      .down
    jmp     .default
.up:
    mov     ebx, 1
    jmp     .update
.down:
    mov     ebx, -1
.update:
    invoke  GetWindowTextA, [hwnd_e], buffer, 32
    stdcall str2int, buffer
    add     eax, ebx
    cmp     eax, 0
    jge     .positive
    xor     eax, eax
.positive:
    cinvoke wsprintfA, buffer, fmt_int, eax
    invoke  SetWindowTextA, [hwnd_e], buffer
    xor     eax, eax
    jmp     .finish
.default:
    invoke  CallWindowProcA, [oldEditProc], [hwnd_e], [wmsg], [wparam], [lparam]
    jmp     .finish
.finish:
    pop     edi esi ebx
    ret
endp

proc str2int strptr
    push    ebx esi
    mov     esi, [strptr]
    xor     eax, eax
    xor     ebx, ebx
.next_char:
    lodsb
    test    al, al
    jz      .done
    cmp     al, '0'
    jb      .done
    cmp     al, '9'
    ja      .done
    sub     al, '0'
    imul    ebx, 10
    add     ebx, eax
    jmp     .next_char
.done:
    mov     eax, ebx
    pop     esi ebx
    ret
endp

section '.data' data readable writeable

    class_name   db 'CircleAppClass',0
    title        db 'Circle Drawer',0
    static_class db 'STATIC',0
    edit_class   db 'EDIT',0
    fmt_int      db '%d',0

    txt_x db 'pos x',0
    txt_y db 'pos y',0
    txt_r db 'radius',0
    txt_w db 'stroke width',0

    val_x db '200',0
    val_y db '150',0
    val_r db '100',0
    val_w db '2',0

    wc WNDCLASS 0,WindowProc,0,0,NULL,NULL,NULL,COLOR_BTNFACE+1,NULL,class_name

    hwnd        dd ?
    msg         MSG
    ps          PAINTSTRUCT
    hdc         dd ?

    hedit_x     dd ?
    hedit_y     dd ?
    hedit_r     dd ?
    hedit_w     dd ?
    oldEditProc dd ?

    hpen        dd ?
    hpenOld     dd ?
    hbrushOld   dd ?

    val_cx      dd ?
    val_cy      dd ?
    val_cr      dd ?
    val_cw      dd ?

    buffer      rb 32

section '.idata' import data readable writeable

    library kernel32,'KERNEL32.DLL',\
            user32,'USER32.DLL',\
            gdi32,'GDI32.DLL'

    import kernel32,\
           GetModuleHandleA,'GetModuleHandleA',\
           ExitProcess,'ExitProcess'

    import user32,\
           LoadIconA,'LoadIconA',\
           LoadCursorA,'LoadCursorA',\
           RegisterClassA,'RegisterClassA',\
           CreateWindowExA,'CreateWindowExA',\
           GetMessageA,'GetMessageA',\
           TranslateMessage,'TranslateMessage',\
           DispatchMessageA,'DispatchMessageA',\
           DefWindowProcA,'DefWindowProcA',\
           PostQuitMessage,'PostQuitMessage',\
           BeginPaint,'BeginPaint',\
           EndPaint,'EndPaint',\
           InvalidateRect,'InvalidateRect',\
           GetWindowTextA,'GetWindowTextA',\
           SetWindowTextA,'SetWindowTextA',\
           SetWindowLongA,'SetWindowLongA',\
           CallWindowProcA,'CallWindowProcA',\
           IsDialogMessageA,'IsDialogMessageA',\
           wsprintfA,'wsprintfA'

    import gdi32,\
           CreatePen,'CreatePen',\
           SelectObject,'SelectObject',\
           DeleteObject,'DeleteObject',\
           Ellipse,'Ellipse',\
           GetStockObject,'GetStockObject'
