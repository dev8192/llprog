format PE GUI 4.0
entry start

include 'win32a.inc'

section '.text' code readable executable

start:
    invoke  GetModuleHandle, 0
    mov     [wc.hInstance], eax
    invoke  LoadIcon, 0, IDI_APPLICATION
    mov     [wc.hIcon], eax
    invoke  LoadCursor, 0, IDC_ARROW
    mov     [wc.hCursor], eax
    invoke  RegisterClass, wc
    test    eax, eax
    jz      error

    invoke  CreateWindowEx, 0, class_name, title, WS_VISIBLE+WS_CAPTION+WS_SYSMENU+WS_MINIMIZEBOX,\
        100, 100, 400, 500, NULL, NULL, [wc.hInstance], NULL
    mov     [hwnd], eax

msg_loop:
    invoke  GetMessage, msg, NULL, 0, 0
    cmp     eax, 1
    jb      end_loop
    jne     msg_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     msg_loop

error:
end_loop:
    invoke  ExitProcess, [msg.wParam]

proc WindowProc hwnd,wmsg,wparam,lparam
    push    ebx esi edi
    cmp     [wmsg], WM_CREATE
    je      .wmcreate
    cmp     [wmsg], WM_COMMAND
    je      .wmcommand
    cmp     [wmsg], WM_PAINT
    je      .wmpaint
    cmp     [wmsg], WM_DESTROY
    je      .wmdestroy
.defwndproc:
    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    jmp     .finish
.wmcreate:
    invoke  CreateWindowEx, 0, static_class, txt_x, WS_CHILD+WS_VISIBLE,\
        20, 360, 40, 20, [hwnd], 0, [wc.hInstance], NULL
    invoke  CreateWindowEx, WS_EX_CLIENTEDGE, edit_class, val_x, WS_CHILD+WS_VISIBLE+WS_BORDER+ES_NUMBER,\
        60, 360, 60, 20, [hwnd], 101, [wc.hInstance], NULL
    mov     [hedit_x], eax

    invoke  CreateWindowEx, 0, static_class, txt_y, WS_CHILD+WS_VISIBLE,\
        140, 360, 40, 20, [hwnd], 0, [wc.hInstance], NULL
    invoke  CreateWindowEx, WS_EX_CLIENTEDGE, edit_class, val_y, WS_CHILD+WS_VISIBLE+WS_BORDER+ES_NUMBER,\
        180, 360, 60, 20, [hwnd], 102, [wc.hInstance], NULL
    mov     [hedit_y], eax

    invoke  CreateWindowEx, 0, static_class, txt_r, WS_CHILD+WS_VISIBLE,\
        20, 390, 50, 20, [hwnd], 0, [wc.hInstance], NULL
    invoke  CreateWindowEx, WS_EX_CLIENTEDGE, edit_class, val_r, WS_CHILD+WS_VISIBLE+WS_BORDER+ES_NUMBER,\
        70, 390, 50, 20, [hwnd], 103, [wc.hInstance], NULL
    mov     [hedit_r], eax

    invoke  CreateWindowEx, 0, static_class, txt_w, WS_CHILD+WS_VISIBLE,\
        140, 390, 80, 20, [hwnd], 0, [wc.hInstance], NULL
    invoke  CreateWindowEx, WS_EX_CLIENTEDGE, edit_class, val_w, WS_CHILD+WS_VISIBLE+WS_BORDER+ES_NUMBER,\
        220, 390, 60, 20, [hwnd], 104, [wc.hInstance], NULL
    mov     [hedit_w], eax

    xor     eax, eax
    jmp     .finish
.wmcommand:
    mov     eax, [wparam]
    shr     eax, 16
    cmp     ax, EN_CHANGE
    jne     .finish
    invoke  InvalidateRect, [hwnd], NULL, TRUE
    xor     eax, eax
    jmp     .finish
.wmpaint:
    invoke  BeginPaint, [hwnd], ps
    mov     [hdc], eax

    invoke  GetWindowText, [hedit_x], buffer, 32
    stdcall str2int, buffer
    mov     [val_cx], eax

    invoke  GetWindowText, [hedit_y], buffer, 32
    stdcall str2int, buffer
    mov     [val_cy], eax

    invoke  GetWindowText, [hedit_r], buffer, 32
    stdcall str2int, buffer
    mov     [val_cr], eax

    invoke  GetWindowText, [hedit_w], buffer, 32
    stdcall str2int, buffer
    mov     [val_cw], eax

    invoke  CreatePen, PS_SOLID, [val_cw], 0x00000000
    mov     [hpen], eax
    invoke  SelectObject, [hdc], eax
    mov     [hpenOld], eax

    invoke  GetStockObject, NULL_BRUSH
    invoke  SelectObject, [hdc], eax
    mov     [hbrushOld], eax

    mov     eax, [val_cx]
    sub     eax, [val_cr]
    mov     ebx, [val_cy]
    sub     ebx, [val_cr]
    mov     ecx, [val_cx]
    add     ecx, [val_cr]
    mov     edx, [val_cy]
    add     edx, [val_cr]

    invoke  Ellipse, [hdc], eax, ebx, ecx, edx

    invoke  SelectObject, [hdc], [hpenOld]
    invoke  DeleteObject, [hpen]
    invoke  SelectObject, [hdc], [hbrushOld]

    invoke  EndPaint, [hwnd], ps
    xor     eax, eax
    jmp     .finish
.wmdestroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
.finish:
    pop     edi esi ebx
    ret
endp

proc str2int strptr
    push    ebx esi
    mov     esi, [strptr]
    xor     eax, eax
    xor     ebx, ebx
.next_char:
    lodsb
    test    al, al
    jz      .done
    cmp     al, '0'
    jb      .done
    cmp     al, '9'
    ja      .done
    sub     al, '0'
    imul    ebx, 10
    add     ebx, eax
    jmp     .next_char
.done:
    mov     eax, ebx
    pop     esi ebx
    ret
endp

section '.data' data readable writeable

    class_name   db 'CircleAppClass',0
    title        db 'Circle Drawer',0
    static_class db 'STATIC',0
    edit_class   db 'EDIT',0

    txt_x db 'pos x',0
    txt_y db 'pos y',0
    txt_r db 'radius',0
    txt_w db 'stroke width',0

    val_x db '200',0
    val_y db '150',0
    val_r db '100',0
    val_w db '2',0

    wc WNDCLASS 0,WindowProc,0,0,NULL,NULL,NULL,COLOR_BTNFACE+1,NULL,class_name

    hwnd      dd ?
    msg       MSG
    ps        PAINTSTRUCT
    hdc       dd ?

    hedit_x   dd ?
    hedit_y   dd ?
    hedit_r   dd ?
    hedit_w   dd ?

    hpen      dd ?
    hpenOld   dd ?
    hbrushOld dd ?

    val_cx    dd ?
    val_cy    dd ?
    val_cr    dd ?
    val_cw    dd ?

    buffer    rb 32

section '.idata' import data readable writeable
    library kernel32,'KERNEL32.DLL',\
            user32,'USER32.DLL',\
            gdi32,'GDI32.DLL'
            
    include 'api\kernel32.inc'
    include 'api\user32.inc'
    include 'api\gdi32.inc'
