format PE GUI 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    wc WNDCLASS
    msg MSG
    hMainWnd dd ?
    hFont dd ?
    hBrushZero dd ?
    hBrushOne dd ?
    current_byte db 0
    updating db 0
    buffer rb 32

    _class db 'ByteVizClass', 0
    _title db 'Byte Visualizer', 0
    _static db 'STATIC', 0
    _edit db 'EDIT', 0
    _button db 'BUTTON', 0
    _zero db '0', 0
    _one db '1', 0
    _shift_l db '<<', 0
    _shift_r db '>>', 0

section '.text' code readable executable
start:
    invoke GetModuleHandle, 0
    mov [wc.hInstance], eax
    mov [wc.style], CS_HREDRAW or CS_VREDRAW
    mov [wc.lpfnWndProc], WindowProc
    invoke LoadIcon, 0, IDI_APPLICATION
    mov [wc.hIcon], eax
    invoke LoadCursor, 0, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.hbrBackground], COLOR_BTNFACE+1
    mov [wc.lpszClassName], _class
    invoke RegisterClass, wc

    invoke CreateWindowEx, 0, _class, _title,\
        WS_VISIBLE or WS_OVERLAPPEDWINDOW - WS_SIZEBOX - WS_MAXIMIZEBOX,\
        128, 128, 300, 160, 0, 0, [wc.hInstance], 0
    mov [hMainWnd], eax

msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    test eax, eax
    jz end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp msg_loop

end_loop:
    invoke ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    push ebx esi edi
    mov eax, [wmsg]
    cmp eax, WM_CREATE
    je .wm_create
    cmp eax, WM_COMMAND
    je .wm_command
    cmp eax, WM_CTLCOLORSTATIC
    je .wm_ctlcolor
    cmp eax, WM_DESTROY
    je .wm_destroy
.def_proc:
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    jmp .finish
.wm_create:
    invoke CreateSolidBrush, 0x000000FF
    mov [hBrushZero], eax
    invoke CreateSolidBrush, 0x0000FF00
    mov [hBrushOne], eax
    xor edi, edi
.create_bits:
    cmp edi, 8
    jge .bits_done
    mov eax, edi
    imul eax, 30
    add eax, 20
    cmp edi, 4
    jl .no_gap
    add eax, 10
.no_gap:
    mov ebx, 107
    sub ebx, edi
    invoke CreateWindowEx, 0, _static, _zero,\
        WS_CHILD or WS_VISIBLE or SS_NOTIFY or SS_CENTER or SS_CENTERIMAGE or WS_BORDER,\
        eax, 10, 25, 25, [hwnd], ebx, [wc.hInstance], 0
    inc edi
    jmp .create_bits
.bits_done:
    invoke CreateWindowEx, WS_EX_CLIENTEDGE, _edit, _zero,\
        WS_CHILD or WS_VISIBLE or ES_CENTER or ES_UPPERCASE, 50, 50, 60, 20, [hwnd], 200, [wc.hInstance], 0
    invoke CreateWindowEx, WS_EX_CLIENTEDGE, _edit, _zero,\
        WS_CHILD or WS_VISIBLE or ES_CENTER or ES_UPPERCASE, 160, 50, 60, 20, [hwnd], 201, [wc.hInstance], 0
    invoke CreateWindowEx, 0, _button, _shift_l,\
        WS_CHILD or WS_VISIBLE or BS_PUSHBUTTON, 80, 90, 40, 25, [hwnd], 300, [wc.hInstance], 0
    invoke CreateWindowEx, 0, _button, _shift_r,\
        WS_CHILD or WS_VISIBLE or BS_PUSHBUTTON, 150, 90, 40, 25, [hwnd], 301, [wc.hInstance], 0
    invoke GetStockObject, DEFAULT_GUI_FONT
    mov [hFont], eax
    mov edi, 100
.font_loop:
    cmp edi, 301
    jg .font_done
    invoke GetDlgItem, [hwnd], edi
    test eax, eax
    jz .next_font
    invoke SendMessage, eax, WM_SETFONT, [hFont], TRUE
.next_font:
    inc edi
    jmp .font_loop
.font_done:
    call UpdateHex
    call UpdateDec
    call UpdateBits
    xor eax, eax
    jmp .finish
.wm_command:
    mov eax, [wparam]
    mov edx, eax
    and edx, 0FFFFh
    shr eax, 16
    cmp eax, STN_CLICKED
    jne .not_clicked
    cmp edx, 100
    jl .not_bit_click
    cmp edx, 107
    jg .not_bit_click
    sub edx, 100
    mov ecx, edx
    mov eax, 1
    shl eax, cl
    xor byte [current_byte], al
    call UpdateBits
    call UpdateDec
    call UpdateHex
    xor eax, eax
    jmp .finish
.not_bit_click:
    cmp edx, 300
    jne .not_lshift
    shl byte [current_byte], 1
    call UpdateBits
    call UpdateDec
    call UpdateHex
    xor eax, eax
    jmp .finish
.not_lshift:
    cmp edx, 301
    jne .not_rshift
    shr byte [current_byte], 1
    call UpdateBits
    call UpdateDec
    call UpdateHex
    xor eax, eax
    jmp .finish
.not_rshift:
    jmp .def_proc
.not_clicked:
    cmp eax, EN_CHANGE
    jne .def_proc
    cmp byte [updating], 1
    je .def_proc
    cmp edx, 200
    jne .not_dec_change
    invoke GetDlgItemInt, [hwnd], 200, 0, 0
    cmp eax, 255
    jbe .dec_store
    mov eax, 255
    mov byte [current_byte], al
    call UpdateDec
    jmp .dec_update_others
.dec_store:
    mov byte [current_byte], al
.dec_update_others:
    call UpdateBits
    call UpdateHex
    xor eax, eax
    jmp .finish
.not_dec_change:
    cmp edx, 201
    jne .def_proc
    invoke GetDlgItemText, [hwnd], 201, buffer, 16
    call ParseHex
    cmp ebx, 255
    jbe .hex_store
    mov ebx, 255
    mov byte [current_byte], bl
    call UpdateHex
    jmp .hex_update_others
.hex_store:
    mov byte [current_byte], bl
.hex_update_others:
    call UpdateBits
    call UpdateDec
    xor eax, eax
    jmp .finish
.wm_ctlcolor:
    invoke GetWindowLong, [lparam], GWL_ID
    cmp eax, 100
    jl .def_proc
    cmp eax, 107
    jg .def_proc
    sub eax, 100
    mov ecx, eax
    mov al, byte [current_byte]
    bt ax, cx
    jc .bit_one
.bit_zero:
    invoke SetBkMode, [wparam], TRANSPARENT
    invoke SetTextColor, [wparam], 0x000000
    mov eax, [hBrushZero]
    jmp .finish
.bit_one:
    invoke SetBkMode, [wparam], TRANSPARENT
    invoke SetTextColor, [wparam], 0x000000
    mov eax, [hBrushOne]
    jmp .finish
.wm_destroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    jmp .finish
.finish:
    pop edi esi ebx
    ret
endp

UpdateBits:
    mov byte [updating], 1
    xor edi, edi
.ub_loop:
    cmp edi, 8
    jge .ub_done
    mov eax, 1
    mov ecx, edi
    shl eax, cl
    test byte [current_byte], al
    jz .ub_zero
    mov edx, _one
    jmp .ub_set
.ub_zero:
    mov edx, _zero
.ub_set:
    mov ebx, edi
    add ebx, 100
    invoke SetDlgItemText, [hMainWnd], ebx, edx
    invoke GetDlgItem, [hMainWnd], ebx
    invoke InvalidateRect, eax, 0, TRUE
    inc edi
    jmp .ub_loop
.ub_done:
    mov byte [updating], 0
    ret

UpdateDec:
    mov byte [updating], 1
    movzx eax, byte [current_byte]
    invoke SetDlgItemInt, [hMainWnd], 200, eax, FALSE
    mov byte [updating], 0
    ret

UpdateHex:
    mov byte [updating], 1
    mov al, byte [current_byte]
    call FormatHex
    invoke SetDlgItemText, [hMainWnd], 201, buffer
    mov byte [updating], 0
    ret

FormatHex:
    mov ah, al
    shr al, 4
    and ah, 0Fh
    cmp al, 9
    jbe .fh_high_digit
    add al, 'A' - 10 - '0'
.fh_high_digit:
    add al, '0'
    cmp ah, 9
    jbe .fh_low_digit
    add ah, 'A' - 10 - '0'
.fh_low_digit:
    add ah, '0'
    mov byte [buffer], al
    mov byte [buffer+1], ah
    mov byte [buffer+2], 0
    ret

ParseHex:
    mov esi, buffer
    xor ebx, ebx
.ph_loop:
    lodsb
    test al, al
    jz .ph_done
    shl ebx, 4
    cmp al, '9'
    jbe .ph_digit
    and al, 0DFh
    sub al, 'A' - 10
    jmp .ph_add
.ph_digit:
    sub al, '0'
.ph_add:
    add bl, al
    jmp .ph_loop
.ph_done:
    ret

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL',\
            user32, 'USER32.DLL',\
            gdi32, 'GDI32.DLL'
    include 'api\kernel32.inc'
    include 'api\user32.inc'
    include 'api\gdi32.inc'
