CONSOLE_MODE equ 0

match =1, CONSOLE_MODE {
    format PE console 4.0
}
match =0, CONSOLE_MODE {
    format PE GUI 4.0
}

entry start

include 'win32a.inc'

DIS_CtlID  equ 4
DIS_hdc    equ 24
DIS_rcItem equ 28

section '.data' data readable writeable

    wc WNDCLASS
    msg MSG
    hwndMain dd ?
    hwndDec dd ?
    hwndHex dd ?
    hFont dd ?
    
    val dd 0
    updating dd 0

    classMain db 'ByteVisClass',0
    classButton db 'BUTTON',0
    classEdit db 'EDIT',0
    classStatic db 'STATIC',0
    
    fmtDec db '%d',0
    fmtHex db '%02X',0
    
    str0 db '0',0
    str1 db '1',0
    strLShift db '<<',0
    strRShift db '>>',0
    strDecLabel db 'Dec:',0
    strHexLabel db 'Hex:',0
    strTitle db 'Byte Visualizer',0

    buf rb 256

section '.text' code readable executable

start:
    invoke GetModuleHandle, 0
    mov [wc.hInstance], eax
    mov [wc.style], 0
    mov [wc.lpfnWndProc], WindowProc
    mov [wc.cbClsExtra], 0
    mov [wc.cbWndExtra], 0
    mov [wc.hIcon], 0
    invoke LoadCursor, 0, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.hbrBackground], COLOR_BTNFACE+1
    mov [wc.lpszMenuName], 0
    mov [wc.lpszClassName], classMain
    invoke RegisterClass, wc
    
    invoke CreateWindowEx, 0, classMain, strTitle, WS_VISIBLE+WS_SYSMENU, 100, 100, 360, 200, 0, 0, [wc.hInstance], 0
    mov [hwndMain], eax

msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    test eax, eax
    jz end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp msg_loop
end_loop:
    invoke ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp [wmsg], WM_CREATE
    je .wmcreate
    cmp [wmsg], WM_COMMAND
    je .wmcommand
    cmp [wmsg], WM_DRAWITEM
    je .wmdrawitem
    cmp [wmsg], WM_DESTROY
    je .wmdestroy
.defwndproc:
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    jmp .finish

.wmcreate:
    mov eax, [hwnd]
    mov [hwndMain], eax

    invoke GetStockObject, DEFAULT_GUI_FONT
    mov [hFont], eax

    mov ecx, 7
.bit_loop:
    push ecx
    mov eax, 7
    sub eax, ecx
    imul eax, 35
    add eax, 20
    cmp ecx, 3
    jg .skip_gap
    add eax, 15
.skip_gap:
    mov edx, ecx
    add edx, 100
    invoke CreateWindowEx, 0, classButton, 0, WS_CHILD+WS_VISIBLE+BS_OWNERDRAW, eax, 20, 30, 30, [hwnd], edx, [wc.hInstance], 0
    pop ecx
    dec ecx
    jns .bit_loop

    invoke CreateWindowEx, 0, classStatic, strDecLabel, WS_CHILD+WS_VISIBLE, 50, 70, 30, 20, [hwnd], 0, [wc.hInstance], 0
    invoke SendMessage, eax, WM_SETFONT, [hFont], 0
    
    invoke CreateWindowEx, WS_EX_CLIENTEDGE, classEdit, 0, WS_CHILD+WS_VISIBLE+ES_NUMBER+ES_AUTOHSCROLL, 85, 68, 40, 22, [hwnd], 200, [wc.hInstance], 0
    mov [hwndDec], eax
    invoke SendMessage, eax, WM_SETFONT, [hFont], 0

    invoke CreateWindowEx, 0, classStatic, strHexLabel, WS_CHILD+WS_VISIBLE, 180, 70, 30, 20, [hwnd], 0, [wc.hInstance], 0
    invoke SendMessage, eax, WM_SETFONT, [hFont], 0
    
    invoke CreateWindowEx, WS_EX_CLIENTEDGE, classEdit, 0, WS_CHILD+WS_VISIBLE+ES_AUTOHSCROLL, 215, 68, 40, 22, [hwnd], 201, [wc.hInstance], 0
    mov [hwndHex], eax
    invoke SendMessage, eax, WM_SETFONT, [hFont], 0

    invoke CreateWindowEx, 0, classButton, strLShift, WS_CHILD+WS_VISIBLE, 100, 110, 50, 25, [hwnd], 300, [wc.hInstance], 0
    invoke SendMessage, eax, WM_SETFONT, [hFont], 0
    
    invoke CreateWindowEx, 0, classButton, strRShift, WS_CHILD+WS_VISIBLE, 190, 110, 50, 25, [hwnd], 301, [wc.hInstance], 0
    invoke SendMessage, eax, WM_SETFONT, [hFont], 0

    stdcall UpdateUI
    xor eax, eax
    jmp .finish

.wmcommand:
    mov eax, [wparam]
    mov edx, eax
    shr edx, 16
    and eax, 0xFFFF
    
    cmp eax, 100
    jl .not_bit
    cmp eax, 107
    jg .not_bit
    sub eax, 100
    mov ecx, eax
    mov eax, [val]
    btc eax, ecx
    mov [val], eax
    stdcall UpdateUI
    xor eax, eax
    jmp .finish
.not_bit:
    cmp eax, 300
    jne .not_lshift
    mov eax, [val]
    shl eax, 1
    and eax, 0xFF
    mov [val], eax
    stdcall UpdateUI
    xor eax, eax
    jmp .finish
.not_lshift:
    cmp eax, 301
    jne .not_rshift
    mov eax, [val]
    shr eax, 1
    and eax, 0xFF
    mov [val], eax
    stdcall UpdateUI
    xor eax, eax
    jmp .finish
.not_rshift:
    cmp eax, 200
    jne .not_dec
    cmp edx, EN_CHANGE
    jne .defwndproc
    cmp [updating], 1
    je .defwndproc
    invoke GetDlgItemInt, [hwnd], 200, 0, 0
    and eax, 0xFF
    mov [val], eax
    stdcall UpdateUI_FromDec
    xor eax, eax
    jmp .finish
.not_dec:
    cmp eax, 201
    jne .defwndproc
    cmp edx, EN_CHANGE
    jne .defwndproc
    cmp [updating], 1
    je .defwndproc
    invoke GetDlgItemText, [hwnd], 201, buf, 255
    stdcall ParseHex, buf
    and eax, 0xFF
    mov [val], eax
    stdcall UpdateUI_FromHex
    xor eax, eax
    jmp .finish

.wmdrawitem:
    mov edi, [lparam]
    mov eax, [edi+DIS_CtlID]
    cmp eax, 100
    jl .defwndproc
    cmp eax, 107
    jg .defwndproc
    
    sub eax, 100
    mov ecx, eax
    mov eax, [val]
    bt eax, ecx
    jc .bit_is_1
.bit_is_0:
    invoke CreateSolidBrush, 0x008080FF
    mov ebx, str0
    jmp .draw_bg
.bit_is_1:
    invoke CreateSolidBrush, 0x0080FF80
    mov ebx, str1
.draw_bg:
    push eax
    mov ecx, edi
    add ecx, DIS_rcItem
    invoke FillRect, [edi+DIS_hdc], ecx, eax
    pop eax
    invoke DeleteObject, eax
    
    invoke SelectObject, [edi+DIS_hdc], [hFont]
    push eax
    invoke SetBkMode, [edi+DIS_hdc], TRANSPARENT
    mov ecx, edi
    add ecx, DIS_rcItem
    invoke DrawText, [edi+DIS_hdc], ebx, 1, ecx, DT_CENTER+DT_VCENTER+DT_SINGLELINE
    pop eax
    invoke SelectObject, [edi+DIS_hdc], eax
    
    xor eax, eax
    jmp .finish

.wmdestroy:
    invoke PostQuitMessage, 0
    xor eax, eax

.finish:
    ret
endp

proc UpdateUI
    mov [updating], 1
    stdcall UpdateBits
    stdcall UpdateDec
    stdcall UpdateHex
    mov [updating], 0
    ret
endp

proc UpdateUI_FromDec
    mov [updating], 1
    stdcall UpdateBits
    stdcall UpdateHex
    mov [updating], 0
    ret
endp

proc UpdateUI_FromHex
    mov [updating], 1
    stdcall UpdateBits
    stdcall UpdateDec
    mov [updating], 0
    ret
endp

proc UpdateBits
    mov ecx, 100
.loop:
    push ecx
    invoke GetDlgItem, [hwndMain], ecx
    invoke InvalidateRect, eax, 0, 1
    pop ecx
    inc ecx
    cmp ecx, 108
    jl .loop
    ret
endp

proc UpdateDec
    cinvoke wsprintf, buf, fmtDec, [val]
    invoke SetWindowText, [hwndDec], buf
    ret
endp

proc UpdateHex
    cinvoke wsprintf, buf, fmtHex, [val]
    invoke SetWindowText, [hwndHex], buf
    ret
endp

proc ParseHex str_ptr
    push esi
    mov esi, [str_ptr]
    xor eax, eax
    xor edx, edx
.loop:
    lodsb
    test al, al
    jz .done
    cmp al, '0'
    jb .loop
    cmp al, '9'
    jbe .digit
    or al, 0x20
    cmp al, 'a'
    jb .loop
    cmp al, 'f'
    ja .loop
    sub al, 'a' - 10
    jmp .add
.digit:
    sub al, '0'
.add:
    shl edx, 4
    or dl, al
    jmp .loop
.done:
    mov eax, edx
    pop esi
    ret
endp

section '.idata' import data readable writeable

    library kernel32,'KERNEL32.DLL',\
            user32,'USER32.DLL',\
            gdi32,'GDI32.DLL'

    import kernel32,\
           GetModuleHandle,'GetModuleHandleA',\
           ExitProcess,'ExitProcess'

    import user32,\
           RegisterClass,'RegisterClassA',\
           CreateWindowEx,'CreateWindowExA',\
           DefWindowProc,'DefWindowProcA',\
           GetMessage,'GetMessageA',\
           TranslateMessage,'TranslateMessage',\
           DispatchMessage,'DispatchMessageA',\
           PostQuitMessage,'PostQuitMessage',\
           LoadCursor,'LoadCursorA',\
           GetDlgItem,'GetDlgItem',\
           GetDlgItemInt,'GetDlgItemInt',\
           GetDlgItemText,'GetDlgItemTextA',\
           SetWindowText,'SetWindowTextA',\
           InvalidateRect,'InvalidateRect',\
           SendMessage,'SendMessageA',\
           FillRect,'FillRect',\
           DrawText,'DrawTextA',\
           wsprintf,'wsprintfA'

    import gdi32,\
           GetStockObject,'GetStockObject',\
           CreateSolidBrush,'CreateSolidBrush',\
           DeleteObject,'DeleteObject',\
           SelectObject,'SelectObject',\
           SetBkMode,'SetBkMode'
