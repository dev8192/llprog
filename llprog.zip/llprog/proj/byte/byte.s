; not working
format PE GUI 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    wc WNDCLASS
    msg MSG
    hwndMain dd ?
    hwndBits dd 8 dup(?)
    hwndEditDec dd ?
    hwndEditHex dd ?
    hFont dd ?
    hBrushOne dd ?
    hBrushZero dd ?
    current_byte db 0
    updating db 0

    szClassName db 'ByteVisClass',0
    szTitle db 'Byte Visualizer',0
    szStatic db 'STATIC',0
    szEdit db 'EDIT',0
    szButton db 'BUTTON',0
    szDecLabel db 'Dec:',0
    szHexLabel db 'Hex:',0
    szShiftL db '<<',0
    szShiftR db '>>',0
    szFmtDec db '%u',0
    szFmtHex db '%02X',0
    szOne db '1',0
    szZero db '0',0
    buf db 16 dup(0)

section '.text' code readable executable
start:
    invoke GetModuleHandle, 0
    mov [wc.hInstance], eax
    mov [wc.lpfnWndProc], WindowProc
    invoke LoadCursor, 0, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.hbrBackground], COLOR_BTNFACE+1
    mov [wc.lpszClassName], szClassName
    invoke RegisterClass, wc

    invoke CreateWindowEx, 0, szClassName, szTitle, WSVISIBLE+WSOVERLAPPEDWINDOW-WSMAXIMIZEBOX-WSTHICKFRAME, \
        CWUSEDEFAULT, CWUSEDEFAULT, 310, 180, 0, 0, [wc.hInstance], 0
    mov [hwndMain], eax

    invoke GetStockObject, DEFAULTGUIFONT
    mov [hFont], eax

    invoke CreateSolidBrush, 0x0000AA00
    mov [hBrushOne], eax
    invoke CreateSolidBrush, 0x000000AA
    mov [hBrushZero], eax

msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    test eax, eax
    jz end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp msg_loop

end_loop:
    invoke DeleteObject, [hBrushOne]
    invoke DeleteObject, [hBrushZero]
    invoke ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp [wmsg], WM_CREATE
    je .wmcreate
    cmp [wmsg], WM_COMMAND
    je .wmcommand
    cmp [wmsg], WM_DRAWITEM
    je .wmdrawitem
    cmp [wmsg], WM_DESTROY
    je .wmdestroy
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret

.wmcreate:
    push ebx esi edi
    mov esi, 7
.create_bits:
    mov eax, 7
    sub eax, esi
    imul eax, 30
    add eax, 10
    cmp esi, 3
    jg .no_gap
    add eax, 15
.no_gap:
    mov ebx, eax

    mov eax, 100
    add eax, esi
    invoke CreateWindowEx, 0, szButton, 0, WSCHILD+WSVISIBLE+BS_OWNERDRAW, \
        ebx, 10, 30, 30, [hwnd], eax, [wc.hInstance], 0
    mov [hwndBits+esi4], eax

    dec esi
    jns .create_bits

    invoke CreateWindowEx, 0, szStatic, szDecLabel, WSCHILD+WSVISIBLE, \
        10, 60, 30, 20, [hwnd], 0, [wc.hInstance], 0
    invoke SendMessage, eax, WM_SETFONT, [hFont], FALSE

    invoke CreateWindowEx, WSEXCLIENTEDGE, szEdit, 0, WSCHILD+WSVISIBLE+ES_NUMBER, \
        45, 60, 50, 20, [hwnd], 200, [wc.hInstance], 0
    mov [hwndEditDec], eax
    invoke SendMessage, eax, WM_SETFONT, [hFont], FALSE

    invoke CreateWindowEx, 0, szStatic, szHexLabel, WSCHILD+WSVISIBLE, \
        145, 60, 30, 20, [hwnd], 0, [wc.hInstance], 0
    invoke SendMessage, eax, WM_SETFONT, [hFont], FALSE

    invoke CreateWindowEx, WSEXCLIENTEDGE, szEdit, 0, WSCHILD+WSVISIBLE, \
        180, 60, 50, 20, [hwnd], 201, [wc.hInstance], 0
    mov [hwndEditHex], eax
    invoke SendMessage, eax, WM_SETFONT, [hFont], FALSE

    invoke CreateWindowEx, 0, szButton, szShiftL, WSCHILD+WSVISIBLE, \
        80, 100, 50, 30, [hwnd], 300, [wc.hInstance], 0
    invoke SendMessage, eax, WM_SETFONT, [hFont], FALSE

    invoke CreateWindowEx, 0, szButton, szShiftR, WSCHILD+WSVISIBLE, \
        145, 100, 50, 30, [hwnd], 301, [wc.hInstance], 0
    invoke SendMessage, eax, WM_SETFONT, [hFont], FALSE

    stdcall UpdateUI
    pop edi esi ebx
    xor eax, eax
    ret

.wmcommand:
    mov eax, [wparam]
    mov edx, eax
    shr edx, 16
    and eax, 0xFFFF

    cmp eax, 100
    jl .not_bit
    cmp eax, 107
    jg .not_bit
    sub eax, 100
    mov cl, al
    mov al, 1
    shl al, cl
    xor [current_byte], al
    stdcall UpdateUI
    xor eax, eax
    ret

.not_bit:
    cmp eax, 300
    jne .not_shl
    shl [current_byte], 1
    stdcall UpdateUI
    xor eax, eax
    ret

.not_shl:
    cmp eax, 301
    jne .not_shr
    shr [current_byte], 1
    stdcall UpdateUI
    xor eax, eax
    ret

.not_shr:
    cmp eax, 200
    jne .not_dec
    cmp edx, EN_CHANGE
    jne .cmd_done
    cmp [updating], 1
    je .cmd_done
    invoke GetWindowText, [hwndEditDec], buf, 16
    stdcall ParseDec, buf
    mov [current_byte], al
    stdcall UpdateUI
    xor eax, eax
    ret

.not_dec:
    cmp eax, 201
    jne .cmd_done
    cmp edx, EN_CHANGE
    jne .cmd_done
    cmp [updating], 1
    je .cmd_done
    invoke GetWindowText, [hwndEditHex], buf, 16
    stdcall ParseHex, buf
    mov [current_byte], al
    stdcall UpdateUI
    xor eax, eax
    ret

.cmd_done:
    xor eax, eax
    ret

.wmdrawitem:
    push ebx esi edi
    mov edi, [lparam]
    mov eax, [edi+DRAWITEMSTRUCT.CtlID]
    cmp eax, 100
    jl .draw_done
    cmp eax, 107
    jg .draw_done

    sub eax, 100
    mov cl, al
    mov al, [current_byte]
    shr al, cl
    and eax, 1

    test eax, eax
    jz .is_zero
    mov ebx, [hBrushOne]
    mov esi, szOne
    jmp .draw_bg
.is_zero:
    mov ebx, [hBrushZero]
    mov esi, szZero
.draw_bg:
    lea eax, [edi+DRAWITEMSTRUCT.rcItem]
    invoke FillRect, [edi+DRAWITEMSTRUCT.hDC], eax, ebx

    invoke SetBkMode, [edi+DRAWITEMSTRUCT.hDC], TRANSPARENT
    invoke SetTextColor, [edi+DRAWITEMSTRUCT.hDC], 0x00FFFFFF
    lea eax, [edi+DRAWITEMSTRUCT.rcItem]
    invoke DrawText, [edi+DRAWITEMSTRUCT.hDC], esi, 1, eax, DTCENTER + DTVCENTER + DT_SINGLELINE

.draw_done:
    pop edi esi ebx
    mov eax, 1
    ret

.wmdestroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    ret
endp

proc UpdateUI
    cmp [updating], 1
    je .done
    mov [updating], 1

    mov ecx, 8
.redraw_loop:
    dec ecx
    push ecx
    invoke InvalidateRect, [hwndBits+ecx4], 0, TRUE
    pop ecx
    test ecx, ecx
    jnz .redraw_loop

    movzx eax, [current_byte]
    invoke wsprintf, buf, szFmtDec, eax
    invoke SetWindowText, [hwndEditDec], buf

    movzx eax, [current_byte]
    invoke wsprintf, buf, szFmtHex, eax
    invoke SetWindowText, [hwndEditHex], buf

    mov [updating], 0
.done:
    ret
endp

proc ParseDec strptr
    push ebx esi
    mov esi, [strptr]
    xor eax, eax
    xor ebx, ebx
.loop:
    mov bl, byte [esi]
    test bl, bl
    jz .done
    cmp bl, '0'
    jl .skip
    cmp bl, '9'
    jg .skip
    sub bl, '0'
    imul eax, 10
    add eax, ebx
    cmp eax, 255
    jle .skip
    mov eax, 255
.skip:
    inc esi
    jmp .loop
.done:
    pop esi ebx
    ret
endp

proc ParseHex strptr
    push ebx esi
    mov esi, [strptr]
    xor eax, eax
    xor ebx, ebx
.loop:
    mov bl, byte [esi]
    test bl, bl
    jz .done
    cmp bl, '0'
    jl .skip
    cmp bl, '9'
    jle .digit
    and bl, 0xDF
    cmp bl, 'A'
    jl .skip
    cmp bl, 'F'
    jg .skip
    sub bl, 'A' - 10
    jmp .add
.digit:
    sub bl, '0'
.add:
    shl eax, 4
    add eax, ebx
    cmp eax, 255
    jle .skip
    mov eax, 255
.skip:
    inc esi
    jmp .loop
.done:
    pop esi ebx
    ret
endp

section '.idata' import data readable
    library kernel32,'KERNEL32.DLL',\
            user32,'USER32.DLL',\
            gdi32,'GDI32.DLL'

    include 'api\kernel32.inc'
    include 'api\user32.inc'
    include 'api\gdi32.inc'
