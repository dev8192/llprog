format PE console
entry start

include 'win32a.inc'

DIB_RGB_COLORS = 0

section '.data' data readable writeable
    filename db '0files/screenshot.bmp', 0
    
    header:
        dw 0x4D42
    fsize:
        dd 0
        dw 0, 0
        dd 54
    bmih:
        dd 40
    w:  dd 1920
    h:  dd 1080
        dw 1
        dw 32
        dd 0
    isize:
        dd 0
        dd 0, 0, 0, 0

    hScreenDC dd ?
    hMemDC    dd ?
    hBitmap   dd ?
    pPixels   dd ?
    hFile     dd ?
    written   dd ?

section '.text' code readable executable
start:
    invoke GetDC, 0
    mov [hScreenDC], eax

    invoke CreateCompatibleDC, [hScreenDC]
    mov [hMemDC], eax

    invoke CreateCompatibleBitmap, [hScreenDC], [w], [h]
    mov [hBitmap], eax

    invoke SelectObject, [hMemDC], [hBitmap]
    invoke BitBlt, [hMemDC], 0, 0, [w], [h], [hScreenDC], 0, 0, SRCCOPY

    mov eax, [w]
    imul eax, [h]
    shl eax, 2
    mov [isize], eax
    add eax, 54
    mov [fsize], eax

    invoke GlobalAlloc, GPTR, [isize]
    mov [pPixels], eax

    invoke GetDIBits, [hScreenDC], [hBitmap], 0, [h], [pPixels], bmih, DIB_RGB_COLORS

    invoke CreateFile, filename, GENERIC_WRITE, 0, 0, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0
    mov [hFile], eax

    invoke WriteFile, [hFile], header, 54, written, 0
    invoke WriteFile, [hFile], [pPixels], [isize], written, 0

    invoke CloseHandle, [hFile]
    invoke GlobalFree, [pPixels]
    invoke DeleteObject, [hBitmap]
    invoke DeleteDC, [hMemDC]
    invoke ReleaseDC, 0, [hScreenDC]
    
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
        user32, 'user32.dll',\
        gdi32, 'gdi32.dll'

    import kernel32,\
        CreateFile, 'CreateFileA',\
        WriteFile, 'WriteFile',\
        CloseHandle, 'CloseHandle',\
        GlobalAlloc, 'GlobalAlloc',\
        GlobalFree, 'GlobalFree',\
        ExitProcess, 'ExitProcess'

    import user32,\
        GetDC, 'GetDC',\
        ReleaseDC, 'ReleaseDC',\
        GetSystemMetrics, 'GetSystemMetrics'

    import gdi32,\
        CreateCompatibleDC, 'CreateCompatibleDC',\
        CreateCompatibleBitmap, 'CreateCompatibleBitmap',\
        SelectObject, 'SelectObject',\
        BitBlt, 'BitBlt',\
        GetDIBits, 'GetDIBits',\
        DeleteDC, 'DeleteDC',\
        DeleteObject, 'DeleteObject'
