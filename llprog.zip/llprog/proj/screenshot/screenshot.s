format PE console 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    filename    db 'screenshot.bmp', 0
    err_msg     db 'Error creating screenshot.', 0ah, 0
    success_msg db 'Screenshot saved as screenshot.bmp', 0ah, 0

    align 4
    bmi         BITMAPINFO
    bfh         BITMAPFILEHEADER
    
    scr_width   dd ?
    scr_height  dd ?
    hScreenDC   dd ?
    hMemoryDC   dd ?
    hBitmap     dd ?
    hOldBitmap  dd ?
    hFile       dd ?
    pPixels     dd ?
    dwWritten   dd ?

section '.code' code readable executable
start:
    ; Get screen dimensions
    invoke GetSystemMetrics, SM_CXSCREEN
    mov [scr_width], eax
    invoke GetSystemMetrics, SM_CYSCREEN
    mov [scr_height], eax

    ; Create Device Contexts
    invoke GetDC, 0
    mov [hScreenDC], eax
    invoke CreateCompatibleDC, [hScreenDC]
    mov [hMemoryDC], eax

    ; Setup Bitmap Info for 24-bit RGB
    mov [bmi.bmiHeader.biSize], sizeof.BITMAPINFOHEADER
    mov eax, [scr_width]
    mov [bmi.bmiHeader.biWidth], eax
    mov eax, [scr_height]
    mov [bmi.bmiHeader.biHeight], eax
    mov [bmi.bmiHeader.biPlanes], 1
    mov [bmi.bmiHeader.biBitCount], 24
    mov [bmi.bmiHeader.biCompression], BI_RGB

    ; Create DIB Section (direct access to pixels)
    invoke CreateDIBSection, [hMemoryDC], bmi, DIB_RGB_COLORS, pPixels, 0, 0
    mov [hBitmap], eax
    invoke SelectObject, [hMemoryDC], [hBitmap]
    mov [hOldBitmap], eax

    ; Copy screen to memory bitmap
    invoke BitBlt, [hMemoryDC], 0, 0, [scr_width], [scr_height], [hScreenDC], 0, 0, SRCCOPY

    ; Prepare File Header
    mov [bfh.bfType], 4D42h ; 'BM'
    mov eax, [scr_width]
    imul eax, 3
    add eax, 3
    and eax, not 3 ; padding to 4 bytes
    imul eax, [scr_height]
    add eax, sizeof.BITMAPFILEHEADER + sizeof.BITMAPINFOHEADER
    mov [bfh.bfSize], eax
    mov [bfh.bfOffBits], sizeof.BITMAPFILEHEADER + sizeof.BITMAPINFOHEADER

    ; Save to File
    invoke CreateFile, filename, GENERIC_WRITE, 0, 0, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0
    mov [hFile], eax
    cmp eax, INVALID_HANDLE_VALUE
    je .error

    invoke WriteFile, [hFile], bfh, sizeof.BITMAPFILEHEADER, dwWritten, 0
    invoke WriteFile, [hFile], bmi, sizeof.BITMAPINFOHEADER, dwWritten, 0
    
    ; Calculate row size with padding for WriteFile
    mov eax, [scr_width]
    imul eax, 3
    add eax, 3
    and eax, not 3
    imul eax, [scr_height]
    invoke WriteFile, [hFile], [pPixels], eax, dwWritten, 0
    invoke CloseHandle, [hFile]

    cinvoke printf, success_msg
    jmp .cleanup

.error:
    cinvoke printf, err_msg

.cleanup:
    invoke SelectObject, [hMemoryDC], [hOldBitmap]
    invoke DeleteObject, [hBitmap]
    invoke DeleteDC, [hMemoryDC]
    invoke ReleaseDC, 0, [hScreenDC]
    
    cinvoke _getch
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll', \
            user32,   'user32.dll', \
            gdi32,    'gdi32.dll', \
            msvcrt,   'msvcrt.dll'

    import kernel32, CreateFile, 'CreateFileA', WriteFile, 'WriteFile', \
                     CloseHandle, 'CloseHandle', ExitProcess, 'ExitProcess'
    import user32,   GetDC, 'GetDC', ReleaseDC, 'ReleaseDC', \
                     GetSystemMetrics, 'GetSystemMetrics'
    import gdi32,    CreateCompatibleDC, 'CreateCompatibleDC', \
                     CreateDIBSection, 'CreateDIBSection', \
                     SelectObject, 'SelectObject', BitBlt, 'BitBlt', \
                     DeleteDC, 'DeleteDC', DeleteObject, 'DeleteObject'
    import msvcrt,   printf, 'printf', _getch, '_getch'
