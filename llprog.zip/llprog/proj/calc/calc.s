format PE GUI 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable

    cls_name        db 'FasmCalc', 0
    wnd_title       db 'Calculator', 0
    btn_cls         db 'BUTTON', 0
    edt_cls         db 'EDIT', 0
    fmt_d           db '%d', 0

    wc              WNDCLASS
    msg             MSG

    hwnd_edit       dd ?

    val1            dd 0
    val2            dd 0
    curr_op         dd 0
    new_num         dd 1

    disp_buf        rb 32
    
    t0              db '0', 0
    t1              db '1', 0
    t2              db '2', 0
    t3              db '3', 0
    t4              db '4', 0
    t5              db '5', 0
    t6              db '6', 0
    t7              db '7', 0
    t8              db '8', 0
    t9              db '9', 0
    tA              db '+', 0
    tS              db '-', 0
    tM              db '*', 0
    tD              db '/', 0
    tE              db '=', 0
    tC              db 'C', 0

    btn_data:
        dd 10, 45, 40, 40, 1007, t7
        dd 55, 45, 40, 40, 1008, t8
        dd 100, 45, 40, 40, 1009, t9
        dd 145, 45, 40, 40, 1013, tD
        dd 10, 90, 40, 40, 1004, t4
        dd 55, 90, 40, 40, 1005, t5
        dd 100, 90, 40, 40, 1006, t6
        dd 145, 90, 40, 40, 1012, tM
        dd 10, 135, 40, 40, 1001, t1
        dd 55, 135, 40, 40, 1002, t2
        dd 100, 135, 40, 40, 1003, t3
        dd 145, 135, 40, 40, 1011, tS
        dd 10, 180, 40, 40, 1015, tC
        dd 55, 180, 40, 40, 1000, t0
        dd 100, 180, 40, 40, 1014, tE
        dd 145, 180, 40, 40, 1010, tA
    btn_count = 16

section '.text' code readable executable

start:
    mov     [wc.style], CS_HREDRAW or CS_VREDRAW
    mov     [wc.lpfnWndProc], WindowProc
    mov     [wc.cbClsExtra], 0
    mov     [wc.cbWndExtra], 0
    invoke  GetModuleHandle, 0
    mov     [wc.hInstance], eax
    invoke  LoadIcon, 0, IDI_APPLICATION
    mov     [wc.hIcon], eax
    invoke  LoadCursor, 0, IDC_ARROW
    mov     [wc.hCursor], eax
    mov     [wc.hbrBackground], COLOR_BTNFACE + 1
    mov     [wc.lpszMenuName], 0
    mov     [wc.lpszClassName], cls_name
    invoke  RegisterClass, wc
    invoke  CreateWindowEx, 0, cls_name, wnd_title,\
        WS_VISIBLE + WS_OVERLAPPEDWINDOW - WS_MAXIMIZEBOX - WS_THICKFRAME,\
        100, 100, 210, 270, 0, 0, [wc.hInstance], 0

msg_loop:
    invoke  GetMessage, msg, 0, 0, 0
    cmp     eax, 0
    je      end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     msg_loop

end_loop:
    invoke  ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    push    ebx esi edi
    cmp     [wmsg], WM_CREATE
    je      .wmcreate
    cmp     [wmsg], WM_COMMAND
    je      .wmcommand
    cmp     [wmsg], WM_DESTROY
    je      .wmdestroy
.defwndproc:
    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    jmp     .finish
.wmcreate:
    ;invoke  CreateWindowEx, WS_EX_CLIENTEDGE, edt_cls, t0,\
    ;    WS_CHILD + WS_VISIBLE + ES_RIGHT + ES_READONLY,
    ;    10, 10, 175, 25, [hwnd], 100, [wc.hInstance], 0
    invoke  CreateWindowEx, \
        WS_EX_CLIENTEDGE, \                          ; DWORD dwExStyle
        edt_cls, \                                   ; LPCSTR lpClassName
        t0, \                                        ; LPCSTR lpWindowName
        WS_CHILD + \
        WS_VISIBLE + \
        ES_RIGHT + \
        ES_READONLY, \                               ; DWORD dwStyle
        10, \                                        ; int X
        10, \                                        ; int Y
        175, \                                       ; int nWidth
        25, \                                        ; int nHeight
        [hwnd], \                                    ; HWND hWndParent
        100, \                                       ; HMENU hMenu
        [wc.hInstance], \                                   ; HINSTANCE hInstance
        0                                            ; LPVOID lpParam
    mov     [hwnd_edit], eax
    mov     esi, btn_data
    mov     ecx, btn_count
.btn_loop:
    push    ecx
    invoke  CreateWindowEx, 0, btn_cls, dword [esi+20],\
        WS_CHILD + WS_VISIBLE + BS_PUSHBUTTON,\
        dword [esi+0], dword [esi+4], dword [esi+8], dword [esi+12],\
        [hwnd], dword [esi+16], [wc.hInstance], 0
    add     esi, 24
    pop     ecx
    loop    .btn_loop
    xor     eax, eax
    jmp     .finish
.wmcommand:
    mov     eax, [wparam]
    and     eax, 0FFFFh
    cmp     eax, 1000
    jl      .defwndproc
    cmp     eax, 1009
    jle     .num_pressed
    cmp     eax, 1013
    jle     .op_pressed
    cmp     eax, 1014
    je      .eq_pressed
    cmp     eax, 1015
    je      .clr_pressed
    jmp     .defwndproc
.num_pressed:
    sub     eax, 1000
    push    eax
    cmp     [new_num], 1
    jne     .append_num
    pop     eax
    mov     [val1], eax
    mov     [new_num], 0
    jmp     .update_disp
.append_num:
    mov     eax, [val1]
    imul    eax, 10
    pop     ebx
    add     eax, ebx
    mov     [val1], eax
    jmp     .update_disp
.op_pressed:
    mov     [curr_op], eax
    mov     eax, [val1]
    mov     [val2], eax
    mov     [new_num], 1
    jmp     .finish
.eq_pressed:
    mov     eax, [curr_op]
    cmp     eax, 1010
    je      .do_add
    cmp     eax, 1011
    je      .do_sub
    cmp     eax, 1012
    je      .do_mul
    cmp     eax, 1013
    je      .do_div
    jmp     .finish
.do_add:
    mov     eax, [val2]
    add     eax, [val1]
    mov     [val1], eax
    jmp     .calc_done
.do_sub:
    mov     eax, [val2]
    sub     eax, [val1]
    mov     [val1], eax
    jmp     .calc_done
.do_mul:
    mov     eax, [val2]
    imul    eax, [val1]
    mov     [val1], eax
    jmp     .calc_done
.do_div:
    cmp     [val1], 0
    je      .clr_pressed
    mov     eax, [val2]
    cdq
    idiv    dword [val1]
    mov     [val1], eax
.calc_done:
    mov     [curr_op], 0
    mov     [new_num], 1
    jmp     .update_disp
.clr_pressed:
    mov     [val1], 0
    mov     [val2], 0
    mov     [curr_op], 0
    mov     [new_num], 1
.update_disp:
    cinvoke wsprintf, disp_buf, fmt_d, [val1]
    invoke  SetWindowText, [hwnd_edit], disp_buf
    xor     eax, eax
    jmp     .finish
.wmdestroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
.finish:
    pop     edi esi ebx
    ret
endp

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL',\
            user32, 'USER32.DLL'

    include 'api\kernel32.inc'
    include 'api\user32.inc'
