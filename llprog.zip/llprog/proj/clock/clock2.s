format PE GUI 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    wc WNDCLASSEX
    msg MSG
    ps PAINTSTRUCT
    time SYSTEMTIME

    hwnd dd ?
    hdc dd ?
    hPenHour dd ?
    hPenMin dd ?
    hPenSec dd ?

    classname db 'AnalogClockClass', 0
    title db 'Analog Clock', 0
    fmt_d db '%d', 0
    num_str db 16 dup(0)

    n dd ?
    num_x dd ?
    num_y dd ?
    num_dx dd ?
    num_dy dd ?

    hx dd ?
    hy dd ?
    hdx dd ?
    hdy dd ?

    temp_int dd ?
    f_sec dd ?
    f_min dd ?
    f_hour dd ?

    a_sec dd ?
    a_min dd ?
    a_hour dd ?

    c60 dd 60.0
    rad_per_60 dd 0.1047197551
    rad_per_12 dd 0.5235987756
    r_num dd 125

section '.text' code readable executable
start:
    mov [wc.cbSize], sizeof.WNDCLASSEX
    mov [wc.style], CS_HREDRAW or CS_VREDRAW
    mov [wc.lpfnWndProc], WindowProc
    mov [wc.cbClsExtra], 0
    mov [wc.cbWndExtra], 0
    invoke GetModuleHandle, 0
    mov [wc.hInstance], eax
    invoke LoadIcon, 0, IDI_APPLICATION
    mov [wc.hIcon], eax
    mov [wc.hIconSm], eax
    invoke LoadCursor, 0, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.hbrBackground], COLOR_WINDOW+1
    mov [wc.lpszMenuName], 0
    mov [wc.lpszClassName], classname
    invoke RegisterClassEx, wc

    invoke CreateWindowEx, 0, classname, title, WS_OVERLAPPEDWINDOW or WS_VISIBLE, \
        CW_USEDEFAULT, CW_USEDEFAULT, 420, 440, 0, 0, [wc.hInstance], 0
    mov [hwnd], eax

    invoke ShowWindow, [hwnd], SW_SHOW
    invoke UpdateWindow, [hwnd]

.msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    cmp eax, 0
    jle .end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp .msg_loop

.end_loop:
    invoke ExitProcess, [msg.wParam]

proc WindowProc wnd, wmsg, wparam, lparam
    cmp [wmsg], WM_DESTROY
    je .wmdestroy
    cmp [wmsg], WM_PAINT
    je .wmpaint
    cmp [wmsg], WM_CREATE
    je .wmcreate
    cmp [wmsg], WM_TIMER
    je .wmtimer

.defwndproc:
    invoke DefWindowProc, [wnd], [wmsg], [wparam], [lparam]
    ret

.wmcreate:
    invoke SetTimer, [wnd], 1, 1000, 0
    invoke CreatePen, PS_SOLID, 5, 0x00000000
    mov [hPenHour], eax
    invoke CreatePen, PS_SOLID, 3, 0x00000000
    mov [hPenMin], eax
    invoke CreatePen, PS_SOLID, 1, 0x000000FF
    mov [hPenSec], eax
    xor eax, eax
    ret

.wmtimer:
    invoke InvalidateRect, [wnd], 0, TRUE
    xor eax, eax
    ret

.wmpaint:
    invoke BeginPaint, [wnd], ps
    mov [hdc], eax

    finit

    invoke Ellipse, [hdc], 50, 50, 350, 350

    invoke SetTextAlign, [hdc], TA_CENTER or TA_BASELINE
    invoke SetBkMode, [hdc], TRANSPARENT
    mov [n], 1

.num_loop:
    fild dword [n]
    fmul dword [rad_per_12]
    fsincos
    fild dword [r_num]
    fld st0
    fmulp st2, st0
    fmulp st2, st0
    fistp dword [num_dy]
    fistp dword [num_dx]

    mov eax, 200
    add eax, [num_dx]
    mov [num_x], eax

    mov eax, 200
    sub eax, [num_dy]
    add eax, 5
    mov [num_y], eax

    cinvoke wsprintf, num_str, fmt_d, [n]
    invoke TextOut, [hdc], [num_x], [num_y], num_str, eax

    inc [n]
    cmp [n], 12
    jle .num_loop

    invoke GetLocalTime, time

    fild word [time.wSecond]
    fst dword [f_sec]
    fdiv dword [c60]
    fild word [time.wMinute]
    faddp st1, st0
    fst dword [f_min]
    fdiv dword [c60]
    movzx eax, word [time.wHour]
    cmp eax, 12
    jl .h_ok
    sub eax, 12
.h_ok:
    mov [temp_int], eax
    fild dword [temp_int]
    faddp st1, st0
    fstp dword [f_hour]

    fld dword [f_sec]
    fmul dword [rad_per_60]
    fstp dword [a_sec]

    fld dword [f_min]
    fmul dword [rad_per_60]
    fstp dword [a_min]

    fld dword [f_hour]
    fmul dword [rad_per_12]
    fstp dword [a_hour]

    stdcall DrawHand, [hdc], 200, 200, [a_hour], 70, [hPenHour]
    stdcall DrawHand, [hdc], 200, 200, [a_min], 110, [hPenMin]
    stdcall DrawHand, [hdc], 200, 200, [a_sec], 135, [hPenSec]

    invoke EndPaint, [wnd], ps
    xor eax, eax
    ret

.wmdestroy:
    invoke KillTimer, [wnd], 1
    invoke DeleteObject, [hPenHour]
    invoke DeleteObject, [hPenMin]
    invoke DeleteObject, [hPenSec]
    invoke PostQuitMessage, 0
    xor eax, eax
    ret
endp

proc DrawHand hdc, cx, cy, angle, length, hPen
    invoke SelectObject, [hdc], [hPen]
    push eax

    invoke MoveToEx, [hdc], [cx], [cy], 0
    fld dword [angle]
    fsincos
    fild dword [length]
    fld st0
    fmulp st2, st0
    fmulp st2, st0
    fistp dword [hdy]
    fistp dword [hdx]

    mov eax, [cx]
    add eax, [hdx]
    mov [hx], eax

    mov eax, [cy]
    sub eax, [hdy]
    mov [hy], eax

    invoke LineTo, [hdc], [hx], [hy]

    pop eax
    invoke SelectObject, [hdc], eax
    ret
endp

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL', \
        user32, 'USER32.DLL', \
        gdi32, 'GDI32.DLL'

    import kernel32, \
        GetModuleHandle, 'GetModuleHandleA', \
        GetLocalTime, 'GetLocalTime', \
        ExitProcess, 'ExitProcess'

    import user32, \
        RegisterClassEx, 'RegisterClassExA', \
        CreateWindowEx, 'CreateWindowExA', \
        DefWindowProc, 'DefWindowProcA', \
        GetMessage, 'GetMessageA', \
        TranslateMessage, 'TranslateMessage', \
        DispatchMessage, 'DispatchMessageA', \
        LoadCursor, 'LoadCursorA', \
        LoadIcon, 'LoadIconA', \
        SetTimer, 'SetTimer', \
        KillTimer, 'KillTimer', \
        InvalidateRect, 'InvalidateRect', \
        BeginPaint, 'BeginPaint', \
        EndPaint, 'EndPaint', \
        ShowWindow, 'ShowWindow', \
        UpdateWindow, 'UpdateWindow', \
        wsprintf, 'wsprintfA', \
        PostQuitMessage, 'PostQuitMessage'

    import gdi32, \
        CreatePen, 'CreatePen', \
        SelectObject, 'SelectObject', \
        DeleteObject, 'DeleteObject', \
        Ellipse, 'Ellipse', \
        MoveToEx, 'MoveToEx', \
        LineTo, 'LineTo', \
        SetTextAlign, 'SetTextAlign', \
        SetBkMode, 'SetBkMode', \
        TextOut, 'TextOutA'
