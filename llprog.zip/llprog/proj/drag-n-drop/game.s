format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    hwnd        dd ?
    wc          WNDCLASS
    msg         MSG
    ps          PAINTSTRUCT

    szClass     db 'ColorGameApp', 0
    szTitle     db 'Color Match Game', 0
    szWin       db 'You Win! Play again?', 0
    szLose      db 'You Lose! Play again?', 0
    szBoxTitle  db 'Game Over', 0
    color_fmt   db '%x', 10, 0

    seed        dd 0

    colors      dd 0x000000FF, 0x0000FF00, 0x00FF0000
    rects       dd 40, 40, 120, 120
                dd 150, 40, 230, 120
                dd 260, 40, 340, 120

circleX_def = 150
circleY_def = 160

    circleX     dd circleX_def
    circleY     dd circleY_def
    circleCol   dd 0

    isDragging  dd 0
    dragOffX    dd 0
    dragOffY    dd 0

section '.text' code readable executable

start:
    invoke  GetTickCount
    mov     [seed], eax

    mov     [wc.style], CS_HREDRAW or CS_VREDRAW
    mov     [wc.lpfnWndProc], WindowProc
    invoke  GetModuleHandle, 0
    mov     [wc.hInstance], eax
    invoke  LoadIcon, 0, IDI_APPLICATION
    mov     [wc.hIcon], eax
    invoke  LoadCursor, 0, IDC_ARROW
    mov     [wc.hCursor], eax
    mov     [wc.hbrBackground], COLOR_WINDOW + 1
    mov     [wc.lpszClassName], szClass
    invoke  RegisterClass, wc

    invoke  CreateWindowEx, 0, szClass, szTitle,\
            WS_VISIBLE or WS_OVERLAPPEDWINDOW xor WS_THICKFRAME xor WS_MAXIMIZEBOX,\
            CW_USEDEFAULT, CW_USEDEFAULT, 400, 320, 0, 0, [wc.hInstance], 0
    mov     [hwnd], eax

    call    ResetGame

msg_loop:
    invoke  GetMessage, msg, 0, 0, 0
    test    eax, eax
    jz      end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     msg_loop

end_loop:
    invoke  ExitProcess, [msg.wParam]

proc ResetGame
    mov     eax, [seed]
    imul    eax, 214013
    add     eax, 2531011
    mov     [seed], eax
    shr     eax, 16
    mov     ecx, 3
    xor     edx, edx
    div     ecx

    mov     [circleCol], edx
    mov     [circleX], circleX_def
    mov     [circleY], circleY_def

    cinvoke printf, color_fmt, [circleCol]

    cmp     [hwnd], 0
    je      .done
    invoke  InvalidateRect, [hwnd], 0, TRUE
.done:
    ret
endp

proc WindowProc hwnd_p, wmsg, wparam, lparam
    push    ebx esi edi

    cmp     [wmsg], WM_PAINT
    je      .wmpaint
    cmp     [wmsg], WM_LBUTTONDOWN
    je      .wmlbuttondown
    cmp     [wmsg], WM_MOUSEMOVE
    je      .wmmousemove
    cmp     [wmsg], WM_LBUTTONUP
    je      .wmlbuttonup
    cmp     [wmsg], WM_DESTROY
    je      .wmdestroy

.defwndproc:
    pop     edi esi ebx
    invoke  DefWindowProc, [hwnd_p], [wmsg], [wparam], [lparam]
    ret

.wmpaint:
    invoke  BeginPaint, [hwnd_p], ps

    mov     esi, 0
    mov     edi, rects
.draw_boxes:
    mov     eax, [colors + esi*4]
    invoke  CreateSolidBrush, eax
    push    eax
    invoke  FillRect, [ps.hdc], edi, eax
    pop     eax
    invoke  DeleteObject, eax
    
    add     edi, 16
    inc     esi
    cmp     esi, 3
    jl      .draw_boxes

    mov     eax, [circleCol]
    mov     eax, [colors + eax*4]
    invoke  CreateSolidBrush, eax
    mov     ebx, eax
    invoke  SelectObject, [ps.hdc], ebx
    mov     esi, eax

    mov     ecx, [circleX]
    mov     edx, [circleY]
    mov     edi, ecx
    add     edi, 80
    push    edx
    add     edx, 80
    pop     eax
    invoke  Ellipse, [ps.hdc], ecx, eax, edi, edx

    invoke  SelectObject, [ps.hdc], esi
    invoke  DeleteObject, ebx

    invoke  EndPaint, [hwnd_p], ps
    jmp     .finish

.wmlbuttondown:
    mov     eax, [lparam]
    movsx   ebx, ax
    shr     eax, 16
    movsx   ecx, ax

    mov     edx, [circleX]
    cmp     ebx, edx
    jl      .finish
    add     edx, 80
    cmp     ebx, edx
    jg      .finish

    mov     edx, [circleY]
    cmp     ecx, edx
    jl      .finish
    add     edx, 80
    cmp     ecx, edx
    jg      .finish

    mov     [isDragging], 1
    sub     ebx, [circleX]
    mov     [dragOffX], ebx
    sub     ecx, [circleY]
    mov     [dragOffY], ecx
    invoke  SetCapture, [hwnd_p]
    jmp     .finish

.wmmousemove:
    cmp     [isDragging], 1
    jne     .finish

    mov     eax, [lparam]
    movsx   ebx, ax
    shr     eax, 16
    movsx   ecx, ax

    sub     ebx, [dragOffX]
    sub     ecx, [dragOffY]
    mov     [circleX], ebx
    mov     [circleY], ecx

    invoke  InvalidateRect, [hwnd_p], 0, TRUE
    jmp     .finish

.wmlbuttonup:
    cmp     [isDragging], 1
    jne     .finish
    mov     [isDragging], 0
    invoke  ReleaseCapture

    mov     ebx, [circleX]
    add     ebx, 40
    mov     ecx, [circleY]
    add     ecx, 40

    cmp     ecx, 40
    jl      .miss
    cmp     ecx, 120
    jg      .miss

    cmp     ebx, 40
    jl      .miss
    cmp     ebx, 120
    jle     .hit_red

    cmp     ebx, 150
    jl      .miss
    cmp     ebx, 230
    jle     .hit_green

    cmp     ebx, 260
    jl      .miss
    cmp     ebx, 340
    jle     .hit_blue
    jmp     .miss

.hit_red:
    mov     eax, 0
    jmp     .check_win
.hit_green:
    mov     eax, 1
    jmp     .check_win
.hit_blue:
    mov     eax, 2
    jmp     .check_win

.check_win:
    cmp     eax, [circleCol]
    je      .win
    invoke  MessageBox, [hwnd_p], szLose, szBoxTitle, MB_YESNO or MB_ICONQUESTION
    jmp     .after_msg
.win:
    invoke  MessageBox, [hwnd_p], szWin, szBoxTitle, MB_YESNO or MB_ICONQUESTION

.after_msg:
    cmp     eax, IDYES
    je      .do_reset
    invoke  DestroyWindow, [hwnd_p]
    jmp     .finish

.do_reset:
    call    ResetGame
    jmp     .finish

.miss:
    mov     [circleX], circleX_def
    mov     [circleY], circleY_def
    invoke  InvalidateRect, [hwnd_p], 0, TRUE
    jmp     .finish

.wmdestroy:
    invoke  PostQuitMessage, 0
    
.finish:
    pop     edi esi ebx
    xor     eax, eax
    ret
endp

section '.idata' import data readable writeable
    library kernel32, 'KERNEL32.DLL',\
            user32, 'USER32.DLL',\
            gdi32, 'GDI32.DLL',\
            msvcrt, 'MSVCRT.DLL'

    import kernel32,\
        ExitProcess, 'ExitProcess',\
        GetModuleHandle, 'GetModuleHandleA',\
        GetTickCount, 'GetTickCount'

    import user32,\
        BeginPaint, 'BeginPaint',\
        CreateWindowEx, 'CreateWindowExA',\
        DefWindowProc, 'DefWindowProcA',\
        DestroyWindow, 'DestroyWindow',\
        DispatchMessage, 'DispatchMessageA',\
        EndPaint, 'EndPaint',\
        FillRect, 'FillRect',\
        GetMessage, 'GetMessageA',\
        InvalidateRect, 'InvalidateRect',\
        LoadCursor, 'LoadCursorA',\
        LoadIcon, 'LoadIconA',\
        MessageBox, 'MessageBoxA',\
        PostQuitMessage, 'PostQuitMessage',\
        RegisterClass, 'RegisterClassA',\
        ReleaseCapture, 'ReleaseCapture',\
        SetCapture, 'SetCapture',\
        TranslateMessage, 'TranslateMessage'

    import gdi32,\
        CreateSolidBrush, 'CreateSolidBrush',\
        DeleteObject, 'DeleteObject',\
        Ellipse, 'Ellipse',\
        SelectObject, 'SelectObject'

    import msvcrt,\
        printf, 'printf'
