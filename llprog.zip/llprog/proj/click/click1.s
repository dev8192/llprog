format PE GUI
include 'win32a.inc'

IDC_LABEL   = 100
IDC_CANVAS  = 101

;------------------------------------------------------------------------------
section '.data' data readable writeable
    className       db 'FasmCanvasClass',0
    canvasClassName db 'CanvasChildClass',0
    windowTitle     db 'Canvas Click Example',0
    labelInitText   db 'Click on canvas',0
    coordFormat     db 'X: %d, Y: %d',0
    errorCaption    db 'Error',0
    errorText       db 'Failed to create window.',0

    hInstance       dd ?
    hLabel          dd ?

;------------------------------------------------------------------------------
section '.code' code readable executable
start:
    invoke  GetModuleHandle,0
    mov     [hInstance], eax
    call    WinMain
    invoke  ExitProcess, eax

;------------------------------------------------------------------------------
WinMain:
    push    ebp
    mov     ebp, esp
    sub     esp, 4          ; for msg

    ; Register main window class
    push    [hInstance]
    push    offset className
    call    RegisterMainClass
    test    eax, eax
    jz      .error

    ; Register canvas child class
    push    [hInstance]
    push    offset canvasClassName
    call    RegisterCanvasClass
    test    eax, eax
    jz      .error

    ; Create main window
    invoke  CreateWindowEx, 0, className, windowTitle, \
            WS_VISIBLE+WS_OVERLAPPEDWINDOW, \
            CW_USEDEFAULT, CW_USEDEFAULT, 400, 300, \
            NULL, NULL, [hInstance], NULL
    test    eax, eax
    jz      .error

    ; Message loop
.message_loop:
    invoke  GetMessage, esp, NULL, 0, 0
    test    eax, eax
    jz      .end_loop
    invoke  TranslateMessage, esp
    invoke  DispatchMessage, esp
    jmp     .message_loop

.end_loop:
    mov     eax, [esp+8]    ; wParam from message
    leave
    ret

.error:
    invoke  MessageBox, NULL, errorText, errorCaption, MB_OK
    mov     eax, 1
    leave
    ret

;------------------------------------------------------------------------------
RegisterMainClass:
    push    ebp
    mov     ebp, esp
    sub     esp, sizeof.WNDCLASS

    mov     [esp+WNDCLASS.style], CS_HREDRAW+CS_VREDRAW
    mov     [esp+WNDCLASS.lpfnWndProc], WndProc
    mov     [esp+WNDCLASS.cbClsExtra], 0
    mov     [esp+WNDCLASS.cbWndExtra], 0
    mov     eax, [ebp+8]                ; hInstance
    mov     [esp+WNDCLASS.hInstance], eax
    invoke  LoadIcon, 0, IDI_APPLICATION
    mov     [esp+WNDCLASS.hIcon], eax
    invoke  LoadCursor, 0, IDC_ARROW
    mov     [esp+WNDCLASS.hCursor], eax
    mov     [esp+WNDCLASS.hbrBackground], COLOR_WINDOW+1
    mov     [esp+WNDCLASS.lpszMenuName], 0
    mov     eax, [ebp+12]               ; className
    mov     [esp+WNDCLASS.lpszClassName], eax

    invoke  RegisterClass, esp
    leave
    ret     8

;------------------------------------------------------------------------------
RegisterCanvasClass:
    push    ebp
    mov     ebp, esp
    sub     esp, sizeof.WNDCLASS

    mov     [esp+WNDCLASS.style], CS_HREDRAW+CS_VREDRAW
    mov     [esp+WNDCLASS.lpfnWndProc], CanvasProc
    mov     [esp+WNDCLASS.cbClsExtra], 0
    mov     [esp+WNDCLASS.cbWndExtra], 0
    mov     eax, [ebp+8]                ; hInstance
    mov     [esp+WNDCLASS.hInstance], eax
    invoke  LoadIcon, 0, IDI_APPLICATION
    mov     [esp+WNDCLASS.hIcon], eax
    invoke  LoadCursor, 0, IDC_ARROW
    mov     [esp+WNDCLASS.hCursor], eax
    mov     [esp+WNDCLASS.hbrBackground], COLOR_WINDOW+1
    mov     [esp+WNDCLASS.lpszMenuName], 0
    mov     eax, [ebp+12]               ; className
    mov     [esp+WNDCLASS.lpszClassName], eax

    invoke  RegisterClass, esp
    leave
    ret     8

;------------------------------------------------------------------------------
WndProc:
    push    ebp
    mov     ebp, esp
    push    ebx esi edi

    cmp     dword [ebp+12], WM_CREATE
    je      .wm_create
    cmp     dword [ebp+12], WM_DESTROY
    je      .wm_destroy
    cmp     dword [ebp+12], WM_SIZE
    je      .wm_size

.def:
    invoke  DefWindowProc, [ebp+8], [ebp+12], [ebp+16], [ebp+20]
    jmp     .finish

.wm_create:
    ; Create canvas child
    invoke  CreateWindowEx, 0, canvasClassName, NULL, \
            WS_CHILD+WS_VISIBLE, \
            0, 0, 0, 0, \
            [ebp+8], IDC_CANVAS, [hInstance], NULL
    test    eax, eax
    jz      .create_fail

    ; Create label child
    invoke  CreateWindowEx, 0, 'STATIC', labelInitText, \
            WS_CHILD+WS_VISIBLE+SS_SUNKEN, \
            0, 0, 0, 0, \
            [ebp+8], IDC_LABEL, [hInstance], NULL
    test    eax, eax
    jz      .create_fail
    mov     [hLabel], eax

    xor     eax, eax
    jmp     .finish

.create_fail:
    xor     eax, eax
    jmp     .finish

.wm_size:
    ; Resize children: canvas takes top, label fixed at bottom
    mov     ecx, [ebp+16]               ; width
    mov     edx, [ebp+20]                ; height
    sub     edx, 30                      ; leave 30 pixels for label
    ; Move canvas (IDC_CANVAS) to fill above label
    invoke  GetDlgItem, [ebp+8], IDC_CANVAS
    invoke  MoveWindow, eax, 0, 0, ecx, edx, TRUE
    ; Move label to bottom
    invoke  GetDlgItem, [ebp+8], IDC_LABEL
    invoke  MoveWindow, eax, 0, edx, ecx, 30, TRUE
    xor     eax, eax
    jmp     .finish

.wm_destroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
    jmp     .finish

.finish:
    pop     edi esi ebx
    leave
    ret     16

;------------------------------------------------------------------------------
CanvasProc:
    push    ebp
    mov     ebp, esp
    push    ebx esi edi

    cmp     dword [ebp+12], WM_LBUTTONDOWN
    je      .wm_lbuttondown
    cmp     dword [ebp+12], WM_PAINT
    je      .wm_paint
    cmp     dword [ebp+12], WM_ERASEBKGND
    je      .wm_erase

.def:
    invoke  DefWindowProc, [ebp+8], [ebp+12], [ebp+16], [ebp+20]
    jmp     .finish

.wm_lbuttondown:
    ; Get coordinates (x = low word of lParam, y = high word)
    mov     eax, [ebp+20]                ; lParam
    movzx   ecx, ax                       ; x
    shr     eax, 16                       ; y
    push    eax ecx

    ; Format string
    sub     esp, 32                       ; buffer
    push    eax                            ; y
    push    ecx                            ; x
    push    offset coordFormat
    push    esp+12                         ; buffer (after pushes, stack is messy)
    call    [wsprintfA]
    add     esp, 16                        ; clean arguments (4*4)

    ; Get parent window
    invoke  GetParent, [ebp+8]
    ; Get label handle
    invoke  GetDlgItem, eax, IDC_LABEL
    ; Set label text
    invoke  SetWindowText, eax, esp+4      ; buffer is at esp+4 now? careful
    add     esp, 32
    xor     eax, eax
    jmp     .finish

.wm_paint:
    ; Fill canvas with light gray
    invoke  BeginPaint, [ebp+8], esp-8
    push    eax
    invoke  GetStockObject, LTGRAY_BRUSH
    push    eax
    push    [eax+4]                        ; hdc from BeginPaint (PAINTSTRUCT.hdc)
    call    [FillRect]
    invoke  EndPaint, [ebp+8], esp-8
    xor     eax, eax
    jmp     .finish

.wm_erase:
    ; Return non-zero to avoid flicker (we paint everything in WM_PAINT)
    mov     eax, 1
    jmp     .finish

.finish:
    pop     edi esi ebx
    leave
    ret     16

;------------------------------------------------------------------------------
section '.idata' import data readable writeable
    library kernel32, 'kernel32.dll', \
            user32, 'user32.dll', \
            gdi32, 'gdi32.dll'

    import kernel32, \
           GetModuleHandle, 'GetModuleHandleA', \
           ExitProcess, 'ExitProcess'

    import user32, \
           RegisterClass, 'RegisterClassA', \
           CreateWindowEx, 'CreateWindowExA', \
           DefWindowProc, 'DefWindowProcA', \
           GetMessage, 'GetMessageA', \
           TranslateMessage, 'TranslateMessage', \
           DispatchMessage, 'DispatchMessageA', \
           MessageBox, 'MessageBoxA', \
           LoadIcon, 'LoadIconA', \
           LoadCursor, 'LoadCursorA', \
           PostQuitMessage, 'PostQuitMessage', \
           GetDlgItem, 'GetDlgItem', \
           MoveWindow, 'MoveWindow', \
           SetWindowText, 'SetWindowTextA', \
           GetParent, 'GetParent', \
           BeginPaint, 'BeginPaint', \
           EndPaint, 'EndPaint', \
           wsprintfA, 'wsprintfA'

    import gdi32, \
           GetStockObject, 'GetStockObject', \
           FillRect, 'FillRect'
