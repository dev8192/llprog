; works
format PE GUI 4.0
entry start

include 'win32a.inc'

section '.text' code readable executable

start:
    invoke  GetModuleHandle, 0
    mov     [wc.hInstance], eax
    invoke  LoadIcon, 0, IDI_APPLICATION
    mov     [wc.hIcon], eax
    invoke  LoadCursor, 0, IDC_ARROW
    mov     [wc.hCursor], eax
    mov     [wc.style], 0
    mov     [wc.lpfnWndProc], WindowProc
    mov     [wc.cbClsExtra], 0
    mov     [wc.cbWndExtra], 0
    mov     [wc.hbrBackground], COLOR_BTNFACE+1
    mov     [wc.lpszMenuName], 0
    mov     [wc.lpszClassName], _main_class
    invoke  RegisterClass, wc

    mov     [wc.lpfnWndProc], CanvasProc
    mov     [wc.hbrBackground], COLOR_WINDOW+1
    mov     [wc.lpszClassName], _canvas_class
    invoke  RegisterClass, wc

    invoke  CreateWindowEx, 0, _main_class, _title, WS_VISIBLE+WS_OVERLAPPEDWINDOW, 100, 100, 440, 400, 0, 0, [wc.hInstance], 0
    mov     [hwnd_main], eax

msg_loop:
    invoke  GetMessage, msg, 0, 0, 0
    cmp     eax, 0
    je      end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     msg_loop

end_loop:
    invoke  ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp     [wmsg], WM_CREATE
    je      .wmcreate
    cmp     [wmsg], WM_DESTROY
    je      .wmdestroy

.defwndproc:
    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    jmp     .finish

.wmcreate:
    invoke  CreateWindowEx, 0, _static_class, _initial_text, WS_CHILD+WS_VISIBLE, 10, 10, 200, 20, [hwnd], 100, [wc.hInstance], 0
    invoke  CreateWindowEx, WS_EX_CLIENTEDGE, _canvas_class, 0, WS_CHILD+WS_VISIBLE, 10, 40, 400, 300, [hwnd], 101, [wc.hInstance], 0
    xor     eax, eax
    jmp     .finish

.wmdestroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax

.finish:
    ret
endp

proc CanvasProc hwnd, wmsg, wparam, lparam
    cmp     [wmsg], WM_LBUTTONDOWN
    je      .wmlbuttondown

.defwndproc:
    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    jmp     .finish

.wmlbuttondown:
    mov     eax, [lparam]
    movzx   ecx, ax
    shr     eax, 16
    movzx   edx, ax
    cinvoke wsprintf, buf, _fmt, ecx, edx
    invoke  GetParent, [hwnd]
    invoke  GetDlgItem, eax, 100
    invoke  SetWindowText, eax, buf
    xor     eax, eax

.finish:
    ret
endp

section '.data' data readable writeable

    _main_class     db 'MainWinClass', 0
    _canvas_class   db 'CanvasWinClass', 0
    _static_class   db 'STATIC', 0
    _title          db 'Canvas Window', 0
    _fmt            db 'X: %d, Y: %d', 0
    _initial_text   db 'Click the canvas!', 0

    wc              WNDCLASS
    msg             MSG
    hwnd_main       dd ?
    buf             rb 64

section '.idata' import data readable writeable

    library kernel32, 'KERNEL32.DLL',\
            user32, 'USER32.DLL'

    import kernel32,\
           GetModuleHandle, 'GetModuleHandleA',\
           ExitProcess, 'ExitProcess'

    import user32,\
           RegisterClass, 'RegisterClassA',\
           CreateWindowEx, 'CreateWindowExA',\
           DefWindowProc, 'DefWindowProcA',\
           GetMessage, 'GetMessageA',\
           TranslateMessage, 'TranslateMessage',\
           DispatchMessage, 'DispatchMessageA',\
           LoadCursor, 'LoadCursorA',\
           LoadIcon, 'LoadIconA',\
           PostQuitMessage, 'PostQuitMessage',\
           wsprintf, 'wsprintfA',\
           GetParent, 'GetParent',\
           GetDlgItem, 'GetDlgItem',\
           SetWindowText, 'SetWindowTextA'
