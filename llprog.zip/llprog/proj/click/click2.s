format PE GUI 4.0
include 'win32a.inc'

section '.data' data readable writeable

    szAppClass  db 'CoordApp', 0
    szAppTitle  db 'Click Coords', 0
    szCanvas    db 'CanvasClass', 0
    szLabel     db '', 0
    szStatic    db 'STATIC', 0
    szFmt       db 'x=%d, y=%d', 0

    hInstance   dd 0
    hMainWnd    dd 0
    hCanvas     dd 0
    hLabel      dd 0

    wc          WNDCLASSEX
    msg         MSG
    ps          PAINTSTRUCT

    coordBuf    rb 64

section '.code' code readable executable

start:
    invoke  GetModuleHandle, 0
    mov     [hInstance], eax

    mov     [wc.cbSize],        WNDCLASSEX.size
    mov     [wc.style],         CS_HREDRAW or CS_VREDRAW
    mov     [wc.lpfnWndProc],   MainWndProc
    mov     [wc.cbClsExtra],    0
    mov     [wc.cbWndExtra],    0
    mov     eax, [hInstance]
    mov     [wc.hInstance],     eax
    invoke  LoadIcon, 0, IDI_APPLICATION
    mov     [wc.hIcon],         eax
    invoke  LoadCursor, 0, IDC_ARROW
    mov     [wc.hCursor],       eax
    invoke  GetStockObject, WHITE_BRUSH
    mov     [wc.hbrBackground], eax
    mov     [wc.lpszMenuName],  0
    mov     [wc.lpszClassName], szAppClass
    mov     [wc.hIconSm],       0
    invoke  RegisterClassEx, wc

    invoke  CreateWindowEx, 0, szAppClass, szAppTitle, \
            WS_OVERLAPPEDWINDOW, \
            CW_USEDEFAULT, CW_USEDEFAULT, 480, 360, \
            0, 0, [hInstance], 0
    mov     [hMainWnd], eax

    invoke  ShowWindow, [hMainWnd], SW_SHOWDEFAULT
    invoke  UpdateWindow, [hMainWnd]

.msg_loop:
    invoke  GetMessage, msg, 0, 0, 0
    test    eax, eax
    jz      .done
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     .msg_loop

.done:
    invoke  ExitProcess, [msg.wParam]

proc MainWndProc hwnd, uMsg, wParam, lParam
    cmp     [uMsg], WM_CREATE
    je      .on_create
    cmp     [uMsg], WM_DESTROY
    je      .on_destroy
    invoke  DefWindowProc, [hwnd], [uMsg], [wParam], [lParam]
    ret

.on_create:
    invoke  CreateWindowEx, WS_EX_CLIENTEDGE, szStatic, szLabel, \
            WS_CHILD or WS_VISIBLE or SS_CENTER, \
            10, 10, 440, 24, \
            [hwnd], 1, [hInstance], 0
    mov     [hLabel], eax

    invoke  RegisterCanvasClass
    invoke  CreateWindowEx, WS_EX_CLIENTEDGE, szCanvas, 0, \
            WS_CHILD or WS_VISIBLE, \
            10, 44, 440, 270, \
            [hwnd], 2, [hInstance], 0
    mov     [hCanvas], eax

    xor     eax, eax
    ret

.on_destroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
    ret
endp

proc RegisterCanvasClass
    locals
        wcv  WNDCLASSEX
    endl
    mov     [wcv.cbSize],        WNDCLASSEX.size
    mov     [wcv.style],         CS_HREDRAW or CS_VREDRAW
    mov     [wcv.lpfnWndProc],   CanvasWndProc
    mov     [wcv.cbClsExtra],    0
    mov     [wcv.cbWndExtra],    0
    mov     eax, [hInstance]
    mov     [wcv.hInstance],     eax
    mov     [wcv.hIcon],         0
    invoke  LoadCursor, 0, IDC_CROSS
    mov     [wcv.hCursor],       eax
    invoke  GetStockObject, WHITE_BRUSH
    mov     [wcv.hbrBackground], eax
    mov     [wcv.lpszMenuName],  0
    mov     [wcv.lpszClassName], szCanvas
    mov     [wcv.hIconSm],       0
    invoke  RegisterClassEx, wcv
    ret
endp

proc CanvasWndProc hwnd, uMsg, wParam, lParam
    cmp     [uMsg], WM_LBUTTONDOWN
    je      .on_click
    cmp     [uMsg], WM_PAINT
    je      .on_paint
    invoke  DefWindowProc, [hwnd], [uMsg], [wParam], [lParam]
    ret

.on_click:
    mov     eax, [lParam]
    movsx   ecx, ax
    sar     eax, 16
    movsx   edx, ax
    invoke  wsprintf, coordBuf, szFmt, ecx, edx
    invoke  SetWindowText, [hLabel], coordBuf
    xor     eax, eax
    ret

.on_paint:
    invoke  BeginPaint, [hwnd], ps
    invoke  EndPaint, [hwnd], ps
    xor     eax, eax
    ret
endp

section '.idata' import data readable writeable

    library kernel32, 'kernel32.dll', \
            user32,   'user32.dll',   \
            gdi32,    'gdi32.dll'

    import kernel32, \
        GetModuleHandle,  'GetModuleHandleA', \
        ExitProcess,      'ExitProcess'

    import user32, \
        RegisterClassEx,  'RegisterClassExA',   \
        CreateWindowEx,   'CreateWindowExA',    \
        ShowWindow,       'ShowWindow',          \
        UpdateWindow,     'UpdateWindow',        \
        GetMessage,       'GetMessageA',         \
        TranslateMessage, 'TranslateMessage',    \
        DispatchMessage,  'DispatchMessageA',    \
        PostQuitMessage,  'PostQuitMessage',     \
        DefWindowProc,    'DefWindowProcA',      \
        BeginPaint,       'BeginPaint',          \
        EndPaint,         'EndPaint',            \
        LoadIcon,         'LoadIconA',           \
        LoadCursor,       'LoadCursorA',         \
        SetWindowText,    'SetWindowTextA',      \
        wsprintf,         'wsprintfA'

    import gdi32, \
        GetStockObject,   'GetStockObject'
