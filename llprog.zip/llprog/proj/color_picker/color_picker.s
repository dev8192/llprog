format PE
entry start

include 'win32a.inc'

WINDOW_WIDTH = 220
WINDOW_HEIGHT = 160
BTN_ID = 101
BTN_X = 50
BTN_Y = 30
BTN_W = 100
BTN_H = 30

section '.data' data readable writeable
    class_name db 'ExampleWindow', 0
    window_name db 'Example Window', 0
    cls_button db 'BUTTON', 0
    str_pick db 'Pick color', 0
    str_cancel db 'Cancel', 0
    fmt_string db 'rgb(%u, %u, %u)', 0

    wc WNDCLASS
    msg MSG
    ps PAINTSTRUCT
    pt POINT

    hBtn dd ?
    picker_active dd 0
    color_picked dd 0
    extracted_color dd 0

    text_buffer rb 32

    rect_color RECT BTN_X, BTN_Y, BTN_X+BTN_W, BTN_Y+BTN_H
    rect_text RECT 0, 70, WINDOW_WIDTH, 100

section '.text' code readable executable
start:
    invoke GetModuleHandle, 0
    mov [wc.hInstance], eax
    mov [wc.style], CS_HREDRAW or CS_VREDRAW
    mov [wc.lpfnWndProc], WindowProc
    mov [wc.hCursor], 0
    mov [wc.hbrBackground], COLOR_WINDOW + 1
    mov [wc.lpszClassName], class_name
    invoke RegisterClass, wc

    invoke CreateWindowEx, 0, class_name, window_name,\
        WS_VISIBLE or WS_OVERLAPPED or WS_CAPTION or WS_SYSMENU, \
        CW_USEDEFAULT, CW_USEDEFAULT, WINDOW_WIDTH, WINDOW_HEIGHT, \
        0, 0, [wc.hInstance], 0

.msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    cmp eax, 0
    jle .end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp .msg_loop

.end_loop:
    invoke ExitProcess, [msg.wParam]

proc WindowProc uses ebx esi, hwnd, wmsg, wparam, lparam
    cmp [wmsg], WM_CREATE
    je .wm_create
    cmp [wmsg], WM_COMMAND
    je .wm_command
    cmp [wmsg], WM_LBUTTONDOWN
    je .wm_lbuttondown
    cmp [wmsg], WM_SETCURSOR
    je .wm_setcursor
    cmp [wmsg], WM_PAINT
    je .wm_paint
    cmp [wmsg], WM_DESTROY
    je .wm_destroy
.defwindowproc:
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    jmp .finish

.wm_create:
    invoke CreateWindowEx, 0, cls_button, str_pick, \
        WS_CHILD or WS_VISIBLE, \
        BTN_X, BTN_Y, BTN_W, BTN_H,\
        [hwnd], BTN_ID, [wc.hInstance], 0
    mov [hBtn], eax
    xor eax, eax
    jmp .finish

.wm_command:
    cmp [lparam], 0
    je .defwindowproc
    mov eax, [wparam]
    and eax, 0xFFFF
    cmp eax, BTN_ID
    jne .defwindowproc

    cmp [picker_active], 1
    je .finish

    mov [picker_active], 1
    invoke SetWindowText, [hBtn], str_cancel
    invoke SetCapture, [hwnd]
    invoke LoadCursor, 0, IDC_CROSS
    invoke SetCursor, eax
    jmp .finish

.wm_lbuttondown:
    cmp [picker_active], 1
    jne .defwindowproc

    invoke GetCursorPos, pt
    invoke WindowFromPoint, [pt.x], [pt.y]
    cmp eax, [hBtn]
    je .cancel_picker

.pick_color:
    invoke GetDC, 0
    mov esi, eax
    invoke GetPixel, esi, [pt.x], [pt.y]
    mov [extracted_color], eax
    invoke ReleaseDC, 0, esi

    mov [picker_active], 0
    mov [color_picked], 1
    invoke ReleaseCapture
    invoke ShowWindow, [hBtn], SW_HIDE
    invoke InvalidateRect, [hwnd], 0, TRUE
    jmp .finish

.cancel_picker:
    mov [picker_active], 0
    invoke ReleaseCapture
    invoke SetWindowText, [hBtn], str_pick
    invoke LoadCursor, 0, IDC_ARROW
    invoke SetCursor, eax
    jmp .finish

.wm_setcursor:
    cmp [picker_active], 1
    jne .defwindowproc
    invoke LoadCursor, 0, IDC_CROSS
    invoke SetCursor, eax
    mov eax, TRUE
    jmp .finish

.wm_paint:
    invoke BeginPaint, [hwnd], ps
    cmp [color_picked], 1
    jne .end_paint

    invoke CreateSolidBrush, [extracted_color]
    mov ebx, eax
    invoke FillRect, [ps.hdc], rect_color, ebx
    invoke DeleteObject, ebx

    mov eax, [extracted_color]
    movzx ebx, al
    movzx ecx, ah
    shr eax, 16
    movzx edx, al
    cinvoke wsprintf, text_buffer, fmt_string, ebx, ecx, edx

    invoke SetBkMode, [ps.hdc], TRANSPARENT
    invoke DrawText, [ps.hdc], text_buffer, -1, rect_text,\
        DT_CENTER or DT_TOP or DT_SINGLELINE

.end_paint:
    invoke EndPaint, [hwnd], ps
    xor eax, eax
    jmp .finish

.wm_destroy:
    invoke PostQuitMessage, 0
    xor eax, eax

.finish:
    ret
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll', \
            user32,             'user32.dll', \
            gdi32,              'gdi32.dll'
    import  kernel32, \
            GetModuleHandle,    'GetModuleHandleA', \
            ExitProcess,        'ExitProcess'
    import  user32, \
            RegisterClass,      'RegisterClassA', \
            CreateWindowEx,     'CreateWindowExA', \
            GetMessage,         'GetMessageA', \
            TranslateMessage,   'TranslateMessage', \
            DispatchMessage,    'DispatchMessageA', \
            DefWindowProc,      'DefWindowProcA', \
            PostQuitMessage,    'PostQuitMessage', \
            SetCapture,         'SetCapture', \
            ReleaseCapture,     'ReleaseCapture', \
            SetCursor,          'SetCursor', \
            LoadCursor,         'LoadCursorA', \
            GetCursorPos,       'GetCursorPos', \
            WindowFromPoint,    'WindowFromPoint', \
            SetWindowText,      'SetWindowTextA', \
            ShowWindow,         'ShowWindow', \
            InvalidateRect,     'InvalidateRect', \
            BeginPaint,         'BeginPaint', \
            EndPaint,           'EndPaint', \
            DrawText,           'DrawTextA', \
            FillRect,           'FillRect', \
            wsprintf,           'wsprintfA', \
            GetDC,              'GetDC', \
            ReleaseDC,          'ReleaseDC'
    import  gdi32, \
            CreateSolidBrush,   'CreateSolidBrush', \
            DeleteObject,       'DeleteObject', \
            SetBkMode,          'SetBkMode', \
            GetPixel,           'GetPixel'
