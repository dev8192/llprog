format PE console 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    filename db 'C:/llprog_priv/road.jpg', 0
    mode     db 'rb', 0
    err_msg  db 'Error loading JPEG.', 10, 0
    fmt      db 'Width: %u px', 10, \
                'Height: %u px', 10, 0

section '.code' code readable executable
start:
    cinvoke fopen, filename, mode
    test eax, eax
    jz .error
    mov edi, eax

    cinvoke fgetc, edi
    cmp eax, 0xFF
    jne .error
    cinvoke fgetc, edi
    cmp eax, 0xD8
    jne .error

.next_marker:
    cinvoke fgetc, edi
    cmp eax, -1
    je .error
    cmp eax, 0xFF
    jne .next_marker

.skip_ff:
    cinvoke fgetc, edi
    cmp eax, 0xFF
    je .skip_ff

    cmp eax, -1
    je .error
    cmp eax, 0xD9
    je .error
    cmp eax, 0xDA
    je .error
    cmp eax, 0xC0
    je .found_sof
    cmp eax, 0xC2
    je .found_sof

    cinvoke fgetc, edi
    shl eax, 8
    mov ebx, eax
    cinvoke fgetc, edi
    or ebx, eax
    sub ebx, 2
    jbe .next_marker

    cinvoke fseek, edi, ebx, 1
    jmp .next_marker

.found_sof:
    cinvoke fseek, edi, 3, 1

    cinvoke fgetc, edi
    shl eax, 8
    mov ebx, eax
    cinvoke fgetc, edi
    or ebx, eax

    cinvoke fgetc, edi
    shl eax, 8
    mov esi, eax
    cinvoke fgetc, edi
    or esi, eax

    cinvoke printf, fmt, esi, ebx

.close:
    cinvoke fclose, edi
    invoke ExitProcess, 0

.error:
    cinvoke printf, err_msg
    invoke ExitProcess, 1

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL', \
            msvcrt,   'MSVCRT.DLL'

    import kernel32, \
           ExitProcess, 'ExitProcess'

    import msvcrt, \
           fopen,  'fopen', \
           fgetc,  'fgetc', \
           fseek,  'fseek', \
           fclose, 'fclose', \
           printf, 'printf'
