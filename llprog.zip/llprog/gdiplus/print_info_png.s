format PE console 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    filename db 'C:/llprog_priv/ascii.png', 0
    mode     db 'rb', 0
    err_msg  db 'Error loading PNG.', 10, 0
    fmt      db 'Width: %u px', 10, \
                'Height: %u px', 10, \
                'Bit Depth: %u', 10, \
                'Color Type: %u', 10, 0
    buffer   rb 32

section '.code' code readable executable
start:
    cinvoke fopen, filename, mode
    test eax, eax
    jz .error
    mov ebx, eax

    cinvoke fread, buffer, 1, 32, ebx

    mov eax, dword [buffer]
    cmp eax, 0x474E5089
    jne .close

    mov eax, dword [buffer+16]
    bswap eax
    mov esi, eax

    mov eax, dword [buffer+20]
    bswap eax
    mov edi, eax

    movzx ecx, byte [buffer+24]
    movzx edx, byte [buffer+25]

    cinvoke printf, fmt, esi, edi, ecx, edx

.close:
    cinvoke fclose, ebx
    invoke ExitProcess, 0

.error:
    cinvoke printf, err_msg
    invoke ExitProcess, 1

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL', \
            msvcrt,   'MSVCRT.DLL'

    import kernel32, \
           ExitProcess, 'ExitProcess'

    import msvcrt, \
           fopen,  'fopen', \
           fread,  'fread', \
           fclose, 'fclose', \
           printf, 'printf'
