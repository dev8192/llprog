format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    folder       db "C:/llprog_priv/images", 0
    szTitle      db 'Image Viewer', 0
    szBtnPrev    db 'prev', 0
    szBtnNext    db 'next', 0
    szBtnPlus    db '+', 0
    szBtnMinus   db '-', 0
    szButton     db 'BUTTON', 0
    szWildcard   db '*.*', 0

    wc           WNDCLASS 0, WindowProc, 0, 0, 0, 0, 0, COLOR_WINDOW+1, 0, szTitle
    msg          MSG
    ps           PAINTSTRUCT
    findData     WIN32_FIND_DATA

    gdiInput     dd 1, 0, 0, 0
    token        dd ?
    image        dd 0
    graphics     dd ?
    img_w        dd ?
    img_h        dd ?
    draw_w       dd ?
    draw_h       dd ?
    zoom         dd 1.0
    zoom_step    dd 1.25

    argc         dd ?
    argv         dd ?
    fileCount    dd 0
    currentIndex dd 0
    hFind        dd ?

section '.bss' readable writeable
    fileNames    rb 260 * 1024
    wszPath      rw 260

section '.text' code readable executable
start:
    invoke  GdiplusStartup, token, gdiInput, 0

    invoke  GetCommandLineW
    invoke  CommandLineToArgvW, eax, argc
    mov     [argv], eax

    cmp     dword [argc], 2
    jl      .scan_dir
    mov     eax, [argv]
    mov     ebx, [eax+4]
    invoke  SetCurrentDirectoryW, ebx

.scan_dir:
    invoke  FindFirstFileA, szWildcard, findData
    cmp     eax, -1
    je      .find_done
    mov     [hFind], eax

.find_loop:
    test    [findData.dwFileAttributes], 16
    jnz     .next_file
    mov     eax, [fileCount]
    imul    eax, 260
    add     eax, fileNames
    invoke  lstrcpyA, eax, findData.cFileName
    inc     [fileCount]
    cmp     [fileCount], 1024
    jae     .find_done

.next_file:
    invoke  FindNextFileA, [hFind], findData
    test    eax, eax
    jnz     .find_loop
    invoke  FindClose, [hFind]

.find_done:
    invoke  GetModuleHandleA, 0
    mov     [wc.hInstance], eax
    invoke  RegisterClassA, wc

    invoke  CreateWindowExA, 0, szTitle, szTitle, WS_OVERLAPPEDWINDOW or WS_VISIBLE,\
        CW_USEDEFAULT, CW_USEDEFAULT, 800, 600, 0, 0, [wc.hInstance], 0
    
    call    LoadCurrentImage

msg_loop:
    invoke  GetMessageA, msg, 0, 0, 0
    test    eax, eax
    jz      end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessageA, msg
    jmp     msg_loop

end_loop:
    cmp     [image], 0
    je      .skip_dispose
    invoke  GdipDisposeImage, [image]
.skip_dispose:
    invoke  GdiplusShutdown, [token]
    invoke  ExitProcess, 0

LoadCurrentImage:
    cmp     [image], 0
    je      .load_new
    invoke  GdipDisposeImage, [image]
    mov     [image], 0
.load_new:
    cmp     [fileCount], 0
    je      .done
    mov     eax, [currentIndex]
    imul    eax, 260
    add     eax, fileNames
    invoke  MultiByteToWideChar, 0, 0, eax, -1, wszPath, 260
    invoke  GdipLoadImageFromFile, wszPath, image
.done:
    ret

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp     [wmsg], WM_CREATE
    je      .wm_create
    cmp     [wmsg], WM_COMMAND
    je      .wm_command
    cmp     [wmsg], WM_PAINT
    je      .wm_paint
    cmp     [wmsg], WM_DESTROY
    je      .wm_destroy

.def:
    invoke  DefWindowProcA, [hwnd], [wmsg], [wparam], [lparam]
    ret

.wm_create:
    invoke  CreateWindowExA, 0, szButton, szBtnPrev, 0x50000000, 10, 10, 60, 30, [hwnd], 101, [wc.hInstance], 0
    invoke  CreateWindowExA, 0, szButton, szBtnNext, 0x50000000, 80, 10, 60, 30, [hwnd], 102, [wc.hInstance], 0
    invoke  CreateWindowExA, 0, szButton, szBtnPlus, 0x50000000, 150, 10, 40, 30, [hwnd], 103, [wc.hInstance], 0
    invoke  CreateWindowExA, 0, szButton, szBtnMinus, 0x50000000, 200, 10, 40, 30, [hwnd], 104, [wc.hInstance], 0
    xor     eax, eax
    ret

.wm_command:
    mov     eax, [wparam]
    and     eax, 0xFFFF
    cmp     eax, 101
    je      .do_prev
    cmp     eax, 102
    je      .do_next
    cmp     eax, 103
    je      .do_plus
    cmp     eax, 104
    je      .do_minus
    xor     eax, eax
    ret

.do_prev:
    cmp     [currentIndex], 0
    je      .done_cmd
    dec     [currentIndex]
    call    LoadCurrentImage
    invoke  InvalidateRect, [hwnd], 0, 1
    jmp     .done_cmd

.do_next:
    mov     eax, [currentIndex]
    inc     eax
    cmp     eax, [fileCount]
    jge     .done_cmd
    mov     [currentIndex], eax
    call    LoadCurrentImage
    invoke  InvalidateRect, [hwnd], 0, 1
    jmp     .done_cmd

.do_plus:
    fld     [zoom]
    fmul    [zoom_step]
    fstp    [zoom]
    invoke  InvalidateRect, [hwnd], 0, 1
    jmp     .done_cmd

.do_minus:
    fld     [zoom]
    fdiv    [zoom_step]
    fstp    [zoom]
    invoke  InvalidateRect, [hwnd], 0, 1
.done_cmd:
    xor     eax, eax
    ret

.wm_paint:
    invoke  BeginPaint, [hwnd], ps
    cmp     [image], 0
    je      .end_paint

    invoke  GdipCreateFromHDC, eax, graphics
    invoke  GdipGetImageWidth, [image], img_w
    invoke  GdipGetImageHeight, [image], img_h

    fild    [img_w]
    fmul    [zoom]
    fistp   [draw_w]

    fild    [img_h]
    fmul    [zoom]
    fistp   [draw_h]

    invoke  GdipDrawImageRectI, [graphics], [image], 10, 50, [draw_w], [draw_h]
    invoke  GdipDeleteGraphics, [graphics]

.end_paint:
    invoke  EndPaint, [hwnd], ps
    xor     eax, eax
    ret

.wm_destroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
    ret
endp

section '.idata' import data readable writeable
    library kernel32, 'KERNEL32.DLL',\
        user32, 'USER32.DLL',\
        shell32, 'SHELL32.DLL',\
        gdiplus, 'GDIPLUS.DLL'

    import kernel32,\
        GetCommandLineW, 'GetCommandLineW',\
        SetCurrentDirectoryW, 'SetCurrentDirectoryW',\
        FindFirstFileA, 'FindFirstFileA',\
        FindNextFileA, 'FindNextFileA',\
        FindClose, 'FindClose',\
        lstrcpyA, 'lstrcpyA',\
        MultiByteToWideChar, 'MultiByteToWideChar',\
        GetModuleHandleA, 'GetModuleHandleA',\
        ExitProcess, 'ExitProcess'

    import user32,\
        RegisterClassA, 'RegisterClassA',\
        CreateWindowExA, 'CreateWindowExA',\
        GetMessageA, 'GetMessageA',\
        TranslateMessage, 'TranslateMessage',\
        DispatchMessageA, 'DispatchMessageA',\
        DefWindowProcA, 'DefWindowProcA',\
        InvalidateRect, 'InvalidateRect',\
        BeginPaint, 'BeginPaint',\
        EndPaint, 'EndPaint',\
        PostQuitMessage, 'PostQuitMessage'

    import shell32,\
        CommandLineToArgvW, 'CommandLineToArgvW'

    import gdiplus,\
        GdiplusStartup, 'GdiplusStartup',\
        GdipLoadImageFromFile, 'GdipLoadImageFromFile',\
        GdipDisposeImage, 'GdipDisposeImage',\
        GdipCreateFromHDC, 'GdipCreateFromHDC',\
        GdipGetImageWidth, 'GdipGetImageWidth',\
        GdipGetImageHeight, 'GdipGetImageHeight',\
        GdipDrawImageRectI, 'GdipDrawImageRectI',\
        GdipDeleteGraphics, 'GdipDeleteGraphics',\
        GdiplusShutdown, 'GdiplusShutdown'
