; not working with webp

format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    filename            db 'C:/llprog_priv/images/hotel.webp', 0
    gdiplusStartupInput dd 1, 0, 0, 0
    gdiplusToken        dd 0
    hImage              dd 0
    hGraphics           dd 0
    imgWidth            dd 0
    imgHeight           dd 0
    argc                dd 0
    hdc                 dd 0
    hwnd                dd 0
    clsName             db 'WebPViewer', 0

    wc:
        .style          dd 0
        .lpfnWndProc    dd WindowProc
        .cbClsExtra     dd 0
        .cbWndExtra     dd 0
        .hInstance      dd 0
        .hIcon          dd 0
        .hCursor        dd 0
        .hbrBackground  dd 6
        .lpszMenuName   dd 0
        .lpszClassName  dd clsName

    msg                 MSG
    ps                  PAINTSTRUCT

section '.text' code readable executable

start:
    invoke  GdiplusStartup, gdiplusToken, gdiplusStartupInput, 0
    invoke  GetModuleHandleA, 0
    mov     [wc.hInstance], eax
    invoke  LoadCursorA, 0, IDC_ARROW
    mov     [wc.hCursor], eax
    invoke  RegisterClassA, wc
    invoke  CreateWindowExA, 0, clsName, clsName, WS_OVERLAPPEDWINDOW + WS_VISIBLE,\
        CW_USEDEFAULT, CW_USEDEFAULT, 800, 600, 0, 0, [wc.hInstance], 0
    mov     [hwnd], eax
    invoke  GetCommandLineW
    invoke  CommandLineToArgvW, eax, argc
    cmp     dword [argc], 2
    jl      .msg_loop
    mov     eax, [eax+4]
    invoke  GdipLoadImageFromFile, eax, hImage

.msg_loop:
    invoke  GetMessageA, msg, 0, 0, 0
    test    eax, eax
    jz      .end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessageA, msg
    jmp     .msg_loop

.end_loop:
    cmp     dword [hImage], 0
    je      .skip_dispose
    invoke  GdipDisposeImage, [hImage]
.skip_dispose:
    invoke  GdiplusShutdown, [gdiplusToken]
    invoke  ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp     [wmsg], WM_PAINT
    je      .wmpaint
    cmp     [wmsg], WM_DESTROY
    je      .wmdestroy
.def:
    invoke  DefWindowProcA, [hwnd], [wmsg], [wparam], [lparam]
    ret
.wmpaint:
    invoke  BeginPaint, [hwnd], ps
    mov     [hdc], eax
    cmp     dword [hImage], 0
    je      .endpaint
    invoke  GdipCreateFromHDC, [hdc], hGraphics
    invoke  GdipGetImageWidth, [hImage], imgWidth
    invoke  GdipGetImageHeight, [hImage], imgHeight
    invoke  GdipDrawImageRectI, [hGraphics], [hImage], 0, 0, [imgWidth], [imgHeight]
    invoke  GdipDeleteGraphics, [hGraphics]
.endpaint:
    invoke  EndPaint, [hwnd], ps
    xor     eax, eax
    ret
.wmdestroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
    ret
endp

section '.idata' import data readable writeable
    library kernel32, 'KERNEL32.DLL',\
            user32, 'USER32.DLL',\
            shell32, 'SHELL32.DLL',\
            gdiplus, 'GDIPLUS.DLL'

    import kernel32,\
           GetModuleHandleA, 'GetModuleHandleA',\
           ExitProcess, 'ExitProcess',\
           GetCommandLineW, 'GetCommandLineW'

    import user32,\
           LoadCursorA, 'LoadCursorA',\
           RegisterClassA, 'RegisterClassA',\
           CreateWindowExA, 'CreateWindowExA',\
           GetMessageA, 'GetMessageA',\
           TranslateMessage, 'TranslateMessage',\
           DispatchMessageA, 'DispatchMessageA',\
           DefWindowProcA, 'DefWindowProcA',\
           BeginPaint, 'BeginPaint',\
           EndPaint, 'EndPaint',\
           PostQuitMessage, 'PostQuitMessage'

    import shell32,\
           CommandLineToArgvW, 'CommandLineToArgvW'

    import gdiplus,\
           GdiplusStartup, 'GdiplusStartup',\
           GdiplusShutdown, 'GdiplusShutdown',\
           GdipLoadImageFromFile, 'GdipLoadImageFromFile',\
           GdipDisposeImage, 'GdipDisposeImage',\
           GdipCreateFromHDC, 'GdipCreateFromHDC',\
           GdipDeleteGraphics, 'GdipDeleteGraphics',\
           GdipGetImageWidth, 'GdipGetImageWidth',\
           GdipGetImageHeight, 'GdipGetImageHeight',\
           GdipDrawImageRectI, 'GdipDrawImageRectI'
