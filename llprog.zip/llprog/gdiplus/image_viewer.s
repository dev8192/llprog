include 'win32a.inc'

format PE GUI 4.0
entry start

section '.data' data readable writeable
    szName      db 'PNG Viewer', 0
    filename    db 'C:/llprog_priv/road.jpg', 0

    wc       WNDCLASS 0, WindowProc, 0, 0, 0, 0, 0, COLOR_WINDOW+1, 0, szName
    msg      MSG
    ps       PAINTSTRUCT

    gdiInput dd 1, 0, 0, 0
    token    dd ?
    image    dd ?
    graphics dd ?

section '.text' code readable executable
start:
    invoke  GdiplusStartup, token, gdiInput, 0
    invoke  GdipLoadImageFromFile, filename, image

    invoke  GetModuleHandle, 0
    mov     [wc.hInstance], eax
    invoke  LoadCursor, 0, IDC_ARROW
    mov     [wc.hCursor], eax
    invoke  RegisterClass, wc

    invoke  CreateWindowEx, 0, szName, szName, WS_OVERLAPPEDWINDOW or WS_VISIBLE,\
        CW_USEDEFAULT, CW_USEDEFAULT, 800, 600, 0, 0, [wc.hInstance], 0

msg_loop:
    invoke  GetMessage, msg, 0, 0, 0
    test    eax, eax
    jle     end_loop
    invoke  DispatchMessage, msg
    jmp     msg_loop

end_loop:
    invoke  GdipDisposeImage, [image]
    invoke  GdiplusShutdown, [token]
    invoke  ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp     [wmsg], WM_PAINT
    je      .wm_paint
    cmp     [wmsg], WM_DESTROY
    je      .wm_destroy

.def:
    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret

.wm_paint:
    invoke  BeginPaint, [hwnd], ps
    invoke  GdipCreateFromHDC, eax, graphics
    invoke  GdipDrawImageI, [graphics], [image], 0, 0
    invoke  GdipDeleteGraphics, [graphics]
    invoke  EndPaint, [hwnd], ps
    xor     eax, eax
    ret

.wm_destroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
    ret
endp

section '.idata' import data readable writeable
    library kernel32, 'KERNEL32.DLL',\
        user32, 'USER32.DLL',\
        gdiplus, 'GDIPLUS.DLL'

    import kernel32,\
        GetModuleHandle, 'GetModuleHandleA',\
        ExitProcess, 'ExitProcess'

    import user32,\
        RegisterClass, 'RegisterClassA',\
        CreateWindowEx, 'CreateWindowExA',\
        GetMessage, 'GetMessageA',\
        DispatchMessage, 'DispatchMessageA',\
        DefWindowProc, 'DefWindowProcA',\
        BeginPaint, 'BeginPaint',\
        EndPaint, 'EndPaint',\
        LoadCursor,'LoadCursorA',\
        PostQuitMessage, 'PostQuitMessage'

    import gdiplus,\
        GdiplusStartup, 'GdiplusStartup',\
        GdipLoadImageFromFile, 'GdipLoadImageFromFile',\
        GdipCreateFromHDC, 'GdipCreateFromHDC',\
        GdipDrawImageI, 'GdipDrawImageI',\
        GdipDeleteGraphics, 'GdipDeleteGraphics',\
        GdipDisposeImage, 'GdipDisposeImage',\
        GdiplusShutdown, 'GdiplusShutdown'
