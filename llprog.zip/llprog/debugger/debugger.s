format PE console
entry start

include 'win32a.inc'

de_dwDebugEventCode      equ de+0
de_dwProcessId           equ de+4
de_dwThreadId            equ de+8
de_cp_hFile              equ de+12
de_ld_hFile              equ de+12
de_exc_ExceptionCode     equ de+12
de_exc_ExceptionAddress  equ de+24

ctx_ContextFlags         equ ctx+0
ctx_Ebx                  equ ctx+164
ctx_Eax                  equ ctx+176
ctx_Eip                  equ ctx+184
ctx_EFlags               equ ctx+192

START_BTN = 101
STEP_BTN = 102
CONT_BTN = 103
EDIT_CONTROL = 104

section '.data' data readable writeable
    szClass     db 'MiniDbg', 0
    szTitle     db 'Mini Debugger', 0
    szBtnClass  db 'BUTTON', 0
    szEditClass db 'EDIT', 0
    szBtnStart  db 'Start Target', 0
    szBtnStep   db 'Step (F7)', 0
    szBtnCont   db 'Continue (F9)', 0
    szTarget    db 'notepad.exe', 0

    szFmtStart  db 'Started debugging: %s', 13, 10, 0
    szFmtExit   db 'Process exited.', 13, 10, 0
    szFmtExc    db 'Exception %08X at %08X | EIP: %08X EAX: %08X EBX: %08X', 13, 10, 0

    wc          WNDCLASSEX
    msg         MSG
    pi          PROCESS_INFORMATION
    si          STARTUPINFO

    hwnd        dd 0
    hEdit       dd 0
    hThread     dd 0
    de          rb 256
    ctx         rb 1024
    buf         rb 512

section '.code' code readable executable
start:
    invoke  GetModuleHandle, 0
    mov     [wc.hInstance], eax
    mov     [wc.cbSize], sizeof.WNDCLASSEX
    mov     [wc.lpfnWndProc], WindowProc
    mov     [wc.lpszClassName], szClass
    mov     [wc.hbrBackground], COLOR_WINDOW+1
    invoke  LoadCursor, 0, IDC_ARROW
    mov     [wc.hCursor], eax
    invoke  RegisterClassExA, wc

    invoke  CreateWindowEx, 0, szClass, szTitle, WS_VISIBLE or WS_OVERLAPPEDWINDOW,\
        100, 100, 640, 480, 0, 0, [wc.hInstance], 0
    mov     [hwnd], eax

msg_loop:
    invoke  GetMessage, msg, 0, 0, 0
    test    eax, eax
    jz      end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessageA, msg
    jmp     msg_loop

end_loop:
    invoke  ExitProcess, [msg.wParam]

proc WindowProc, hw, wmsg, wparam, lparam
    cmp     [wmsg], WM_CREATE
    je      .wm_create
    cmp     [wmsg], WM_COMMAND
    je      .wm_command
    cmp     [wmsg], WM_TIMER
    je      .wm_timer
    cmp     [wmsg], WM_DESTROY
    je      .wm_destroy

.def_proc:
    invoke  DefWindowProc, [hw], [wmsg], [wparam], [lparam]
    ret

.wm_create:
    invoke  CreateWindowEx, 0, szBtnClass, szBtnStart, WS_CHILD or WS_VISIBLE,\
        10, 10, 100, 30, [hw], START_BTN, [wc.hInstance], 0
    invoke  CreateWindowEx, 0, szBtnClass, szBtnStep, WS_CHILD or WS_VISIBLE,\
        120, 10, 100, 30, [hw], STEP_BTN, [wc.hInstance], 0
    invoke  CreateWindowEx, 0, szBtnClass, szBtnCont, WS_CHILD or WS_VISIBLE,\
        230, 10, 100, 30, [hw], CONT_BTN, [wc.hInstance], 0
    invoke  CreateWindowEx, WS_EX_CLIENTEDGE, szEditClass, 0,\
        WS_CHILD or WS_VISIBLE or WS_VSCROLL or ES_MULTILINE or ES_AUTOVSCROLL or ES_READONLY,\
        10, 50, 600, 380, [hw], EDIT_CONTROL, [wc.hInstance], 0
    mov     [hEdit], eax
    xor     eax, eax
    ret

.wm_command:
    mov     eax, [wparam]
    cmp     eax, START_BTN
    je      .cmd_start
    cmp     eax, STEP_BTN
    je      .cmd_step
    cmp     eax, CONT_BTN
    je      .cmd_cont
    jmp     .def_proc

.cmd_start:
    mov     [si.cb], sizeof.STARTUPINFO
    invoke  CreateProcess, szTarget, 0, 0, 0, FALSE, 2, 0, 0, si, pi
    invoke  SetTimer, [hw], 1, 10, 0
    cinvoke wsprintf, buf, szFmtStart, szTarget
    invoke  LogText, buf
    xor     eax, eax
    ret

.cmd_step:
    or      dword [ctx_EFlags], 0x100
    invoke  SetThreadContext, [hThread], ctx
    invoke  CloseHandle, [hThread]
    invoke  ContinueDebugEvent, dword [de_dwProcessId], dword [de_dwThreadId], 0x00010002
    invoke  SetTimer, [hw], 1, 10, 0
    xor     eax, eax
    ret

.cmd_cont:
    and     dword [ctx_EFlags], 0xFFFFFEFF
    invoke  SetThreadContext, [hThread], ctx
    invoke  CloseHandle, [hThread]
    invoke  ContinueDebugEvent, dword [de_dwProcessId], dword [de_dwThreadId], 0x00010002
    invoke  SetTimer, [hw], 1, 10, 0
    xor     eax, eax
    ret

.wm_timer:
    invoke  WaitForDebugEvent, de, 0
    test    eax, eax
    jz      .timer_done

    mov     eax, dword [de_dwDebugEventCode]
    cmp     eax, 1
    je      .on_exception
    cmp     eax, 3
    je      .on_create_proc
    cmp     eax, 6
    je      .on_load_dll
    cmp     eax, 5
    je      .on_exit

.continue_event:
    invoke  ContinueDebugEvent, dword [de_dwProcessId], dword [de_dwThreadId], 0x00010002
    xor     eax, eax
    ret

.on_create_proc:
    invoke  CloseHandle, dword [de_cp_hFile]
    jmp     .continue_event

.on_load_dll:
    invoke  CloseHandle, dword [de_ld_hFile]
    jmp     .continue_event

.on_exit:
    invoke  KillTimer, [hw], 1
    cinvoke wsprintf, buf, szFmtExit
    invoke  LogText, buf
    jmp     .continue_event

.on_exception:
    invoke  KillTimer, [hw], 1
    invoke  OpenThread, 0x1FFFFF, FALSE, dword [de_dwThreadId]
    mov     [hThread], eax

    mov     dword [ctx_ContextFlags], 0x10007
    invoke  GetThreadContext, [hThread], ctx

    cinvoke wsprintf, buf, szFmtExc, dword [de_exc_ExceptionCode],\
        dword [de_exc_ExceptionAddress], dword [ctx_Eip],\
        dword [ctx_Eax], dword [ctx_Ebx]
    invoke  LogText, buf
    xor     eax, eax
    ret

.timer_done:
    xor     eax, eax
    ret

.wm_destroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
    ret
endp

proc LogText, pszText
    invoke  SendMessage, [hEdit], EM_SETSEL, -1, -1
    invoke  SendMessage, [hEdit], EM_REPLACESEL, 0, [pszText]
    ret
endp

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL',\
            user32,   'USER32.DLL'

    import  kernel32,\
            CreateProcess, 'CreateProcessA',\
            WaitForDebugEvent, 'WaitForDebugEvent',\
            ContinueDebugEvent, 'ContinueDebugEvent',\
            GetThreadContext, 'GetThreadContext',\
            SetThreadContext, 'SetThreadContext',\
            OpenThread, 'OpenThread',\
            CloseHandle, 'CloseHandle',\
            ExitProcess, 'ExitProcess',\
            GetModuleHandle, 'GetModuleHandleA'

    import  user32,\
            CreateWindowEx, 'CreateWindowExA',\
            DefWindowProc, 'DefWindowProcA',\
            SendMessage, 'SendMessageA',\
            GetMessage, 'GetMessageA',\
            TranslateMessage, 'TranslateMessage',\
            DispatchMessageA, 'DispatchMessageA',\
            SetTimer, 'SetTimer',\
            KillTimer, 'KillTimer',\
            RegisterClassExA, 'RegisterClassExA',\
            PostQuitMessage, 'PostQuitMessage',\
            wsprintf, 'wsprintfA',\
            LoadCursor, 'LoadCursorA'
