format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    msg_dbg    db 'Debugger detected!', 10, 0
    msg_nodbg  db 'No debugger detected.', 10, 0
    safe_esp   dd 0

section '.text' code readable executable
start:
    push ebp
    mov ebp, esp

    push seh_handler
    push dword [fs:0]
    mov dword [fs:0], esp
    mov [safe_esp], esp

    invoke CloseHandle, 0xDEADBEEF

cleanup:
    pop dword [fs:0]
    add esp, 4
    
    cinvoke printf, msg_nodbg
    jmp exit_prog

continue_label:
    mov esp, [safe_esp]
    pop dword [fs:0]
    add esp, 4
    
    cinvoke printf, msg_dbg

exit_prog:
    mov esp, ebp
    pop ebp
    invoke ExitProcess, 0

proc seh_handler c, pExceptionRecord, pEstablisherFrame, pContextRecord, pDispatcherContext
    mov eax, [pContextRecord]
    mov dword [eax + 0xB8], continue_label
    mov eax, 0
    ret
endp

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
        msvcrt, 'msvcrt.dll'

    import kernel32,\
        CloseHandle, 'CloseHandle',\
        ExitProcess, 'ExitProcess'

    import msvcrt,\
        printf, 'printf'
