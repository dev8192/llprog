format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    str1        db 'abc', 0
    str1_len    = $ - str1 - 1
    fmt_x       db '%x', 10, 0
    fmt_c       db '%c', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc print_first_and_last_char1 uses esi edi, buf, buf_sz
    mov esi, [buf]
    mov edi, esi
    add edi, [buf_sz]
    dec edi
    cinvoke printf, fmt_x, esi
    cinvoke printf, fmt_x, edi
    movzx eax, byte [esi]
    cinvoke printf, fmt_c, eax
    movzx eax, byte [edi]
    cinvoke printf, fmt_c, eax
    ret
endp

proc print_first_and_last_char2 uses ebx esi edi, buf, buf_sz
    mov esi, [buf]
    mov ebx, [buf_sz]
    lea edi, [esi + ebx - 1]
    cinvoke printf, fmt_x, esi
    cinvoke printf, fmt_x, edi
    movzx eax, byte [esi]
    cinvoke printf, fmt_c, eax
    movzx eax, byte [edi]
    cinvoke printf, fmt_c, eax
    ret
endp

proc main
    cinvoke puts, '*** main1 ***'
    stdcall print_first_and_last_char1, str1, str1_len
    stdcall print_first_and_last_char2, str1, str1_len
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
