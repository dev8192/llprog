format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    str1        db 'abcd', 0
    str1_len    = $ - str1 - 1
    str2        db 'abc', 0
    str2_len    = $ - str2 - 1
    fmt_s       db '%s', 10, 0
    fmt_x       db '%x', 10, 0
    fmt_dd      db '  %d %d', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc reverse_string1 uses esi edi, buf, buf_sz
    mov eax, [buf_sz]
    test eax, eax
    jz .done
    mov esi, [buf]
    lea edi, [esi + eax - 1]
.loop:
    cmp esi, edi
    jae .done
    mov al, [esi]
    mov dl, [edi]
    mov [esi], dl
    mov [edi], al
    inc esi
    dec edi
    jmp .loop
.done:
    ret
endp

; [esi] [edi] al
;   a     b    ?
;   a     b    a
;   a     a    b
;   b     a    b
proc reverse_string uses esi edi, buf, buf_sz
    mov esi, [buf]
    mov eax, [buf_sz]
    lea edi, [esi + eax - 1]
    cmp esi, edi
    jae .done
.loop:
    mov al, [esi]
    xchg al, [edi]
    mov [esi], al
    inc esi
    dec edi
    cmp esi, edi
    jb .loop
.done:
    ret
endp

proc run_test, buf, buf_sz
    cmp [buf_sz], 0
    jz .done
    cinvoke printf, fmt_s, [buf]
    stdcall reverse_string, [buf], [buf_sz]
    cinvoke printf, fmt_s, [buf]
.done:
    ret
endp

proc main
    cinvoke puts, '*** main1 ***'
    stdcall run_test, str1, str1_len
    stdcall run_test, str2, str2_len
    stdcall run_test, 0, 0
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    stdcall .func, '3 iterations', 5, 10
    stdcall .func, '2 iterations', 5, 9
    stdcall .func, 'no iterations', 5, 5
    stdcall .func, 'no iterations', 5, 4
    ret
endp

; jae = jnc = jnb
proc .func uses esi edi, msg, start_addr, end_addr
    cinvoke puts, [msg]
    mov esi, [start_addr]
    mov edi, [end_addr]
.loop:
    cmp esi, edi
    jnc .done
    cinvoke printf, fmt_dd, esi, edi
    inc esi
    dec edi
    jmp .loop
.done:
    ret
endp

; jbe = jna = jc+jz
proc .func2 uses esi edi, msg, start_addr, end_addr
    cinvoke puts, [msg]
    mov esi, [start_addr]
    mov edi, [end_addr]
.loop:
    cmp edi, esi
    jc .done
    jz .done
    cinvoke printf, fmt_dd, esi, edi
    inc esi
    dec edi
    jmp .loop
.done:
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
