format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_dn          db '%d', 10, 0
    fmt_point       db '%d %d', 10, 0
    points1:
        dd 200, 51
        dd 300, 223
        dd 100, 223

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc polygon arr, arr_len
    mov ebx, [arr]
    cinvoke printf, fmt_point, dword [ebx], dword [ebx + 4]
    ret
endp

proc main
    cinvoke puts, '*** main1 ***'
    locals
        points2 dd  200, 52,\
                    300, 223,\
                    100, 223
    endl
    stdcall polygon, points1, 3
    stdcall polygon, addr points2, 3
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
