format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_u   db '%u', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc print_nums uses ebx esi edi, start_num, count, step
    mov ebx, [start_num]
    mov esi, ebx
    add esi, [count]
    mov edi, [step]
.loop:
    cinvoke printf, fmt_u, ebx
    add ebx, edi
    cmp ebx, esi
    jb .loop
    ret
endp

proc main
    cinvoke puts, '*** main1 ***'
    stdcall print_nums, 0, 14, 1
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
