format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    input_text      db "H3ello Pyt2hon 1Is Awe5some", 0
    buf_size        = $ - input_text
    result_buf      db buf_size dup(0)
    checksum        dd 0
    fmt_d           db '%d', 10, 0
    fmt_s           db '%s', 10, 0

section '.text' code readable executable
start:
    stdcall test1
    invoke ExitProcess, 0

proc test1
    stdcall .decode_spy_message
    cinvoke printf, fmt_s, result_buf
    cinvoke printf, fmt_d, [checksum]
    ret
endp

proc .decode_spy_message uses esi edi
    xor esi, esi
    xor edi, edi
.loop:
    movzx eax, [input_text + esi]
    cmp al, '0'
    jb .copy
    cmp al, '9'
    ja .copy
    sub al, '0'
    add [checksum], eax
    jmp .continue
.copy:
    mov al, [input_text + esi]
    mov [result_buf + edi], al
    inc edi
.continue:
    inc esi
    cmp esi, buf_size
    jl .loop
    mov [result_buf + edi], 0
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
