format PE
entry start

include 'win32ax.inc'

; db = define byte          1
; dw = define word          2
; dd = define double word   4
section '.data' data readable writeable
    fmt_d       db '%d', 10, 0
    arr1        dd 11, 22, 33, 44
    arr1_len    = ($ - arr1) / 4
    result      rd 4

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main1
    cinvoke puts, '*** main1 ***'
    cinvoke printf, fmt_d, [arr1 + 0 * 4]
    cinvoke printf, fmt_d, [arr1 + 1 * 4]
    cinvoke printf, fmt_d, [arr1 + 2 * 4]
    cinvoke printf, fmt_d, [arr1 + 3 * 4]
    ret
endp

proc print_arr uses ebx esi, arr, arr_len
    xor ebx, ebx
    mov esi, [arr]
.loop:
    cinvoke printf, fmt_d, dword [esi + ebx * 4]
    inc ebx
    cmp ebx, [arr_len]
    jb .loop
    ret
endp

proc main2 uses ebx
    cinvoke puts, '*** main2 ***'
    stdcall print_arr, arr1, arr1_len
    ret
endp

proc main uses ebx
    cinvoke puts, '*** main3 ***'
    xor ebx, ebx
.loop:
    mov eax, [arr1 + ebx * 4]
    shl eax, 1
    mov [result + ebx * 4], eax
    inc ebx
    cmp ebx, arr1_len
    jb .loop
    stdcall print_arr, result, arr1_len
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
