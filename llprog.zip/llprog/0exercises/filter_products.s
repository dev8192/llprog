format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    item1   db "Laptop", 0
    item2   db "Mouse", 0
    item3   db "Keyboard", 0
    item4   db "Monitor", 0
    item5   db "USB Drive", 0

    catalog:
            dd item1, 1200
            dd item2, 25
            dd item3, 80
            dd item4, 300
            dd item5, 15
    catalog_len1 = $ - catalog
    catalog_len2 = ($ - catalog) / 8
    
    fmt_d       db '%d', 10, 0
    fmt_x       db '%x', 10, 0
    fmt_s       db '%s', 10, 0
    fmt_tuple   db "('%s', %d)", 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main1
    cinvoke puts, '*** main1 ***'
    cinvoke printf, fmt_d, catalog_len1
    cinvoke printf, fmt_d, catalog_len2
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    cinvoke printf, fmt_s, dword [catalog]
    cinvoke printf, fmt_s, dword [catalog + 8]
    cinvoke printf, fmt_s, dword [catalog + 16]
    ret
endp

proc main3
    cinvoke puts, '*** main3 ***'
    cinvoke printf, fmt_s, dword [catalog]
    cinvoke printf, fmt_s, dword [catalog + catalog_len1 - 8]
    ret
endp

proc main3 uses ebx
    cinvoke puts, '*** main3 ***'
    mov ebx, 0
.loop:
    lea eax, [catalog + ebx * 8]
    cinvoke printf, fmt_s, dword [eax]
    inc ebx
    cmp ebx, catalog_len2
    jl .loop
    ret
endp

proc main uses ebx
    cinvoke puts, '*** main4 ***'
    xor ebx, ebx
.loop:
    lea eax, [catalog + ebx * 8]
    cinvoke printf, fmt_tuple, dword [eax], dword [eax + 4]
    inc ebx
    cmp ebx, catalog_len1 / 8
    jl .loop
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
