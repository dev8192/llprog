format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_x       db '%x', 10, 0
    fmt_s       db '%s', 10, 0
    fmt_d       db '%d', 10, 0
    fmt_dd      db '%d %d', 10, 0
    str1        db 'Hello World', 0
    str2        db 'one two three', 0
    vowels      db 'aeiou'
    vowels_len  = $ - vowels

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc count_vowels1 uses ebx esi, buf
    xor ebx, ebx
    mov esi, [buf]
    invoke CharLower, [buf]
    invoke lstrlen, [buf]
.loop:
    cmp byte [esi], 'a'
    je .increment
    cmp byte [esi], 'e'
    je .increment
    cmp byte [esi], 'i'
    je .increment
    cmp byte [esi], 'o'
    je .increment
    cmp byte [esi], 'u'
    je .increment
    jmp .continue
.increment:
    inc ebx
.continue:
    inc esi
    dec eax
    jnz .loop
    mov eax, ebx
    ret
endp

proc is_vowel1, ch
    cmp [ch], 'a'
    je .found
    cmp [ch], 'e'
    je .found
    cmp [ch], 'i'
    je .found
    cmp [ch], 'o'
    je .found
    cmp [ch], 'u'
    je .found
    xor eax, eax
    jmp .exit
.found:
    mov eax, 1
.exit:
    ret
endp

proc is_vowel, ch
    mov ecx, vowels_len
    mov eax, vowels
    mov edx, [ch]
.loop:
    cmp dl, byte [eax]
    je .found
    inc eax
    dec ecx
    jnz .loop
    mov eax, 0
    jmp .exit
.found:
    mov eax, 1
.exit:
    ret
endp

proc count_vowels uses ebx esi edi, buf
    xor ebx, ebx
    mov esi, [buf]
    invoke CharLower, [buf]
    invoke lstrlen, [buf]
    mov edi, eax
.loop:
    movzx eax, byte [esi]
    stdcall is_vowel, eax
    test eax, eax
    jz .continue
    inc ebx
.continue:
    inc esi
    dec edi
    jnz .loop
    mov eax, ebx
    ret
endp

proc main
    cinvoke puts, '*** main1 ***'
    stdcall count_vowels, str1
    cinvoke printf, fmt_d, eax

    stdcall count_vowels, str2
    cinvoke printf, fmt_d, eax
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            user32,         'user32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            lstrlen,        'lstrlenA',\
            ExitProcess,    'ExitProcess'
    import  user32,\
            CharLower,      'CharLowerA'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
