format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_d       db '%d', 10, 0
    arr         dd 3, 7, 2, 9, 1

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main1
    cinvoke puts, '*** main1 ***'
    cinvoke printf, fmt_d, [arr + 0]
    cinvoke printf, fmt_d, [arr + 4]
    cinvoke printf, fmt_d, [arr + 8]
    ret
endp

proc main2 uses ebx
    cinvoke puts, '*** main2 ***'
    mov ebx, 0
.loop:
    lea eax, [arr + ebx * 4]
    cinvoke printf, fmt_d, dword [eax]
    inc ebx
    cmp ebx, 5
    jl .loop
    ret
endp

proc main
    cinvoke puts, '*** main3 ***'
    stdcall find_max_in_list, arr
    cinvoke printf, fmt_d, eax
    ret
endp

proc find_max_in_list uses ebx esi edi, numbers
    local result:DWORD
    mov esi, [numbers]
    mov ebx, 0
    lea eax, [esi + ebx * 4]
    mov eax, dword [eax]
    mov [result], eax
.loop:
    inc ebx
    lea eax, [esi + ebx * 4]
    mov eax, dword [eax]
    cmp [result], eax
    jge .continue
    mov [result], eax
.continue:
    cmp ebx, 5
    jl .loop
.exit:
    mov eax, [result]
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
