; not working
format PE console 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable

    host        db 'example.com',0
    request     db 'GET / HTTP/1.1',13,10,\
                    'Host: example.com',13,10,\
                    'Connection: close',13,10,13,10,0

    newline     db 13,10,0

section '.bss' readable writeable

    wsa         rb 400
    sock        dd ?
    addr        dd ?
    buf         rb 4096
    recvd       dd ?
    hOut        dd ?

section '.code' code readable executable

start:
    invoke  GetStdHandle, STD_OUTPUT_HANDLE
    mov     [hOut], eax

    invoke  WSAStartup, 0202h, wsa

    invoke  socket, AF_INET, SOCK_STREAM, IPPROTO_TCP
    mov     [sock], eax

    invoke  gethostbyname, host
    mov     eax, [eax+12]
    mov     eax, [eax]
    mov     [addr], eax

    mov     eax, [addr]
    bswap   eax
    mov     [addr], eax

    mov     eax, [addr]
    shl     eax, 16
    or      eax, 80h
    mov     [addr], eax

    invoke  connect, [sock], addr, 16

    invoke  send, [sock], request, strlen request, 0

.read:
    invoke  recv, [sock], buf, 4096, 0
    cmp     eax, 0
    jle     .done
    mov     [recvd], eax
    mov     eax, [hOut]
    push    0
    push    recvd
    push    [recvd]
    push    buf
    push    eax
    call    [WriteConsoleA]
    add     esp, 20
    jmp     .read

.done:
    invoke  closesocket, [sock]
    invoke  WSACleanup
    invoke  ExitProcess, 0

strlen:
    push    esi
    mov     esi, eax
    xor     ecx, ecx
.l:
    cmp     byte [esi+ecx], 0
    je      .e
    inc     ecx
    jmp     .l
.e:
    mov     eax, ecx
    pop     esi
    ret

section '.idata' import data readable writeable

    library kernel32,'KERNEL32.DLL',\
            ws2_32,'WS2_32.DLL'

    import  kernel32,\
            GetStdHandle,'GetStdHandle',\
            WriteConsoleA,'WriteConsoleA',\
            ExitProcess,'ExitProcess'

    import  ws2_32,\
            WSAStartup,'WSAStartup',\
            WSACleanup,'WSACleanup',\
            socket,'socket',\
            connect,'connect',\
            send,'send',\
            recv,'recv',\
            closesocket,'closesocket',\
            gethostbyname,'gethostbyname'
