format PE Console 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable

    agent_name      db 'FasmTutor', 0
    server_name     db 'localhost', 0
    verb            db 'GET', 0
    path            db '/', 0

    h_inet          dd ?
    h_conn          dd ?
    h_req           dd ?
    h_stdout        dd ?
    bytes_read      dd ?
    bytes_writ      dd ?

    buffer          rb 1024

section '.text' code readable executable

start:
    invoke  GetStdHandle, STD_OUTPUT_HANDLE
    mov     [h_stdout], eax

    invoke  InternetOpen, agent_name, 1, 0, 0, 0
    cmp     eax, 0
    je      exit_app
    mov     [h_inet], eax

    invoke  InternetConnect, [h_inet], server_name, 8080, 0, 0, 3, 0, 0
    cmp     eax, 0
    je      cleanup_inet
    mov     [h_conn], eax

    invoke  HttpOpenRequest, [h_conn], verb, path, 0, 0, 0, 0, 0
    cmp     eax, 0
    je      cleanup_conn
    mov     [h_req], eax

    ;invoke  HttpSendRequest, [h_req], 0, 0, 0, 0
    invoke  HttpSendRequest, \
        [h_req], \      ; HINTERNET hRequest
        0, \            ; LPCSTR    lpszHeaders
        0, \            ; DWORD     dwHeadersLength
        0, \            ; LPVOID    lpOptional
        0               ; DWORD     dwOptionalLength
    cmp     eax, 0
    je      cleanup_req

read_loop:
    invoke  InternetReadFile, [h_req], buffer, 1024, bytes_read
    cmp     eax, 0
    je      cleanup_req
    cmp     [bytes_read], 0
    je      cleanup_req

    invoke  WriteFile, [h_stdout], buffer, [bytes_read], bytes_writ, 0
    jmp     read_loop

cleanup_req:
    invoke  InternetCloseHandle, [h_req]

cleanup_conn:
    invoke  InternetCloseHandle, [h_conn]

cleanup_inet:
    invoke  InternetCloseHandle, [h_inet]

exit_app:
    invoke  ExitProcess, 0

section '.idata' import data readable

    library kernel32, 'KERNEL32.DLL',\
            wininet, 'WININET.DLL'

    import kernel32,\
           GetStdHandle, 'GetStdHandle',\
           WriteFile, 'WriteFile',\
           ExitProcess, 'ExitProcess'

    import wininet,\
            InternetOpen, 'InternetOpenA',\
            InternetConnect, 'InternetConnectA',\
            HttpOpenRequest, 'HttpOpenRequestA',\
            HttpSendRequest, 'HttpSendRequestA',\
            InternetReadFile, 'InternetReadFile',\
            InternetCloseHandle, 'InternetCloseHandle'
