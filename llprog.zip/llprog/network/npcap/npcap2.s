format PE console
entry start

include 'win32a.inc'

PCAP_ERRBUF_SIZE equ 256
PROMISC equ 1
SNAPLEN equ 65536
TO_MS equ 1000
PCAP_IF_NAME_OFFSET equ 4
PCAP_PKTHDR_LEN_OFFSET equ 12
EXIT_SUCCESS equ 0
EXIT_FAILURE equ 1
LOOP_INFINITE equ 0
LF equ 10
NULL equ 0

section '.data' data readable writeable
    errbuf rb PCAP_ERRBUF_SIZE
    alldevs dd NULL
    adhandle dd NULL
    fmt_err db "Error: %s", LF, NULL
    fmt_nodevs db "No interfaces found.", LF, NULL
    fmt_dev db "Listening on %s...", LF, NULL
    fmt_pkt db "Packet captured. Wire length: %d bytes", LF, NULL

section '.text' code readable executable

proc packet_handler c, user, header, pkt_data
    mov eax, [header]
    mov eax, [eax + PCAP_PKTHDR_LEN_OFFSET]
    cinvoke printf, fmt_pkt, eax
    ret
endp

proc start
    cinvoke pcap_findalldevs, alldevs, errbuf
    test eax, eax
    jz .devs_ok
    cinvoke printf, fmt_err, errbuf
    invoke ExitProcess, EXIT_FAILURE

.devs_ok:
    mov eax, [alldevs]
    test eax, eax
    jnz .has_dev
    cinvoke printf, fmt_nodevs
    invoke ExitProcess, EXIT_FAILURE

.has_dev:
    mov edx, [eax + PCAP_IF_NAME_OFFSET]
    cinvoke printf, fmt_dev, edx
    mov eax, [alldevs]
    mov edx, [eax + PCAP_IF_NAME_OFFSET]
    cinvoke pcap_open_live, edx, SNAPLEN, PROMISC, TO_MS, \
        errbuf
    mov [adhandle], eax
    test eax, eax
    jnz .open_ok
    cinvoke printf, fmt_err, errbuf
    cinvoke pcap_freealldevs, [alldevs]
    invoke ExitProcess, EXIT_FAILURE

.open_ok:
    cinvoke pcap_freealldevs, [alldevs]
    cinvoke pcap_loop, [adhandle], LOOP_INFINITE, \
        packet_handler, NULL
    cinvoke pcap_close, [adhandle]
    invoke ExitProcess, EXIT_SUCCESS
endp

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL', \
        msvcrt, 'MSVCRT.DLL', \
        wpcap, 'WPCAP.DLL'

    import kernel32, \
        ExitProcess, 'ExitProcess'

    import msvcrt, \
        printf, 'printf'

    import wpcap, \
        pcap_findalldevs, 'pcap_findalldevs', \
        pcap_open_live, 'pcap_open_live', \
        pcap_freealldevs, 'pcap_freealldevs', \
        pcap_loop, 'pcap_loop', \
        pcap_close, 'pcap_close'
