format PE Console 4.0
entry start

include 'win32a.inc'

AF_INET         = 2
SOCK_STREAM     = 1
IPPROTO_TCP     = 6
INADDR_ANY      = 0
SOMAXCONN       = 5

section '.data' data readable writeable

    wsa_data        rb 400
    srv_sock        dd ?
    cli_sock        dd ?
    counter         dd 1
    recv_buf        rb 64

    sin_family      dw ?
    sin_port        dw ?
    sin_addr        dd ?
    sin_zero        rb 8

section '.text' code readable executable

start:
    invoke  WSAStartup, 0202h, wsa_data
    invoke  socket, AF_INET, SOCK_STREAM, IPPROTO_TCP
    mov     [srv_sock], eax

    mov     [sin_family], AF_INET
    invoke  htons, 8080
    mov     [sin_port], ax
    mov     [sin_addr], INADDR_ANY

    invoke  bind, [srv_sock], sin_family, 16
    invoke  listen, [srv_sock], SOMAXCONN

accept_loop:
    invoke  accept, [srv_sock], 0, 0
    mov     [cli_sock], eax

    invoke  recv, [cli_sock], recv_buf, 64, 0
    invoke  send, [cli_sock], counter, 4, 0

    inc     dword [counter]

    invoke  closesocket, [cli_sock]
    jmp     accept_loop

section '.idata' import data readable

    library ws2_32, 'WS2_32.DLL'

    import ws2_32,\
           WSAStartup, 'WSAStartup',\
           socket, 'socket',\
           htons, 'htons',\
           bind, 'bind',\
           listen, 'listen',\
           accept, 'accept',\
           recv, 'recv',\
           send, 'send',\
           closesocket, 'closesocket'
