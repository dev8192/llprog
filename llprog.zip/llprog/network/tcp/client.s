format PE Console 4.0
entry start

include 'win32a.inc'

AF_INET         = 2
SOCK_STREAM     = 1
IPPROTO_TCP     = 6

section '.data' data readable writeable

    wsa_data        rb 400
    cli_sock        dd ?
    
    sin_family      dw ?
    sin_port        dw ?
    sin_addr        dd ?
    sin_zero        rb 8

    ip_addr         db '127.0.0.1', 0
    fmt_out         db 'Server returned: %d', 13, 10, 0
    
    sys_time        rb 16
    recv_val        dd ?
    out_buf         rb 128
    h_stdout        dd ?
    bytes_writ      dd ?

section '.text' code readable executable

start:
    invoke  GetStdHandle, STD_OUTPUT_HANDLE
    mov     [h_stdout], eax

    invoke  WSAStartup, 0202h, wsa_data
    invoke  socket, AF_INET, SOCK_STREAM, IPPROTO_TCP
    mov     [cli_sock], eax

    mov     [sin_family], AF_INET
    invoke  htons, 8080
    mov     [sin_port], ax
    invoke  inet_addr, ip_addr
    mov     [sin_addr], eax

    invoke  connect, [cli_sock], sin_family, 16
    
    invoke  GetSystemTime, sys_time
    invoke  send, [cli_sock], sys_time, 16, 0
    
    invoke  recv, [cli_sock], recv_val, 4, 0

    cinvoke wsprintf, out_buf, fmt_out, [recv_val]
    invoke  lstrlen, out_buf
    invoke  WriteFile, [h_stdout], out_buf, eax, bytes_writ, 0

    invoke  closesocket, [cli_sock]
    invoke  WSACleanup
    invoke  ExitProcess, 0

section '.idata' import data readable

    library kernel32, 'KERNEL32.DLL',\
            user32, 'USER32.DLL',\
            ws2_32, 'WS2_32.DLL'

    import kernel32,\
           GetStdHandle, 'GetStdHandle',\
           GetSystemTime, 'GetSystemTime',\
           lstrlen, 'lstrlenA',\
           WriteFile, 'WriteFile',\
           ExitProcess, 'ExitProcess'

    import user32,\
           wsprintf, 'wsprintfA'

    import ws2_32,\
           WSAStartup, 'WSAStartup',\
           WSACleanup, 'WSACleanup',\
           socket, 'socket',\
           htons, 'htons',\
           inet_addr, 'inet_addr',\
           connect, 'connect',\
           send, 'send',\
           recv, 'recv',\
           closesocket, 'closesocket'
