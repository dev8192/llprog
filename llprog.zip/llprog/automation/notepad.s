format PE console
entry main

include 'win32a.inc'

section '.data' data readable writeable
    notepad_exe db 'notepad.exe', 0
    notepad_cls db 'Notepad', 0
    hello_msg db 'hello world', 0
    filename db 'hello.txt', 0

section '.text' code readable executable

proc type_string uses esi ebx, string_ptr
    mov esi, [string_ptr]
.type_loop:
    lodsb
    test al, al
    jz .done
    movzx eax, al
    invoke VkKeyScan, eax
    movzx ebx, al
    invoke keybd_event, ebx, 0, 0, 0
    invoke keybd_event, ebx, 0, KEYEVENTF_KEYUP, 0
    jmp .type_loop
.done:
    ret
endp

proc main
    invoke WinExec, notepad_exe, SW_SHOW
    invoke Sleep, 1500

    invoke FindWindow, notepad_cls, 0
    test eax, eax
    jz .exit
    invoke SetForegroundWindow, eax
    invoke Sleep, 500

    invoke type_string, hello_msg
    invoke Sleep, 500

    invoke keybd_event, VK_CONTROL, 0, 0, 0
    invoke keybd_event, 'S', 0, 0, 0
    invoke keybd_event, 'S', 0, KEYEVENTF_KEYUP, 0
    invoke keybd_event, VK_CONTROL, 0, KEYEVENTF_KEYUP, 0
    invoke Sleep, 1500

    invoke type_string, filename
    invoke Sleep, 500

    invoke keybd_event, VK_RETURN, 0, 0, 0
    invoke keybd_event, VK_RETURN, 0, KEYEVENTF_KEYUP, 0

.exit:
    invoke ExitProcess, 0
endp

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL',\
        user32, 'USER32.DLL'

    import kernel32,\
        WinExec, 'WinExec',\
        Sleep, 'Sleep',\
        ExitProcess, 'ExitProcess'

    import user32,\
        FindWindow, 'FindWindowA',\
        SetForegroundWindow, 'SetForegroundWindow',\
        VkKeyScan, 'VkKeyScanA',\
        keybd_event, 'keybd_event'
