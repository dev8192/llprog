format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    calc_cmd db 'calc.exe', 0
    calc_title db 'Calculator', 0
    fmt db 'Window %d: x=%d, y=%d, w=%d, h=%d', 10, 0
    hwnds dd 3 dup(0)
    rect RECT
    screen_width dd 0
    screen_height dd 0
    window_width dd 0
    wait_windows_msg    db 'wait_windows_msg', 10, 0

section '.text' code readable executable
start:
    mov ebx, 3
.launch:
    invoke WinExec, calc_cmd, SW_SHOWNORMAL
    dec ebx
    jnz .launch
.wait_calcs:
    cinvoke printf, wait_windows_msg
    invoke Sleep, 500
    xor esi, esi
    xor edi, edi
.find_next:
    invoke FindWindowEx, 0, esi, 0, calc_title
    test eax, eax
    jz .check_found
    mov esi, eax
    mov [hwnds + edi * 4], eax
    inc edi
    cmp edi, 3
    jl .find_next
.check_found:
    cmp edi, 3
    jl .wait_calcs
    invoke GetSystemMetrics, SM_CXSCREEN
    mov [screen_width], eax
    mov ecx, 3
    xor edx, edx
    div ecx
    mov [window_width], eax
    invoke GetSystemMetrics, SM_CYSCREEN
    mov [screen_height], eax
    xor ebx, ebx
.arrange:
    mov eax, [window_width]
    imul eax, ebx
    mov esi, eax
    mov edi, [window_width]
    cmp ebx, 2
    jne .move
    mov edi, [screen_width]
    sub edi, esi
.move:
    invoke MoveWindow, [hwnds + ebx * 4], esi, 0, edi, [screen_height], TRUE
    inc ebx
    cmp ebx, 3
    jl .arrange
    xor ebx, ebx
.print:
    invoke Sleep, 2000
    invoke GetWindowRect, [hwnds + ebx * 4], rect
    mov eax, [rect.bottom]
    sub eax, [rect.top]
    mov ecx, [rect.right]
    sub ecx, [rect.left]
    inc ebx
    cinvoke printf, fmt, ebx, [rect.left], [rect.top], ecx, eax
    cmp ebx, 3
    jl .print
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
        user32, 'user32.dll',\
        msvcrt, 'msvcrt.dll'
    import kernel32,\
        WinExec, 'WinExec',\
        Sleep, 'Sleep',\
        ExitProcess, 'ExitProcess'
    import user32,\
        FindWindowEx, 'FindWindowExA',\
        GetSystemMetrics, 'GetSystemMetrics',\
        MoveWindow, 'MoveWindow',\
        GetWindowRect, 'GetWindowRect'
    import msvcrt,\
        printf, 'printf'
