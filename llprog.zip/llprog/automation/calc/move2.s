format PE GUI 4.0
entry start

include 'win32a.inc'

DWMWA_EXTENDED_FRAME_BOUNDS = 9

section '.data' data readable writeable
    calc_cmd db 'calc.exe', 0
    calc_title db 'Calculator', 0
    hwnd dd 0
    target_x dd 0
    target_y dd 0
    target_w dd 0
    target_h dd 0

section '.bss' readable writeable
    rect_win RECT
    rect_dwm RECT

section '.text' code readable executable
start:
    invoke WinExec, calc_cmd, SW_SHOWNORMAL
    invoke Sleep, 5000
    invoke FindWindowA, 0, calc_title
    test eax, eax
    jz .done
    mov [hwnd], eax
    invoke GetWindowRect, [hwnd], rect_win
    invoke DwmGetWindowAttribute, [hwnd], DWMWA_EXTENDED_FRAME_BOUNDS, rect_dwm, 16
    mov eax, [rect_win.left]
    sub eax, [rect_dwm.left]
    mov [target_x], eax
    mov eax, [rect_win.top]
    sub eax, [rect_dwm.top]
    mov [target_y], eax
    mov eax, [rect_win.right]
    sub eax, [rect_dwm.right]
    sub eax, [target_x]
    add eax, 500
    mov [target_w], eax
    mov eax, [rect_win.bottom]
    sub eax, [rect_dwm.bottom]
    sub eax, [target_y]
    add eax, 720
    mov [target_h], eax
    invoke MoveWindow, [hwnd], [target_x], [target_y], [target_w], [target_h], TRUE
.done:
    invoke ExitProcess, 0

section '.idata' import data readable writeable
    library kernel32,               'kernel32.dll',\
            user32,                 'user32.dll',\
            dwmapi,                 'dwmapi.dll'
    import  kernel32,\
            ExitProcess,            'ExitProcess',\
            Sleep,                  'Sleep',\
            WinExec,                'WinExec'
    import  user32,\
            FindWindowA,            'FindWindowA',\
            GetWindowRect,          'GetWindowRect',\
            MoveWindow,             'MoveWindow'
    import  dwmapi,\
            DwmGetWindowAttribute,  'DwmGetWindowAttribute'
