format PE GUI 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    calc_cmd db 'calc.exe', 0
    calc_title db 'Calculator', 0

section '.text' code readable executable
start:
    invoke WinExec, calc_cmd, SW_SHOWNORMAL
    invoke Sleep, 5000
    invoke FindWindowA, 0, calc_title
    test eax, eax
    jz .done
    invoke MoveWindow, eax, 0, 0, 500, 720, TRUE
.done:
    ret
    invoke ExitProcess, 0

section '.idata' import data readable writeable
    library kernel32, 'kernel32.dll',\
        user32, 'user32.dll'
    import kernel32,\
        ExitProcess, 'ExitProcess',\
        Sleep, 'Sleep',\
        WinExec, 'WinExec'
    import user32,\
        FindWindowA, 'FindWindowA',\
        MoveWindow, 'MoveWindow'
