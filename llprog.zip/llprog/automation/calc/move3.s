format PE GUI 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    calc_cmd db 'calc.exe', 0
    calc_class db 'ApplicationFrameWindow', 0
    calc_title db 'Calculator', 0

section '.bss' readable writeable
    rect_win RECT
    rect_dwm RECT
    target_y dd ?
    target_w dd ?
    target_h dd ?

section '.text' code readable executable

start:
    invoke main
    invoke ExitProcess, 0

proc main
    invoke WinExec, calc_cmd, SW_SHOWNORMAL
    mov edi, 50

.wait_loop:
    invoke Sleep, 100
    invoke FindWindowA, calc_class, calc_title
    test eax, eax
    jnz .found_window
    invoke FindWindowA, 0, calc_title
    test eax, eax
    jz .retry

.found_window:
    mov ebx, eax
    invoke ShowWindow, ebx, SW_RESTORE
    invoke IsWindowVisible, ebx
    test eax, eax
    jz .retry
    invoke GetWindowRect, ebx, rect_win
    test eax, eax
    jz .retry
    invoke DwmGetWindowAttribute, ebx, 9, rect_dwm, 16
    test eax, eax
    jnz .retry
    mov eax, [rect_dwm.right]
    cmp eax, [rect_dwm.left]
    jle .retry
    mov eax, [rect_win.left]
    sub eax, [rect_dwm.left]
    mov esi, eax
    mov eax, [rect_win.top]
    sub eax, [rect_dwm.top]
    mov [target_y], eax
    mov eax, [rect_win.right]
    sub eax, [rect_dwm.right]
    sub eax, esi
    add eax, 500
    mov [target_w], eax
    mov eax, [rect_win.bottom]
    sub eax, [rect_dwm.bottom]
    sub eax, [target_y]
    add eax, 720
    mov [target_h], eax
    invoke MoveWindow, ebx, esi, [target_y], [target_w], [target_h], TRUE
    jmp .done

.retry:
    dec edi
    jnz .wait_loop

.done:
    ret
endp

section '.idata' import data readable writeable

    library kernel32, 'kernel32.dll', \
        user32, 'user32.dll', \
        dwmapi, 'dwmapi.dll'

    import kernel32, \
        ExitProcess, 'ExitProcess', \
        Sleep, 'Sleep', \
        WinExec, 'WinExec'

    import user32, \
        FindWindowA, 'FindWindowA', \
        GetWindowRect, 'GetWindowRect', \
        IsWindowVisible, 'IsWindowVisible', \
        MoveWindow, 'MoveWindow', \
        ShowWindow, 'ShowWindow'

    import dwmapi, \
        DwmGetWindowAttribute, 'DwmGetWindowAttribute'
