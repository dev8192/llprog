format PE GUI 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    calc_cmd db 'calc.exe', 0

section '.text' code readable executable

start:
    invoke WinExec, calc_cmd, SW_SHOWNORMAL
    invoke Sleep, 2000

    stdcall PressKey, 0x31
    stdcall PressKey, 0x32
    stdcall PressKey, 0x33

    invoke ExitProcess, 0

proc PressKey vk_code
    invoke keybd_event, [vk_code], 0, 0, 0
    invoke keybd_event, [vk_code], 0, KEYEVENTF_KEYUP, 0
    ret
endp

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL',\
            user32, 'USER32.DLL'

    import kernel32,\
           WinExec, 'WinExec',\
           Sleep, 'Sleep',\
           ExitProcess, 'ExitProcess'

    import user32,\
           keybd_event, 'keybd_event'
