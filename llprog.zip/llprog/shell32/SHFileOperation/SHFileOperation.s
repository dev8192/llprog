format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    ; SHFILEOPSTRUCT structure (30 bytes total for 32-bit)
    struct SHFILEOPSTRUCT
        hwnd                  dd ?
        wFunc                 dd ?
        pFrom                 dd ?
        pTo                   dd ?
        fFlags                dw ?
        fAnyOperationsAborted dd ?
        hNameMappings         dd ?
        lpszProgressTitle     dd ?
    ends

    file_op SHFILEOPSTRUCT

    ; Path MUST be double null-terminated
    paths db '0files/folder1', 0, 0
    ;paths db '0files/folder1', 0, '0files/folder2', 0, '0files/folder3', 0, 0
    ; TODO: What about wildcards?
    
    msg_done    db 'Operation completed.', 10, 0
    msg_err     db 'Operation failed with code: %d', 10, 0

section '.code' code readable executable
start:
    ; Initialize the structure
    mov [file_op.hwnd], 0
    mov [file_op.wFunc], FO_DELETE
    mov [file_op.pFrom], dir_to_delete
    mov [file_op.pTo], 0
    ; FOF_NOCONFIRMATION (10h) | FOF_SILENT (04h) | FOF_NOERRORUI (0400h)
    mov [file_op.fFlags], 0414h 
    mov [file_op.lpszProgressTitle], 0

    invoke SHFileOperation, file_op
    test eax, eax
    jnz .error

    cinvoke printf, msg_done
    jmp .exit

.error:
    cinvoke printf, msg_err, eax

.exit:
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            shell32,  'shell32.dll',\
            msvcrt,   'msvcrt.dll'

    import kernel32,\
           ExitProcess, 'ExitProcess'

    import shell32,\
           SHFileOperation, 'SHFileOperationA'

    import msvcrt,\
           printf, 'printf'
