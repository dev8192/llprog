format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    path     db "path\to\folder", 0
    fmt_err  db "Failed to create path. Error: %u", 10, 0

section '.code' code readable executable

start:
    invoke SHCreateDirectoryEx, \
        0, \        ; HWND hwnd
        path, \     ; LPCSTR pszPath
        0           ; SECURITY_ATTRIBUTES *psa

    test eax, eax   ; Returns ERROR_SUCCESS (0) on success
    jz .success

    cinvoke printf, fmt_err, eax
    cinvoke exit, eax

.success:
    cinvoke exit, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            msvcrt, 'msvcrt.dll',\
            shell32, 'shell32.dll'

    import msvcrt,\
           exit, 'exit',\
           printf, 'printf'

    import shell32,\
           SHCreateDirectoryEx, 'SHCreateDirectoryExA'
