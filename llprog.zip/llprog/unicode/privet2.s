format PE CONSOLE 4.0
entry start

include 'win32a.inc' ; Back to standard 'A' for UTF-8

section '.code' code readable executable
  start:
    ; 1. Set the console output to UTF-8 (Code Page 65001)
    invoke SetConsoleOutputCP, 65001

    ; 2. Get Handle and Write
    invoke GetStdHandle, STD_OUTPUT_HANDLE
    mov [stdout], eax
    invoke WriteFile, [stdout], msg, msg_len, written, 0
    invoke ExitProcess, 0

section '.data' data readable writeable
    msg      db 'привет мир', 13, 10 
    msg_len  = $ - msg
    stdout   dd ?
    written  dd ?

section '.idata' import data readable
    library kernel32, 'kernel32.dll'
    import kernel32, \
           SetConsoleOutputCP, 'SetConsoleOutputCP', \
           GetStdHandle, 'GetStdHandle', \
           WriteFile, 'WriteFile', \
           ExitProcess, 'ExitProcess'
