format PE CONSOLE 4.0
entry start

include 'win32w.inc'  ; Use the "Wide" version for Unicode constants

section '.code' code readable executable
  start:
    ; 1. Get the handle for Standard Output
    invoke GetStdHandle, STD_OUTPUT_HANDLE
    mov [stdout], eax

    ; 2. Write Unicode string to console
    ; WriteConsoleW(handle, buffer, chars_to_write, chars_written_ptr, reserved)
    invoke WriteConsoleW, [stdout], msg, msg_len, written, 0

    ; 3. Exit
    invoke ExitProcess, 0

section '.data' data readable writeable
    ; 'du' defines a 2-byte-per-character (UTF-16) string
    msg      du 'привет мир', 13, 10 
    msg_len  = ($ - msg) / 2          ; Length is in characters, not bytes
    stdout   dd ?
    written  dd ?

section '.idata' import data readable
    library kernel32, 'kernel32.dll'

    import kernel32, \
           GetStdHandle, 'GetStdHandle', \
           WriteConsoleW, 'WriteConsoleW', \
           ExitProcess, 'ExitProcess'
