format PE
entry start

include 'win32a.inc'

WINDOW_WIDTH = 300
WINDOW_HEIGHT = 300
BTN_ID = 101
BTN_X = 100
BTN_Y = 10
BTN_W = 100
BTN_H = 30

CIRC_X = 50
CIRC_Y = 50
CIRC_SIZE = 200

TIMER_ID = 1
TIMER_INTERVAL = 20

COLOR_RED = 0x0000FF
COLOR_BLACK = 0x000000
MAIN_WINDOW_STYLE = WS_VISIBLE or WS_OVERLAPPED or WS_CAPTION or WS_SYSMENU
WS_EX_COMPOSITED = 0x02000000

section '.data' data readable writeable
    className db 'FadeApp', 0
    windowName db 'Animation', 0
    cls_button db 'BUTTON', 0
    str_fade_out db 'Fade out', 0
    str_fade_in db 'Fade in', 0

    wc WNDCLASS
    msg MSG
    ps PAINTSTRUCT

    rect_window RECT 0, 0, WINDOW_WIDTH, WINDOW_HEIGHT
    rect_circle RECT CIRC_X, CIRC_Y, CIRC_X+CIRC_SIZE, CIRC_Y+CIRC_SIZE
    rect_mem RECT 0, 0, CIRC_SIZE, CIRC_SIZE

    hBtn dd ?
    win_w dd ?
    win_h dd ?

    progress dd 100
    alpha dd 255
    fade_dir dd -1

    memDC dd ?
    hBmp dd ?
    hOldBmp dd ?
    hPen dd ?
    hOldPen dd ?
    hBrush dd ?
    hOldBrush dd ?
    msg_erasebkgnd db 'msg_erasebkgnd', 10, 0

section '.code' code readable executable
start:
    invoke GetModuleHandle, 0
    mov [wc.hInstance], eax
    mov [wc.style], CS_HREDRAW or CS_VREDRAW
    mov [wc.lpfnWndProc], WindowProc
    invoke LoadCursor, 0, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.hbrBackground], COLOR_WINDOW + 1
    mov [wc.lpszClassName], className
    invoke RegisterClass, wc

    invoke AdjustWindowRect, rect_window, MAIN_WINDOW_STYLE, FALSE

    mov eax, [rect_window.right]
    sub eax, [rect_window.left]
    mov [win_w], eax

    mov eax, [rect_window.bottom]
    sub eax, [rect_window.top]
    mov [win_h], eax

    invoke CreateWindowEx, WS_EX_COMPOSITED, className, windowName,\
        MAIN_WINDOW_STYLE,\
        CW_USEDEFAULT, CW_USEDEFAULT, [win_w], [win_h],\
        0, 0, [wc.hInstance], 0

.msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    cmp eax, 0
    jle .end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp .msg_loop

.end_loop:
    invoke ExitProcess, [msg.wParam]

proc WindowProc uses ebx esi edi, hwnd, wmsg, wparam, lparam
    cmp [wmsg], WM_CREATE
    je .wm_create
    cmp [wmsg], WM_COMMAND
    je .wm_command
    cmp [wmsg], WM_TIMER
    je .wm_timer
    cmp [wmsg], WM_PAINT
    je .wm_paint
    cmp [wmsg], WM_DESTROY
    je .wm_destroy
.defwindowproc:
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret

.wm_create:
    invoke CreateWindowEx, 0, cls_button, str_fade_out,\
        WS_CHILD or WS_VISIBLE,\
        BTN_X, BTN_Y, BTN_W, BTN_H,\
        [hwnd], BTN_ID, [wc.hInstance], 0
    mov [hBtn], eax
    xor eax, eax
    ret

.wm_command:
    mov eax, [wparam]
    and eax, 0xFFFF
    cmp eax, BTN_ID
    jne .defwindowproc

    invoke EnableWindow, [hBtn], FALSE
    invoke SetTimer, [hwnd], TIMER_ID, TIMER_INTERVAL, 0
    xor eax, eax
    ret

.wm_timer:
    mov eax, [progress]
    add eax, [fade_dir]
    mov [progress], eax

    cmp eax, 0
    jle .fade_out_done
    cmp eax, 100
    jge .fade_in_done
    jmp .update_alpha

.fade_out_done:
    mov [progress], 0
    mov [fade_dir], 1
    invoke KillTimer, [hwnd], TIMER_ID
    invoke SetWindowText, [hBtn], str_fade_in
    invoke EnableWindow, [hBtn], TRUE
    jmp .update_alpha

.fade_in_done:
    mov [progress], 100
    mov [fade_dir], -1
    invoke KillTimer, [hwnd], TIMER_ID
    invoke SetWindowText, [hBtn], str_fade_out
    invoke EnableWindow, [hBtn], TRUE

.update_alpha:
    mov eax, [progress]
    imul eax, 255
    mov ecx, 100
    cdq
    idiv ecx
    mov [alpha], eax
    invoke InvalidateRect, [hwnd], rect_circle, FALSE
    xor eax, eax
    ret

.wm_paint:
    invoke BeginPaint, [hwnd], ps
    invoke FillRect, [ps.hdc], rect_circle, COLOR_WINDOW + 1

    cmp [alpha], 0
    jle .end_paint

    invoke CreateCompatibleDC, [ps.hdc]
    mov [memDC], eax
    invoke CreateCompatibleBitmap, [ps.hdc], CIRC_SIZE, CIRC_SIZE
    mov [hBmp], eax
    invoke SelectObject, [memDC], [hBmp]
    mov [hOldBmp], eax

    invoke FillRect, [memDC], rect_mem, COLOR_WINDOW + 1

    invoke CreatePen, PS_SOLID, 5, COLOR_BLACK
    mov [hPen], eax
    invoke SelectObject, [memDC], [hPen]
    mov [hOldPen], eax

    invoke CreateSolidBrush, COLOR_RED
    mov [hBrush], eax
    invoke SelectObject, [memDC], [hBrush]
    mov [hOldBrush], eax

    invoke Ellipse, [memDC], 5, 5, CIRC_SIZE-5, CIRC_SIZE-5

    invoke SelectObject, [memDC], [hOldBrush]
    invoke DeleteObject, [hBrush]
    invoke SelectObject, [memDC], [hOldPen]
    invoke DeleteObject, [hPen]

    mov eax, [alpha]
    shl eax, 16

    invoke AlphaBlend, [ps.hdc], CIRC_X, CIRC_Y, CIRC_SIZE, CIRC_SIZE,\
        [memDC], 0, 0, CIRC_SIZE, CIRC_SIZE, eax

    invoke SelectObject, [memDC], [hOldBmp]
    invoke DeleteObject, [hBmp]
    invoke DeleteDC, [memDC]

.end_paint:
    invoke EndPaint, [hwnd], ps
    xor eax, eax
    ret

.wm_destroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    ret
endp ; WindowProc

section '.idata' import data readable
    library kernel32,               'kernel32.dll',\
            user32,                 'user32.dll',\
            gdi32,                  'gdi32.dll',\
            msimg32,                'msimg32.dll',\
            msvcrt,                 'msvcrt.dll'
    import  kernel32,\
            GetModuleHandle,        'GetModuleHandleA',\
            ExitProcess,            'ExitProcess'
    import  user32,\
            AdjustWindowRect,       'AdjustWindowRect',\
            BeginPaint,             'BeginPaint',\
            CreateWindowEx,         'CreateWindowExA',\
            DefWindowProc,          'DefWindowProcA',\
            DispatchMessage,        'DispatchMessageA',\
            EnableWindow,           'EnableWindow',\
            EndPaint,               'EndPaint',\
            FillRect,               'FillRect',\
            GetMessage,             'GetMessageA',\
            InvalidateRect,         'InvalidateRect',\
            KillTimer,              'KillTimer',\
            LoadCursor,             'LoadCursorA',\
            PostQuitMessage,        'PostQuitMessage',\
            RegisterClass,          'RegisterClassA',\
            SetTimer,               'SetTimer',\
            SetWindowText,          'SetWindowTextA',\
            TranslateMessage,       'TranslateMessage'
    import  gdi32,\
            CreateCompatibleDC,     'CreateCompatibleDC',\
            CreateCompatibleBitmap, 'CreateCompatibleBitmap',\
            SelectObject,           'SelectObject',\
            DeleteObject,           'DeleteObject',\
            DeleteDC,               'DeleteDC',\
            CreatePen,              'CreatePen',\
            CreateSolidBrush,       'CreateSolidBrush',\
            Ellipse,                'Ellipse'
    import  msimg32,\
            AlphaBlend,             'AlphaBlend'
    import  msvcrt,\
            printf,                 'printf'
