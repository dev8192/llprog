format PE CONSOLE 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt_step db 10, '%s', 10, 0
    fmt_st0  db '  ST(0) = %f', 10, 0
    fmt_st1  db '  ST(1) = %f', 10, 0
    fmt_st2  db '  ST(2) = %f', 10, 0

    msg1 db '1. fldpi (Push PI onto empty stack):', 0
    msg2 db '2. fld1 (Push 1.0, shifts PI to ST(1)):', 0
    msg3 db '3. fldl2t (Push log2(10), shifts others down):', 0
    msg4 db '4. faddp (Add ST(0) + ST(1), pop result to new ST(0)):', 0

    ; Double precision (8 bytes) buffers for printf
    val0 dq ?
    val1 dq ?
    val2 dq ?

section '.text' code readable executable
start:
    finit

    ; --- STEP 1 ---
    cinvoke printf, fmt_step, msg1

    fldpi
    fst qword [val0]

    cinvoke printf, fmt_st0, dword [val0], dword [val0+4]

    ; --- STEP 2 ---
    cinvoke printf, fmt_step, msg2

    fld1
    fst  qword [val0] ; Current ST0 (1.0)
    fst  st1          ; Note: fst doesn't work to mem for ST1, so we use st1
    fxch st1          ; Swap to get ST1 into ST0 for a moment
    fst  qword [val1] ; Store what was ST1 (PI)
    fxch st1          ; Swap back

    cinvoke printf, fmt_st0, dword [val0], dword [val0+4]
    cinvoke printf, fmt_st1, dword [val1], dword [val1+4]

    ; --- STEP 3 ---
    cinvoke printf, fmt_step, msg3

    fldl2t
    fst qword [val0]  ; New ST0
    fxch st1
    fst qword [val1]  ; New ST1
    fxch st1          ; Restore
    fxch st2
    fst qword [val2]  ; New ST2
    fxch st2          ; Restore

    cinvoke printf, fmt_st0, dword [val0], dword [val0+4]
    cinvoke printf, fmt_st1, dword [val1], dword [val1+4]
    cinvoke printf, fmt_st2, dword [val2], dword [val2+4]

    ; --- STEP 4 ---
    cinvoke printf, fmt_step, msg4

    faddp             ; ST1 = ST1 + ST0, then POP
    fst qword [val0]  ; Result
    fxch st1
    fst qword [val1]  ; Remaining
    fxch st1

    cinvoke printf, fmt_st0, dword [val0], dword [val0+4]
    cinvoke printf, fmt_st1, dword [val1], dword [val1+4]

    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL', \
            msvcrt, 'MSVCRT.DLL'

    import kernel32, \
            ExitProcess, 'ExitProcess'

    import msvcrt, \
            printf, 'printf'
