format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    val_a       dq 10.5
    val_b       dq 2.5
    result      dq ?
    fmt_str     db 'Result: %.2f', 10, 0

section '.text' code readable executable
start:
    mov         eax, val_a
    fld         qword [eax]

    ;fld         [val_a]

    fadd        [val_b]
    fstp        [result]

    cinvoke     printf, fmt_str, dword [result], dword [result+4]
    
    cinvoke     exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
