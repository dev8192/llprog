format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt_str     db 'Result: %.2f', 10, 0

section '.text' code readable executable
start:
    ; 10.5 (0x4025000000000000)
    push        0x40250000
    push        0x00000000
    fld         qword [esp]
    add         esp, 8

    ; 2.5 (0x4004000000000000)
    push        0x40040000
    push        0x00000000
    fadd        qword [esp]
    add         esp, 8

    sub         esp, 8
    fstp        qword [esp]
    
    cinvoke     printf, fmt_str
    add         esp, 8

    cinvoke     exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
