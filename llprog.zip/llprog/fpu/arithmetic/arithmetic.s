format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    val1    dq 15.75
    val2    dq 3.5
    res_add dq ?
    res_sub dq ?
    res_mul dq ?
    res_div dq ?

    fmt     db "a = %f", 10, \
               "b = %f", 10, \
               "a + b = %f", 10, \
               "a - b = %f", 10, \
               "a * b = %f", 10, \
               "a / b = %f", 10, 0

section '.text' code readable executable
start:
    fld     [val1]
    fadd    [val2]
    fstp    [res_add]

    fld     [val1]
    fsub    [val2]
    fstp    [res_sub]

    fld     [val1]
    fmul    [val2]
    fstp    [res_mul]

    fld     [val1]
    fdiv    [val2]
    fstp    [res_div]

    cinvoke printf, fmt, \
        dword [val1], dword [val1+4], \
        dword [val2], dword [val2+4], \
        dword [res_add], dword [res_add+4], \
        dword [res_sub], dword [res_sub+4], \
        dword [res_mul], dword [res_mul+4], \
        dword [res_div], dword [res_div+4]

    invoke  ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll', \
            msvcrt, 'msvcrt.dll'

    import  kernel32, \
            ExitProcess, 'ExitProcess'

    import  msvcrt, \
            printf, 'printf'
