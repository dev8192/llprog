format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt db "%.16f", 10, 0
    pi_val dq ?

section '.text' code readable executable
start:
    ; 3.141592653589793 (js)
    ; 3.1415926535897931 (fasm)
    fldpi
    fstp qword [pi_val]
    cinvoke printf, fmt, dword [pi_val], dword [pi_val+4]
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import msvcrt,\
        printf, 'printf',\
        exit, 'exit'
