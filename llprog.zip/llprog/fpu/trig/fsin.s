format PE console 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    deg_45    dq 45.0
    deg_180   dq 180.0
    result    dq ?
    fmt       db 'Sin(45 degrees) = %.4f', 0ah, 0

section '.code' code readable executable
start:
    finit
    
    ; Convert 45 degrees to radians: (45 * pi) / 180
    fld qword [deg_45]
    fldpi                ; Push PI onto FPU stack
    fmulp                ; ST(1) = 45 * PI, then pop
    fdiv qword [deg_180] ; ST(0) = (45 * PI) / 180
    
    ; Calculate Sine
    fsin
    
    fstp qword [result]

    cinvoke printf, fmt, dword [result], dword [result+4]

    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll', \
            msvcrt,   'msvcrt.dll'

    import kernel32, \
           ExitProcess, 'ExitProcess'

    import msvcrt, \
           printf, 'printf'
