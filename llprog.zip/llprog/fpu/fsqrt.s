format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    value     dq 25.0
    result    dq ?
    fmt       db '%.1f: %.1f', 10, 0

section '.code' code readable executable
start:
    finit
    fld     [value]
    fsqrt
    fstp    [result]

    cinvoke printf, fmt,\
        dword [value],  dword [value+4],\
        dword [result], dword [result+4]
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll', \
            msvcrt,   'msvcrt.dll'

    import kernel32, \
           ExitProcess, 'ExitProcess'

    import msvcrt, \
           printf, 'printf'
