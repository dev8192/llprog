; -------------------------------------
; Add GetStdHandle() and WriteConsole()
; -------------------------------------

format PE console

include 'win32a.inc'

section '.text' code readable executable
    invoke  GetStdHandle, STD_OUTPUT_HANDLE
    invoke  WriteConsole, eax, msg, 13, 0, 0
    invoke  ExitProcess, 0

section '.data' data readable writeable
    msg     db 'one two three'

section '.idata' import data readable writeable
    library kernel32,       'kernel32.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess',\
            GetStdHandle,   'GetStdHandle',\
            WriteConsole,   'WriteConsoleA'
