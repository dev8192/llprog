; --------------------------------
; Starting point. Absolute minimum
; --------------------------------

format PE

mov eax, 22
ret
