; --------------------------------
; Starting point. Absolute minimum
; --------------------------------

format PE

mov eax, 123
ret
