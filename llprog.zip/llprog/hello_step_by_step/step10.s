; --------------------------------
; Starting point. Absolute minimum
; --------------------------------

format PE

mov eax, 42
ret
