format PE
entry start

include 'win32a.inc'

section '.data' readable writeable
    errbuf      rb 256
    device_name dd ?
    adhandle    dd ?
    alldevs     dd ?
    
    msg_found   db 'Capturing on: %s',13,10,0
    msg_pkt     db 'Packet captured! Length: %d bytes',13,10,0
    msg_no_dev  db 'No interfaces found. Is Npcap installed?',0
    msg_err     db 'Error: %s',0

section '.text' readable executable
start:
    invoke pcap_findalldevs, alldevs, errbuf
    test eax, eax
    jnz  .error_msg

    mov eax, [alldevs]
    test eax, eax
    jz   .no_devices

    mov [device_name], eax
    mov eax, [eax] ; d->name is the first field in the struct
    invoke printf, msg_found, eax

    ; pcap_open_live(name, snaplen, promisc, to_ms, errbuf)
    mov eax, [device_name]
    mov eax, [eax]
    invoke pcap_open_live, eax, 65536, 1, 1000, errbuf
    test eax, eax
    jz   .error_msg
    mov [adhandle], eax

    ; pcap_loop(handle, count, callback, user_data)
    invoke pcap_loop, [adhandle], 0, packet_handler, 0

    jmp .exit

.no_devices:
    invoke printf, msg_no_dev
    jmp .exit

.error_msg:
    invoke printf, msg_err, errbuf

.exit:
    invoke ExitProcess, 0

proc packet_handler user, pkt_header, pkt_data
    pushad
    ; pkt_header + 8 is the 'len' field in pcap_pkthdr struct
    mov eax, [pkt_header]
    mov eax, [eax+8] 
    invoke printf, msg_pkt, eax
    popad
    ret
endp

section '.idata' import readable
    library kernel32,           'kernel32.dll',\
            msvcrt,             'msvcrt.dll',\
            wpcap,              'wpcap.dll'
    import  kernel32,\
            ExitProcess,        'ExitProcess'
    import  msvcrt,\
            printf,             'printf'
    import  wpcap,\
            pcap_findalldevs,   'pcap_findalldevs',\
            pcap_open_live,     'pcap_open_live',\
            pcap_loop,          'pcap_loop'
