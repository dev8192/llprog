format PE
entry start

include 'win32a.inc'

section '.data' readable writeable
    alldevs     dd 0
    errbuf      rb 256
    curr_dev    dd 0

    msg_header  db 'Available Network Interfaces:',13,10,0
    msg_dev     db 'Name: %s',13,10,0
    msg_desc    db 'Description: %s',13,10,0
    msg_nl      db 13,10,0
    msg_err     db 'Error finding devices: %s',0
    msg_none    db 'No devices found. Make sure Npcap is installed.',0

section '.text' readable executable
start:
    stdcall test10
    invoke ExitProcess, 0

proc test10
    cinvoke printf, "%d%c", esp, 10
    invoke pcap_findalldevs, 0, 0
    cinvoke printf, "%d%c", esp, 10
    ret
endp

proc test20
    ; int pcap_findalldevs(pcap_if_t **alldevs, char *errbuf)
    invoke pcap_findalldevs, alldevs, errbuf
    cmp eax, -1
    je .error

    mov eax, [alldevs]
    test eax, eax
    jz .no_devices
    mov [curr_dev], eax

    invoke printf, msg_header

.loop_devs:
    mov ebx, [curr_dev]
    test ebx, ebx
    jz .finish

    ; Print Name (first field in pcap_if struct)
    mov eax, [ebx]
    invoke printf, msg_dev, eax

    ; Print Description (second field in pcap_if struct)
    mov eax, [ebx+4]
    test eax, eax
    jz .next
    invoke printf, msg_desc, eax

.next:
    invoke printf, msg_nl
    ; Move to next device (next field is the 3rd dword in the pcap_if struct)
    mov eax, [ebx+8]
    mov [curr_dev], eax
    jmp .loop_devs

.finish:
    ; 2. Clean up and free the device list
    invoke pcap_freealldevs, [alldevs]
    jmp .exit

.error:
    invoke printf, msg_err, errbuf
    jmp .exit

.no_devices:
    invoke printf, msg_none

.exit:
    ret
endp

section '.idata' import readable
    library kernel32,           'kernel32.dll',\
            msvcrt,             'msvcrt.dll',\
            wpcap,              'wpcap.dll'
    import  kernel32,\
            ExitProcess,        'ExitProcess'
    import  msvcrt,\
            printf,             'printf'
    import  wpcap,\
            pcap_findalldevs,   'pcap_findalldevs',\
            pcap_freealldevs,   'pcap_freealldevs'
