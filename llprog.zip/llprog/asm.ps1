<#
Set-Alias asm ./asm.ps1
$env:INCLUDE = "C:/fasm/INCLUDE"
Unblock-File -Path ./asm.ps1

Set-ExecutionPolicy Bypass -Scope Process

$LASTEXITCODE must be 0
#>

param(
    [Parameter(Mandatory=$true)]
    [string]$InputAsm
)
$OutputFile = "./prog.exe"
$Fasm = "C:/fasm/fasm.exe"
& $Fasm $InputAsm $OutputFile
