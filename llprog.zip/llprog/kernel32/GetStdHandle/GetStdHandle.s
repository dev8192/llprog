; KERNEL32.INC of the fasm source code makes one definition twice:
; STD_OUTPUT_HANDLE    = -11
; STD_OUTPUT_HANDLE      = 0FFFFFFF5h

format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt     db '%u',0
    outbuf  rb 32

section '.bss' readable writeable
    hOut    dd ?

section '.code' code readable executable

start:
    invoke  GetStdHandle, STD_OUTPUT_HANDLE
    mov     [hOut], eax
    cinvoke wsprintfA, outbuf, fmt, eax
    invoke  lstrlenA, outbuf
    invoke  WriteConsoleA, [hOut], outbuf, eax, 0, 0
    invoke  ExitProcess, 0

section '.idata' import data readable writeable
    library kernel32, 'kernel32.dll', \
            user32,   'user32.dll'

    import kernel32, \
        ExitProcess,   'ExitProcess', \
        GetStdHandle,  'GetStdHandle', \
        WriteConsoleA, 'WriteConsoleA', \
        lstrlenA,      'lstrlenA'

    import user32, \
        wsprintfA, 'wsprintfA'

