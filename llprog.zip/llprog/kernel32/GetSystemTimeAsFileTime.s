format PE
entry start

include 'win32ax.inc'

; 1773906150758
; 1773906159121

section '.data' data readable writeable
    fmt_llu     db '%llu', 10, 0
    fmt_uu      db '%u %u', 10, 0
    
section '.text' code readable executable
start:
    stdcall main
    invoke  ExitProcess, 0

proc main1
    local filetime:FILETIME
    invoke  GetSystemTimeAsFileTime, addr filetime
    cinvoke printf, fmt_uu, [filetime.dwHighDateTime], [filetime.dwLowDateTime]
    ret
endp



proc main
    local filetime:FILETIME
    invoke  GetSystemTimeAsFileTime, filetime
    
    ; FILETIME is 100-nanosecond intervals since January 1, 1601
    ; Unix epoch is January 1, 1970
    ; Difference: 11644473600 seconds = 116444736000000000 (100-ns intervals)
    
    mov     eax, dword [filetime]
    mov     edx, dword [filetime + 4]
    
    ; Subtract the epoch difference (116444736000000000)
    ; Low part:  0x019DB1DED53E8000
    sub     eax, 0xD53E8000
    sbb     edx, 0x019DB1DE
    
    ; Now EDX:EAX contains 100-nanosecond intervals since Unix epoch
    ; Divide by 10000 to get milliseconds
    mov     ecx, 10000
    
    ; EDX:EAX / ECX
    ; First divide high part
    push    eax             ; save low part
    mov     eax, edx        ; high part to eax
    xor     edx, edx        ; clear edx
    div     ecx             ; eax = high quotient, edx = remainder
    mov     ebx, eax        ; save high quotient
    
    pop     eax             ; restore low part
    div     ecx             ; eax = low quotient (with remainder from high)
    
    ; Now EBX:EAX = milliseconds since Unix epoch
    
    cinvoke printf, fmt_llu, eax, ebx
    ret
endp

section '.idata' import data readable
    library kernel32,                   'kernel32.dll',\
            msvcrt,                     'msvcrt.dll'
    import  kernel32,\
            GetSystemTimeAsFileTime,    'GetSystemTimeAsFileTime',\
            ExitProcess,                'ExitProcess'
    import  msvcrt,\
            printf,                     'printf'
