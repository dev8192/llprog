format PE console
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    msg db 'Game Piano (A S D F keys, ESC to exit)', 0

section '.code' code readable executable

start:
    invoke printf, msg
main_loop:
    ;invoke _getch
    cmp al, 27
    je exit
    cmp al, 'a'
    je note1
    cmp al, 's'
    je note2
    cmp al, 'd'
    je note3
    cmp al, 'f'
    je note4
    jmp main_loop
note1:
    invoke Beep, 262, 200   
    jmp main_loop
note2:
    invoke Beep, 294, 200   
    jmp main_loop
note3:
    invoke Beep, 330, 200   
    jmp main_loop
note4:
    invoke Beep, 349, 200  
    jmp main_loop
exit:
    invoke ExitProcess, 0
section '.idata' import data readable writeable

library kernel32, 'kernel32.dll',\
        msvcrt,   'msvcrt.dll'

import kernel32,\
       Beep, 'Beep',\
       ExitProcess, 'ExitProcess'

import msvcrt,\
       printf, 'printf',\
       _getch, '_getch'
