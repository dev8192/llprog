format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    msg_start    db 'Locking thread to Core 0...', 10, 0
    msg_error    db 'ERROR: Thread escaped to Core %u!', 10, 0
    msg_success  db 'Success: Verified 10,000,000 iterations on Core 0.', 10, 0
    msg_fail_api db 'Failed to set Affinity Mask.', 10, 0

section '.code' code readable executable
start:
    cinvoke printf, msg_start

    ; --- 1. SET AFFINITY ---
    ; Mask 1 = Core 0
    ; Mask 2 = Core 1
    ; Mask 4 = Core 2
    invoke GetCurrentThread
    invoke SetThreadAffinityMask, eax, 1 
    test eax, eax
    jz api_failed

    ; --- 2. VERIFICATION LOOP ---
    mov ecx, 10000000        ; 10 Million checks
  verify_loop:
    push ecx                 ; Save loop counter
    
    invoke GetCurrentProcessorNumber
    
    ; Since we locked to Mask 1 (Core 0), 
    ; GetCurrentProcessorNumber MUST return 0.
    cmp eax, 0
    jne escaped              ; If it's not 0, affinity failed
    
    pop ecx                  ; Restore loop counter
    loop verify_loop

    ; --- 3. RESULTS ---
    cinvoke printf, msg_success
    jmp exit

escaped:
    ; EAX contains the core we accidentally moved to
    pop ecx                  ; Clean stack
    cinvoke printf, msg_error, eax
    jmp exit

api_failed:
    cinvoke printf, msg_fail_api

exit:
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll', \
            msvcrt,   'msvcrt.dll'

    import kernel32, ExitProcess, 'ExitProcess', \
                     GetCurrentThread, 'GetCurrentThread', \
                     SetThreadAffinityMask, 'SetThreadAffinityMask', \
                     GetCurrentProcessorNumber, 'GetCurrentProcessorNumber'

    import msvcrt, printf, 'printf'
