format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    filename db '0files/input.txt', 0
    char_x   db 'x'
    hFile    dd ?
    written  dd ?

section '.text' code readable executable
start:
    invoke CreateFile, filename, GENERIC_WRITE, 0, 0,\
        OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0
    mov [hFile], eax

    xor esi, esi

.patch_loop:
    invoke WriteFile, [hFile], char_x, 1, written, 0
    ; DWORD SetFilePointer(
    ;     [in]                HANDLE hFile,
    ;     [in]                LONG   lDistanceToMove,
    ;     [in, out, optional] PLONG  lpDistanceToMoveHigh,
    ;     [in]                DWORD  dwMoveMethod
    ; );
    invoke SetFilePointer, [hFile], 7, 0, FILE_CURRENT
    
    inc esi
    cmp esi, 5
    jl .patch_loop

    invoke CloseHandle, [hFile]
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll'

    import kernel32,\
        CreateFile, 'CreateFileA',\
        SetFilePointer, 'SetFilePointer',\
        WriteFile, 'WriteFile',\
        CloseHandle, 'CloseHandle',\
        ExitProcess, 'ExitProcess'
