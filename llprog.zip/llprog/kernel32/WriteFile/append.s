format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    filename db '0files/output.txt', 0
    msg      db 'This line is appended to the file.', 13, 10
    msg_len  = $ - msg
    
    msg_ok   db 'Successfully appended to file.', 10, 0
    msg_err  db 'Failed to open file.', 10, 0
    
    hFile    dd ?
    written  dd ?

section '.text' code readable executable
start:
    invoke CreateFile, filename, GENERIC_WRITE, 0, 0, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0
    cmp eax, -1
    je .error
    mov [hFile], eax

    invoke SetFilePointer, [hFile], 0, 0, FILE_END

    invoke WriteFile, [hFile], msg, msg_len, written, 0
    invoke CloseHandle, [hFile]

    cinvoke printf, msg_ok
    invoke ExitProcess, 0

.error:
    cinvoke printf, msg_err
    invoke ExitProcess, 1

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
        msvcrt, 'msvcrt.dll'

    import kernel32,\
        CreateFile, 'CreateFileA',\
        SetFilePointer, 'SetFilePointer',\
        WriteFile, 'WriteFile',\
        CloseHandle, 'CloseHandle',\
        ExitProcess, 'ExitProcess'

    import msvcrt,\
        printf, 'printf'
