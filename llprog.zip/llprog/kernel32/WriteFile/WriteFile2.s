format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    filename db '0files/output.txt', 0
    msg      db 'This is a message written to a file.', 13, 10
    msg_len  = $ - msg
    
    msg_ok   db 'Successfully wrote to output.txt', 10, 0
    msg_err  db 'Failed to open file.', 10, 0
    
    hFile    dd ?
    written  dd ?

section '.text' code readable executable
start:
    invoke CreateFile, \
        filename, \               ; LPCSTR                lpFileName
        GENERIC_WRITE, \          ; DWORD                 dwDesiredAccess
        0, \                      ; DWORD                 dwShareMode
        0, \                      ; LPSECURITY_ATTRIBUTES lpSecurityAttributes
        CREATE_ALWAYS, \          ; DWORD                 dwCreationDisposition
        FILE_ATTRIBUTE_NORMAL, \  ; DWORD                 dwFlagsAndAttributes
        0                         ; HANDLE                hTemplateFile
    cmp eax, -1
    je .error
    mov [hFile], eax

    invoke WriteFile, [hFile], msg, msg_len, written, 0
    invoke CloseHandle, [hFile]

    cinvoke printf, msg_ok
    invoke ExitProcess, 0

.error:
    cinvoke printf, msg_err
    invoke ExitProcess, 1

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
        msvcrt, 'msvcrt.dll'

    import kernel32,\
        CreateFile, 'CreateFileA',\
        WriteFile, 'WriteFile',\
        CloseHandle, 'CloseHandle',\
        ExitProcess, 'ExitProcess'

    import msvcrt,\
        printf, 'printf'
