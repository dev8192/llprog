format PE CONSOLE 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    msg db 'Hello via WriteFile!', 10
    msg_len = $ - msg
    bytes_written dd 0

section '.text' code readable executable
start:
    invoke GetStdHandle, STD_OUTPUT_HANDLE
    invoke WriteFile, eax, msg, msg_len, bytes_written, 0
    
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll'

    import kernel32,\
           GetStdHandle, 'GetStdHandle',\
           WriteFile, 'WriteFile',\
           ExitProcess, 'ExitProcess'
