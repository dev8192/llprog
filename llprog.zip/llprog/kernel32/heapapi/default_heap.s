; working
format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt_ptr db 'Allocated at: %p', 10, 0
    fmt_val db 'Value stored: %d', 10, 0
    fmt_msg db 'Memory freed successfully', 10, 0
    
    hHeap dd ?
    pMem  dd ?

section '.text' code readable executable
start:
    invoke GetProcessHeap
    mov [hHeap], eax

    invoke HeapAlloc, [hHeap], 0, 256
    mov [pMem], eax

    push eax
    push fmt_ptr
    call [printf]
    add esp, 8

    mov ecx, [pMem]
    mov dword [ecx], 777

    push dword [ecx]
    push fmt_val
    call [printf]
    add esp, 8

    invoke HeapFree, [hHeap], 0, [pMem]

    push fmt_msg
    call [printf]
    add esp, 4

    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL', \
        msvcrt, 'MSVCRT.DLL'

    import kernel32, \
        GetProcessHeap, 'GetProcessHeap', \
        HeapAlloc, 'HeapAlloc', \
        HeapFree, 'HeapFree', \
        ExitProcess, 'ExitProcess'

    import msvcrt, \
        printf, 'printf'
