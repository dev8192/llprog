format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt_heap db 'Heap created at: %p', 10, 0
    fmt_ptr  db 'Memory allocated at: %p', 10, 0
    fmt_val  db 'Value stored: %d', 10, 0
    fmt_msg  db 'Heap destroyed successfully', 10, 0
    
    hHeap dd ?
    pMem  dd ?

section '.text' code readable executable
start:
    ;invoke HeapCreate, 0, 4096, 0
    invoke HeapCreate, \
        0, \                ; DWORD  flOptions
        4096, \             ; SIZE_T dwInitialSize
        0                   ; SIZE_T dwMaximumSize
    mov [hHeap], eax

    push eax
    push fmt_heap
    call [printf]
    add esp, 8

    invoke HeapAlloc, [hHeap], 0, 1024
    mov [pMem], eax

    push eax
    push fmt_ptr
    call [printf]
    add esp, 8

    mov ecx, [pMem]
    mov dword [ecx], 999

    push dword [ecx]
    push fmt_val
    call [printf]
    add esp, 8

    invoke HeapFree, [hHeap], 0, [pMem]

    invoke HeapDestroy, [hHeap]

    push fmt_msg
    call [printf]
    add esp, 4

    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL', \
        msvcrt, 'MSVCRT.DLL'

    import kernel32, \
        HeapCreate, 'HeapCreate', \
        HeapAlloc, 'HeapAlloc', \
        HeapFree, 'HeapFree', \
        HeapDestroy, 'HeapDestroy', \
        ExitProcess, 'ExitProcess'

    import msvcrt, \
        printf, 'printf'
