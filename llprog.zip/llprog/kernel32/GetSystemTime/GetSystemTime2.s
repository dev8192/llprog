format PE console
include 'win32a.inc'

; SYSTEMTIME layout (8 WORDs, 16 bytes total):
; +0  wYear
; +2  wMonth
; +4  wDayOfWeek
; +6  wDay
; +8  wHour
; +10 wMinute
; +12 wSecond
; +14 wMilliseconds

section '.data' data readable writeable

    szFmt   db 'Date: %04d-%02d-%02d', 13, 10, \
               'Time: %02d:%02d:%02d.%03d', 13, 10, 0
    buf     rb 128
    written dd 0
    hOut    dd 0

section '.code' code readable executable

start:
    invoke  GetStdHandle, STD_OUTPUT_HANDLE
    mov     [hOut], eax

    sub     esp, 16
    mov     ebx, esp

    invoke  GetSystemTime, ebx

    movzx   eax, word [ebx+0]
    movzx   ecx, word [ebx+2]
    movzx   edx, word [ebx+6]
    push    edx
    push    ecx
    push    eax
    movzx   eax, word [ebx+14]
    movzx   ecx, word [ebx+12]
    movzx   edx, word [ebx+10]
    movzx   esi, word [ebx+8]
    push    eax
    push    ecx
    push    edx
    push    esi
    push    szFmt
    push    buf
    call    [wsprintf]
    add     esp, 9*4

    add     esp, 16

    invoke  lstrlen, buf
    invoke  WriteConsole, [hOut], buf, eax, written, 0

    invoke  ExitProcess, 0

section '.idata' import data readable writeable

    library kernel32, 'kernel32.dll', \
            user32,   'user32.dll'

    import kernel32, \
        GetStdHandle,  'GetStdHandle',  \
        GetSystemTime, 'GetSystemTime', \
        WriteConsole,  'WriteConsoleA', \
        lstrlen,       'lstrlenA',      \
        ExitProcess,   'ExitProcess'

    import user32, \
        wsprintf,      'wsprintfA'
