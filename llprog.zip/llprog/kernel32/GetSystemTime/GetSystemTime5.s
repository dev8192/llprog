format PE console 4.0
entry start

include 'win32a.inc'

STD_OUTPUT_HANDLE equ -11

struct SYSTEMTIME
    wYear           dw ?
    wMonth          dw ?
    wDayOfWeek      dw ?
    wDay            dw ?
    wHour           dw ?
    wMinute         dw ?
    wSecond         dw ?
    wMilliseconds   dw ?
ends

section '.data' data readable writeable

    sysTime         SYSTEMTIME
    outbuf          db '0000-00-00 00:00:00',13,10,0
    bytes_written   dd ?

section '.code' code readable executable

proc write_dec_zero value, pstr, width
    push    ebx
    push    esi
    push    edi

    mov     eax, [value]
    mov     edi, [pstr]
    mov     ecx, [width]
    mov     esi, ecx
    mov     ebx, 10

    add     edi, ecx
    dec     edi

  .next:
    xor     edx, edx
    div     ebx
    add     dl, '0'
    mov     [edi], dl
    dec     edi
    dec     ecx
    test    eax, eax
    jnz     .next

  .fill:
    cmp     ecx, 0
    jle     .done
    mov     byte [edi], '0'
    dec     edi
    dec     ecx
    jmp     .fill

  .done:
    pop     edi
    pop     esi
    pop     ebx
    ret
endp

start:
    invoke  GetSystemTime, sysTime

    movzx   eax, [sysTime.wYear]
    invoke  write_dec_zero, eax, outbuf, 4

    movzx   eax, [sysTime.wMonth]
    invoke  write_dec_zero, eax, outbuf+5, 2

    movzx   eax, [sysTime.wDay]
    invoke  write_dec_zero, eax, outbuf+8, 2

    movzx   eax, [sysTime.wHour]
    invoke  write_dec_zero, eax, outbuf+11, 2

    movzx   eax, [sysTime.wMinute]
    invoke  write_dec_zero, eax, outbuf+14, 2

    movzx   eax, [sysTime.wSecond]
    invoke  write_dec_zero, eax, outbuf+17, 2

    invoke  GetStdHandle, STD_OUTPUT_HANDLE
    mov     ebx, eax
    invoke  WriteConsoleA, ebx, outbuf, 21, bytes_written, 0

    invoke  ExitProcess, 0

section '.idata' import data readable writeable

    library kernel32, 'KERNEL32.DLL'

    import  kernel32, \
            GetSystemTime,  'GetSystemTime', \
            GetStdHandle,   'GetStdHandle', \
            WriteConsoleA,  'WriteConsoleA', \
            ExitProcess,    'ExitProcess'
