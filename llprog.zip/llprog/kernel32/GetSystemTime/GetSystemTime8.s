format PE console
entry start

include 'win32a.inc'

struct SYSTEMTIME
    wYear         dw ?
    wMonth        dw ?
    wDayOfWeek    dw ?
    wDay          dw ?
    wHour         dw ?
    wMinute       dw ?
    wSecond       dw ?
    wMilliseconds dw ?
ends

section '.data' data readable writeable
    st SYSTEMTIME
    fmt db 'System Time (UTC): %04d-%02d-%02d %02d:%02d:%02d', 10, 0

section '.code' code readable executable
start:
    invoke  GetSystemTime, st

    movzx   eax, [st.wSecond]
    push    eax
    movzx   eax, [st.wMinute]
    push    eax
    movzx   eax, [st.wHour]
    push    eax
    movzx   eax, [st.wDay]
    push    eax
    movzx   eax, [st.wMonth]
    push    eax
    movzx   eax, [st.wYear]
    push    eax
    push    fmt
    call    [printf]
    add     esp, 28

    invoke  ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL',\
            msvcrt, 'MSVCRT.DLL'

    import  kernel32,\
            GetSystemTime, 'GetSystemTime',\
            ExitProcess, 'ExitProcess'

    import  msvcrt,\
            printf, 'printf'
