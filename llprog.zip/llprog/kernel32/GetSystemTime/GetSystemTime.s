; not working
format PE console
include 'win32a.inc'

section '.data' data readable writeable
    fmt db 'Year: %d  Month: %d  Day: %d  Hour: %d  Minute: %d  Second: %d  Milliseconds: %d',13,10,0
    caption db 'System Time',0
    buffer rb 256
    hStdOut dd ?

section '.code' code readable executable
start:
    invoke  GetStdHandle, STD_OUTPUT_HANDLE
    mov     [hStdOut], eax

    sub     esp, sizeof.SYSTEMTIME
    mov     ebx, esp
    invoke  GetSystemTime, ebx

    movzx   eax, word [ebx+SYSTEMTIME.wYear]
    movzx   ecx, word [ebx+SYSTEMTIME.wMonth]
    movzx   edx, word [ebx+SYSTEMTIME.wDay]
    push    edx
    push    ecx
    push    eax
    movzx   eax, word [ebx+SYSTEMTIME.wHour]
    push    eax
    movzx   eax, word [ebx+SYSTEMTIME.wMinute]
    push    eax
    movzx   eax, word [ebx+SYSTEMTIME.wSecond]
    push    eax
    movzx   eax, word [ebx+SYSTEMTIME.wMilliseconds]
    push    eax
    push    fmt
    push    buffer
    call    [wsprintf]
    add     esp, 9*4

    invoke  lstrlen, buffer
    invoke  WriteConsole, [hStdOut], buffer, eax, 0, 0

    add     esp, sizeof.SYSTEMTIME
    invoke  ExitProcess, 0

section '.idata' import data readable writeable
    library kernel32, 'kernel32.dll', \
            user32,   'user32.dll'

    import kernel32, \
           GetStdHandle, 'GetStdHandle', \
           WriteConsole, 'WriteConsoleA', \
           lstrlen, 'lstrlenA', \
           ExitProcess, 'ExitProcess', \
           GetSystemTime, 'GetSystemTime'

    import user32, \
           wsprintf, 'wsprintfA'
