; working
format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    sysTime SYSTEMTIME
    fmt db 'System Time (UTC): %04d-%02d-%02d %02d:%02d:%02d', 10, 0

section '.code' code readable executable
start:
    invoke  GetSystemTime, sysTime

    movzx   eax, [sysTime.wSecond]
    push    eax
    movzx   eax, [sysTime.wMinute]
    push    eax
    movzx   eax, [sysTime.wHour]
    push    eax
    movzx   eax, [sysTime.wDay]
    push    eax
    movzx   eax, [sysTime.wMonth]
    push    eax
    movzx   eax, [sysTime.wYear]
    push    eax
    push    fmt
    call    [printf]
    add     esp, 28

    invoke  ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL',\
            msvcrt, 'MSVCRT.DLL'

    import  kernel32,\
            GetSystemTime, 'GetSystemTime',\
            ExitProcess, 'ExitProcess'

    import  msvcrt,\
            printf, 'printf'
