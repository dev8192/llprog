format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    st SYSTEMTIME
    fmt_time db 'System Time (UTC): %04d-%02d-%02d %02d:%02d:%02d.%03d', 10, 0

section '.text' code readable executable
start:
    invoke GetSystemTime, st

    movzx eax, [st.wMilliseconds]
    push eax
    movzx eax, [st.wSecond]
    push eax
    movzx eax,[st.wMinute]
    push eax
    movzx eax, [st.wHour]
    push eax
    movzx eax, [st.wDay]
    push eax
    movzx eax,[st.wMonth]
    push eax
    movzx eax, [st.wYear]
    push eax
    push fmt_time
    call [printf]
    add esp, 32

    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL', \
        msvcrt, 'MSVCRT.DLL'

    import kernel32, \
        GetSystemTime, 'GetSystemTime', \
        ExitProcess, 'ExitProcess'

    import msvcrt, \
        printf, 'printf'
        