format PE console 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    st SYSTEMTIME
    buf db 'Year: ',0
    num db '0000',13,10,0
    written dd ?

section '.code' code readable executable

proc itoa4 val, out
    mov eax, [val]
    mov edi, [out]
    mov ecx, 4
    mov ebx, 10
    add edi, 3
  .loop:
    xor edx, edx
    div ebx
    add dl, '0'
    mov [edi], dl
    dec edi
    dec ecx
    jnz .loop
    ret
endp

start:
    invoke GetSystemTime, st

    movzx eax, [st.wYear]
    invoke itoa4, eax, num

    invoke GetStdHandle, -11
    mov ebx, eax

    invoke WriteConsoleA, ebx, buf, 6, written, 0
    invoke WriteConsoleA, ebx, num, 6, written, 0

    invoke ExitProcess, 0

section '.idata' import data readable writeable
    library kernel32,'KERNEL32.DLL'
    import kernel32,\
        GetSystemTime,'GetSystemTime',\
        GetStdHandle,'GetStdHandle',\
        WriteConsoleA,'WriteConsoleA',\
        ExitProcess,'ExitProcess'
