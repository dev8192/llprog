; working
format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    sysTime SYSTEMTIME
    fmt db 'System Time (UTC): %04d-%02d-%02d %02d:%02d:%02d', 10, 0

section '.code' code readable executable
start:
    invoke  GetSystemTime, sysTime
    cinvoke printf, \
        fmt, \
        [sysTime.wYear], \
        [sysTime.wMonth], \
        [sysTime.wDay], \
        [sysTime.wHour], \
        [sysTime.wMinute], \
        [sysTime.wSecond]

    invoke  ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL',\
            msvcrt, 'MSVCRT.DLL'

    import  kernel32,\
            GetSystemTime, 'GetSystemTime',\
            ExitProcess, 'ExitProcess'

    import  msvcrt,\
            printf, 'printf'
