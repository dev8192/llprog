format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt_pid    db "Process ID (PID): %u", 10, 0
    fmt_handle db "Pseudo-Handle:    0x%08X", 10, 0

section '.code' code readable executable

start:
    invoke GetCurrentProcessId
    cinvoke printf, fmt_pid, eax

    ; constant -1 0xFFFFFFFF
    invoke GetCurrentProcess
    cinvoke printf, fmt_handle, eax

    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            msvcrt, 'msvcrt.dll'

    import kernel32,\
           GetCurrentProcessId, 'GetCurrentProcessId',\
           GetCurrentProcess, 'GetCurrentProcess',\
           ExitProcess, 'ExitProcess'

    import msvcrt,\
           printf, 'printf'
