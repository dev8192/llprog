format PE console 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt_d       db '%d', 10, 0
    fmt_u       db '%u', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc mul_div, num, numerator, denominator
    invoke MulDiv, [num], [numerator], [denominator]
    cinvoke printf, fmt_d, eax
    ret
endp

proc main1
    stdcall mul_div, 30, 10, 3
    ret
endp

proc main2
    cinvoke printf, fmt_d, 0x7FFFFFFF ; 2147483647
    cinvoke printf, fmt_d, 0x80000000 ; -2147483648
    cinvoke printf, fmt_u, 0xFFFFFFFF ; 4294967295
    cinvoke printf, fmt_d, 4294967295
    ret
endp

proc main3
    stdcall mul_div, -10, 10, 100
    stdcall mul_div, 10, -10, 100
    stdcall mul_div, 10, 10, -100
    ret
endp

; ------------------
; overflow
; 18446744073709551615
; ------------------
proc main4
    stdcall mul_div, 1073741824, 4, 2
    stdcall mul_div, -2147483648, 2, 1
    stdcall mul_div, 2147483647, 2, 1
    stdcall mul_div, 1000000000, 3, 1
    stdcall mul_div, 1000000000, 10, 5
    stdcall mul_div, 2147483647, 2147483647, 1
    ret
endp

; ------------------
; zero division
; ------------------
proc main5
    stdcall mul_div, 1000, 5, 0
    ret
endp

section '.idata' import data readable
library kernel32,       'kernel32.dll',\
        msvcrt,         'msvcrt.dll'
import  kernel32,\
        ExitProcess,    'ExitProcess',\
        MulDiv,         'MulDiv'
import  msvcrt,\
        printf,         'printf'
