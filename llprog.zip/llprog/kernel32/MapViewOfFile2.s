format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    file_name db '0files\months.txt', 0
    fmt_d db '%d', 10, 0
    fmt_c db '%c', 10, 0

    hFile dd 0
    hMap dd 0
    pView dd 0

section '.text' code readable executable
start:
    stdcall test10
    invoke  ExitProcess, 0

proc map_view_of_file, callback
    invoke CreateFile, file_name, GENERIC_READ, FILE_SHARE_READ, 0, \
           OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0
    cmp eax, INVALID_HANDLE_VALUE
    je .error
    mov [hFile], eax

    invoke CreateFileMapping, [hFile], 0, PAGE_READONLY, 0, 0, 0
    test eax, eax
    jz .close_file
    mov [hMap], eax

    invoke MapViewOfFile, [hMap], FILE_MAP_READ, 0, 0, 1
    test eax, eax
    jz .close_map
    mov [pView], eax

    stdcall [callback], pView

    invoke UnmapViewOfFile, [pView]

.close_map:
    invoke CloseHandle, [hMap]

.close_file:
    invoke CloseHandle, [hFile]

.error:
    ret
endp

proc print_single_char
    mov eax, [pView]
    movzx ecx, byte [eax]
    cinvoke printf, fmt_c, ecx
    ret
endp

proc print_multiple_chars
    mov eax, [pView]
    movzx ecx, byte [eax]
    cinvoke printf, fmt_c, ecx
    mov eax, [pView]
    movzx ecx, byte [eax + 1]
    cinvoke printf, fmt_c, ecx
    ret
endp

proc test10

endp

section '.idata' import data readable

    library kernel32, 'KERNEL32.DLL',\
            msvcrt, 'MSVCRT.DLL'

    import kernel32,\
           ExitProcess, 'ExitProcess',\
           CreateFile, 'CreateFileA',\
           CreateFileMapping, 'CreateFileMappingA',\
           MapViewOfFile, 'MapViewOfFile',\
           UnmapViewOfFile, 'UnmapViewOfFile',\
           CloseHandle, 'CloseHandle'

    import msvcrt,\
           printf, 'printf',\
           puts,    'puts'
