format PE console
entry start

include 'win32a.inc'

section '.text' code readable executable
start:
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll'
    import kernel32, ExitProcess, 'ExitProcess'
