format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    dir_name db "0files/new_folder", 0
    fmt_err  db "CreateDirectory failed. Error: %u", 10, 0

section '.code' code readable executable

start:
    invoke CreateDirectory, dir_name, 0
    test eax, eax
    jnz .success

    invoke GetLastError
    cinvoke printf, fmt_err, eax
    cinvoke exit, eax

.success:
    cinvoke exit, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            msvcrt, 'msvcrt.dll'

    import kernel32,\
           CreateDirectory, 'CreateDirectoryA',\
           GetLastError, 'GetLastError'

    import msvcrt,\
           exit, 'exit',\
           printf, 'printf'
