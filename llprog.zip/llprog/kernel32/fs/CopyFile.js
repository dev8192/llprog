const fs = require('fs');

const src_file = '0files/days.txt'
const dst_file = '0files/days1.txt'

try {
    fs.copyFileSync(src_file, dst_file); // overwrite
    // fs.copyFileSync(src_file, dst_file, fs.constants.COPYFILE_EXCL); // no overwrite
    console.log('File copied successfully.');
} catch (err) {
    console.error('Error copying file:', err);
}
