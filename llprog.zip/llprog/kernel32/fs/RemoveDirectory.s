format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    dir_name    db '0files/new_folder2', 0
    msg_success db 'Folder removed successfully.', 10, 0
    msg_error   db 'Error removing folder. Code: %d', 10, 0

section '.code' code readable executable
start:
    invoke  RemoveDirectory, dir_name
    test    eax, eax
    jz      .error

    cinvoke printf, msg_success
    jmp     .exit

.error:
    invoke  GetLastError
    cinvoke printf, msg_error, eax

.exit:
    invoke  ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            msvcrt,   'msvcrt.dll'

    import  kernel32,\
            RemoveDirectory, 'RemoveDirectoryA',\
            GetLastError,    'GetLastError',\
            ExitProcess,     'ExitProcess'

    import  msvcrt,\
            printf, 'printf'
