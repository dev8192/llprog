format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    target   db "0files/file2.txt", 0
    fmt_err  db "Delete failed. Error: %u", 10, 0

section '.code' code readable executable

start:
    invoke DeleteFile, target
    test eax, eax
    jnz .success

    invoke GetLastError
    cinvoke printf, fmt_err, eax
    cinvoke exit, eax

.success:
    cinvoke exit, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            msvcrt, 'msvcrt.dll'

    import kernel32,\
           DeleteFile, 'DeleteFileA',\
           GetLastError, 'GetLastError'

    import msvcrt,\
           exit, 'exit',\
           printf, 'printf'
