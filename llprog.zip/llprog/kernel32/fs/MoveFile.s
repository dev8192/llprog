format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    old_name db "0files/file1.txt", 0
    new_name db "0files/file2.txt", 0
    fmt_err  db "Error: %u", 10, 0

section '.code' code readable executable

start:
    invoke MoveFile, old_name, new_name
    test eax, eax
    jnz .success

    invoke GetLastError
    cinvoke printf, fmt_err, eax
    cinvoke exit, eax

.success:
    cinvoke exit, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            msvcrt, 'msvcrt.dll'

    import kernel32,\
           MoveFile, 'MoveFileA',\
           GetLastError, 'GetLastError'

    import msvcrt,\
           exit, 'exit',\
           printf, 'printf'
