format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    src_file    db '0files/days.txt', 0
    dst_file    db '0files/days1.txt', 0
    msg_success db 'File copied successfully.', 10, 0
    msg_error   db 'Error copying file. Code: %d', 10, 0

section '.code' code readable executable
start:
    ;invoke  CopyFile, src_file, dst_file, 0 ; overwrite
    invoke  CopyFile, src_file, dst_file, 1 ; no overwrite
    test    eax, eax
    jz      .error

    cinvoke printf, msg_success
    jmp     .exit

.error:
    invoke  GetLastError
    cinvoke printf, msg_error, eax

.exit:
    invoke  ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            msvcrt,   'msvcrt.dll'

    import  kernel32,\
            CopyFile, 'CopyFileA',\
            GetLastError, 'GetLastError',\
            ExitProcess, 'ExitProcess'

    import  msvcrt,\
            printf, 'printf'
