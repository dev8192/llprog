format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    path     db "my\nested\folder\path", 0
    fmt_err  db "Failed at segment. Error: %u", 10, 0

section '.code' code readable executable

start:
    mov edi, path

.loop:
    mov al, [edi]
    test al, al
    jz .done
    
    cmp al, '\'
    je .create
    cmp al, '/'
    je .create
    
    inc edi
    jmp .loop

.create:
    mov byte [edi], 0
    invoke CreateDirectory, path, 0
    mov byte [edi], '\'
    
    inc edi
    jmp .loop

.done:
    invoke CreateDirectory, path, 0
    test eax, eax
    jnz .success

    invoke GetLastError
    cmp eax, 183 ; ERROR_ALREADY_EXISTS
    je .success

    cinvoke printf, fmt_err, eax
    cinvoke exit, eax

.success:
    cinvoke exit, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            msvcrt, 'msvcrt.dll'

    import kernel32,\
           CreateDirectory, 'CreateDirectoryA',\
           GetLastError, 'GetLastError'

    import msvcrt,\
           exit, 'exit',\
           printf, 'printf'
