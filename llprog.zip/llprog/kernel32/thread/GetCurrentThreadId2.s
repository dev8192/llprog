format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    msg_main   db 'Main thread ID: %u', 10, 0
    msg_worker db 'Worker thread ID: %u', 10, 0
    thread_id  dd ?
    handles    dd 2 dup(?)

section '.text' code readable executable
start:
    invoke  GetCurrentThreadId
    cinvoke printf, msg_main, eax

    invoke  CreateThread, 0, 0, ThreadProc, 0, 0, thread_id
    mov     [handles], eax

    invoke  CreateThread, 0, 0, ThreadProc, 0, 0, thread_id
    mov     [handles+4], eax

    invoke  WaitForMultipleObjects, 2, handles, 1, -1

    invoke  CloseHandle, [handles]
    invoke  CloseHandle, [handles+4]

    invoke  ExitProcess, 0

ThreadProc:
    invoke  GetCurrentThreadId
    cinvoke printf, msg_worker, eax
    ret     4

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            msvcrt, 'msvcrt.dll'

    import kernel32,\
           CloseHandle, 'CloseHandle',\
           CreateThread, 'CreateThread',\
           ExitProcess, 'ExitProcess',\
           GetCurrentThreadId, 'GetCurrentThreadId',\
           WaitForMultipleObjects, 'WaitForMultipleObjects'

    import msvcrt,\
           printf, 'printf'
