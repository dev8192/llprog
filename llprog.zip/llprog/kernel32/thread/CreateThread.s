format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    msg_main      db 'Main thread started.', 10, 0
    msg_thread    db 'Worker thread running. Parameter: %d', 10, 0
    msg_wait      db 'Waiting for worker thread...', 10, 0
    msg_done      db 'Worker thread finished.', 10, 0
    thread_id     dd ?
    thread_handle dd ?
    thread_param  dd 42

section '.text' code readable executable

start:
    cinvoke printf, msg_main
    invoke  CreateThread, 0, 0, ThreadProc, [thread_param], 0, thread_id
    mov     [thread_handle], eax
    
    cinvoke printf, msg_wait
    invoke  WaitForSingleObject, [thread_handle], -1
    invoke  CloseHandle, [thread_handle]
    
    cinvoke printf, msg_done
    invoke  ExitProcess, 0

ThreadProc:
    push    ebp
    mov     ebp, esp
    
    invoke  Sleep, 30000
    cinvoke printf, msg_thread, [ebp+8]
    
    mov     eax, 0
    pop     ebp
    ret     4

section '.idata' import data readable

    library kernel32, 'KERNEL32.DLL',\
            msvcrt, 'MSVCRT.DLL'

    import kernel32,\
           CreateThread, 'CreateThread',\
           WaitForSingleObject, 'WaitForSingleObject',\
           CloseHandle, 'CloseHandle',\
           Sleep, 'Sleep',\
           ExitProcess, 'ExitProcess'

    import msvcrt,\
           printf, 'printf'
