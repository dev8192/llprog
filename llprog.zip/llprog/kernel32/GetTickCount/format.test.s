format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    msg_pass db 'Test passed.', 10, 0
    msg_fail db 'Test failed. Expected %u, got %u', 10, 0

section '.text' code readable executable
start:
    stdcall test10
    invoke ExitProcess, 0
    
proc test10
    stdcall check_result, 4294967295, 49, 17, 2, 47, 295
    stdcall check_result, 2693230109, 31, 4, 7, 10, 109 + 1
    ret
endp

MS_PER_SECOND = 1000
MS_PER_MINUTE = 60 * MS_PER_SECOND
MS_PER_HOUR   = 60 * MS_PER_MINUTE
MS_PER_DAY    = 24 * MS_PER_HOUR

proc check_result, expected, days, hours, mins, secs, msecs
    mov ecx, [msecs]

    mov eax, [secs]
    mov edx, MS_PER_SECOND
    mul edx
    add ecx, eax

    mov eax, [mins]
    mov edx, MS_PER_MINUTE
    mul edx
    add ecx, eax

    mov eax, [hours]
    mov edx, MS_PER_HOUR
    mul edx
    add ecx, eax

    mov eax, [days]
    mov edx, MS_PER_DAY
    mul edx
    add ecx, eax

    cmp ecx, [expected]
    jnz .fail
    cinvoke printf, msg_pass
    jmp .done
.fail:
    cinvoke printf, msg_fail, [expected], ecx
.done:
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
