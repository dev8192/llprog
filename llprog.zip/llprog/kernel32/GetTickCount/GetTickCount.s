format PE console
entry start

include 'win32a.inc'

section '.data' readable writable
    fmt      db '%u', 10, 0

section '.code' readable executable
start:
    invoke GetTickCount
    cinvoke printf, fmt, eax
    cinvoke exit, 0

section '.idata' import readable
    library kernel32, 'KERNEL32.DLL',\
            msvcrt,   'MSVCRT.DLL'
    import kernel32,\
           GetTickCount, 'GetTickCount'
    import msvcrt,\
           exit,    'exit',\
           printf,  'printf'
