format PE
entry start

include 'win32a.inc'

section '.data' readable writable
    fmt      db '%u', 10, 0

section '.text' readable executable
start:
    invoke GetTickCount
    cinvoke printf, fmt, eax
    invoke ExitProcess, 0

section '.idata' import readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            GetTickCount,   'GetTickCount',\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
