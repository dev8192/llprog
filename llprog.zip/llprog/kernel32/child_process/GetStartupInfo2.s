; not working
format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable

    si STARTUPINFO
    buf rb 1024

    fmt_cb             db 'cb:              %u',13,10,0
    fmt_lpReserved     db 'lpReserved:      0x%08X',13,10,0
    fmt_lpDesktop      db 'lpDesktop:       %s',13,10,0
    fmt_lpDesktop_null db 'lpDesktop:       (null)',13,10,0
    fmt_lpTitle        db 'lpTitle:         %s',13,10,0
    fmt_lpTitle_null   db 'lpTitle:         (null)',13,10,0
    fmt_dwX            db 'dwX:             %u',13,10,0
    fmt_dwY            db 'dwY:             %u',13,10,0
    fmt_dwXSize        db 'dwXSize:         %u',13,10,0
    fmt_dwYSize        db 'dwYSize:         %u',13,10,0
    fmt_dwXCountChars  db 'dwXCountChars:   %u',13,10,0
    fmt_dwYCountChars  db 'dwYCountChars:   %u',13,10,0
    fmt_dwFillAttribute db 'dwFillAttribute: 0x%08X',13,10,0
    fmt_dwFlags        db 'dwFlags:         0x%08X',13,10,0
    fmt_wShowWindow    db 'wShowWindow:     %u',13,10,0
    fmt_cbReserved2    db 'cbReserved2:     %u',13,10,0
    fmt_lpReserved2    db 'lpReserved2:     0x%08X',13,10,0
    fmt_hStdInput      db 'hStdInput:       0x%08X',13,10,0
    fmt_hStdOutput     db 'hStdOutput:      0x%08X',13,10,0
    fmt_hStdError      db 'hStdError:       0x%08X',13,10,0

section '.code' code readable executable

start:
    mov [si.cb], sizeof.STARTUPINFO
    invoke GetStartupInfoA, si

    cinvoke wsprintf, buf, fmt_cb, [si.cb]
    invoke WriteFile, <invoke GetStdHandle, STD_OUTPUT_HANDLE>, buf, eax, 0, 0

macro print_field fmt, val {
    cinvoke wsprintf, buf, fmt, val
    push eax
    invoke GetStdHandle, STD_OUTPUT_HANDLE
    pop ecx
    invoke WriteFile, eax, buf, ecx, 0, 0
}

macro print_str_field fmt_valid, fmt_null, ptr_val {
    local .is_null, .done
    mov eax, ptr_val
    test eax, eax
    jz .is_null
    cinvoke wsprintf, buf, fmt_valid, ptr_val
    jmp .done
.is_null:
    cinvoke wsprintf, buf, fmt_null
.done:
    push eax
    invoke GetStdHandle, STD_OUTPUT_HANDLE
    pop ecx
    invoke WriteFile, eax, buf, ecx, 0, 0
}

    print_field fmt_lpReserved, [si.lpReserved]

    print_str_field fmt_lpDesktop, fmt_lpDesktop_null, [si.lpDesktop]
    print_str_field fmt_lpTitle, fmt_lpTitle_null, [si.lpTitle]

    print_field fmt_dwX, [si.dwX]
    print_field fmt_dwY, [si.dwY]
    print_field fmt_dwXSize, [si.dwXSize]
    print_field fmt_dwYSize, [si.dwYSize]
    print_field fmt_dwXCountChars, [si.dwXCountChars]
    print_field fmt_dwYCountChars, [si.dwYCountChars]
    print_field fmt_dwFillAttribute, [si.dwFillAttribute]
    print_field fmt_dwFlags, [si.dwFlags]

    movzx eax, [si.wShowWindow]
    print_field fmt_wShowWindow, eax

    movzx eax, [si.cbReserved2]
    print_field fmt_cbReserved2, eax

    print_field fmt_lpReserved2, [si.lpReserved2]
    print_field fmt_hStdInput, [si.hStdInput]
    print_field fmt_hStdOutput, [si.hStdOutput]
    print_field fmt_hStdError, [si.hStdError]

    invoke ExitProcess, 0

section '.idata' import data readable

    library kernel32, 'kernel32.dll',\
            user32, 'user32.dll'

    import kernel32,\
           GetStartupInfoA, 'GetStartupInfoA',\
           GetStdHandle, 'GetStdHandle',\
           WriteFile, 'WriteFile',\
           ExitProcess, 'ExitProcess'

    import user32,\
           wsprintf, 'wsprintfA'
