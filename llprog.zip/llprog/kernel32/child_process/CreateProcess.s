format PE
entry start

include 'win32ax.inc'

LANG_ENGLISH_US = 0x0409

section '.data' data readable writeable
    fmt_success     db 'Success: %x', 10, 0
    fmt_err         db "Error %u (0x%X): '%s'", 10, 0
    buffer          rb 256

    app_name        db 'kernel32/children/hello.exe', 0
    cmd_line1       db 'C:\Windows\System32\notepad.exe 0files/abc.txt', 0
    cmd_line2       db 'C:\Windows\System32\notepad.exe "0files/hello world.txt"', 0
    start_info      STARTUPINFO
    proc_info       PROCESS_INFORMATION

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc CreateProcess_func lpApplicationName,\
        lpCommandLine, lpProcessAttributes, lpThreadAttributes,\
        bInheritHandles, dwCreationFlags, lpEnvironment,\
        lpCurrentDirectory, lpStartupInfo, lpProcessInformation

    invoke  CreateProcess, [lpApplicationName],\
            [lpCommandLine], [lpProcessAttributes], [lpThreadAttributes],\
            [bInheritHandles], [dwCreationFlags], [lpEnvironment],\
            [lpCurrentDirectory], [lpStartupInfo], [lpProcessInformation]
    push    eax
    test    eax, eax
    jz      .error
    cinvoke printf, fmt_success, eax
    jmp     .done
.error:
    invoke  GetLastError
    mov     ebx, eax
    invoke  FormatMessage,\
            FORMAT_MESSAGE_FROM_SYSTEM + FORMAT_MESSAGE_MAX_WIDTH_MASK,\
            0, eax, LANG_ENGLISH_US, buffer, 256, 0
    cinvoke printf, fmt_err, ebx, ebx, buffer
.done:
    pop eax
    ret
endp

; ------------------------------------------------
; lpApplicationName
; ------------------------------------------------
proc main1
    cinvoke puts, '*** main1 ***'
    mov [start_info.cb], sizeof.STARTUPINFO
    stdcall CreateProcess_func, app_name, 0, 0, 0, 0, \
            0, 0, 0, start_info, proc_info
    ret
endp

; ------------------------------------------------
; lpCommandLine
; ------------------------------------------------
proc main
    cinvoke puts, '*** main1 ***'
    mov [start_info.cb], sizeof.STARTUPINFO
    stdcall CreateProcess_func, 0, cmd_line2, 0, 0, 0, \
            0, 0, 0, start_info, proc_info
    ret
endp

; ------------------------------------------------
; Error 87 (0x57): 'The parameter is incorrect. '
; ------------------------------------------------
proc main34534b
    cinvoke puts, '*** main1 ***'
    mov [start_info.cb], sizeof.STARTUPINFO
    stdcall CreateProcess_func, 0, 0, 0, 0, 0, \
            0, 0, 0, start_info, proc_info
    ret
endp

; ------------------------------------------------
; Error 87 (0x57): 'The parameter is incorrect. '
; ------------------------------------------------
proc main43f
    cinvoke puts, '*** main1 ***'
    mov [start_info.cb], sizeof.STARTUPINFO
    stdcall CreateProcess_func, app_name, 0, 0, 0, 0, \
            0, 0, 0, start_info, 0
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    mov [start_info.cb], sizeof.STARTUPINFO
    stdcall CreateProcess_func, app_name, 0, 0, 0, 0, \
            DETACHED_PROCESS, 0, 0, start_info, proc_info
    test eax, eax
    jz .failed
    ;invoke CloseHandle, [proc_info.hProcess]
    ;invoke CloseHandle, [proc_info.hThread]
.failed:
    ret
endp

proc main3
    cinvoke puts, '*** main3 ***'
    invoke GetStartupInfo, start_info
    stdcall CreateProcess_func, app_name, 0, 0, 0, 0, \
            DETACHED_PROCESS, 0, 0, start_info, proc_info
    test eax, eax
    jz .failed
    invoke CloseHandle, [proc_info.hProcess]
    invoke CloseHandle, [proc_info.hThread]
.failed:
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            FormatMessage,  'FormatMessageA',\
            GetLastError,   'GetLastError',\
            GetStartupInfo, 'GetStartupInfoA',\
            CreateProcess,  'CreateProcessA',\
            CloseHandle,    'CloseHandle',\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
