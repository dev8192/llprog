format PE GUI 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    app_name    db './tetris.exe', 0
    start_info  STARTUPINFO
    proc_info   PROCESS_INFORMATION

section '.code' code readable executable
start:
    invoke GetStartupInfo, start_info

    ; Create the detached process
    ; 0x08 = DETACHED_PROCESS
    invoke CreateProcess, app_name, NULL, NULL, NULL, FALSE, \
           0x08, NULL, NULL, start_info, proc_info
    test eax, eax
    jz .failed

    ; Close handles to fully orphan the child
    invoke CloseHandle, [proc_info.hProcess]
    invoke CloseHandle, [proc_info.hThread]

.failed:
    invoke ExitProcess, 0

section '.idata' import data readable writeable
  library kernel32, 'KERNEL32.DLL'

  import kernel32, \
         GetStartupInfo, 'GetStartupInfoA', \
         CreateProcess, 'CreateProcessA', \
         CloseHandle, 'CloseHandle', \
         ExitProcess, 'ExitProcess'
