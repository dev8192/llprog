; not working
format PE Console 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    si STARTUPINFO

    null_str            db "(null)", 0
    fmt_cb              db "cb: %u", 10, 0
    fmt_str             db "%s: %s", 10, 0
    fmt_u               db "%s: %u", 10, 0
    fmt_hex             db "%s: 0x%08X", 10, 0

    s_lpReserved        db "lpReserved", 0
    s_lpDesktop         db "lpDesktop", 0
    s_lpTitle           db "lpTitle", 0
    s_dwX               db "dwX", 0
    s_dwY               db "dwY", 0
    s_dwXSize           db "dwXSize", 0
    s_dwYSize           db "dwYSize", 0
    s_dwXCountChars     db "dwXCountChars", 0
    s_dwYCountChars     db "dwYCountChars", 0
    s_dwFillAttribute   db "dwFillAttribute", 0
    s_dwFlags           db "dwFlags", 0
    s_wShowWindow       db "wShowWindow", 0
    s_cbReserved2       db "cbReserved2", 0
    s_lpReserved2       db "lpReserved2", 0
    s_hStdInput         db "hStdInput", 0
    s_hStdOutput        db "hStdOutput", 0
    s_hStdError         db "hStdError", 0

section '.text' code readable executable

start:
    invoke  GetStartupInfoA, si

    cinvoke printf, fmt_cb, [si.cb]

    mov     eax, [si.lpReserved]
    test    eax, eax
    jnz     .lpres_ok
    mov     eax, null_str
.lpres_ok:
    cinvoke printf, fmt_str, s_lpReserved, eax

    mov     eax, [si.lpDesktop]
    test    eax, eax
    jnz     .lpdesk_ok
    mov     eax, null_str
.lpdesk_ok:
    cinvoke printf, fmt_str, s_lpDesktop, eax

    mov     eax, [si.lpTitle]
    test    eax, eax
    jnz     .lptit_ok
    mov     eax, null_str
.lptit_ok:
    cinvoke printf, fmt_str, s_lpTitle, eax

    cinvoke printf, fmt_u, s_dwX, [si.dwX]
    cinvoke printf, fmt_u, s_dwY, [si.dwY]
    cinvoke printf, fmt_u, s_dwXSize, [si.dwXSize]
    cinvoke printf, fmt_u, s_dwYSize, [si.dwYSize]
    cinvoke printf, fmt_u, s_dwXCountChars, [si.dwXCountChars]
    cinvoke printf, fmt_u, s_dwYCountChars, [si.dwYCountChars]
    cinvoke printf, fmt_u, s_dwFillAttribute, [si.dwFillAttribute]
    cinvoke printf, fmt_hex, s_dwFlags, [si.dwFlags]

    movzx   eax, word [si.wShowWindow]
    cinvoke printf, fmt_u, s_wShowWindow, eax

    movzx   eax, word [si.cbReserved2]
    cinvoke printf, fmt_u, s_cbReserved2, eax

    cinvoke printf, fmt_hex, s_lpReserved2, [si.lpReserved2]
    cinvoke printf, fmt_hex, s_hStdInput, [si.hStdInput]
    cinvoke printf, fmt_hex, s_hStdOutput, [si.hStdOutput]
    cinvoke printf, fmt_hex, s_hStdError, [si.hStdError]

    invoke  ExitProcess, 0

section '.idata' import data readable

    library kernel32, 'KERNEL32.DLL',\
            msvcrt, 'MSVCRT.DLL'

    import kernel32,\
           ExitProcess, 'ExitProcess',\
           GetStartupInfoA, 'GetStartupInfoA'

    import msvcrt,\
           printf, 'printf'
