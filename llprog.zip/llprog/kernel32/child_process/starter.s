format PE
entry start

include 'win32a.inc'

section '.data' data readable writable
    target_exe   db 'C:\path\to\file\target.exe', 0
    new_dll_path db ';C:\some\other\path', 0   ; Note the leading semicolon
    env_var_name db 'PATH', 0

    old_path     rb 4096
    new_path     rb 4096
    
    startup_info STARTUPINFO
    process_info PROCESS_INFORMATION

section '.text' code readable executable
start:
    invoke GetEnvironmentVariable, env_var_name, old_path, 4096
    test eax, eax
    jz .fail

    ; 2. PATCH THE PATH (Concatenate: New = Old + ";C:\..." )
    invoke lstrcpy, new_path, old_path
    invoke lstrcat, new_path, new_dll_path
    
    ; Apply to current process so child inherits it
    invoke SetEnvironmentVariable, env_var_name, new_path

    ; 3. START CHILD PROCESS
    invoke GetStartupInfo, startup_info
    invoke CreateProcess, target_exe, 0, 0, 0, FALSE, 0, 0, 0, startup_info, process_info
    test eax, eax
    jz .restore_fail

    ; 4. WAIT UNTIL TERMINATED
    invoke WaitForSingleObject, [process_info.hProcess], -1 ; -1 = Infinite

    ; Clean up child handles
    invoke CloseHandle, [process_info.hProcess]
    invoke CloseHandle, [process_info.hThread]

.restore_fail:
    ; 5. "UNPATCH" (Restore old path)
    invoke SetEnvironmentVariable, env_var_name, old_path

.fail:
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL'
    import kernel32, \
           GetEnvironmentVariable, 'GetEnvironmentVariableA', \
           SetEnvironmentVariable, 'SetEnvironmentVariableA', \
           CreateProcess, 'CreateProcessA', \
           WaitForSingleObject, 'WaitForSingleObject', \
           GetStartupInfo, 'GetStartupInfoA', \
           lstrcpy, 'lstrcpyA', \
           lstrcat, 'lstrcatA', \
           CloseHandle, 'CloseHandle', \
           ExitProcess, 'ExitProcess'
