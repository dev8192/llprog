format PE GUI 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    app_name    db './tetris.exe', 0
    start_info  STARTUPINFO
    proc_info   PROCESS_INFORMATION

section '.code' code readable executable
start:
    mov [start_info.cb], sizeof.STARTUPINFO

    ; 2. Create the process with DETACHED_PROCESS (0x08)
    invoke CreateProcess, app_name, NULL, NULL, NULL, FALSE, \
           0x08, NULL, NULL, start_info, proc_info
    
    ; 3. Check for success (EAX != 0)
    test eax, eax
    jz .exit

    ; 4. Close handles to orphan the child
    invoke CloseHandle, [proc_info.hProcess]
    invoke CloseHandle, [proc_info.hThread]

.exit:
    invoke ExitProcess, 0

section '.idata' import data readable writeable
  library kernel32, 'KERNEL32.DLL'
  import kernel32, \
         CreateProcess, 'CreateProcessA', \
         CloseHandle, 'CloseHandle', \
         ExitProcess, 'ExitProcess'
