format PE GUI 4.0
include 'win32ax.inc' ; Use 'x' for better structure support

section '.data' readable writeable
    cmd_line db 'cmd.exe /c ipconfig', 0
    filename db 'output.txt', 0
    
    sinfo    STARTUPINFO          <0>
    pinfo    PROCESS_INFORMATION  <0>
    sattr    SECURITY_ATTRIBUTES  sizeof.SECURITY_ATTRIBUTES, 0, TRUE ; TRUE allows inheritance

section '.code' readable executable
start:
    ; 1. Create (or open) the file where output will go
    invoke CreateFile, filename, GENERIC_WRITE, FILE_SHARE_READ, \
           sattr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL
    mov ebx, eax ; Save file handle in ebx

    ; 2. Configure STARTUPINFO to use this file for output/errors
    mov [sinfo.cb], sizeof.STARTUPINFO
    mov [sinfo.dwFlags], STARTF_USESTDHANDLES
    mov [sinfo.hStdOutput], ebx ; Point stdout to our file
    mov [sinfo.hStdError], ebx  ; Point stderr to our file

    ; 3. Run the process with handle inheritance set to TRUE
    invoke CreateProcess, NULL, cmd_line, NULL, NULL, TRUE, \
           0, NULL, NULL, sinfo, pinfo

    ; 4. Wait for it to finish so the file is fully written
    invoke WaitForSingleObject, [pinfo.hProcess], INFINITE

    ; Cleanup
    invoke CloseHandle, ebx ; Close our file handle
    invoke CloseHandle, [pinfo.hProcess]
    invoke CloseHandle, [pinfo.hThread]

    ; Now you can simply read 'output.txt' to see what happened!
    invoke MessageBox, NULL, "Check output.txt for results", "Done", MB_OK
    invoke ExitProcess, 0

.end start
