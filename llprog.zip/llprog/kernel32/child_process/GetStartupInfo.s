format PE
entry start

include 'win32ax.inc'

; --------------------------------------------------------------------
; 18 fields, 68 bytes
; cb
; lpReserved          lpDesktop           lpTitle
; dwX/dwY             dwXSize/dwYSize     dwXCountChars/dwYCountChars
; dwFillAttribute     dwFlags             wShowWindow
; cbReserved2         lpReserved2
; hStdInput           hStdOutput          hStdError
; --------------------------------------------------------------------
section '.data' data readable writeable
    fmt_d       db '%d', 10, 0
    fmt_s       db '%s', 10, 0

    fmt_cb              db 'cb              : %u', 10, 0
    fmt_lpReserved      db 'lpReserved      : 0x%08X', 10, 0
    fmt_lpDesktop       db 'lpDesktop       : %s', 10, 0
    fmt_lpTitle         db 'lpTitle         : %s', 10, 0
    fmt_dwX             db 'dwX             : %u', 10, 0
    fmt_dwY             db 'dwY             : %u', 10, 0
    fmt_dwXSize         db 'dwXSize         : %u', 10, 0
    fmt_dwYSize         db 'dwYSize         : %u', 10, 0
    fmt_dwXCountChars   db 'dwXCountChars   : %u', 10, 0
    fmt_dwYCountChars   db 'dwYCountChars   : %u', 10, 0
    fmt_dwFillAttribute db 'dwFillAttribute : 0x%08X', 10, 0
    fmt_dwFlags         db 'dwFlags         : 0x%08X', 10, 0
    fmt_wShowWindow     db 'wShowWindow     : %u', 10, 0
    fmt_cbReserved2     db 'cbReserved2     : %u', 10, 0
    fmt_lpReserved2     db 'lpReserved2     : %u', 10, 0
    fmt_hStdInput       db 'hStdInput       : 0x%08X', 10, 0
    fmt_hStdOutput      db 'hStdOutput      : 0x%08X', 10, 0
    fmt_hStdError       db 'hStdError       : 0x%08X', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke  ExitProcess, 0

proc main1
    cinvoke puts, '*** main1 ***'
    cinvoke printf, fmt_d, sizeof.STARTUPINFO   ; 68
    cinvoke printf, fmt_d, 16 * 4 + 2 * 2
    cinvoke printf, fmt_d, STARTUPINFO.lpReserved
    cinvoke printf, fmt_d, STARTUPINFO.lpTitle
    ret
endp

proc main
    local si1:STARTUPINFO
    lea edi, [si1]
    mov ecx, sizeof.STARTUPINFO
    xor eax, eax
    rep stosb
    cinvoke puts, '*** main2 ***'
    invoke  GetStartupInfo, addr si1
    cinvoke printf, fmt_d, eax
    stdcall print_startup_info, addr si1
    cinvoke printf, fmt_s, [si1.lpTitle]
    ret
endp

proc print_startup_info uses esi, si_ptr
    mov esi, [si_ptr]
    cinvoke printf, fmt_cb, [esi + STARTUPINFO.cb]
    cinvoke printf, fmt_lpReserved, [esi + STARTUPINFO.lpReserved]
    cinvoke printf, fmt_lpDesktop, [esi + STARTUPINFO.lpDesktop]
    cinvoke printf, fmt_lpTitle, [esi + STARTUPINFO.lpTitle]
    cinvoke printf, fmt_dwX, [esi + STARTUPINFO.dwX]
    cinvoke printf, fmt_dwY, [esi + STARTUPINFO.dwY]
    cinvoke printf, fmt_dwXSize, [esi + STARTUPINFO.dwXSize]
    cinvoke printf, fmt_dwYSize, [esi + STARTUPINFO.dwYSize]
    cinvoke printf, fmt_dwXCountChars, [esi + STARTUPINFO.dwXCountChars]
    cinvoke printf, fmt_dwYCountChars, [esi + STARTUPINFO.dwYCountChars]
    cinvoke printf, fmt_dwFillAttribute, [esi + STARTUPINFO.dwFillAttribute]
    cinvoke printf, fmt_dwFlags, [esi + STARTUPINFO.dwFlags]
    movzx eax, [esi + STARTUPINFO.wShowWindow]
    cinvoke printf, fmt_wShowWindow, eax
    movzx eax, [esi + STARTUPINFO.cbReserved2]
    cinvoke printf, fmt_cbReserved2, eax
    cinvoke printf, fmt_lpReserved2, [esi + STARTUPINFO.lpReserved2]
    cinvoke printf, fmt_hStdInput, [esi + STARTUPINFO.hStdInput]
    cinvoke printf, fmt_hStdOutput, [esi + STARTUPINFO.hStdOutput]
    cinvoke printf, fmt_hStdError, [esi + STARTUPINFO.hStdError]
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            GetStartupInfo, 'GetStartupInfoA',\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
