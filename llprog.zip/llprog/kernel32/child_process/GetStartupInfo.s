; not working
format PE CONSOLE 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt db 'STARTUPINFO Structure:', 10 \
           '  cb:              %u', 10 \
           '  lpReserved:      %p', 10 \
           '  lpDesktop:       %s', 10 \
           '  lpTitle:         %s', 10 \
           '  dwX:             %u', 10 \
           '  dwY:             %u', 10 \
           '  dwXSize:         %u', 10 \
           '  dwYSize:         %u', 10 \
           '  dwFlags:         0x%08X', 10 \
           '  wShowWindow:     %u', 10, 0
    
    start_info STARTUPINFO

section '.code' code readable executable
start:
    invoke  GetStartupInfo, start_info

    cinvoke printf, fmt, \
            [start_info.cb], \
            [start_info.lpReserved], \
            [start_info.lpDesktop], \
            [start_info.lpTitle], \
            [start_info.dwX], \
            [start_info.dwY], \
            [start_info.dwXSize], \
            [start_info.dwYSize], \
            [start_info.dwFlags], \
            [start_info.wShowWindow]

    invoke  ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL', \
            msvcrt, 'MSVCRT.DLL'

    import kernel32, \
           GetStartupInfo, 'GetStartupInfoA', \
           ExitProcess, 'ExitProcess'

    import msvcrt, \
           printf, 'printf'
