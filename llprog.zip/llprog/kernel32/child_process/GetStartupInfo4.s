format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable

start_info STARTUPINFO

fmt db 'STARTUPINFO:', 0Dh, 0Ah
    db '  cb              = %lu', 0Dh, 0Ah
    db '  lpReserved      = 0x%08X', 0Dh, 0Ah
    db '  lpDesktop       = 0x%08X', 0Dh, 0Ah
    db '  lpTitle         = 0x%08X', 0Dh, 0Ah
    db '  dwX             = %lu', 0Dh, 0Ah
    db '  dwY             = %lu', 0Dh, 0Ah
    db '  dwXSize         = %lu', 0Dh, 0Ah
    db '  dwYSize         = %lu', 0Dh, 0Ah
    db '  dwXCountChars   = %lu', 0Dh, 0Ah
    db '  dwYCountChars   = %lu', 0Dh, 0Ah
    db '  dwFillAttribute = 0x%08X', 0Dh, 0Ah
    db '  dwFlags         = 0x%08X', 0Dh, 0Ah
    db '  wShowWindow     = %u', 0Dh, 0Ah
    db '  hStdInput       = 0x%08X', 0Dh, 0Ah
    db '  hStdOutput      = 0x%08X', 0Dh, 0Ah
    db '  hStdError       = 0x%08X', 0Dh, 0Ah, 0

section '.code' code readable executable

start:
    mov     [start_info.cb], sizeof.STARTUPINFO
    invoke  GetStartupInfoA, start_info

    cinvoke printf, fmt, \
            [start_info.cb], \
            [start_info.lpReserved], \
            [start_info.lpDesktop], \
            [start_info.lpTitle], \
            [start_info.dwX], \
            [start_info.dwY], \
            [start_info.dwXSize], \
            [start_info.dwYSize], \
            [start_info.dwXCountChars], \
            [start_info.dwYCountChars], \
            [start_info.dwFillAttribute], \
            [start_info.dwFlags], \
            [start_info.wShowWindow], \
            [start_info.hStdInput], \
            [start_info.hStdOutput], \
            [start_info.hStdError]

    invoke  ExitProcess, 0

section '.idata' import data readable

    library kernel32, 'kernel32.dll', \
            msvcrt,   'msvcrt.dll'

    import kernel32, \
           GetStartupInfoA, 'GetStartupInfoA', \
           ExitProcess,     'ExitProcess'

    import msvcrt, \
           printf, 'printf'
