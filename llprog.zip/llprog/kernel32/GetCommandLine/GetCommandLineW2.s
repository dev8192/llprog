format PE CONSOLE 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt_cmd db 'Command Line: %ls', 10, 0

section '.text' code readable executable
start:
    invoke GetCommandLineW
    cinvoke printf, fmt_cmd, eax

    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL', \
            msvcrt, 'MSVCRT.DLL'

    import kernel32, \
           GetCommandLineW, 'GetCommandLineW', \
           ExitProcess, 'ExitProcess'

    import msvcrt, \
           printf, 'printf'
