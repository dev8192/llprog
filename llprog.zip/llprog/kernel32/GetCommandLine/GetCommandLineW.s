format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt db "Command line: %ls", 10, 0

section '.text' code readable executable
start:
    invoke GetCommandLine
    cinvoke printf, fmt, eax
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32,   'KERNEL32.DLL',\
            msvcrt,     'MSVCRT.DLL'

    import kernel32,\
        GetCommandLine, 'GetCommandLineW',\
        ExitProcess,    'ExitProcess'

    import msvcrt,\
        printf, 'printf'
