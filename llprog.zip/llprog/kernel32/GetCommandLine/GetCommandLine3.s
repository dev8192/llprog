format PE console
include 'win32a.inc'

entry start

section '.data' data readable writeable
    fmt db "Command line: %s", 10, 0

section '.code' code readable executable
start:
    call [GetCommandLineA]
    
    ; arguments are pushed in reverse order
    push eax
    push fmt
    call [printf]
    add esp, 8 ; cdecl - caller cleans up the stack
    
    push 0
    call [ExitProcess]

section '.idata' import data readable writeable

    library kernel32, 'kernel32.dll', \
            msvcrt,   'msvcrt.dll'

    import kernel32, \
        GetCommandLineA, 'GetCommandLineA', \
        ExitProcess,     'ExitProcess'

    import msvcrt, \
        printf, 'printf'
