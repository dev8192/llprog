format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt_str     db "'%s'", 10, 0

section '.text' code readable executable
start:
    stdcall test10
    invoke  ExitProcess, 0

; ------------------------------------------------------------------------------
; ./prog.exe                '"C:\llprog\prog.exe"'
; ./prog.exe hello          '"C:\llprog\prog.exe" hello'
; ./prog.exe hello 123      '"C:\llprog\prog.exe" hello 123'
; ------------------------------------------------------------------------------
proc test10
    invoke  GetCommandLine
    cinvoke printf, fmt_str, eax
    ret
endp

proc test20
    invoke  GetCommandLine
    mov     esi, eax

    mov     edi, esi
  .len_loop:
    cmp     byte [edi], 0
    je      .len_done
    inc     edi
    jmp     .len_loop
  .len_done:
    sub     edi, esi

    invoke  GetStdHandle, STD_OUTPUT_HANDLE
    mov     ebx, eax


    invoke WriteFile, \
        ebx, \            ; hFile
        esi, \            ; lpBuffer
        edi, \            ; nNumberOfBytesToWrite
        bytes_written, \  ; lpNumberOfBytesWritten
        0                 ; lpOverlapped

    mov     byte [newline], 13
    mov     byte [newline+1], 10
    invoke  WriteFile, ebx, newline, 2, bytes_written, 0
    ret
endp

section '.idata' import data readable writeable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            GetCommandLine, 'GetCommandLineA',\
            GetStdHandle,   'GetStdHandle',\
            WriteFile,      'WriteFile',\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
