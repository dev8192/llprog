format PE console 4.0
entry start

include 'win32a.inc'

section '.text' code readable executable

start:
    invoke  GetCommandLineA
    mov     esi, eax

    mov     edi, esi
  .len_loop:
    cmp     byte [edi], 0
    je      .len_done
    inc     edi
    jmp     .len_loop
  .len_done:
    sub     edi, esi

    invoke  GetStdHandle, STD_OUTPUT_HANDLE
    mov     ebx, eax

    invoke WriteFile, \
        ebx, \            ; hFile
        esi, \            ; lpBuffer
        edi, \            ; nNumberOfBytesToWrite
        bytes_written, \  ; lpNumberOfBytesWritten
        0                 ; lpOverlapped

    mov     byte [newline], 13
    mov     byte [newline+1], 10
    invoke  WriteFile, ebx, newline, 2, bytes_written, 0

    invoke  ExitProcess, 0

section '.data' data readable writeable
    bytes_written dd ?
    newline       db 0,0

section '.idata' import data readable writeable
    library kernel32, 'KERNEL32.DLL'
    import kernel32, \
        GetCommandLineA, 'GetCommandLineA', \
        GetStdHandle,    'GetStdHandle', \
        WriteFile,       'WriteFile', \
        ExitProcess,     'ExitProcess'
