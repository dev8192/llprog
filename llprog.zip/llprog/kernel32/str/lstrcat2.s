format PE console 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    res_path    db 256 dup(0)
    root        db 'C:\Users\', 0
    user        db 'Developer\', 0
    subdir      db 'Projects\FASM\main.asm', 0
    fmt         db 'Full File Path:', 10, '%s', 10, 0

section '.code' code readable executable
start:
    invoke lstrcpy, res_path, root
    invoke lstrcat, res_path, user
    invoke lstrcat, res_path, subdir

    cinvoke printf, fmt, res_path
    
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL', \
            msvcrt,   'MSVCRT.DLL'

    import kernel32, \
           lstrcpy,     'lstrcpyA', \
           lstrcat,     'lstrcatA', \
           ExitProcess, 'ExitProcess'

    import msvcrt, \
           printf, 'printf'
