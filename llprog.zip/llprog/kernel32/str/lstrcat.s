format PE console 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    buffer      db 'Hello ', 64 dup(0)
    buf_size = $ - buffer
    source      db 'World!', 0
    format_str  db 'Result: %s', 10, 0
    fmt2  db 'buf_size: %d', 10, 0

section '.code' code readable executable
start:
    invoke lstrcat, buffer, source
    cinvoke printf, format_str, buffer
    cinvoke printf, fmt2, buf_size
    
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL', \
            msvcrt,   'MSVCRT.DLL'

    import kernel32, \
           lstrcat,     'lstrcatA', \
           ExitProcess, 'ExitProcess'

    import msvcrt, \
           printf, 'printf'
