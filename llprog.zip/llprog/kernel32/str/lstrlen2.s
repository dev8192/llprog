format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    s1      db 'aaa', 10, 0
    s2      db 'bbbb', 10, 0
    s3      db 'ccccc', 10, 0
    hOut    dd ?

section '.code' code readable executable

start:
    invoke  GetStdHandle, STD_OUTPUT_HANDLE
    mov     [hOut], eax

    invoke  lstrlen, s1
    invoke  WriteConsole, [hOut], s1, eax, 0, 0

    invoke  lstrlen, s2
    invoke  WriteConsole, [hOut], s2, eax, 0, 0

    invoke  lstrlen, s3
    invoke  WriteConsole, [hOut], s3, eax, 0, 0

    invoke  ExitProcess, 0

section '.idata' import data readable writeable
    library kernel32,       'kernel32.dll'

    import  kernel32, \
            ExitProcess,    'ExitProcess', \
            GetStdHandle,   'GetStdHandle', \
            WriteConsole,   'WriteConsoleA', \
            lstrlen,        'lstrlenA'
