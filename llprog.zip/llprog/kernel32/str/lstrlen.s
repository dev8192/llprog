format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    s1      db 'aaaaa', 0
    s2      db 'bbbbbbbbbb', 0
    s3      db 'ccccccccccccccc', 0
    fmt     db '%u', 10, 0

section '.code' code readable executable

start:
    invoke  lstrlen, s1
    cinvoke printf, fmt, eax

    invoke  lstrlen, s2
    cinvoke printf, fmt, eax

    invoke  lstrlen, s3
    cinvoke printf, fmt, eax

    cinvoke  exit, 0

section '.idata' import data readable writeable
    library kernel32,   'kernel32.dll',\
            msvcrt,     'msvcrt.dll'

    import  kernel32,\
            lstrlen,    'lstrlenA'

    import msvcrt,\
            exit,       'exit',\
            printf,     'printf'
