format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    msg      db 'aaaaa', 0
    msglen = $ - msg
    fmt      db '%u', 10, 0

section '.text' code readable executable
start:
    invoke  lstrlen, msg
    cinvoke printf, fmt, eax
    cinvoke printf, fmt, msglen
    cinvoke exit, 0

section '.idata' import data readable
    library kernel32,   'kernel32.dll',\
            msvcrt,     'msvcrt.dll'
    import  kernel32,\
            lstrlen,    'lstrlenA'
    import  msvcrt,\
            exit,       'exit',\
            printf,     'printf'
