format PE GUI 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    szSource db 'String copied successfully using lstrcpy.', 0
    szTitle  db 'lstrcpy Example', 0

section '.bss' readable writeable
    szDest rb 256

section '.text' code readable executable
start:
    invoke  lstrcpy, szDest, szSource
    invoke  MessageBox, NULL, szDest, szTitle, MB_OK
    invoke  ExitProcess, 0

section '.idata' import data readable writeable
    library kernel32, 'KERNEL32.DLL',\
            user32, 'USER32.DLL'

    import kernel32,\
        lstrcpy, 'lstrcpyA',\
        ExitProcess, 'ExitProcess'

    import user32,\
        MessageBox, 'MessageBoxA'
