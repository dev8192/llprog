format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    path     db "my\nested\folder\path", 0
    fmt_err  db "Failed at segment. Error: %u", 10, 0

section '.text' code readable executable
start:
   ;stdcall create_directory_recursive, "hello"
   ;stdcall create_directory_recursive, "my\nested\folder\path"
    stdcall create_directory_recursive, ""
    invoke ExitProcess, 0

proc create_directory_recursive, path
    mov edi, [path]
.loop:
    mov al, [edi]
    test al, al
    jz .done
    
    cmp al, '\'
    je .create
    cmp al, '/'
    je .create
    
    inc edi
    jmp .loop

.create:
    mov byte [edi], 0
    invoke CreateDirectory, [path], 0
    mov byte [edi], '\'
    
    inc edi
    jmp .loop

.done:
    invoke CreateDirectory, [path], 0
    test eax, eax
    jnz .success

    invoke GetLastError
    cmp eax, 183 ; ERROR_ALREADY_EXISTS
    je .success

    cinvoke printf, fmt_err, eax
    ret

.success:
    ret
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            msvcrt,             'msvcrt.dll'
    import  kernel32,\
            CreateDirectory,    'CreateDirectoryA',\
            ExitProcess,        'ExitProcess',\
            GetLastError,       'GetLastError'
    import  msvcrt,\
            printf,             'printf'
