format PE
entry start

include 'win32ax.inc'

LANG_ENGLISH_US = 0x0409

section '.data' data readable writeable
    fmt_success db 'Success: %x', 10, 0
    fmt_err     db "Error %u (0x%X): '%s'", 10, 0
    buffer      rb 256

section '.text' code readable executable
start:
    stdcall main
    invoke  ExitProcess, 0

proc create_directory uses ebx, dir_path
    invoke  CreateDirectory, [dir_path], 0
    test    eax, eax
    jz      .error
    cinvoke printf, fmt_success, eax
    jmp     .done
.error:
    invoke  GetLastError
    mov     ebx, eax
    invoke  FormatMessage,\
            FORMAT_MESSAGE_FROM_SYSTEM + FORMAT_MESSAGE_MAX_WIDTH_MASK,\
            0, eax, LANG_ENGLISH_US, buffer, 256, 0
    cinvoke printf, fmt_err, ebx, ebx, buffer
.done:
    ret
endp

; ------------------------------------------------------------------------------
; Error 183 (0xB7): 'Cannot create a file when that file already exists. '
; ------------------------------------------------------------------------------
proc main10
    stdcall create_directory, '0files/new_folder'
    stdcall create_directory, '0files/new_folder'
    ret
endp

; ------------------------------------------------------------------------------
; Error 3 (0x3): 'The system cannot find the path specified. '
; ------------------------------------------------------------------------------
proc main
    stdcall create_directory, '0files/path/to/folder'
    stdcall create_directory, ''
    ret
endp

; ------------------------------------------------------------------------------
; The folder is created in
; C:\Users\<YourUsername>\AppData\Local\VirtualStore\Windows
; ------------------------------------------------------------------------------
proc main30
    stdcall create_directory, 'C:/Windows/hello'
    ret
endp

; ------------------------------------------------------------------------------
; Error 267 (0x10B): 'The directory name is invalid. '
; ------------------------------------------------------------------------------
proc main40
    stdcall create_directory, 'hello:world'
    stdcall create_directory, 'con'
    stdcall create_directory, 'prn'
    stdcall create_directory, 'aux'
    stdcall create_directory, 'com1'
    stdcall create_directory, 'lpt1'
    stdcall create_directory, ''
    ret
endp

; ------------------------------------------------------------------------------
; ERROR_INVALID_NAME
; Error 123 (0x7B): 'The filename, directory name, or volume label syntax is incorrect. '
; ------------------------------------------------------------------------------
proc main50
    stdcall create_directory, 'hello*world'
    stdcall create_directory, 'hello|world'
    stdcall create_directory, 'hello?world'
    stdcall create_directory, 'hello"world'
    stdcall create_directory, 'hello<world'
    stdcall create_directory, 'hello>world'
    ret
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            msvcrt,             'msvcrt.dll'
    import  kernel32,\
            CreateDirectory,    'CreateDirectoryA',\
            ExitProcess,        'ExitProcess',\
            FormatMessage,      'FormatMessageA',\
            GetLastError,       'GetLastError'
    import  msvcrt,\
            printf,             'printf'
