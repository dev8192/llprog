format PE
entry start

include 'win32a.inc'

PCAP_ERRBUF_SIZE equ 256
NULL equ 0
EXIT_SUCCESS equ 0
EXIT_FAILURE equ 1
LF equ 10

section '.data' data readable writeable
    custom_dir db "C:\Windows\System32\Npcap", NULL
    dll_name db "wpcap.dll", NULL
    func_name db "pcap_findalldevs", NULL
    fmt_err_dir db "Failed to set DLL directory.", LF, NULL
    fmt_err_dll db "Failed to load DLL.", LF, NULL
    fmt_err_proc db "Failed to get proc address.", LF, NULL
    fmt_err_pcap db "Pcap error: %s", LF, NULL
    fmt_success db "Success calling pcap_findalldevs.", LF, NULL
    
    hmodule dd NULL
    pcap_findalldevs dd NULL
    alldevs dd NULL
    errbuf rb PCAP_ERRBUF_SIZE

section '.text' code readable executable
start:
    invoke SetDllDirectory, custom_dir
    test eax, eax
    jnz .dir_ok
    cinvoke printf, fmt_err_dir
    invoke ExitProcess, EXIT_FAILURE

.dir_ok:
    invoke LoadLibrary, dll_name
    mov [hmodule], eax
    test eax, eax
    jnz .dll_ok
    cinvoke printf, fmt_err_dll
    invoke ExitProcess, EXIT_FAILURE

.dll_ok:
    invoke GetProcAddress, [hmodule], func_name
    mov [pcap_findalldevs], eax
    test eax, eax
    jnz .proc_ok
    cinvoke printf, fmt_err_proc
    invoke FreeLibrary, [hmodule]
    invoke ExitProcess, EXIT_FAILURE

.proc_ok:
    cinvoke pcap_findalldevs, alldevs, errbuf
    test eax, eax
    jz .pcap_ok
    cinvoke printf, fmt_err_pcap, errbuf
    invoke FreeLibrary, [hmodule]
    invoke ExitProcess, EXIT_FAILURE

.pcap_ok:
    cinvoke printf, fmt_success
    invoke FreeLibrary, [hmodule]
    invoke ExitProcess, EXIT_SUCCESS

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL', \
        msvcrt, 'MSVCRT.DLL'

    import kernel32, \
        SetDllDirectory, 'SetDllDirectoryA', \
        LoadLibrary, 'LoadLibraryA', \
        GetProcAddress, 'GetProcAddress', \
        FreeLibrary, 'FreeLibrary', \
        ExitProcess, 'ExitProcess'

    import msvcrt, \
        printf, 'printf'
