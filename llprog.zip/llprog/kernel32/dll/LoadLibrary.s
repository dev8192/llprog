; In your .data section
path_to_dll  db 'C:\Windows\System32\Npcap\wpcap.dll',0
pcap_open_name db 'pcap_open_live',0
wpcap_handle dd ?
_pcap_open_live dd ?

; In your .code section
invoke LoadLibrary, path_to_dll
mov [wpcap_handle], eax
test eax, eax
jz .dll_error

invoke GetProcAddress, [wpcap_handle], pcap_open_name
mov [_pcap_open_live], eax

; Now you can call the function via the pointer
push errbuf
push 1000
; ... other arguments ...
call [_pcap_open_live]








;invoke SetDllDirectory, 'C:\Windows\System32\Npcap\'

