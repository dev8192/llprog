format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    path_buffer db 260 dup (0)  ; MAX_PATH is 260
    fmt         db '"%s"', 10, 0
    msg_err     db 'Error retrieving path.', 10, 0

section '.code' code readable executable
start:
    invoke  GetModuleFileName, 0, path_buffer, 260
    test    eax, eax
    jz      .error

    cinvoke printf, fmt, path_buffer

    ; Walk backward from the end to find the last backslash
    mov     ecx, eax            ; EAX = length of string
    lea     edi, [path_buffer + ecx - 1]
    mov     al, '\'
    std                         ; Search backwards
    repne   scasb
    cld                         ; Reset direction flag
    
    ; Null-terminate at the backslash to remove the filename
    mov     byte [edi + 2], 0

    cinvoke printf, fmt, path_buffer
    jmp     .exit

.error:
    cinvoke printf, msg_err

.exit:
    invoke  ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            msvcrt,   'msvcrt.dll'

    import  kernel32,\
            GetModuleFileName, 'GetModuleFileNameA',\
            ExitProcess, 'ExitProcess'

    import  msvcrt,\
            printf, 'printf'
