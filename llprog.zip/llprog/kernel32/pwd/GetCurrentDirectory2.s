format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt1     db '%s', 10, 0
    fmt2     db '%x', 10, 0
    buf      rb 8 ; 'C:\llprog' is 9 bytes
    num      dd 0xFFFFFFFF ; ffff0067

section '.text' code readable executable
start:
    invoke  GetCurrentDirectory, 4096, buf
    cinvoke printf, fmt1, buf
    cinvoke printf, fmt2, [num]
    cinvoke exit, 0

section '.idata' import data readable
    library kernel32,'kernel32.dll',\
            msvcrt,'msvcrt.dll'

    import kernel32,\
        GetCurrentDirectory,'GetCurrentDirectoryA'

    import msvcrt,\
        printf,'printf',\
        exit,'exit'
