format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    new_dir     db '0files', 0
    msg_success db 'Directory changed successfully.', 10, 0
    msg_error   db 'Failed to change directory. Error code: %d', 10, 0

section '.code' code readable executable
start:
    invoke  SetCurrentDirectory, new_dir
    test    eax, eax
    jz      .error

    cinvoke printf, msg_success
    jmp     .exit

.error:
    invoke  GetLastError
    cinvoke printf, msg_error, eax

.exit:
    invoke  ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            msvcrt,   'msvcrt.dll'

    import  kernel32,\
            SetCurrentDirectory, 'SetCurrentDirectoryA',\
            GetLastError, 'GetLastError',\
            ExitProcess, 'ExitProcess'

    import  msvcrt,\
            printf, 'printf'
