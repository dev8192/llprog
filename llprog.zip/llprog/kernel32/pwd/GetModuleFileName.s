format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt1        db '%d', 10, 0
    fmt2        db '%s', 10, 0
    ;path_buffer db 260 dup (0)  ; MAX_PATH is 260
    path_buffer db 10 dup (0)
    ; it works, but where does it write the bytes?

section '.code' code readable executable
start:
    ; 'C:\llprog\prog.exe' is 18 bytes
    invoke  GetModuleFileName, 0, path_buffer, 260
    cinvoke printf, fmt1, eax
    cinvoke printf, fmt2, path_buffer

.exit:
    invoke  ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            msvcrt,   'msvcrt.dll'

    import  kernel32,\
            GetModuleFileName, 'GetModuleFileNameA',\
            ExitProcess, 'ExitProcess'

    import  msvcrt,\
            printf, 'printf'
