format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt     db '%s', 10, 0
    buf     rb 4096

section '.text' code readable executable
start:
    invoke  GetCurrentDirectory, 4096, buf
    cinvoke printf, fmt, buf
    cinvoke exit, 0

section '.idata' import data readable
    library kernel32,'kernel32.dll',\
            msvcrt,'msvcrt.dll'

    import kernel32,\
        GetCurrentDirectory, 'GetCurrentDirectoryA'

    import msvcrt,\
        printf, 'printf',\
        exit, 'exit'
