format PE console
entry start

include 'win32a.inc'

BUF_SIZE = 128

section '.data' data readable writeable
    filename db '0files/output.txt',0
    
    msg_write db 'Hello, FASM!',13,10
    msg_write_len = $ - msg_write

    msg_success db 'File written successfully.',13,10
    msg_success_len = $ - msg_success

    msg_err_create db 'Error creating file!',13,10
    msg_err_create_len = $ - msg_err_create
    
    msg_err_write db 'Error writing to file!',13,10
    msg_err_write_len = $ - msg_err_write
    
    msg_err_open db 'Error opening file for reading!',13,10
    msg_err_open_len = $ - msg_err_open
    
    msg_err_read db 'Error reading file!',13,10
    msg_err_read_len = $ - msg_err_read
    
    msg_result db 'Read from file: '
    msg_result_len = $ - msg_result

section '.bss' data readable writeable
    buffer db BUF_SIZE dup (?)

    hFile dd ?
    bytes dd ?
    hConsole dd ?
    read_len dd ?

section '.code' code readable executable
start:
    invoke CreateFile, filename, GENERIC_WRITE,\
        0, 0, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0
    cmp eax, INVALID_HANDLE_VALUE
    je error_create
    mov [hFile], eax

    invoke WriteFile, [hFile], msg_write, msg_write_len, bytes, 0
    test eax, eax
    jz error_write

    invoke CloseHandle, [hFile]

    invoke GetStdHandle, STD_OUTPUT_HANDLE
    mov [hConsole], eax
    invoke WriteConsole, [hConsole], msg_success, msg_success_len, bytes, 0

    invoke CreateFile, filename, GENERIC_READ, FILE_SHARE_READ,\
        0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0
    cmp eax, INVALID_HANDLE_VALUE
    je error_open
    mov [hFile], eax

    invoke ReadFile, [hFile], buffer, BUF_SIZE, read_len, 0
    test eax, eax
    jz error_read

    invoke CloseHandle, [hFile]

    invoke WriteConsole, [hConsole], msg_result, msg_result_len, bytes, 0
    invoke WriteConsole, [hConsole], buffer, [read_len], bytes, 0

    jmp finish

error_create:
    invoke GetStdHandle, STD_OUTPUT_HANDLE
    mov [hConsole], eax
    invoke WriteConsole, [hConsole], msg_err_create, msg_err_create_len, bytes, 0
    jmp finish

error_write:
    invoke WriteConsole, [hConsole], msg_err_write, msg_err_write_len, bytes, 0
    invoke CloseHandle, [hFile]
    jmp finish

error_open:
    invoke WriteConsole, [hConsole], msg_err_open, msg_err_open_len, bytes, 0
    jmp finish

error_read:
    invoke WriteConsole, [hConsole], msg_err_read, msg_err_read_len, bytes, 0
    invoke CloseHandle, [hFile]

finish:
    invoke ReadConsole, [hConsole], buffer, 1, bytes, 0
    invoke ExitProcess, 0

section '.idata' import data readable writeable
    library kernel32,       'kernel32.dll'
    import  kernel32,\
            CreateFile,     'CreateFileA',\
            WriteFile,      'WriteFile',\
            ReadFile,       'ReadFile',\
            CloseHandle,    'CloseHandle',\
            GetStdHandle,   'GetStdHandle',\
            WriteConsole,   'WriteConsoleA',\
            ReadConsole,    'ReadConsoleA',\
            ExitProcess,    'ExitProcess'
