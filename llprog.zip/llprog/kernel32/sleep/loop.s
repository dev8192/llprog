format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    hello_msg db 'hello', 10, 0
    counter   dd 5

section '.text' code readable executable
start:
print_loop:
    cinvoke printf, hello_msg
    invoke  Sleep, 1000

    dec     [counter]
    cmp     [counter], 0
    jg      print_loop

    invoke  ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            msvcrt, 'msvcrt.dll'

    import kernel32,\
           Sleep, 'Sleep',\
           ExitProcess, 'ExitProcess'

    import msvcrt,\
           printf, 'printf'
