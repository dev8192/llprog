format PE
entry start

include 'win32ax.inc'

LANG_ENGLISH_US = 0x0409
ERROR_SUCCESS   = 0

section '.data' data readable writeable
    fmt_success db 'Success: %d (0x%x)', 10, 0
    fmt_err     db "Error %u (0x%X): '%s'", 10, 0
    buffer      rb 256
    mutex1      db 'Global\MyTestMutex_1', 0
    mutex2      db 'Global\MyTestMutex_2', 0
    mutex3      db 'Global\MyTestMutex_3', 0
    force_fmt_msg   dd 1

section '.text' code readable executable
start:
    stdcall main
    invoke  ExitProcess, 0

proc create_mutex uses ebx, lpMutexAttributes, bInitialOwner, lpName
    invoke  SetLastError, ERROR_SUCCESS
    invoke  CreateMutex, [lpMutexAttributes], [bInitialOwner], [lpName]
    test    eax, eax
    jz      .error
    cinvoke printf, fmt_success, eax, eax
    cmp     [force_fmt_msg], 0
    jz      .done
.error:
    invoke  GetLastError
    mov     ebx, eax
    invoke  FormatMessage,\
            FORMAT_MESSAGE_FROM_SYSTEM + FORMAT_MESSAGE_MAX_WIDTH_MASK,\
            0, eax, LANG_ENGLISH_US, buffer, 256, 0
    cinvoke printf, fmt_err, ebx, ebx, buffer
.done:
    ret
endp

; ----------------------------------------------------------
; no error
; ----------------------------------------------------------
proc main1
    stdcall create_mutex, 0, 0, mutex1
    stdcall create_mutex, 0, 0, mutex2
    stdcall create_mutex, 0, 0, mutex3
    ret
endp

; ----------------------------------------------------------
; no error
; ----------------------------------------------------------
proc main
    stdcall create_mutex, 0, 0, mutex1
    stdcall create_mutex, 0, 0, mutex1
    ret
endp

section '.idata' import data readable
library kernel32,       'kernel32.dll',\
        msvcrt,         'msvcrt.dll'
import  kernel32,\
        CreateMutex,    'CreateMutexA',\
        ExitProcess,    'ExitProcess',\
        FormatMessage,  'FormatMessageA',\
        GetLastError,   'GetLastError',\
        SetLastError,   'SetLastError'
import  msvcrt,\
        printf,         'printf'
