format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    file_name  db "non_existent_file.txt", 0
    fmt_err    db "Error code: %u", 10, 0

section '.code' code readable executable

start:
    ;invoke DeleteFile, file_name
    
    invoke GetLastError
    cinvoke printf, fmt_err, eax

    cinvoke exit, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            msvcrt, 'msvcrt.dll'

    import kernel32,\
           DeleteFile, 'DeleteFileA',\
           GetLastError, 'GetLastError'

    import msvcrt,\
           exit, 'exit',\
           printf, 'printf'
