format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt db "Last error code is: %d", 10, 0

section '.code' code readable executable

start:
    invoke  GetLastError
    cinvoke printf, fmt, eax

    invoke  SetLastError, 1234

    invoke  GetLastError
    cinvoke printf, fmt, eax

    invoke  ExitProcess, 0

section '.idata' import data readable

    library kernel32, 'kernel32.dll',\
            msvcrt, 'msvcrt.dll'

    import kernel32,\
           ExitProcess, 'ExitProcess',\
           GetLastError, 'GetLastError',\
           SetLastError, 'SetLastError'

    import msvcrt,\
           printf, 'printf'
