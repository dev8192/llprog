format PE
entry start

include 'win32a.inc'

LANG_ENGLISH_US = 0x0409

section '.data' data readable writeable
    fmt_d       db "%d", 10, 0
    fmt_err     db "Error %u: '%s'", 10, 0
    buffer      rb 256

section '.text' code readable executable
start:
    stdcall test20
    invoke  ExitProcess, 0

proc test10
    invoke  SetLastError, 123
    invoke  GetLastError
    cinvoke printf, fmt_d, eax
    ret
endp

proc test20 uses ebx
    stdcall .print_error, 0
    stdcall .print_error, 87
    ret
endp

proc .print_error uses ebx, num
    invoke  SetLastError, [num]
    invoke  GetLastError
    mov     ebx, eax
    invoke  FormatMessage,\
            FORMAT_MESSAGE_FROM_SYSTEM + FORMAT_MESSAGE_MAX_WIDTH_MASK,\
            0, eax, LANG_ENGLISH_US, buffer, 256, 0
    cinvoke printf, fmt_err, ebx, buffer
    ret
endp

section '.idata' import data readable
library kernel32,       'kernel32.dll',\
        msvcrt,         'msvcrt.dll'
import  kernel32,\
        ExitProcess,    'ExitProcess',\
        FormatMessage,  'FormatMessageA',\
        GetLastError,   'GetLastError',\
        SetLastError,   'SetLastError'
import  msvcrt,\
        printf,         'printf'
