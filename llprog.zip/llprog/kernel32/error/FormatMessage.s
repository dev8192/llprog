format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    file_name   db "non_existent_file.txt", 0
    fmt         db "Error %u: %s", 10, 0
    buffer      rb 512

section '.code' code readable executable

start:
    invoke DeleteFile, file_name
    
    invoke GetLastError
    mov ebx, eax

    invoke FormatMessageA, \
        FORMAT_MESSAGE_FROM_SYSTEM, \ ; DWORD dwFlags
        0, \                          ; LPCVOID lpSource
        ebx, \                        ; DWORD dwMessageId
        0, \                          ; DWORD dwLanguageId
        buffer, \                     ; LPSTR lpBuffer
        512, \                        ; DWORD nSize
        0                             ; va_list *Arguments

    cinvoke printf, fmt, ebx, buffer

    cinvoke exit, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            msvcrt, 'msvcrt.dll'

    import kernel32,\
           DeleteFile, 'DeleteFileA',\
           GetLastError, 'GetLastError',\
           FormatMessageA, 'FormatMessageA'

    import msvcrt,\
           exit, 'exit',\
           printf, 'printf'
