format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt    db "Error code: %u", 10, 0

section '.code' code readable executable

start:    
    invoke GetLastError
    cinvoke printf, fmt, eax
    cinvoke exit, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            msvcrt, 'msvcrt.dll'

    import kernel32,\
           GetLastError, 'GetLastError'

    import msvcrt,\
           exit, 'exit',\
           printf, 'printf'
