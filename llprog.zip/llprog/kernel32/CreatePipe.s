format PE
entry start

include 'win32ax.inc'

struct SECURITY_ATTRIBUTES
    nLength                 dd ?
    lpSecurityDescriptor    dd ?
    bInheritHandle          dd ?
ends

section '.data' readable writeable
    cmd_line        db 'cmd.exe /c ipconfig', 0
    buffer          db 1024 dup(0)
    bytesRead       dd ?
    sinfo           STARTUPINFO
    pinfo           PROCESS_INFORMATION
    sattr           SECURITY_ATTRIBUTES
    hReadPipe       dd ?
    hWritePipe      dd ?
    fmt_d           db '%d', 10, 0
    outBufSize      dd ?
    inBufSize       dd ?

    msg      db 'Hello from the same process!', 0

section '.text' readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc CreatePipe_func, hReadPipe, hWritePipe, lpPipeAttributes, nSize
    invoke CreatePipe, [hReadPipe], [hWritePipe], [lpPipeAttributes], [nSize]
    ret
endp

; ----------------------------
; Basic example
; ----------------------------
proc main1
    cinvoke puts, '*** main1 ***'
    stdcall CreatePipe_func, hReadPipe, hWritePipe, NULL, 0
    invoke WriteFile, [hWritePipe], msg, 29, NULL, NULL
    invoke ReadFile, [hReadPipe], buffer, 29, bytesRead, NULL
    cinvoke puts, buffer
    invoke CloseHandle, [hReadPipe]
    invoke CloseHandle, [hWritePipe]
    ret
endp

; ------------------
; deadlock
; ------------------
proc main
    cinvoke puts, '*** main11 ***'
    stdcall CreatePipe_func, hReadPipe, hWritePipe, NULL, 29
    invoke GetNamedPipeInfo, [hReadPipe], NULL, outBufSize, inBufSize, NULL
    cinvoke printf, fmt_d, [outBufSize]
    cinvoke printf, fmt_d, [inBufSize]
    invoke WriteFile, [hWritePipe], msg, 29, NULL, NULL
    invoke ReadFile, [hReadPipe], buffer, 29, bytesRead, NULL
    cinvoke puts, buffer
    invoke CloseHandle, [hReadPipe]
    invoke CloseHandle, [hWritePipe]
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    mov [sattr.nLength], sizeof.SECURITY_ATTRIBUTES
    mov [sattr.bInheritHandle], TRUE
    stdcall CreatePipe_func, hReadPipe, hWritePipe, sattr, 0

    mov [sinfo.cb], sizeof.STARTUPINFO
    mov [sinfo.dwFlags], STARTF_USESTDHANDLES
    mov eax, [hWritePipe]
    mov [sinfo.hStdOutput], eax
    mov [sinfo.hStdError], eax

    ; 3. Launch the process with handle inheritance ENABLED (TRUE)
    invoke CreateProcess, NULL, cmd_line, NULL, NULL, TRUE, \
           0, NULL, NULL, sinfo, pinfo

    invoke CloseHandle, [hWritePipe]

    invoke ReadFile, [hReadPipe], buffer, 1024, bytesRead, NULL

    cinvoke puts, buffer

    invoke CloseHandle, [hReadPipe]
    invoke CloseHandle, [pinfo.hProcess]
    invoke CloseHandle, [pinfo.hThread]
    ret
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            msvcrt,             'msvcrt.dll'
    import  kernel32,\
            CreateProcess,      'CreateProcessA',\
            CreatePipe,         'CreatePipe',\
            GetNamedPipeInfo,   'GetNamedPipeInfo',\
            ReadFile,           'ReadFile',\
            WriteFile,          'WriteFile',\
            CloseHandle,        'CloseHandle',\
            ExitProcess,        'ExitProcess'
    import  msvcrt,\
            printf,             'printf',\
            puts,               'puts'
