format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    format_si                           db '%-27s : %u', 10, 0

    str_sizeof_SYSTEM_INFO              db 'sizeof.SYSTEM_INFO', 0
    str_wProcessorArchitecture          db 'wProcessorArchitecture', 0
    str_wReserved                       db 'wReserved', 0
    str_dwPageSize                      db 'dwPageSize', 0
    str_lpMinimumApplicationAddress     db 'lpMinimumApplicationAddress', 0
    str_lpMaximumApplicationAddress     db 'lpMaximumApplicationAddress', 0
    str_dwActiveProcessorMask           db 'dwActiveProcessorMask', 0
    str_dwNumberOfProcessors            db 'dwNumberOfProcessors', 0
    str_dwProcessorType                 db 'dwProcessorType', 0
    str_dwAllocationGranularity         db 'dwAllocationGranularity', 0
    str_wProcessorLevel                 db 'wProcessorLevel', 0
    str_wProcessorRevision              db 'wProcessorRevision', 0

include '../util/print_bytes.data.inc'

section '.text' code readable executable
start:
    stdcall test20
    invoke ExitProcess, 0

; ------------------------------------------------
; sizeof.SYSTEM_INFO          : 36
; wProcessorArchitecture      : 0
; wReserved                   : 2
; dwPageSize                  : 4
; lpMinimumApplicationAddress : 8
; lpMaximumApplicationAddress : 12
; dwActiveProcessorMask       : 16
; dwNumberOfProcessors        : 20
; dwProcessorType             : 24
; dwAllocationGranularity     : 28
; wProcessorLevel             : 32
; wProcessorRevision          : 34
; ------------------------------------------------
proc test10
    cinvoke printf, format_si, str_sizeof_SYSTEM_INFO, sizeof.SYSTEM_INFO
    cinvoke printf, format_si, str_wProcessorArchitecture, SYSTEM_INFO.wProcessorArchitecture
    cinvoke printf, format_si, str_wReserved, SYSTEM_INFO.wReserved
    cinvoke printf, format_si, str_dwPageSize, SYSTEM_INFO.dwPageSize
    cinvoke printf, format_si, str_lpMinimumApplicationAddress, SYSTEM_INFO.lpMinimumApplicationAddress
    cinvoke printf, format_si, str_lpMaximumApplicationAddress, SYSTEM_INFO.lpMaximumApplicationAddress
    cinvoke printf, format_si, str_dwActiveProcessorMask, SYSTEM_INFO.dwActiveProcessorMask
    cinvoke printf, format_si, str_dwNumberOfProcessors, SYSTEM_INFO.dwNumberOfProcessors
    cinvoke printf, format_si, str_dwProcessorType, SYSTEM_INFO.dwProcessorType
    cinvoke printf, format_si, str_dwAllocationGranularity, SYSTEM_INFO.dwAllocationGranularity
    cinvoke printf, format_si, str_wProcessorLevel, SYSTEM_INFO.wProcessorLevel
    cinvoke printf, format_si, str_wProcessorRevision, SYSTEM_INFO.wProcessorRevision
    ret
endp

include '../util/print_bytes.text.inc'

proc print_system_info uses ebx, p_si
    mov ebx, [p_si]
    movzx eax, word [ebx + SYSTEM_INFO.wProcessorArchitecture]
    cinvoke printf, format_si, str_wProcessorArchitecture, eax
    movzx eax, word [ebx + SYSTEM_INFO.wReserved]
    cinvoke printf, format_si, str_wReserved, eax
    cinvoke printf, format_si, str_dwPageSize, [ebx + SYSTEM_INFO.dwPageSize]
    cinvoke printf, format_si, str_lpMinimumApplicationAddress, [ebx + SYSTEM_INFO.lpMinimumApplicationAddress]
    cinvoke printf, format_si, str_lpMaximumApplicationAddress, [ebx + SYSTEM_INFO.lpMaximumApplicationAddress]
    cinvoke printf, format_si, str_dwActiveProcessorMask, [ebx + SYSTEM_INFO.dwActiveProcessorMask]
    cinvoke printf, format_si, str_dwNumberOfProcessors, [ebx + SYSTEM_INFO.dwNumberOfProcessors]
    cinvoke printf, format_si, str_dwProcessorType, [ebx + SYSTEM_INFO.dwProcessorType]
    cinvoke printf, format_si, str_dwAllocationGranularity, [ebx + SYSTEM_INFO.dwAllocationGranularity]
    movzx eax, word [ebx + SYSTEM_INFO.wProcessorLevel]
    cinvoke printf, format_si, str_wProcessorLevel, eax
    movzx eax, word [ebx + SYSTEM_INFO.wProcessorRevision]
    cinvoke printf, format_si, str_wProcessorRevision, eax
    ret
endp

proc test20
    local sys_info:SYSTEM_INFO
    invoke GetSystemInfo, addr sys_info
    stdcall print_system_info, addr sys_info
    stdcall print_bytes, addr sys_info, sizeof.SYSTEM_INFO
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            GetSystemInfo,  'GetSystemInfo',\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
