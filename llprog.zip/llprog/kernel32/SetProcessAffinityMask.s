; Lock your program to a single CPU core
