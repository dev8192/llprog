format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    s1      db 'aaaaa',0
    s2      db 'bbbbbbbbbb',0
    s3      db 'ccccccccccccccc',0
    fmt     db '%u',0
    nl      db 0Dh,0Ah,0

section '.bss' readable writeable
    outbuf  rb 32
    hOut    dd ?

section '.code' code readable executable

start:
    invoke  GetStdHandle, STD_OUTPUT_HANDLE
    mov     [hOut], eax

    invoke  lstrlenA, s1
    cinvoke wsprintfA, outbuf, fmt, eax
    invoke  lstrlenA, outbuf
    invoke  WriteConsoleA, [hOut], outbuf, eax, 0, 0
    invoke  WriteConsoleA, [hOut], nl, 2, 0, 0

    invoke  lstrlenA, s2
    cinvoke wsprintfA, outbuf, fmt, eax
    invoke  lstrlenA, outbuf
    invoke  WriteConsoleA, [hOut], outbuf, eax, 0, 0
    invoke  WriteConsoleA, [hOut], nl, 2, 0, 0

    invoke  lstrlenA, s3
    cinvoke wsprintfA, outbuf, fmt, eax
    invoke  lstrlenA, outbuf
    invoke  WriteConsoleA, [hOut], outbuf, eax, 0, 0
    invoke  WriteConsoleA, [hOut], nl, 2, 0, 0

    invoke  ExitProcess, 0

section '.idata' import data readable writeable
    library kernel32, 'kernel32.dll', \
            user32,   'user32.dll'

    import kernel32, \
        ExitProcess,   'ExitProcess', \
        GetStdHandle,  'GetStdHandle', \
        WriteConsoleA, 'WriteConsoleA', \
        lstrlenA,      'lstrlenA'

    import user32, \
        wsprintfA, 'wsprintfA'
