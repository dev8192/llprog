format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    s1      db 'A',0
    s2      db 'Hello',0
    s3      db 'This is a longer string',0
    fmt     db '%u',0
    outbuf  rb 32

section '.bss' readable writeable
    hOut    dd ?

section '.code' code readable executable

start:
    invoke  GetStdHandle, -11
    mov     [hOut], eax

    invoke  lstrlenA, s1
    cinvoke wsprintfA, outbuf, fmt, eax
    invoke  lstrlenA, outbuf
    invoke  WriteConsoleA, [hOut], outbuf, eax, 0, 0

    invoke  lstrlenA, s2
    cinvoke wsprintfA, outbuf, fmt, eax
    invoke  lstrlenA, outbuf
    invoke  WriteConsoleA, [hOut], outbuf, eax, 0, 0

    invoke  lstrlenA, s3
    cinvoke wsprintfA, outbuf, fmt, eax
    invoke  lstrlenA, outbuf
    invoke  WriteConsoleA, [hOut], outbuf, eax, 0, 0

    invoke  ExitProcess, 0

section '.idata' import data readable writeable
    library kernel32, 'kernel32.dll', \
            user32,   'user32.dll'

    import kernel32, \
        ExitProcess,   'ExitProcess', \
        GetStdHandle,  'GetStdHandle', \
        WriteConsoleA, 'WriteConsoleA', \
        lstrlenA,      'lstrlenA'

    import user32, \
        wsprintfA, 'wsprintfA'
