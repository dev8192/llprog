format PE
entry start

include 'win32ax.inc'

BUF_SIZE = 4096

section '.data' data readable writeable
    buf1    rb BUF_SIZE
    buf2    rb 8
    buf3    db 16 dup('a'), 0
    fmt_d   db '%d', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main1
    cinvoke puts, '*** main1 ***'
    invoke  GetCurrentDirectory, BUF_SIZE, buf1
    cinvoke puts, buf1
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    cinvoke puts, buf3
    invoke  GetCurrentDirectory, BUF_SIZE, buf2
    cinvoke puts, buf2
    cinvoke puts, buf3
    ret
endp

proc main
    cinvoke puts, '*** main3 ***'
    invoke  GetCurrentDirectory, 11, buf1
    cinvoke printf, fmt_d, eax
    cinvoke puts, buf1
    ret
endp

section '.idata' import data readable
    library kernel32,               'kernel32.dll',\
            msvcrt,                 'msvcrt.dll'
    import  kernel32,\
            GetCurrentDirectory,    'GetCurrentDirectoryA',\
            ExitProcess,            'ExitProcess'
    import  msvcrt,\
            printf,                 'printf',\
            puts,                   'puts'
