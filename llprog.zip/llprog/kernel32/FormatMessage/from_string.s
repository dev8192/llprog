format PE
entry start

include 'win32a.inc'

BUFFER_SIZE equ 256
PORT_NUM equ 8080

section '.data' data readable writeable
    template_str1   db "%1!s!:%2!d!", 0
    str_ip          db "127.0.0.1", 0
    args_array      dd str_ip, PORT_NUM
    va_list_var     dd 0

    template_str2   db "Hello%!", 0
    
    template_str3   db "%1 %2 %1", 0
    template_str4   db "%1!*.*s! %4 %5!*s!", 0
    name1           db 'Bill', 0
    name2           db 'Bob', 0
    names_arr       dd name1, name2

    buffer          rb BUFFER_SIZE
    fmt_s           db "'%s'", 10, 0

section '.text' code readable executable
start:
    stdcall test5
    stdcall test6
    stdcall test10
    stdcall test20
    stdcall test21
    invoke ExitProcess, 0

proc test5
    invoke FormatMessage,\
        FORMAT_MESSAGE_FROM_STRING + FORMAT_MESSAGE_IGNORE_INSERTS,\
        template_str1, 0, 0, buffer, BUFFER_SIZE, 0
    cinvoke printf, fmt_s, buffer
    ret
endp

proc test6
    invoke FormatMessage,\
        FORMAT_MESSAGE_FROM_STRING,\
        template_str2, 0, 0, buffer, BUFFER_SIZE, 0
    cinvoke printf, fmt_s, buffer
    ret
endp

proc test10
    push PORT_NUM
    push str_ip
    mov [va_list_var], esp
    invoke FormatMessage,\
        FORMAT_MESSAGE_FROM_STRING,\
        template_str1, 0, 0, buffer, BUFFER_SIZE, va_list_var
    cinvoke printf, fmt_s, buffer
    add esp, 8
    ret
endp

proc test20
    invoke FormatMessage,\
        FORMAT_MESSAGE_FROM_STRING + FORMAT_MESSAGE_ARGUMENT_ARRAY,\
        template_str1, 0, 0, buffer, BUFFER_SIZE, args_array
    cinvoke printf, fmt_s, buffer
    ret
endp

proc test21
    invoke FormatMessage,\
        FORMAT_MESSAGE_FROM_STRING + FORMAT_MESSAGE_ARGUMENT_ARRAY,\
        template_str3, 0, 0, buffer, BUFFER_SIZE, names_arr
    cinvoke printf, fmt_s, buffer
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            FormatMessage,  'FormatMessageA',\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
