format PE console
entry start

include 'win32a.inc'

LANG_ENGLISH_US = 0x0409

section '.data' data readable writeable
    file_name   db "non_existent_file.txt", 0
    fmt_err     db "Error %u: '%s'", 10, 0
    errBuf      rb 512

section '.text' code readable executable
start:
    stdcall test10
    stdcall test11
    stdcall test12
    stdcall test15
    stdcall test20
    invoke ExitProcess, 0

proc test10
    invoke DeleteFile, file_name
    invoke GetLastError
    invoke  FormatMessage, FORMAT_MESSAGE_FROM_SYSTEM,\
            0, eax, 0, errBuf, 512, 0
    cinvoke printf, errBuf
    ret
endp

proc test11 uses ebx
    invoke DeleteFile, file_name
    invoke GetLastError
    mov ebx, eax
    invoke  FormatMessage, FORMAT_MESSAGE_FROM_SYSTEM,\
            0, ebx, 0, errBuf, 512, 0
    cinvoke printf, fmt_err, ebx, errBuf
    ret
endp

proc test12 uses ebx
    invoke DeleteFile, file_name
    invoke GetLastError
    mov ebx, eax
    invoke  FormatMessage,\
            FORMAT_MESSAGE_FROM_SYSTEM + FORMAT_MESSAGE_MAX_WIDTH_MASK,\
            0, ebx, 0, errBuf, 512, 0
    cinvoke printf, fmt_err, ebx, errBuf
    ret
endp

proc test15 uses ebx
    invoke DeleteFile, file_name
    invoke GetLastError
    mov ebx, eax
    invoke  FormatMessage,\
            FORMAT_MESSAGE_FROM_SYSTEM + FORMAT_MESSAGE_MAX_WIDTH_MASK,\
            0, ebx, LANG_ENGLISH_US, errBuf, 512, 0
    cinvoke printf, fmt_err, ebx, errBuf
    ret
endp

proc test20 uses ebx
    local   errBuf:DWORD
    invoke  DeleteFile, file_name
    invoke  GetLastError
    mov     ebx, eax
    lea     eax, [errBuf]
    invoke  FormatMessage,\
            FORMAT_MESSAGE_FROM_SYSTEM +\
            FORMAT_MESSAGE_MAX_WIDTH_MASK +\
            FORMAT_MESSAGE_ALLOCATE_BUFFER,\
            0, ebx, 0, eax, 0, 0
    cinvoke printf, fmt_err, ebx, [errBuf]
    invoke  LocalFree, [errBuf]
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            DeleteFile,     'DeleteFileA',\
            ExitProcess,    'ExitProcess',\
            FormatMessage,  'FormatMessageA',\
            GetLastError,   'GetLastError',\
            LocalFree,      'LocalFree'
    import  msvcrt,\
            exit,           'exit',\
            printf,         'printf'
