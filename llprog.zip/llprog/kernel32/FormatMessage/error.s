format PE
entry start

include 'win32a.inc'

LANG_ENGLISH_US = 0x0409

section '.data' data readable writeable
    err_msg1    db 'Error at address %1: %2', 0
    err_msg2    db 'Error at address %1: %2!', 0
    arg1        db '0x00401000', 0
    arg2        db 'Access Denied', 0
    args_array  dd arg1, arg2
    buffer      rb 256
    fmt_d       db '%d', 10, 0
    fmt_err     db 'Error %d: "%s"', 10, 0

section '.text' code readable executable
start:
    stdcall test10
    invoke ExitProcess, 0

; ------------------------------------------------
; Error 87: "The parameter is incorrect. "
; ------------------------------------------------
proc test10 uses ebx
    xor     ebx, ebx
    invoke  FormatMessage,\
            FORMAT_MESSAGE_FROM_STRING + FORMAT_MESSAGE_ARGUMENT_ARRAY,\
            err_msg2, 0, 0, buffer, 256, args_array
    test    eax, eax
    jnz     .print_msg
    invoke  GetLastError
    mov     ebx, eax
    invoke  FormatMessage,\
            FORMAT_MESSAGE_FROM_SYSTEM + FORMAT_MESSAGE_MAX_WIDTH_MASK,\
            0, eax, LANG_ENGLISH_US, buffer, 256, 0
.print_msg:
    cinvoke printf, fmt_err, ebx, buffer
    ret
endp

proc test20 uses ebx
    xor     ebx, ebx
    invoke  CloseHandle, 1234 ; The handle is invalid.
    invoke  GetLastError
    invoke  FormatMessage,\
            FORMAT_MESSAGE_FROM_SYSTEM + FORMAT_MESSAGE_MAX_WIDTH_MASK,\
            0, eax, LANG_ENGLISH_US, buffer, 256, 0
    test    eax, eax
    jnz     .print_msg
    invoke  GetLastError
    mov     ebx, eax
    invoke  FormatMessage,\
            FORMAT_MESSAGE_FROM_SYSTEM + FORMAT_MESSAGE_MAX_WIDTH_MASK,\
            0, eax, LANG_ENGLISH_US, buffer, 256, 0
.print_msg:
    cinvoke printf, fmt_err, ebx, buffer
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            CloseHandle,    'CloseHandle',\
            GetLastError,   'GetLastError',\
            FormatMessage,  'FormatMessageA',\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
