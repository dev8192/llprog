format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    err_msg1    db 'Error Message 1', 0
    template1   db 'Error at address %1: %2!', 0
    arg1        db '0x00401000', 0
    arg2        db 'Access Denied', 0
    args_array  dd arg1, arg2
    buffer      rb 256
    fmt_d       db '%d', 10, 0
    fmt_err     db '"%s"', 10, 0

section '.text' code readable executable
start:
    stdcall test50
    invoke ExitProcess, 0

proc test10
    invoke  FormatMessage,\
            FORMAT_MESSAGE_FROM_STRING,\
            err_msg1, 0, 0, buffer, 256, 0
    cinvoke printf, fmt_d, eax
    cinvoke printf, fmt_err, buffer
    ret
endp

proc test20
    invoke  FormatMessage,\
            FORMAT_MESSAGE_FROM_STRING + FORMAT_MESSAGE_IGNORE_INSERTS,\
            template1, 0, 0, buffer, 256, 0
    cinvoke printf, fmt_d, eax
    cinvoke printf, fmt_err, buffer
    ret
endp

proc test50
    invoke  FormatMessage,\
            FORMAT_MESSAGE_FROM_STRING + FORMAT_MESSAGE_ARGUMENT_ARRAY,\
            template1, 0, 0, buffer, 256, args_array
    invoke  GetLastError
    cinvoke printf, fmt_d, eax
    cinvoke printf, fmt_err, buffer
    ret
endp

proc test70
    push arg2
    push arg1
    invoke FormatMessage, \
            FORMAT_MESSAGE_FROM_STRING, \
            template1, 0, 0, buffer, 256, esp
    add esp, 8
    cinvoke printf, fmt_d, eax
    cinvoke printf, fmt_err, buffer
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            CloseHandle,    'CloseHandle',\
            GetLastError,   'GetLastError',\
            FormatMessage,  'FormatMessageA',\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
