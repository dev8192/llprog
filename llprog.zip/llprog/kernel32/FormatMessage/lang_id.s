format PE
entry start

include 'win32a.inc'

LANG_ENGLISH_US = 0x0409

section '.data' data readable writeable
    err_msg     db 'Error message', 0
    buffer      rb 256
    fmt_s       db '"%s"', 10, 0

section '.text' code readable executable
start:
    stdcall test20
    invoke ExitProcess, 0

proc test10
    invoke  FormatMessage,\
            FORMAT_MESSAGE_FROM_STRING,\
            err_msg, 0, 0, buffer, 256, 0
    cinvoke printf, fmt_s, buffer
    ret
endp

proc test20
    invoke  CloseHandle, 1234 ; The handle is invalid.
    invoke  GetLastError
    invoke  FormatMessage,\
            FORMAT_MESSAGE_FROM_SYSTEM + FORMAT_MESSAGE_MAX_WIDTH_MASK,\
            0, eax, LANG_ENGLISH_US, buffer, 256, 0
    cinvoke printf, fmt_s, buffer
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            CloseHandle,    'CloseHandle',\
            GetLastError,   'GetLastError',\
            ExitProcess,    'ExitProcess',\
            FormatMessage,  'FormatMessageA'
    import  msvcrt,\
            printf,         'printf'
