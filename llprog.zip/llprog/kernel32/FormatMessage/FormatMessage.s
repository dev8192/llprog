format PE
entry start

include 'win32a.inc'

LANG_ENGLISH_US = 0x0409

section '.data' data readable writeable
    fmt_esp     db 'esp: %x', 10, 0
    fmt_d       db '%d', 10, 0
    fmt_s       db '"%s"', 10, 0
    errBuf      rb 512

section '.text' code readable executable
start:
    stdcall test40
    invoke ExitProcess, 0

proc test10
    cinvoke printf, fmt_esp, esp

    invoke  CloseHandle, 1234
    invoke  GetLastError
    invoke  FormatMessage, FORMAT_MESSAGE_FROM_SYSTEM,\
            0, eax, LANG_ENGLISH_US, errBuf, 512, 0
    cinvoke printf, errBuf

    cinvoke printf, fmt_esp, esp
    ret
endp

proc test20
    invoke  CloseHandle, 1234 ; The handle is invalid.
    invoke  GetLastError
    invoke  FormatMessage, FORMAT_MESSAGE_FROM_SYSTEM,\
            0, eax, LANG_ENGLISH_US, errBuf, 512, 0
    cinvoke printf, fmt_d, eax
    cinvoke printf, fmt_s, errBuf
    movzx eax, [errBuf + 21]
    cinvoke printf, fmt_d, eax
    movzx eax, [errBuf + 22]
    cinvoke printf, fmt_d, eax
    movzx eax, [errBuf + 23]
    cinvoke printf, fmt_d, eax
    ret
endp

proc test30
    invoke  CloseHandle, 1234 ; Error 6: 'The handle is invalid. '
    invoke  GetLastError
    invoke  FormatMessage,\
            FORMAT_MESSAGE_FROM_SYSTEM + FORMAT_MESSAGE_MAX_WIDTH_MASK,\
            0, eax, LANG_ENGLISH_US, errBuf, 512, 0
    cinvoke printf, fmt_d, eax
    cinvoke printf, fmt_s, errBuf
    movzx eax, [errBuf + 20]
    cinvoke printf, fmt_d, eax
    movzx eax, [errBuf + 21]
    cinvoke printf, fmt_d, eax
    movzx eax, [errBuf + 22]
    cinvoke printf, fmt_d, eax
    ret
endp

; ------------------------------------------------
; The operation completed successfully.
; ------------------------------------------------
proc test40
    invoke  FormatMessage,\
            FORMAT_MESSAGE_FROM_SYSTEM + FORMAT_MESSAGE_MAX_WIDTH_MASK,\
            0, 0, LANG_ENGLISH_US, errBuf, 512, 0
    cinvoke printf, fmt_d, eax
    cinvoke printf, fmt_s, errBuf
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            CloseHandle,    'CloseHandle',\
            GetLastError,   'GetLastError',\
            FormatMessage,  'FormatMessageA',\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
