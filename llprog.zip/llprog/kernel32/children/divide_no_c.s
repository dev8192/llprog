format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    err_msg    db 'Error: Division by zero', 10
    ERR_LEN    =  $ - err_msg
    buffer     rb 128
    out_buf    rb 128
    num1       dd ?
    num2       dd ?
    bytes_read dd ?
    bytes_writ dd ?
    h_stdin    dd ?
    h_stdout   dd ?
    h_stderr   dd ?

section '.code' code readable executable
    proc start
        invoke GetStdHandle, STD_INPUT_HANDLE
        mov [h_stdin], eax
        invoke GetStdHandle, STD_OUTPUT_HANDLE
        mov [h_stdout], eax
        invoke GetStdHandle, STD_ERROR_HANDLE
        mov [h_stderr], eax

        invoke ReadFile, [h_stdin], buffer, 128, bytes_read, NULL
        cmp [bytes_read], 0
        je .exit

        stdcall parse_ints, buffer
        mov [num1], eax
        mov [num2], edx

        mov ecx, [num2]
        test ecx, ecx
        jz .error

        mov eax, [num1]
        cdq
        idiv ecx

        stdcall int_to_str, eax, out_buf
        invoke WriteFile, [h_stdout], out_buf, eax, bytes_writ, NULL
        jmp .exit

    .error:
        invoke WriteFile, [h_stderr], err_msg, ERR_LEN, bytes_writ, NULL
        invoke ExitProcess, 1

    .exit:
        invoke ExitProcess, 0
    endp

    proc parse_ints, buf_ptr
        mov esi, [buf_ptr]
        xor eax, eax
        xor ebx, ebx
    .find_first:
        lodsb
        test al, al
        jz .done
        cmp al, '0'
        jb .find_first
        cmp al, '9'
        ja .find_first
        dec esi
    .read_first:
        lodsb
        cmp al, '0'
        jb .gap
        cmp al, '9'
        ja .gap
        sub al, '0'
        movzx ecx, al
        imul ebx, 10
        add ebx, ecx
        jmp .read_first
    .gap:
        push ebx
        xor ebx, ebx
    .find_second:
        lodsb
        test al, al
        jz .one_found
        cmp al, '0'
        jb .find_second
        cmp al, '9'
        ja .find_second
        dec esi
    .read_second:
        lodsb
        cmp al, '0'
        jb .two_found
        cmp al, '9'
        ja .two_found
        sub al, '0'
        movzx ecx, al
        imul ebx, 10
        add ebx, ecx
        jmp .read_second
    .two_found:
        mov edx, ebx
        pop eax
        ret
    .one_found:
        pop eax
        xor edx, edx
        ret
    .done:
        xor eax, eax
        xor edx, edx
        ret
    endp

    proc int_to_str, val, buf
        mov eax, [val]
        mov edi, [buf]
        mov ebx, 10
        xor ecx, ecx
    .push_loop:
        xor edx, edx
        div ebx
        add dl, '0'
        push edx
        inc ecx
        test eax, eax
        jnz .push_loop
        mov edx, ecx
    .pop_loop:
        pop eax
        stosb
        loop .pop_loop
        mov byte [edi], 10
        inc edx
        mov eax, edx
        ret
    endp

section '.idata' import data readable
    library kernel32, 'kernel32.dll'

    import kernel32, \
           GetStdHandle, 'GetStdHandle', \
           ReadFile, 'ReadFile', \
           WriteFile, 'WriteFile', \
           ExitProcess, 'ExitProcess'
