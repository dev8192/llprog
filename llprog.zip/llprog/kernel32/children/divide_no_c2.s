format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt_d       db '%d', 0
    err_msg     db 'Error: Division by zero', 10
    ERR_LEN     =  $ - err_msg
    buffer      rb 256
    out_buf     rb 64
    bytes_read  dd ?
    bytes_writ  dd ?
    h_stdin     dd ?
    h_stdout    dd ?
    h_stderr    dd ?

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, eax

proc main
    invoke GetStdHandle, STD_INPUT_HANDLE
    mov [h_stdin], eax
    invoke GetStdHandle, STD_OUTPUT_HANDLE
    mov [h_stdout], eax
    invoke GetStdHandle, STD_ERROR_HANDLE
    mov [h_stderr], eax

    invoke ReadFile, [h_stdin], buffer, 256, bytes_read, NULL
    cmp [bytes_read], 0
    je .exit

    stdcall get_second_ptr, buffer
    push eax
    invoke StrToInt, buffer
    pop ecx
    push eax
    invoke StrToInt, ecx
    mov ecx, eax
    pop eax

    test ecx, ecx
    jz .error

    cdq
    idiv ecx

    cinvoke wsprintf, out_buf, fmt_d, eax
    invoke lstrlen, out_buf
    invoke WriteFile, [h_stdout], out_buf, eax, bytes_writ, NULL
    jmp .exit

.error:
    invoke WriteFile, [h_stderr], err_msg, ERR_LEN, bytes_writ, NULL
    mov eax, 1
    ret

.exit:
    mov eax, 0
    ret
endp

proc get_second_ptr, buf
    mov esi, [buf]
.find_space:
    lodsb
    test al, al
    jz .end
    cmp al, ' '
    jne .find_space
    mov byte [esi-1], 0
.skip_spaces:
    lodsb
    cmp al, ' '
    je .skip_spaces
    dec esi
    mov eax, esi
    ret
.end:
    mov eax, esi
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            user32,         'user32.dll',\
            shlwapi,        'shlwapi.dll'
    import  kernel32,\
            lstrlen,        'lstrlenA',\
            GetStdHandle,   'GetStdHandle',\
            ReadFile,       'ReadFile',\
            WriteFile,      'WriteFile',\
            ExitProcess,    'ExitProcess'
    import  user32,\
            wsprintf,       'wsprintfA'
    import  shlwapi,\
            StrToInt,       'StrToIntA'
