format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt_in   db '%d', 0
    fmt_out  db '%d', 10, 0
    err_msg  db 'Error: Division by zero', 10, 0
    num1     dd ?
    num2     dd ?

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, eax

proc main
    cinvoke scanf, fmt_in, num1
    cinvoke scanf, fmt_in, num2
    mov eax, [num1]
    mov ecx, [num2]
    test ecx, ecx
    jz .error
    cdq
    idiv ecx
    cinvoke printf, fmt_out, eax
    mov eax, 0
    ret
.error:
    cinvoke __p__iob
    add eax, 64
    cinvoke fprintf, eax, err_msg
    mov eax, 1
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            scanf,          'scanf',\
            printf,         'printf',\
            fprintf,        'fprintf',\
            __p__iob,       '__p__iob'
