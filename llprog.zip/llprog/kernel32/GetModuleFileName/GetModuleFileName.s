format PE Console 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable

    szKernel32  db 'kernel32.dll', 0
    szFormat    db '%s', 10, 0
    buffer      rb MAX_PATH

section '.text' code readable executable
example1:
    invoke  GetModuleFileName, 0, buffer, MAX_PATH
    cinvoke printf, szFormat, buffer
    ret

example2:
    invoke  GetModuleHandle, szKernel32
    invoke  GetModuleFileName, eax, buffer, MAX_PATH
    cinvoke printf, szFormat, buffer
    ret

start:
    call example1
    call example2
    invoke  ExitProcess, 0

section '.idata' import data readable writeable

    library kernel32, 'KERNEL32.DLL',\
            msvcrt, 'MSVCRT.DLL'

    import kernel32,\
           ExitProcess, 'ExitProcess',\
           GetModuleFileName, 'GetModuleFileNameA',\
           GetModuleHandle, 'GetModuleHandleA'

    import msvcrt,\
           printf, 'printf'
