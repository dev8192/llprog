format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    filename        db '0files/months.txt', 0
    fmtStr          db 'Mapped %d bytes: %s', 10, 0
    hFile           dd 0
    hMap            dd 0
    pMap            dd 0
    fileSize        dd 0
    readLen         dd 0
    strLen          dd 0
    bytesWritten    dd 0
    outBuffer       rb 64
    msgBuffer       rb 128
    fmt_c           db '%c', 10, 0

section '.text' code readable executable
start:
    stdcall test1
    invoke  ExitProcess, 0

proc test1 uses esi edi
    invoke  CreateFile, filename, GENERIC_READ, FILE_SHARE_READ, 0, OPEN_EXISTING, 0, 0
    cmp     eax, INVALID_HANDLE_VALUE
    je      .exit
    mov     [hFile], eax

    invoke  CreateFileMapping, [hFile], 0, PAGE_READONLY, 0, 0, 0
    test    eax, eax
    jz      .close_file
    mov     [hMap], eax

    invoke  MapViewOfFile, eax, FILE_MAP_READ, 0, 0, 0
    test    eax, eax
    jz      .close_map
    mov     [pMap], eax

    movzx   eax, [pMap]
    cinvoke printf, fmt_c, pMap

    invoke  UnmapViewOfFile, [pMap]
.close_map:
    invoke  CloseHandle, [hMap]
.close_file:
    invoke  CloseHandle, [hFile]
.exit:
    ret
endp

proc test2 uses esi edi
    invoke  CreateFile, filename, GENERIC_READ, FILE_SHARE_READ, 0, OPEN_EXISTING, 0, 0
    cmp     eax, INVALID_HANDLE_VALUE
    je      .exit
    mov     [hFile], eax

    invoke  GetFileSize, eax, 0
    test    eax, eax
    jz      .close_file
    mov     [fileSize], eax

    invoke  CreateFileMapping, [hFile], 0, PAGE_READONLY, 0, 0, 0
    test    eax, eax
    jz      .close_file
    mov     [hMap], eax

    invoke  MapViewOfFile, eax, FILE_MAP_READ, 0, 0, 0
    test    eax, eax
    jz      .close_map
    mov     [pMap], eax

    mov     esi, eax
    mov     ecx, 32
    cmp     ecx, [fileSize]
    jbe     .len_ok
    mov     ecx, [fileSize]
.len_ok:
    mov     [readLen], ecx
    mov     edi, outBuffer
    rep     movsb
    mov     byte [edi], 0

    cinvoke wsprintfA, msgBuffer, fmtStr, [readLen], outBuffer
    mov     [strLen], eax
    invoke  GetStdHandle, STD_OUTPUT_HANDLE
    invoke  WriteConsoleA, eax, msgBuffer, [strLen], bytesWritten, 0

    invoke  UnmapViewOfFile, [pMap]
.close_map:
    invoke  CloseHandle, [hMap]
.close_file:
    invoke  CloseHandle, [hFile]
.exit:
    ret
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            msvcrt,             'msvcrt.dll'
    import  kernel32,\
            CreateFile,         'CreateFileA',\
            GetFileSize,        'GetFileSize',\
            CreateFileMapping,  'CreateFileMappingA',\
            MapViewOfFile,      'MapViewOfFile',\
            UnmapViewOfFile,    'UnmapViewOfFile',\
            CloseHandle,        'CloseHandle',\
            GetStdHandle,       'GetStdHandle',\
            WriteConsole,       'WriteConsoleA',\
            ExitProcess,        'ExitProcess'
    import  msvcrt,\
            printf,             'printf'
