format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    szMutexName      db 'Local\FasmCreateMutexDemo', 0
    szClassName      db 'MutexDemoClass', 0
    szWindowTitle    db 'Single Instance Application', 0
    szAlreadyRunning db 'Another instance is already running.', 0
    szInitFailed     db 'Failed to create main window.', 0

    hMutex           dd ?
    wc               WNDCLASS
    msg              MSG

section '.text' code readable executable
start:
    invoke  CreateMutex, NULL, FALSE, szMutexName
    mov     [hMutex], eax
    test    eax, eax
    jz      .init_failed
    invoke  GetLastError
    cmp     eax, ERROR_ALREADY_EXISTS
    je      .instance_exists

    mov     [wc.lpfnWndProc], WindowProc
    mov     [wc.hInstance], NULL
    mov     [wc.hCursor], NULL
    mov     [wc.hbrBackground], COLOR_WINDOW + 1
    mov     [wc.lpszClassName], szClassName
    mov     [wc.hIconSm], NULL
    invoke  RegisterClass, wc
    test    eax, eax
    jz      .init_failed

    invoke  CreateWindowEx, 0, szClassName, szWindowTitle,\
            WS_VISIBLE or WS_OVERLAPPEDWINDOW,\
            CW_USEDEFAULT, CW_USEDEFAULT, 400, 300,\
            NULL, NULL, NULL, NULL
    test    eax, eax
    jz      .init_failed

.msg_loop:
    invoke  GetMessage, msg, NULL, 0, 0
    or      eax, eax
    jz      .loop_end
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     .msg_loop
.loop_end:
    invoke  ReleaseMutex, [hMutex]
    invoke  CloseHandle, [hMutex]
    invoke  ExitProcess, [msg.wParam]

.instance_exists:
    invoke  MessageBox, NULL, szAlreadyRunning, szWindowTitle, MB_ICONINFORMATION
    invoke  CloseHandle, [hMutex]
    invoke  ExitProcess, 1

.init_failed:
    invoke  CloseHandle, [hMutex]
    invoke  MessageBox, NULL, szInitFailed, szWindowTitle, MB_ICONERROR
    invoke  ExitProcess, 2

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp     [wmsg], WM_DESTROY
    je      .wm_destroy
    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret

.wm_destroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
    ret
endp

section '.idata' import data readable
library kernel32,           'kernel32.dll',\
        user32,             'user32.dll'
import  kernel32,\
        CreateMutex,        'CreateMutexA',\
        GetLastError,       'GetLastError',\
        ReleaseMutex,       'ReleaseMutex',\
        CloseHandle,        'CloseHandle',\
        ExitProcess,        'ExitProcess'
import  user32,\
        MessageBox,         'MessageBoxA',\
        RegisterClass,      'RegisterClassA',\
        CreateWindowEx,     'CreateWindowExA',\
        GetMessage,         'GetMessageA',\
        TranslateMessage,   'TranslateMessage',\
        DispatchMessage,    'DispatchMessageA',\
        DefWindowProc,      'DefWindowProcA',\
        PostQuitMessage,    'PostQuitMessage'
