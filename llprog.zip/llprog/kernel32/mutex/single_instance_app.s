format PE GUI 4.0
entry start

include 'win32a.inc'

section '.text' code readable executable

start:
    invoke  CreateMutexA, NULL, FALSE, szMutexName
    mov     [hMutex], eax
    test    eax, eax
    jz      .init_failed
    invoke  GetLastError
    cmp     eax, ERROR_ALREADY_EXISTS
    je      .instance_exists

    mov     [wc.cbSize], sizeof.WNDCLASSEX
    mov     [wc.style], 0
    mov     [wc.lpfnWndProc], WindowProc
    mov     [wc.cbClsExtra], 0
    mov     [wc.cbWndExtra], 0
    mov     [wc.hInstance], NULL
    mov     [wc.hIcon], NULL
    mov     [wc.hCursor], NULL
    mov     [wc.hbrBackground], COLOR_WINDOW + 1
    mov     [wc.lpszMenuName], NULL
    mov     [wc.lpszClassName], szClassName
    mov     [wc.hIconSm], NULL

    invoke  RegisterClassExA, wc
    test    eax, eax
    jz      .init_failed

    invoke  CreateWindowExA, 0, szClassName, szWindowTitle, WS_VISIBLE or WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, 400, 300, NULL, NULL, NULL, NULL
    test    eax, eax
    jz      .init_failed

.message_loop:
    invoke  GetMessageA, msg, NULL, 0, 0
    or      eax, eax
    jz      .loop_end
    invoke  TranslateMessage, msg
    invoke  DispatchMessageA, msg
    jmp     .message_loop

.loop_end:
    invoke  ReleaseMutex, [hMutex]
    invoke  CloseHandle, [hMutex]
    invoke  ExitProcess, [msg.wParam]

.instance_exists:
    invoke  MessageBoxA, NULL, szAlreadyRunning, szWindowTitle, MB_ICONINFORMATION
    invoke  CloseHandle, [hMutex]
    invoke  ExitProcess, 1

.init_failed:
    invoke  CloseHandle, [hMutex]
    invoke  MessageBoxA, NULL, szInitFailed, szWindowTitle, MB_ICONERROR
    invoke  ExitProcess, 2

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp     [wmsg], WM_DESTROY
    je      .wm_destroy
    invoke  DefWindowProcA, [hwnd], [wmsg], [wparam], [lparam]
    ret
.wm_destroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
    ret
endp

section '.data' data readable writeable

szMutexName      db 'Local\FasmCreateMutexDemo', 0
szClassName      db 'MutexDemoClass', 0
szWindowTitle    db 'Single Instance Application', 0
szAlreadyRunning db 'Another instance is already running.', 0
szInitFailed     db 'Failed to create main window.', 0

hMutex           dd ?
wc               WNDCLASSEX
msg              MSG

section '.idata' import data readable writeable

library kernel32, 'KERNEL32.DLL',\
        user32,   'USER32.DLL'

import kernel32,\
       CreateMutexA,    'CreateMutexA',\
       GetLastError,    'GetLastError',\
       ReleaseMutex,    'ReleaseMutex',\
       CloseHandle,     'CloseHandle',\
       ExitProcess,     'ExitProcess'

import user32,\
       MessageBoxA,     'MessageBoxA',\
       RegisterClassExA,'RegisterClassExA',\
       CreateWindowExA, 'CreateWindowExA',\
       GetMessageA,     'GetMessageA',\
       TranslateMessage,'TranslateMessage',\
       DispatchMessageA,'DispatchMessageA',\
       DefWindowProcA,  'DefWindowProcA',\
       PostQuitMessage, 'PostQuitMessage'
