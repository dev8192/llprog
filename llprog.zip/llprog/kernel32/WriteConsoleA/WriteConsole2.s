format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    msg db 'Hello!',13,10,0
    msg_len  = $ - msg

section '.text' code readable executable
start:
    invoke  GetStdHandle, -11
    invoke  WriteConsoleA, eax, msg, msg_len, 0, 0
    ;invoke  WriteConsoleA, eax, msg, msg_len, esp, 0
    invoke  ExitProcess, 0

; Does it have to be writeable?
section '.idata' import data readable writeable
    library kernel32, 'kernel32.dll'

    import kernel32, \
        ExitProcess,   'ExitProcess', \
        GetStdHandle,  'GetStdHandle', \
        WriteConsoleA, 'WriteConsoleA'
