format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    msg     db 'Hello from WriteConsoleA',0
    msglen  = $ - msg

section '.bss' readable writeable
    hOut    dd ?

section '.code' code readable executable

start:
    invoke  GetStdHandle, STD_OUTPUT_HANDLE
    mov     [hOut], eax

    ; we can do something else here

    ;invoke  WriteConsoleA, [hOut], msg, msglen, 0, 0
    invoke WriteConsoleA, \
        [hOut], \   ; HANDLE  hConsoleOutput
        msg, \      ; LPCVOID lpBuffer
        msglen, \   ; DWORD   nNumberOfCharsToWrite
        0, \        ; LPDWORD lpNumberOfCharsWritten
        0           ; LPVOID  lpReserved

    invoke  ExitProcess, 0

section '.idata' import data readable writeable
    library kernel32, 'kernel32.dll'

    import kernel32, \
        ExitProcess,   'ExitProcess', \
        GetStdHandle,  'GetStdHandle', \
        WriteConsoleA, 'WriteConsoleA'
