format PE
entry start

include 'win32ax.inc'

LANG_ENGLISH_US = 0x0409
ERR_BUF_SIZE = 256
BUF1_SIZE = 256

section '.data' data readable writeable
    filename1       db '0files/months.txt', 0
    filename2       db '0files/huge_file.bin', 0
    filename3       db 'file that does not exist', 0
    filename4       db 'path/to/file/that/does/not/exist', 0
    fmt_x           db '%x', 10, 0
    fmt_d           db '%d', 10, 0
    hFile           dd ?
    high_part       dd ?
    fmt_success     db 'Success: %d (0x%X)', 10, 0
    fmt_err         db "Error %u (0x%X): '%s'", 10, 0
    err_buf         rb ERR_BUF_SIZE
    buf1            rb BUF1_SIZE
    bytes_read      dd ?

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc CreateFile_func    lpFileName, dwDesiredAccess, dwShareMode,\
                        lpSecurityAttributes, dwCreationDisposition,\
                        dwFlagsAndAttributes, hTemplateFile

    invoke CreateFile, [lpFileName], [dwDesiredAccess], [dwShareMode],\
        [lpSecurityAttributes], [dwCreationDisposition],\
        [dwFlagsAndAttributes], [hTemplateFile]
    cmp     eax, INVALID_HANDLE_VALUE
    push    eax
    je      .error
    cinvoke printf, fmt_success, eax
    jmp     .exit
.error:
    invoke  GetLastError
    push    eax
    invoke  FormatMessage,\
            FORMAT_MESSAGE_FROM_SYSTEM + FORMAT_MESSAGE_MAX_WIDTH_MASK,\
            0, eax, LANG_ENGLISH_US, err_buf, ERR_BUF_SIZE, 0
    pop     eax
    cinvoke printf, fmt_err, eax, eax, err_buf
.exit:
    pop     eax
    ret
endp

proc create_and_read    lpFileName, dwDesiredAccess, dwShareMode,\
                        lpSecurityAttributes, dwCreationDisposition,\
                        dwFlagsAndAttributes, hTemplateFile
    stdcall CreateFile_func, [lpFileName], [dwDesiredAccess], [dwShareMode],\
        [lpSecurityAttributes], [dwCreationDisposition],\
        [dwFlagsAndAttributes], [hTemplateFile]
    cmp eax, INVALID_HANDLE_VALUE
    je .exit
    mov [hFile], eax
    invoke ReadFile, [hFile], buf1, BUF1_SIZE - 1, bytes_read, NULL
    mov eax, [bytes_read]
    sub eax, 2
    mov byte [buf1 + eax], 0
    cinvoke puts, buf1
    invoke CloseHandle, [hFile]
.exit:
    ret
endp

; ---------------------------- questions ----------------------------

; how do i open an existing file for reading with CreateFile in fasm win32
; what is the difference between these?


; ----------------------------
; open an existing file for reading
; ----------------------------
proc main1
    cinvoke puts, '*** main1 ***'
    stdcall create_and_read, filename1, GENERIC_READ, FILE_SHARE_READ, 0,\
        OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0
    ret
endp

; ----------------------------
; Error 2 (0x2): 'The system cannot find the file specified. '
; ----------------------------
proc main11
    cinvoke puts, '*** main11 ***'
    stdcall CreateFile_func, filename3, GENERIC_READ, FILE_SHARE_READ, 0,\
        OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0
    stdcall CreateFile_func, filename3, GENERIC_WRITE, 0, 0,\
        OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0
    ret
endp

; ----------------------------
; Error 3 (0x3): 'The system cannot find the path specified. '
; ----------------------------
proc main12
    cinvoke puts, '*** main12 ***'
    stdcall CreateFile_func, filename4, GENERIC_READ, FILE_SHARE_READ, 0,\
        OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0
    stdcall CreateFile_func, filename4, GENERIC_WRITE, 0, 0,\
        OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0
    ret
endp

; ---------------------------- dwShareMode ----------------------------

proc main13     ; program 1
    cinvoke puts, '*** main13 ***'
    stdcall CreateFile_func, filename1, GENERIC_READ, FILE_SHARE_READ, 0,\
        OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0
    invoke Sleep, 1000000
    ret
endp

; ----------------------------
; Error 32 (0x20): 'The process cannot access the file because it is being used by another process. '
; ----------------------------
proc main14       ; program 2
    cinvoke puts, '*** main14 ***'
    stdcall create_and_read, filename1, GENERIC_READ, 0, 0,\
        OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0
    ret
endp

; ----------------------------
; Success
; ----------------------------
proc main       ; program 2
    cinvoke puts, '*** main15 ***'
    stdcall create_and_read, filename1, GENERIC_READ, FILE_SHARE_READ, 0,\
        OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0
    ret
endp

; --------------------------------------------------------------------

; ----------------------------
; create a huge file
; ----------------------------
proc main2
    cinvoke puts, '*** main2 ***'
    stdcall CreateFile_func, filename2, GENERIC_WRITE, 0, 0,\
            CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0
    cmp     eax, INVALID_HANDLE_VALUE
    je      .error
    mov     [hFile], eax
    mov     [high_part], 1
    invoke  SetFilePointer, [hFile], 20000000h, high_part, FILE_BEGIN
    invoke  SetEndOfFile, [hFile]
    invoke  CloseHandle, [hFile]
    cinvoke printf, str_success
    jmp     .exit
.error:
    cinvoke printf, str_error
.exit:
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            CreateFile,     'CreateFileA',\
            ReadFile,       'ReadFile',\
            WriteFile,      'WriteFile',\
            SetFilePointer, 'SetFilePointer',\
            SetEndOfFile,   'SetEndOfFile',\
            CloseHandle,    'CloseHandle',\
            FormatMessage,  'FormatMessageA',\
            GetLastError,   'GetLastError',\
            Sleep,          'Sleep',\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
