format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    mod_name db 'msvcrt.dll', 0
    sym1     db 'getchar', 0
    sym2     db '_getch', 0
    sym3     db 'oops', 0
    fmt      db '%08X', 10, 0

section '.text' code readable executable
start:
    invoke GetModuleHandle, mod_name
    mov ebx, eax

    invoke GetProcAddress, ebx, sym1
    cinvoke printf, fmt, eax

    invoke GetProcAddress, ebx, sym2
    cinvoke printf, fmt, eax

    invoke GetProcAddress, ebx, sym3
    cinvoke printf, fmt, eax

    cinvoke exit, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll', \
            msvcrt, 'msvcrt.dll'
    import  kernel32, \
            GetModuleHandle, 'GetModuleHandleA', \
            GetProcAddress, 'GetProcAddress'
    import  msvcrt, \
            printf, 'printf', \
            exit, 'exit'
