format PE console
entry start

include 'win32a.inc'

struct PROCESSENTRY32
    dwSize              dd ?
    cntUsage            dd ?
    th32ProcessID       dd ?
    th32DefaultHeapID   dd ?
    th32ModuleID        dd ?
    cntThreads          dd ?
    th32ParentProcessID dd ?
    pcPriClassBase      dd ?
    dwFlags             dd ?
    szExeFile           rb 260
ends

section '.data' data readable writeable
    fmt    db '%6u  %s %6u', 10, 0
    hSnap  dd ?
    pe32   PROCESSENTRY32

section '.text' code readable executable
start:
    invoke CreateToolhelp32Snapshot,\
        2,\     ; TH32CS_SNAPPROCESS
        0       ; pid (ignored)
    cmp eax, -1
    je .exit
    mov [hSnap], eax

    mov [pe32.dwSize], sizeof.PROCESSENTRY32
    invoke Process32First, [hSnap], pe32
    test eax, eax
    jz .close

.print_loop:
    cinvoke printf, fmt, [pe32.th32ProcessID], pe32.szExeFile, [pe32.th32ParentProcessID]
    invoke Process32Next, [hSnap], pe32
    test eax, eax
    jnz .print_loop

.close:
    invoke CloseHandle, [hSnap]

.exit:
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
        msvcrt, 'msvcrt.dll'

    import kernel32,\
        CloseHandle, 'CloseHandle',\
        CreateToolhelp32Snapshot, 'CreateToolhelp32Snapshot',\
        ExitProcess, 'ExitProcess',\
        Process32First, 'Process32First',\
        Process32Next, 'Process32Next'

    import msvcrt,\
        printf, 'printf'
