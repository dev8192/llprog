;format PE GUI
format PE console
entry start

include 'win32a.inc'

struct PROCESSENTRY32
    dwSize              dd ?
    cntUsage            dd ?
    th32ProcessID       dd ?
    th32DefaultHeapID   dd ?
    th32ModuleID        dd ?
    cntThreads          dd ?
    th32ParentProcessID dd ?
    pcPriClassBase      dd ?
    dwFlags             dd ?
    szExeFile           rb 260
ends

section '.data' data readable writeable
    clsName  db 'ProcList', 0
    lvName   db 'SysListView32', 0
    col1     db 'PID', 0
    col2     db 'Name', 0
    col3     db 'PPID', 0
    fmt_d    db '%u', 0
    fmt      db '%u ', 0
    
    hMainWnd  dd ?
    hList     dd ?
    hSnap     dd ?
    
    wc   WNDCLASS
    msg  MSG
    pe32 PROCESSENTRY32
    lvc  LV_COLUMN
    lvi  LV_ITEM
    
    szBuf rb 32

section '.text' code readable executable
start:
    ;invoke InitCommonControls
    
    invoke LoadCursor, 0, IDC_ARROW
    mov [wc.hCursor], eax
    invoke GetModuleHandle, 0
    mov [wc.hInstance], eax
    mov [wc.lpfnWndProc], WindowProc
    mov [wc.lpszClassName], clsName
    mov [wc.hbrBackground], COLOR_WINDOW+1
    invoke RegisterClass, wc
    
    invoke CreateWindowEx, 0, clsName, clsName, WS_VISIBLE or WS_OVERLAPPEDWINDOW, \
        CW_USEDEFAULT, CW_USEDEFAULT, 600, 400, 0, 0, [wc.hInstance], 0
    mov [hMainWnd], eax
    
    invoke CreateWindowEx, 0, lvName, 0, WS_CHILD or WS_VISIBLE or LVS_REPORT, \
        0, 0, 0, 0, [hMainWnd], 0, [wc.hInstance], 0
    mov [hList], eax
    
    mov [lvc.mask], LVCF_TEXT or LVCF_WIDTH
    mov [lvc.cx], 100
    mov [lvc.pszText], col1
    invoke SendMessage, [hList], LVM_INSERTCOLUMNA, 0, lvc
    
    mov [lvc.cx], 300
    mov [lvc.pszText], col2
    invoke SendMessage, [hList], LVM_INSERTCOLUMNA, 1, lvc
    
    mov [lvc.cx], 100
    mov [lvc.pszText], col3
    invoke SendMessage, [hList], LVM_INSERTCOLUMNA, 2, lvc
    
    invoke CreateToolhelp32Snapshot, 2, 0
    mov [hSnap], eax
    mov [pe32.dwSize], sizeof.PROCESSENTRY32
    invoke Process32First, [hSnap], pe32
    
    xor edi, edi
    
.fill_list:
    cinvoke sprintf, szBuf, fmt_d, [pe32.th32ProcessID]
    mov [lvi.mask], LVIF_TEXT
    mov [lvi.iItem], edi
    mov [lvi.iSubItem], 0
    mov [lvi.pszText], szBuf
    invoke SendMessage, [hList], LVM_INSERTITEMA, 0, lvi
    
    mov [lvi.iSubItem], 1
    mov [lvi.pszText], pe32.szExeFile
    invoke SendMessage, [hList], LVM_SETITEMTEXTA, edi, lvi
    
    cinvoke sprintf, szBuf, fmt_d, [pe32.th32ParentProcessID]
    mov [lvi.iSubItem], 2
    mov [lvi.pszText], szBuf
    invoke SendMessage, [hList], LVM_SETITEMTEXTA, edi, lvi
    
    inc edi
    invoke Process32Next, [hSnap], pe32
    test eax, eax
    jnz .fill_list
    
    invoke CloseHandle, [hSnap]

msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    push eax
    cinvoke printf, fmt, eax
    pop eax
    test eax, eax
    jz end_loop
    invoke DispatchMessage, msg
    jmp msg_loop

end_loop:
    invoke ExitProcess, [msg.wParam]

WindowProc:
    mov eax, [esp+8]
    cmp eax, WM_SIZE
    je .wmsize
    cmp eax, WM_DESTROY
    je .wmdestroy
    jmp [DefWindowProc]
.wmsize:
    movzx eax, word [esp+16]
    movzx ecx, word [esp+18]
    invoke MoveWindow, [hList], 0, 0, eax, ecx, 1
    xor eax, eax
    ret 16
.wmdestroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    ret 16

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
        user32, 'user32.dll',\
        comctl32, 'comctl32.dll',\
        msvcrt, 'msvcrt.dll'

    import kernel32,\
        GetModuleHandle, 'GetModuleHandleA',\
        ExitProcess, 'ExitProcess',\
        CreateToolhelp32Snapshot, 'CreateToolhelp32Snapshot',\
        Process32First, 'Process32First',\
        Process32Next, 'Process32Next',\
        CloseHandle, 'CloseHandle'

    import user32,\
        LoadCursor, 'LoadCursorA',\
        RegisterClass, 'RegisterClassA',\
        CreateWindowEx, 'CreateWindowExA',\
        GetMessage, 'GetMessageA',\
        DispatchMessage, 'DispatchMessageA',\
        DefWindowProc, 'DefWindowProcA',\
        PostQuitMessage, 'PostQuitMessage',\
        SendMessage, 'SendMessageA',\
        MoveWindow, 'MoveWindow'

    import comctl32,\
        InitCommonControls, 'InitCommonControls'

    import msvcrt,\
        sprintf, 'sprintf',\
        printf, 'printf'
