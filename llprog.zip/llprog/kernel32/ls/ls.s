format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    search_str  db '*.*', 0
    fmt_str     db '%s', 10, 0
    hFind       dd ?
    find_data   rb 320

section '.text' code readable executable
start:
    invoke  FindFirstFileA, search_str, find_data
    cmp     eax, -1
    je      .end_prog
    mov     [hFind], eax

.print_loop:
    cinvoke printf, fmt_str, find_data + 44
    invoke  FindNextFileA, [hFind], find_data
    test    eax, eax
    jnz     .print_loop

    invoke  FindClose, [hFind]

.end_prog:
    invoke  ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
        msvcrt, 'msvcrt.dll'

    import  kernel32,\
        FindFirstFileA, 'FindFirstFileA',\
        FindNextFileA, 'FindNextFileA',\
        FindClose, 'FindClose',\
        ExitProcess, 'ExitProcess'

    import  msvcrt,\
        printf, 'printf'
