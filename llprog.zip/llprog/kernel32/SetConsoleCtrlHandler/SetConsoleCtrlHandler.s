format PE CONSOLE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    msg_running     db 'Program is running', 10, 0
    msg_caught      db '--- Ctrl+C ---', 10, 0
    msg_done        db 'Done', 10, 0
    exit_flag       dd 0    ; 0 = continue, 1 = stop

section '.text' code readable executable
start:
    invoke  SetConsoleCtrlHandler, HandlerRoutine, TRUE
    test    eax, eax
    jz      .error

.main_loop:
    invoke  printf, msg_running
    cmp     [exit_flag], 1
    je      .finished
    invoke  Sleep, 2000
    jmp     .main_loop

.finished:
    invoke  printf, msg_done
    invoke  ExitProcess, 0

.error:
    invoke  ExitProcess, 1

proc HandlerRoutine dwCtrlType
    cmp     [dwCtrlType], CTRL_C_EVENT
    jne     .not_handled

    invoke  printf, msg_caught
    mov     [exit_flag], 1
    mov     eax, TRUE
    ret

.not_handled:
    mov     eax, FALSE
    ret
endp

section '.idata' import data readable
    library kernel32,               'kernel32.dll',\
            msvcrt,                 'msvcrt.dll'
    import  kernel32,\
            SetConsoleCtrlHandler,  'SetConsoleCtrlHandler',\
            Sleep,                  'Sleep',\
            ExitProcess,            'ExitProcess'
    import  msvcrt,\
            printf,                 'printf'
