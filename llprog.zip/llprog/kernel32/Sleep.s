format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    counter         dd 5
    fmt             db '%d', 10, 0
    char_buffer     db '5', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke  ExitProcess, 0

proc main1
    cinvoke puts, 'Start'
    invoke  Sleep, 2000
    cinvoke puts, 'End'
    ret
endp

proc main2
.loop:
    cinvoke printf, fmt, [counter]
    invoke  Sleep, 1000
    dec     [counter]
    cmp     [counter], 0
    jg      .loop
    ret
endp

proc main
    cinvoke printf, char_buffer
    invoke  Sleep, 1000
    sub     byte [char_buffer], 1
    cmp     byte [char_buffer], '0'
    jg      main
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            Sleep,          'Sleep',\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
