format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    counter dd  0
    fmt     db 'Counter: %d', 13, 0

section '.text' code readable executable
start:
@@:
    inc     [counter]
    cinvoke printf, fmt, [counter]
    invoke  Sleep, 1000
    jmp     @b

    invoke  ExitProcess, 0

section '.idata' import data readable writeable
    library kernel32,       'KERNEL32.DLL',\
            msvcrt,         'MSVCRT.DLL'
    import  kernel32,\
            ExitProcess,    'ExitProcess',\
            Sleep,          'Sleep'
    import  msvcrt,\
            printf,         'printf'
