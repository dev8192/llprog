format PE
entry start

include 'win32a.inc'

NUMBER_OF_CHARS = 5

section '.data' data readable writeable
    hStdIn                  dd ?
    hStdOut                 dd ?
    bytes_read              dd ?
    bytes_written1          dd ?
    bytes_written2          dd ?
    buffer                  rb NUMBER_OF_CHARS
    str1                    db '12345', 10
    str1_len                = $ - str1
    newline                 db 10
    fmt_hex                 db '%x', 10, 0
    fmt_bytes_read          db 'read    : %d', 10, 0
    fmt_bytes_written       db 'written : %d', 10, 0

section '.text' code readable executable
start:
    stdcall test10
    invoke ExitProcess, 0

proc test10
    invoke GetStdHandle, STD_INPUT_HANDLE
    mov [hStdIn], eax
    invoke GetStdHandle, STD_OUTPUT_HANDLE
    mov [hStdOut], eax

    invoke ReadFile, [hStdIn], buffer, NUMBER_OF_CHARS, bytes_read, NULL
    cinvoke printf, fmt_bytes_read, [bytes_read]

    invoke WriteFile, [hStdOut], buffer, NUMBER_OF_CHARS, bytes_written1, NULL
    invoke WriteFile, [hStdOut], newline, 1, bytes_written2, NULL
    cinvoke printf, fmt_bytes_written, [bytes_written1]
    cinvoke printf, fmt_bytes_written, [bytes_written2]

    invoke WriteFile, [hStdOut], str1, str1_len, bytes_written1, NULL
    cinvoke printf, fmt_bytes_written, [bytes_written1]

    ret
endp

section '.idata' import data readable writeable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            GetStdHandle,   'GetStdHandle',\
            ReadFile,       'ReadFile',\
            WriteFile,      'WriteFile',\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
