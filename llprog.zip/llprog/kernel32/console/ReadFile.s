format PE
entry start

include 'win32a.inc'

NUMBER_OF_CHARS = 5

section '.data' data readable writeable
    hStdIn          dd ?
    hStdOut         dd ?
    bytesRead       dd ?
    bytesWritten    dd ?
    buffer          rb NUMBER_OF_CHARS
    str1            db '12345', 10
    str1_len        = $ - str1
    newline         db 10
    fmt_hex         db '%x', 10, 0
    fmt_num         db '%d', 10, 0

section '.text' code readable executable
start:
    stdcall test10
    invoke ExitProcess, 0

proc test10
    invoke GetStdHandle, STD_INPUT_HANDLE
    mov [hStdIn], eax
    invoke GetStdHandle, STD_OUTPUT_HANDLE
    mov [hStdOut], eax

    invoke ReadFile, [hStdIn], buffer, NUMBER_OF_CHARS, bytesRead, NULL
    invoke WriteFile, [hStdOut], buffer, NUMBER_OF_CHARS, bytesWritten, NULL
    invoke WriteFile, [hStdOut], newline, 1, bytesWritten, NULL
    invoke WriteFile, [hStdOut], str1, str1_len, bytesWritten, NULL
    cinvoke printf, fmt_hex, bytesRead
    cinvoke printf, fmt_num, [bytesRead]

    ret
endp

section '.idata' import data readable writeable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            GetStdHandle,   'GetStdHandle',\
            ReadFile,       'ReadFile',\
            WriteFile,      'WriteFile',\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
