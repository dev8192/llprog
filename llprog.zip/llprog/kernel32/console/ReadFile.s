format PE
entry start

include 'win32a.inc'

NUMBER_OF_CHARS = 5

section '.data' data readable writeable
    hStdIn dd ?
    hStdOut dd ?
    bytesRead dd ?
    bytesWritten dd ?
    buffer rb NUMBER_OF_CHARS
    newline    db 10
    str1    db '12345', 10
    str1_len = $ - str1

section '.text' code readable executable
start:
    stdcall test10
    invoke ExitProcess, 0

proc test10
    invoke GetStdHandle, STD_INPUT_HANDLE
    mov [hStdIn], eax
    invoke GetStdHandle, STD_OUTPUT_HANDLE
    mov [hStdOut], eax

    invoke ReadFile, [hStdIn], buffer, NUMBER_OF_CHARS, bytesRead, NULL
    invoke WriteFile, [hStdOut], buffer, NUMBER_OF_CHARS, bytesWritten, NULL
    invoke WriteFile, [hStdOut], str1, str1_len, bytesWritten, NULL

    ret
endp

proc test15
;    invoke GetStdHandle, STD_INPUT_HANDLE
;    mov [hStdIn], eax
;    invoke GetStdHandle, STD_OUTPUT_HANDLE
;    mov [hStdOut], eax
;    
;    invoke ReadFile, [hStdIn], buffer, NUMBER_OF_CHARS, bytesRead, NULL
;    invoke WriteFile, [hStdOut], buffer, NUMBER_OF_CHARS, bytesWritten, NULL
    invoke WriteFile, [hStdOut], newline, 1, bytesWritten, NULL
    invoke WriteFile, [hStdOut], str1, str1_len, bytesWritten, NULL

    ret
endp

section '.idata' import data readable writeable
    library kernel32, 'kernel32.dll'
    import  kernel32, \
            GetStdHandle, 'GetStdHandle', \
            ReadFile, 'ReadFile', \
            WriteFile, 'WriteFile', \
            ExitProcess, 'ExitProcess'
