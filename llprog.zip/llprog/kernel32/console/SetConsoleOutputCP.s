format PE console 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    utf8_str db 'UTF-8 Test: hello 漢字 Привет ✓', 10, 0

section '.code' code readable executable
start:
    ;invoke SetConsoleOutputCP, 65001
    
    cinvoke printf, utf8_str
    
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL', \
            msvcrt,   'MSVCRT.DLL'

    import kernel32, \
           SetConsoleOutputCP, 'SetConsoleOutputCP', \
           ExitProcess,        'ExitProcess'

    import msvcrt, \
           printf, 'printf'
