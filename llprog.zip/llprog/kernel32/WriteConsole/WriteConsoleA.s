format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    msg     db 'one two three'
    msglen  = $ - msg
    chars_written dd ?

section '.text' code readable executable
start:
    invoke  GetStdHandle, STD_OUTPUT_HANDLE
    invoke  WriteConsole, eax, msg, msglen, chars_written, 0
    invoke  ExitProcess, 0

section '.idata' import data readable writeable
    library kernel32,       'kernel32.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess',\
            GetStdHandle,   'GetStdHandle',\
            WriteConsole,   'WriteConsoleA'
