format PE console
entry start

include 'win32a.inc'

section '.idata' import data readable writeable

    library kernel32,'kernel32.dll'

    import kernel32,\
        GetCurrentDirectoryA,'GetCurrentDirectoryA',\
        GetCurrentProcessId,'GetCurrentProcessId',\
        GetStdHandle,'GetStdHandle',\
        WriteFile,'WriteFile',\
        ExitProcess,'ExitProcess'

section '.data' data readable writeable

    pwd_label  db 'pwd: ',0
    pid_label  db 'pid: ',0
    newline    db 10
    buf        rb 4096
    pid_buf    rb 32
    written    dd 0

section '.text' code readable executable

start:
    invoke  GetStdHandle,-11
    mov     [stdout],eax

    invoke  WriteFile,[stdout],pwd_label,5,written,0
    invoke  GetCurrentDirectoryA,4096,buf

    invoke  WriteFile,[stdout],buf,eax,written,0
    invoke  WriteFile,[stdout],newline,1,written,0

    invoke  WriteFile,[stdout],pid_label,5,written,0
    invoke  GetCurrentProcessId
    invoke  dword2str,eax,pid_buf

    invoke  WriteFile,[stdout],pid_buf,eax,written,0
    invoke  WriteFile,[stdout],newline,1,written,0

    invoke  ExitProcess,0

proc dword2str val,str_buf
    mov     eax,[val]
    mov     edi,[str_buf]
    mov     ecx,0
    mov     ebx,10
.divide:
    xor     edx,edx
    div     ebx
    push    edx
    inc     ecx
    test    eax,eax
    jnz     .divide
    mov     esi,ecx
.store:
    pop     edx
    add     dl,'0'
    mov     [edi],dl
    inc     edi
    loop    .store
    mov     eax,esi
    ret
endp

section '.bss' data readable writeable

    stdout  dd ?
