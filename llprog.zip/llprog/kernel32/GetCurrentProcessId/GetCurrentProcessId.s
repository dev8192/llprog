format PE console
entry start

include 'win32a.inc'

section '.idata' import data readable writeable

    library msvcrt,'msvcrt.dll',\
            kernel32,'kernel32.dll'

    import msvcrt,\
        printf,'printf',\
        exit,'exit'

    import kernel32,\
        GetCurrentDirectoryA,'GetCurrentDirectoryA',\
        GetCurrentProcessId,'GetCurrentProcessId'

section '.data' data readable writeable

    fmt_pwd    db 'pwd: %s',10,0
    fmt_pid    db 'pid: %d',10,0
    buf        rb 4096

section '.text' code readable executable

start:
    invoke  GetCurrentDirectoryA,4096,buf
    cinvoke printf,fmt_pwd,buf

    invoke  GetCurrentProcessId
    cinvoke printf,fmt_pid,eax

    cinvoke exit,0
