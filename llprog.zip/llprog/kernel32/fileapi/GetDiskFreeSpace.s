format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    str_root db 'C:\', 0
    str_fmt  db 'Information for %s', 10
             db 'Sectors per cluster: %u', 10
             db 'Bytes per sector:    %u', 10
             db 'Free clusters:       %u', 10
             db 'Total clusters:      %u', 10, 0
    str_err  db 'Failed to get disk free space.', 10, 0

    spc      dd ?
    bps      dd ?
    fc       dd ?
    tc       dd ?

section '.text' code readable executable
start:
    invoke  GetDiskFreeSpace, str_root, spc, bps, fc, tc
    test    eax, eax
    jz      .error

    cinvoke printf, str_fmt, str_root, [spc], [bps], [fc], [tc]
    jmp     .done

.error:
    cinvoke printf, str_err

.done:
    invoke  ExitProcess, 0

section '.idata' import data readable writeable
    library kernel32,           'KERNEL32.DLL',\
            msvcrt,             'MSVCRT.DLL'
    import  kernel32,\
            GetDiskFreeSpace,   'GetDiskFreeSpaceA',\
            ExitProcess,        'ExitProcess'
    import  msvcrt,\
            printf,             'printf'
