format PE Console 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    align 4096
    sectorBuffer    db 'hello world'
    textLen         = $ - sectorBuffer
                    rb 4096 - textLen

    szFile          db 'output.txt', 0
    szSuccess       db 'Success', 10, 0
    szError         db 'File operation failed.', 10, 0

    hFile           dd ?
    bytesWritten    dd ?

section '.text' code readable executable

start:
    invoke  CreateFile, szFile, GENERIC_WRITE, 0, 0, CREATE_ALWAYS, \
            FILE_ATTRIBUTE_NORMAL or FILE_FLAG_NO_BUFFERING or FILE_FLAG_WRITE_THROUGH, 0
    cmp     eax, INVALID_HANDLE_VALUE
    je      .error
    mov     [hFile], eax

    invoke  WriteFile, [hFile], sectorBuffer, 4096, bytesWritten, 0
    test    eax, eax
    jz      .close_error

    invoke  FlushFileBuffers, [hFile]
    
    invoke  CloseHandle, [hFile]

    invoke  CreateFile, szFile, GENERIC_WRITE, 0, 0, OPEN_EXISTING,\
        FILE_ATTRIBUTE_NORMAL, 0
    cmp     eax, INVALID_HANDLE_VALUE
    je      .error
    mov     [hFile], eax

    invoke  SetFilePointer, [hFile], textLen, 0, FILE_BEGIN
    
    invoke  SetEndOfFile, [hFile]
    
    invoke  CloseHandle, [hFile]

    cinvoke printf, szSuccess
    invoke  ExitProcess, 0

.close_error:
    invoke  CloseHandle, [hFile]

.error:
    cinvoke printf, szError
    invoke  ExitProcess, 1

section '.idata' import data readable writeable

    library kernel32, 'KERNEL32.DLL',\
            msvcrt, 'MSVCRT.DLL'

    import kernel32,\
        CloseHandle, 'CloseHandle',\
        CreateFile, 'CreateFileA',\
        ExitProcess, 'ExitProcess',\
        FlushFileBuffers, 'FlushFileBuffers',\
        SetEndOfFile, 'SetEndOfFile',\
        SetFilePointer, 'SetFilePointer',\
        WriteFile, 'WriteFile'

    import msvcrt,\
        printf, 'printf'
