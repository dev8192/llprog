format PE Console 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    szFile      db '0files/months.txt', 0
    szFmt1      db 'GetFileSize   -> High DWORD: %u, Low DWORD: %u', 10, 0
    szFmt2      db 'GetFileSizeEx -> Full 64-bit size: %I64u', 10, 0
    szError     db 'Could not open file.', 10, 0

    hFile       dd ?
    sizeHigh    dd ?
    sizeLow     dd ?
    sizeEx      dq ?

section '.text' code readable executable
start:
    invoke  CreateFile, szFile, GENERIC_READ, FILE_SHARE_READ,\
        0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0
    cmp     eax, INVALID_HANDLE_VALUE
    je      .error
    mov     [hFile], eax

    invoke  GetFileSize, [hFile], sizeHigh
    mov     [sizeLow], eax

    cinvoke printf, szFmt1, [sizeHigh], [sizeLow]

    invoke  GetFileSizeEx, [hFile], sizeEx

    cinvoke printf, szFmt2, dword [sizeEx], dword [sizeEx+4]

    invoke  CloseHandle, [hFile]
    jmp     .exit

.error:
    cinvoke printf, szError

.exit:
    invoke  ExitProcess, 0

section '.idata' import data readable writeable
    library kernel32, 'KERNEL32.DLL',\
            msvcrt, 'MSVCRT.DLL'

    import kernel32,\
        CloseHandle, 'CloseHandle',\
        CreateFile, 'CreateFileA',\
        ExitProcess, 'ExitProcess',\
        GetFileSize, 'GetFileSize',\
        GetFileSizeEx, 'GetFileSizeEx'

    import msvcrt,\
        printf, 'printf'
