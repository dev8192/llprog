format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    str_root    db 'C:\', 0
    str_fmt     db 'Information for %s', 10
                db 'Total bytes:    %I64u', 10
                db 'Free bytes:     %I64u', 10
                db 'Occupied bytes: %I64u', 10, 0
    str_err     db 'Failed to get disk free space.', 10, 0

    free_caller dq ?
    total_bytes dq ?
    free_bytes  dq ?
    occ_bytes   dq ?

section '.text' code readable executable
start:
; free_caller (bytes available specifically to the current user)
; total_bytes (absolute size of the drive)
; free_bytes (absolute free space on the drive).
    invoke  GetDiskFreeSpaceEx, str_root, free_caller, total_bytes, free_bytes
    test    eax, eax
    jz      .error

    mov     eax, dword [total_bytes]
    mov     edx, dword [total_bytes+4]
    
    sub     eax, dword [free_bytes]
    sbb     edx, dword [free_bytes+4]
    
    mov     dword [occ_bytes], eax
    mov     dword [occ_bytes+4], edx

    cinvoke printf, str_fmt, str_root,\
            dword [total_bytes], dword [total_bytes+4],\
            dword [free_bytes], dword [free_bytes+4],\
            dword [occ_bytes], dword [occ_bytes+4]
    jmp     .done

.error:
    cinvoke printf, str_err

.done:
    invoke  ExitProcess, 0

section '.idata' import data readable writeable
    library kernel32,               'KERNEL32.DLL',\
            msvcrt,                 'MSVCRT.DLL'
    import  kernel32,\
            GetDiskFreeSpaceEx,     'GetDiskFreeSpaceExA',\
            ExitProcess,            'ExitProcess'
    import  msvcrt,\
            printf,                 'printf'
