format PE
entry start

include 'win32ax.inc'

LANG_ENGLISH_US = 0x0409

section '.data' data readable writeable
    fmt_success db 'Success: %x', 10, 0
    fmt_err     db "Error %u: '%s'", 10, 0
    buffer      rb 256

section '.text' code readable executable
start:
    stdcall test10
    invoke  ExitProcess, 0

proc test10
    stdcall .error_2, '0files/file1.txt'
    stdcall .error_2, '0files/file1.txt'
    ret
endp

proc .error_2 uses ebx, file_path
    invoke  DeleteFile, [file_path]
    test    eax, eax
    jz      .error
    cinvoke printf, fmt_success, eax
    jmp     .done
.error:
    invoke  GetLastError
    mov     ebx, eax
    invoke  FormatMessage,\
            FORMAT_MESSAGE_FROM_SYSTEM + FORMAT_MESSAGE_MAX_WIDTH_MASK,\
            0, eax, LANG_ENGLISH_US, buffer, 256, 0
    cinvoke printf, fmt_err, ebx, buffer
.done:
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            DeleteFile,     'DeleteFileA',\
            ExitProcess,    'ExitProcess',\
            FormatMessage,  'FormatMessageA',\
            GetLastError,   'GetLastError'
    import  msvcrt,\
            printf,         'printf'
