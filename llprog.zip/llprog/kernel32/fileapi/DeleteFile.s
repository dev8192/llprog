format PE
entry start

include 'win32ax.inc'

LANG_ENGLISH_US = 0x0409

section '.data' data readable writeable
    fmt_success     db 'Success: %x', 10, 0
    fmt_err         db "Error %u (0x%X): '%s'", 10, 0
    buffer          rb 256

; 2 ** 15 = 32768
; 2 ** 16 = 65536

   ;long_file_name db 'c:/', 32763 dup('f'), 0  ; error 3
   ;long_file_name db 'c:/', 32764 dup('f'), 0  ; error 87
   ;long_file_name db 32766 dup('f'), 0         ; error 3
   ;long_file_name db 32767 dup('f'), 0         ; error 87
   
   long_file_name db 65534 dup('f'), 0          ; error 87
  ;long_file_name db 65535 dup('f'), 0          ; error 206

section '.text' code readable executable
start:
    stdcall test40
    invoke  ExitProcess, 0

proc DeleteFile_func lpFileName
    invoke  DeleteFile, [lpFileName]
    test    eax, eax
    jz      .error
    cinvoke printf, fmt_success, eax
    jmp     .done
.error:
    invoke  GetLastError
    push    eax
    invoke  FormatMessage,\
            FORMAT_MESSAGE_FROM_SYSTEM + FORMAT_MESSAGE_MAX_WIDTH_MASK,\
            0, eax, LANG_ENGLISH_US, buffer, 256, 0
    pop     eax
    cinvoke printf, fmt_err, eax, eax, buffer
.done:
    ret
endp

; ----------------------------------------------------------
; Error 2: 'The system cannot find the file specified. '
; ----------------------------------------------------------
proc test10
    stdcall DeleteFile_func, '0files/file1.txt'
    stdcall DeleteFile_func, '0files/file1.txt'
    ret
endp

; ----------------------------------------------------------
; Error 3: 'The system cannot find the path specified. '
; ----------------------------------------------------------
proc test20
    stdcall DeleteFile_func, '0files/path/to/file/file1.txt'
    ret
endp

; ----------------------------------------------------------
; Error 206 (0xCE): 'The filename or extension is too long. '
; Error 87 (0x57): 'The parameter is incorrect. '
; ----------------------------------------------------------
proc test30
    stdcall DeleteFile_func, long_file_name
    ret
endp

; ----------------------------------------------------------
; Error 5 (0x5): 'Access is denied. '
; ----------------------------------------------------------
proc test40
    stdcall DeleteFile_func, '0files\folder1\'
    stdcall DeleteFile_func, '0files\folder1'
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            DeleteFile,     'DeleteFileA',\
            ExitProcess,    'ExitProcess',\
            FormatMessage,  'FormatMessageA',\
            GetLastError,   'GetLastError'
    import  msvcrt,\
            printf,         'printf'
