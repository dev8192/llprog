format PE Console 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    szFile       db '0files/output.txt', 0
    szText       db 'Hello World'
    textLen      = $ - szText
    szSuccess    db 'Data successfully written to physical disk.', 10, 0
    szError      db 'File operation failed.', 10, 0

    hFile        dd ?
    bytesWritten dd ?

section '.text' code readable executable

start:
    invoke  CreateFile, szFile, GENERIC_WRITE, 0, 0,\
        CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL or FILE_FLAG_WRITE_THROUGH, 0
    cmp     eax, INVALID_HANDLE_VALUE
    je      .error
    mov     [hFile], eax

    invoke  WriteFile, [hFile], szText, textLen, bytesWritten, 0
    test    eax, eax
    jz      .close_error

    invoke  FlushFileBuffers, [hFile]
    test    eax, eax
    jz      .close_error

    invoke  CloseHandle, [hFile]
    cinvoke printf, szSuccess
    invoke  ExitProcess, 0

.close_error:
    invoke  CloseHandle, [hFile]

.error:
    cinvoke printf, szError
    invoke  ExitProcess, 1

section '.idata' import data readable writeable

    library kernel32, 'KERNEL32.DLL',\
            msvcrt, 'MSVCRT.DLL'

    import kernel32,\
        CloseHandle, 'CloseHandle',\
        CreateFile, 'CreateFileA',\
        ExitProcess, 'ExitProcess',\
        FlushFileBuffers, 'FlushFileBuffers',\
        WriteFile, 'WriteFile'

    import msvcrt,\
        printf, 'printf'
