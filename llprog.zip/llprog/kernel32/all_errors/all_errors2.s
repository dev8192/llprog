format PE console
include 'win32a.inc'

entry start

section '.data' data readable writeable

    missing_file    db 'C:\NonExistentFile_12345.txt', 0
    missing_path    db 'C:\NonExistentDirectory_12345\File.txt', 0
    system_dir      db 'C:\Windows', 0
    missing_dll     db 'NonExistentLib_12345.dll', 0
    kernel32_dll    db 'kernel32.dll', 0
    missing_proc    db 'NonExistentFunction_12345', 0
    mutex_name      db 'Global\MyTestMutex_12345', 0
    tiny_buffer     db 0

    msg_format      db 'Error %u: %s', 0

section '.code' code readable executable

start:
    ; The system cannot find the file specified
    invoke  DeleteFileA, missing_file
    stdcall PrintLastError

    ; The system cannot find the file specified
    invoke  CreateFileA, missing_path, GENERIC_READ, 0, 0, OPEN_EXISTING, 0, 0
    stdcall PrintLastError

    ; Opening C:\Windows directory for writing
    invoke  CreateFileA, system_dir, GENERIC_WRITE, 0, 0, OPEN_EXISTING, 0, 0
    stdcall PrintLastError

    ; Removing C:\Windows directory
    invoke  RemoveDirectoryA, system_dir
    stdcall PrintLastError

    ; Closing an invalid handle
    invoke  CloseHandle, 12345678h
    stdcall PrintLastError

    ; Setting file pointer with invalid move method
    invoke  SetFilePointer, -1, 0, 0, 999
    stdcall PrintLastError

    ; Loading a non-existent DLL
    invoke  LoadLibraryA, missing_dll
    stdcall PrintLastError

    ; Getting address of a non-existent function
    invoke  GetModuleHandleA, kernel32_dll
    invoke  GetProcAddress, eax, missing_proc
    stdcall PrintLastError

    ; Getting current directory with a 1-byte buffer
    invoke  GetCurrentDirectoryA, 1, tiny_buffer
    stdcall PrintLastError

    ; Creating a mutex that already exists
    invoke  CreateMutexA, 0, 0, mutex_name
    invoke  CreateMutexA, 0, 0, mutex_name
    stdcall PrintLastError

    invoke  ExitProcess, 0

PrintLastError:
    push    ebp
    mov     ebp, esp
    sub     esp, 4
    push    ebx

    invoke  GetLastError
    mov     ebx, eax

    lea     eax, [ebp-4]

    invoke FormatMessageA, \
        FORMAT_MESSAGE_ALLOCATE_BUFFER or \
        FORMAT_MESSAGE_FROM_SYSTEM or \
        FORMAT_MESSAGE_IGNORE_INSERTS, \        ; dwFlags (Standard System Error)
        0, \                                    ; lpSource
        ebx, \                                  ; dwMessageId (The error code)
        0, \                                    ; dwLanguageId (Default)
        eax, \                                  ; lpBuffer (Your pre-defined memory)
        0, \                                    ; nSize (Size of your buffer)
        0                                       ; Arguments

    cinvoke printf, msg_format, ebx, [ebp-4]

    invoke  LocalFree, [ebp-4]

    pop     ebx
    mov     esp, ebp
    pop     ebp
    ret

section '.idata' import data readable

    library kernel32,'KERNEL32.DLL',\
            msvcrt,'MSVCRT.DLL'

    import  kernel32,\
            CloseHandle,'CloseHandle',\
            CreateFileA,'CreateFileA',\
            CreateMutexA,'CreateMutexA',\
            DeleteFileA,'DeleteFileA',\
            ExitProcess,'ExitProcess',\
            FormatMessageA,'FormatMessageA',\
            GetCurrentDirectoryA,'GetCurrentDirectoryA',\
            GetLastError,'GetLastError',\
            GetModuleHandleA,'GetModuleHandleA',\
            GetProcAddress,'GetProcAddress',\
            LoadLibraryA,'LoadLibraryA',\
            LocalFree,'LocalFree',\
            RemoveDirectoryA,'RemoveDirectoryA',\
            SetFilePointer,'SetFilePointer'

    import  msvcrt,\
            printf,'printf'
