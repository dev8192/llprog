format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    sys_time SYSTEMTIME
    loc_time SYSTEMTIME
    fmt_sys  db "System Time (UTC): %04d-%02d-%02d %02d:%02d:%02d", 10, 0
    fmt_loc  db "Local Time:        %04d-%02d-%02d %02d:%02d:%02d", 10, 0

section '.code' code readable executable
start:
    invoke  GetSystemTime, sys_time
    invoke  GetLocalTime, loc_time

    movzx   eax, [sys_time.wSecond]
    push    eax
    movzx   eax, [sys_time.wMinute]
    push    eax
    movzx   eax, [sys_time.wHour]
    push    eax
    movzx   eax, [sys_time.wDay]
    push    eax
    movzx   eax, [sys_time.wMonth]
    push    eax
    movzx   eax, [sys_time.wYear]
    push    eax
    push    fmt_sys
    call    [printf]
    add     esp, 28

    movzx   eax, [loc_time.wSecond]
    push    eax
    movzx   eax, [loc_time.wMinute]
    push    eax
    movzx   eax, [loc_time.wHour]
    push    eax
    movzx   eax, [loc_time.wDay]
    push    eax
    movzx   eax, [loc_time.wMonth]
    push    eax
    movzx   eax, [loc_time.wYear]
    push    eax
    push    fmt_loc
    call    [printf]
    add     esp, 28

    invoke  ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            msvcrt, 'msvcrt.dll'

    import  kernel32,\
            GetSystemTime, 'GetSystemTime',\
            GetLocalTime, 'GetLocalTime',\
            ExitProcess, 'ExitProcess'

    import  msvcrt,\
            printf, 'printf'
