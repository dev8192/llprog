format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    time SYSTEMTIME
    fmt  db "%04d-%02d-%02d %02d:%02d:%02d", 10, 0

section '.code' code readable executable
PrintTime:
    movzx   eax, [time.wSecond]
    push    eax
    movzx   eax, [time.wMinute]
    push    eax
    movzx   eax, [time.wHour]
    push    eax
    movzx   eax, [time.wDay]
    push    eax
    movzx   eax, [time.wMonth]
    push    eax
    movzx   eax, [time.wYear]
    push    eax
    push    fmt
    call    [printf]
    add     esp, 28
    ret

start:
    invoke  GetSystemTime, time
    call    PrintTime

    invoke  GetLocalTime, time
    call    PrintTime

    invoke  ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            msvcrt, 'msvcrt.dll'

    import  kernel32,\
            GetSystemTime, 'GetSystemTime',\
            GetLocalTime, 'GetLocalTime',\
            ExitProcess, 'ExitProcess'

    import  msvcrt,\
            printf, 'printf'
