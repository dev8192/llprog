format PE console
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt  db "%04d-%02d-%02d %02d:%02d:%02d", 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke  ExitProcess, 0

proc print_time, time
    mov     ebx, [time]
    movzx   eax, [ebx + SYSTEMTIME.wSecond]
    push    eax
    movzx   eax, [ebx + SYSTEMTIME.wMinute]
    push    eax
    movzx   eax, [ebx + SYSTEMTIME.wHour]
    push    eax
    movzx   eax, [ebx + SYSTEMTIME.wDay]
    push    eax
    movzx   eax, [ebx + SYSTEMTIME.wMonth]
    push    eax
    movzx   eax, [ebx + SYSTEMTIME.wYear]
    push    eax
    push    fmt
    call    [printf]
    add     esp, 28
    ret
endp

proc main
    local time:SYSTEMTIME

    invoke  GetSystemTime, addr time
    stdcall print_time, addr time

    invoke  GetLocalTime, addr time
    stdcall print_time, addr time
    
    ret
endp

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            msvcrt, 'msvcrt.dll'

    import  kernel32,\
            GetSystemTime, 'GetSystemTime',\
            GetLocalTime, 'GetLocalTime',\
            ExitProcess, 'ExitProcess'

    import  msvcrt,\
            printf, 'printf'
