format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    time SYSTEMTIME
    fmt db 'wYear:         %04u', 10
        db 'wMonth:        %02u', 10
        db 'wDayOfWeek:    %u', 10
        db 'wDay:          %02u', 10
        db 'wHour:         %02u', 10
        db 'wMinute:       %02u', 10
        db 'wSecond:       %02u', 10
        db 'wMilliseconds: %03u', 10, 0

section '.code' code readable executable

start:
    ;invoke  GetSystemTime, time
    invoke  GetLocalTime, time

    movzx   eax, [time.wMilliseconds]
    push    eax
    movzx   eax, [time.wSecond]
    push    eax
    movzx   eax, [time.wMinute]
    push    eax
    movzx   eax, [time.wHour]
    push    eax
    movzx   eax, [time.wDay]
    push    eax
    movzx   eax, [time.wDayOfWeek]
    push    eax
    movzx   eax, [time.wMonth]
    push    eax
    movzx   eax, [time.wYear]
    push    eax
    push    fmt
    call    [printf]
    add     esp, 36

    invoke  ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            msvcrt, 'msvcrt.dll'

    import  kernel32,\
            GetSystemTime, 'GetSystemTime',\
            GetLocalTime, 'GetLocalTime',\
            ExitProcess, 'ExitProcess'

    import  msvcrt,\
            printf, 'printf'
