format PE GUI 4.0
entry main

include 'win32a.inc'

section '.text' code readable executable

proc create_and_open_file uses ebx
    cinvoke fopen, file_name, file_mode
    test eax, eax
    jz .done
    mov ebx, eax

    cinvoke fprintf, ebx, message
    cinvoke fclose, ebx

    invoke WinExec, cmd_line, SW_SHOW

.done:
    ret
endp

proc main
    call create_and_open_file
    invoke ExitProcess, 0
endp

section '.data' data readable writeable
    file_name db 'hello.txt', 0
    file_mode db 'w', 0
    message db 'hello world', 0
    cmd_line db 'notepad.exe hello.txt', 0

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL',\
        msvcrt, 'MSVCRT.DLL'

    import kernel32,\
        WinExec, 'WinExec',\
        ExitProcess, 'ExitProcess'

    import msvcrt,\
        fopen, 'fopen',\
        fprintf, 'fprintf',\
        fclose, 'fclose'
