format PE console
entry start

include 'win32a.inc'

section '.text' code readable executable

start:
    stdcall dict_set, str_key_name, str_val_name
    stdcall dict_set, str_key_age, str_val_age
    stdcall dict_set, str_key_city, str_val_city

    stdcall dict_set, str_key_age, str_val_age_new

    stdcall dict_get, str_key_name
    cinvoke printf, str_fmt_found, str_key_name, eax

    stdcall dict_get, str_key_age
    cinvoke printf, str_fmt_found, str_key_age, eax

    stdcall dict_get, str_key_missing
    test    eax, eax
    jnz     .found_missing
    cinvoke printf, str_fmt_notfound, str_key_missing
    jmp     .done
.found_missing:
    cinvoke printf, str_fmt_found, str_key_missing, eax

.done:
    invoke  Sleep, 2000
    invoke  ExitProcess, 0

proc dict_set key, value
    push    ebx esi
    mov     esi, dict_array
    mov     ebx, 0

.find_loop:
    cmp     ebx, [dict_count]
    jge     .add_new
    mov     eax, ebx
    shl     eax, 3
    add     eax, esi
    
    push    eax
    cinvoke strcmp, dword [eax], [key]
    pop     edx
    
    test    eax, eax
    jz      .update_existing
    
    inc     ebx
    jmp     .find_loop

.update_existing:
    mov     eax, [value]
    mov     dword [edx+4], eax
    jmp     .done

.add_new:
    mov     eax, ebx
    shl     eax, 3
    add     eax, esi
    
    mov     ecx, [key]
    mov     dword [eax], ecx
    mov     ecx, [value]
    mov     dword [eax+4], ecx
    
    inc     [dict_count]

.done:
    pop     esi ebx
    ret
endp

proc dict_get key
    push    ebx esi
    mov     esi, dict_array
    mov     ebx, 0

.find_loop:
    cmp     ebx, [dict_count]
    jge     .not_found
    mov     eax, ebx
    shl     eax, 3
    add     eax, esi
    
    push    eax
    cinvoke strcmp, dword [eax], [key]
    pop     edx
    
    test    eax, eax
    jz      .found
    
    inc     ebx
    jmp     .find_loop

.found:
    mov     eax, dword [edx+4]
    jmp     .done

.not_found:
    xor     eax, eax

.done:
    pop     esi ebx
    ret
endp

section '.data' data readable writeable

    str_key_name     db 'name', 0
    str_val_name     db 'Alice', 0
    str_key_age      db 'age', 0
    str_val_age      db '25', 0
    str_val_age_new  db '26', 0
    str_key_city     db 'city', 0
    str_val_city     db 'New York', 0
    str_key_missing  db 'country', 0

    str_fmt_found    db '%s: %s', 10, 0
    str_fmt_notfound db '%s: <KeyError>', 10, 0

    dict_count       dd 0
    dict_array       rb 800

section '.idata' import data readable writeable

    library kernel32, 'KERNEL32.DLL',\
            msvcrt, 'MSVCRT.DLL'

    import kernel32,\
           Sleep, 'Sleep',\
           ExitProcess, 'ExitProcess'

    import msvcrt,\
           printf, 'printf',\
           strcmp, 'strcmp'
