format PE console
entry start

include 'win32a.inc'

ITEM_ID             equ 0
ITEM_VALUE          equ 4
ITEM_SIZE           equ 8

section '.data' data readable writeable
    nums_arr    dd 42, 13, 99, 7, 50
    NUM_COUNT   = ($ - nums_arr) / 4

    strs_arr    dd str_banana, str_apple, str_cherry, str_date
    STR_COUNT   = ($ - strs_arr) / 4
    str_banana  db 'banana', 0
    str_apple   db 'apple', 0
    str_cherry  db 'cherry', 0
    str_date    db 'date', 0
    fmt_str     db '%s ', 0
    fmt_nl      db 10, 0

    structs_arr dd 1, 500
                dd 2, 100
                dd 3, 300
    STRUCT_COUNT = ($ - structs_arr) / 8
    fmt_struct  db '{id: %d, val: %d} ', 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

include 'algorith/sort/selection.text.inc'

; ----------------------------------------------------------

proc main
    cinvoke puts, '*** main1 ***'
    stdcall print_array32, nums_arr, NUM_COUNT
    stdcall selection_sort, nums_arr, NUM_COUNT, 4, cmp_nums
    stdcall print_array32, nums_arr, NUM_COUNT
    ret
endp

proc cmp_nums c, ptr1:DWORD, ptr2:DWORD
    mov ecx, [ptr1]
    mov eax, [ecx]
    mov ecx, [ptr2]
    sub eax, [ecx]
    ret
endp

; ----------------------------------------------------------

proc main2
    cinvoke puts, '*** main2 ***'
    stdcall selection_sort, strs_arr, STR_COUNT, 4, cmp_strs
    stdcall print_strings, strs_arr, STR_COUNT
    ret
endp

proc print_strings uses ebx esi, str_arr, str_cnt
    mov esi, 0
.print_strs:
    cmp esi, str_cnt
    jae .strs_done
    mov eax, dword [str_arr + esi * 4]
    cinvoke printf, fmt_str, eax
    inc esi
    jmp .print_strs
.strs_done:
    cinvoke printf, fmt_nl
    ret
endp

proc cmp_strs c, a:DWORD, b:DWORD
    mov eax, [a]
    mov ecx, dword [eax]
    mov edx, [b]
    mov eax, dword [edx]
    cinvoke strcmp, ecx, eax
    ret
endp

; ----------------------------------------------------------

proc main3
    cinvoke puts, '*** main3 ***'
    stdcall selection_sort, structs_arr, STRUCT_COUNT, \
            ITEM_SIZE, cmp_structs
    mov esi, 0
.print_structs:
    cmp esi, STRUCT_COUNT
    jae .structs_done
    mov eax, esi
    imul eax, ITEM_SIZE
    add eax, structs_arr
    mov ecx, dword [eax + ITEM_ID]
    mov edx, dword [eax + ITEM_VALUE]
    cinvoke printf, fmt_struct, ecx, edx
    inc esi
    jmp .print_structs
.structs_done:
    cinvoke printf, fmt_nl
    ret
endp

proc cmp_structs c, ptr1:DWORD, ptr2:DWORD
    mov eax, [ptr1]
    mov eax, [eax + ITEM_VALUE]
    mov ecx, [ptr2]
    sub eax, [ecx + ITEM_VALUE]
    ret
endp

; ----------------------------------------------------------

section '.idata' import data readable
    library kernel32,       'kernel32.dll', \
            msvcrt,         'msvcrt.dll'
    import  kernel32, \
            ExitProcess,    'ExitProcess'
    import  msvcrt, \
            printf,         'printf', \
            strcmp,         'strcmp'
