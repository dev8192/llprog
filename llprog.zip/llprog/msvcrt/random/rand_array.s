format PE
entry start

include 'win32a.inc'

NUM_RANDOMS = 100000

section '.data' data readable writeable
    fmt_max db 'Max: %u', 10, 0
    fmt_min db 'Min: %u', 10, 0
    fmt_log db '%u', 10, 0

section '.bss' data readable writeable
    array rb 4 * NUM_RANDOMS

section '.text' code readable executable
start:
    stdcall GenerateRandoms
    stdcall FindMax
    cinvoke printf, fmt_max, eax        ; 32767
    stdcall FindMin
    cinvoke printf, fmt_min, eax        ; 0
    stdcall VisualizeRandMax
    invoke ExitProcess, 0

proc GenerateRandoms uses ebx
    invoke GetTickCount
    cinvoke srand, eax
    xor ebx, ebx
@@:
    cmp ebx, NUM_RANDOMS
    jge .finish
    cinvoke rand
    mov dword [array + ebx * 4], eax
    inc ebx
    jmp @b
.finish:
    ret
endp

proc FindMax uses ebx esi
    mov esi, dword [array]
    cinvoke printf, fmt_log, esi
    mov ebx, 1
@@:
    cmp ebx, NUM_RANDOMS
    jge .finish
    cmp dword [array + ebx * 4], esi
    jle .skip
    mov esi, dword [array + ebx * 4]
    cinvoke printf, fmt_log, esi
.skip:
    inc ebx
    jmp @b
.finish:
    mov eax, esi
    ret
endp

proc FindMin uses ebx esi
    mov esi, dword [array]
    cinvoke printf, fmt_log, esi
    mov ebx, 1
@@:
    cmp ebx, NUM_RANDOMS
    jge .finish
    cmp dword [array + ebx * 4], esi
    jge .skip
    mov esi, dword [array + ebx * 4]
    cinvoke printf, fmt_log, esi
.skip:
    inc ebx
    jmp @b
.finish:
    mov eax, esi
    ret
endp

proc VisualizeRandMax
    mov eax, 1      ; 00000000 00000001
    shl eax, 15     ; 10000000 00000000
    sub eax, 1      ; 01111111 11111111
    cinvoke printf, fmt_log, eax        ; 32767
    cinvoke printf, fmt_log, 0x7FFF     ; 32767
    ret
endp

section '.idata' import data readable writeable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            GetTickCount,   'GetTickCount',\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            srand,          'srand',\
            rand,           'rand',\
            printf,         'printf'
