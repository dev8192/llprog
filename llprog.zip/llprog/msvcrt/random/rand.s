format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt     db '%d', 10, 0

section '.text' code readable executable
start:
    stdcall test10
    stdcall test20
    invoke ExitProcess, 0
    
proc test10
    cinvoke rand
    cinvoke printf, fmt, eax
    cinvoke rand
    cinvoke printf, fmt, eax
    cinvoke rand
    cinvoke printf, fmt, eax
    ret
endp
    
proc test20
    cinvoke srand, 1
    cinvoke rand
    cinvoke printf, fmt, eax
    cinvoke rand
    cinvoke printf, fmt, eax
    cinvoke rand
    cinvoke printf, fmt, eax
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            srand,          'srand',\
            rand,           'rand',\
            printf,         'printf'
