format PE
entry start

include 'win32a.inc'

TEST_ITERATIONS = 100000
RANGE_MIN = 1
RANGE_MAX = 10
SINGLE_VALUE = 7
NEG_MIN = -5
NEG_MAX = 2

section '.data' data readable writeable
    msg_dist db 'Distribution for range %d to %d (%d iterations):', 13, 10, 0
    msg_count db 'Value %d: %d times', 13, 10, 0
    msg_single db 13, 10, 'Test single value (%d, %d): %d', 13, 10, 0
    msg_negative db 'Test negative range (%d, %d): %d', 13, 10, 0
    
    counts dd 10 dup(0)

section '.code' code readable executable
start:
    invoke GetTickCount
    cinvoke srand, eax

    cinvoke printf, msg_dist, RANGE_MIN, RANGE_MAX, TEST_ITERATIONS
    mov esi, TEST_ITERATIONS

.test_loop:
    stdcall GenerateRandom, RANGE_MIN, RANGE_MAX
    sub eax, RANGE_MIN
    inc dword [counts + eax*4]
    dec esi
    jnz .test_loop

    xor esi, esi

.print_loop:
    cmp esi, RANGE_MAX - RANGE_MIN + 1
    jge .test_single
    mov eax, esi
    add eax, RANGE_MIN
    mov ecx, [counts + esi*4]
    cinvoke printf, msg_count, eax, ecx
    inc esi
    jmp .print_loop

.test_single:
    stdcall GenerateRandom, SINGLE_VALUE, SINGLE_VALUE
    cinvoke printf, msg_single, SINGLE_VALUE, SINGLE_VALUE, eax

    stdcall GenerateRandom, NEG_MIN, NEG_MAX
    cinvoke printf, msg_negative, NEG_MIN, NEG_MAX, eax

    invoke ExitProcess, 0

proc GenerateRandom uses ebx esi, val_from, val_to
    mov ebx, [val_from]
    mov esi, [val_to]
    cmp ebx, esi
    jle .no_swap
    xchg ebx, esi

.no_swap:
    sub esi, ebx
    inc esi
    cinvoke rand
    cdq
    idiv esi
    mov eax, edx
    add eax, ebx
    ret
endp

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL', \
        msvcrt, 'MSVCRT.DLL'

    import kernel32, \
        GetTickCount, 'GetTickCount', \
        ExitProcess, 'ExitProcess'

    import msvcrt, \
        printf, 'printf', \
        srand, 'srand', \
        rand, 'rand'
