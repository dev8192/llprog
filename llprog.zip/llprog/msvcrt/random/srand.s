format PE
entry start

include 'win32a.inc'

NUM_RANDOMS equ 5

section '.data' data readable writeable
    fmt_seed db 'Seed: %u', 10, 0
    fmt_result db 'Random number %d: %d', 10, 0

section '.text' code readable executable
start:
    stdcall GenerateRandoms
    invoke ExitProcess, 0

proc GenerateRandoms
    local counter:DWORD
    mov [counter], 1

    ;cinvoke time, 0
    invoke GetTickCount
    push eax
    cinvoke printf, fmt_seed, eax
    pop eax
    cinvoke srand, eax

.print_loop:
    mov eax, [counter]
    cmp eax, NUM_RANDOMS
    jg .finish

    cinvoke rand
    cinvoke printf, fmt_result, [counter], eax

    inc [counter]
    jmp .print_loop

.finish:
    ret
endp

section '.idata' import data readable writeable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            GetTickCount,   'GetTickCount',\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            time,           'time',\
            srand,          'srand',\
            rand,           'rand',\
            printf,         'printf'
