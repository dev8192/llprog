format PE CONSOLE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    msg_prompt db "Enter a character: ", 0
    msg_result db "'%c': %d", 10, 0

section '.code' code readable executable
start:
    cinvoke printf, msg_prompt

    ;cinvoke getchar
    cinvoke _getch

    cinvoke printf, msg_result, eax, eax

    invoke  ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            msvcrt, 'msvcrt.dll'

    import kernel32,\
           ExitProcess, 'ExitProcess'

    import msvcrt,\
           printf, 'printf',\
           getchar, 'getchar',\
           _getch, '_getch'
