; not working

format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    filename db "CONOUT$", 0
    mode     db "w", 0
    message  db "Hello, console via fwrite!", 0
    msglen   = $ - message
    fileptr  dd ?

section '.code' code readable executable

start:
    invoke  fopen, filename, mode
    test    eax, eax
    jz      exit
    mov     [fileptr], eax

    invoke  fwrite, message, 1, msglen, [fileptr]

    invoke  fclose, [fileptr]

exit:
    invoke  exit, 0

section '.idata' import data readable writeable

    library msvcrt, 'msvcrt.dll'

    import msvcrt, \
        fopen, 'fopen', \
        fwrite, 'fwrite', \
        fclose, 'fclose', \
        exit, 'exit'
