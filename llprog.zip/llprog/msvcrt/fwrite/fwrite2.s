format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    filename db "0files/output.txt", 0
    mode        db "w", 0
    data1        db "one two three"
    data_len    = $ - data1
    fileptr     dd ?

section '.code' code readable executable

start:
    cinvoke  fopen, filename, mode
    test    eax, eax
    jz      done
    mov     [fileptr], eax
    cinvoke  fwrite, data1, 1, data_len, [fileptr]
    cinvoke  fclose, [fileptr]

done:
    cinvoke  exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt, \
            fopen, 'fopen', \
            fwrite, 'fwrite', \
            fclose, 'fclose', \
            exit, 'exit'
