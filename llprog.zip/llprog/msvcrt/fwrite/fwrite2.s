format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    filename db "0files/output.txt", 0
    mode     db "w", 0
    data_to_write db "Hello, world!", 0
    itemsize equ 1
    itemcount equ 13
    fileptr dd ?

section '.code' code readable executable

start:
    invoke  fopen, filename, mode
    test    eax, eax
    jz      exit
    mov     [fileptr], eax

    invoke  fwrite, data_to_write, itemsize, itemcount, [fileptr]

    invoke  fclose, [fileptr]

exit:
    invoke  ExitProcess, 0

section '.idata' import data readable writeable

    library kernel32, 'kernel32.dll', \
            msvcrt,   'msvcrt.dll'

    import kernel32, \
        ExitProcess, 'ExitProcess'

    import msvcrt, \
        fopen, 'fopen', \
        fwrite, 'fwrite', \
        fclose, 'fclose'
