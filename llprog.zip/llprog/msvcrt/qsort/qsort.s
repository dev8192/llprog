format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    str_num     db '%d ', 0
    str_newline db 10, 0

    array       dd 89, 12, 45, 2, 71, 33, 5, 19
    array_count = ($ - array) / 4

section '.text' code readable executable
start:
    stdcall print_array
    cinvoke qsort, array, array_count, 4, compare1
    stdcall print_array
    cinvoke qsort, array, array_count, 4, compare2
    stdcall print_array
    cinvoke exit, 0

proc print_array uses ebx
    xor     ebx, ebx

@@:
    cmp     ebx, array_count
    jge     .done
    
    mov     eax, dword [array + ebx*4]
    cinvoke printf, str_num, eax
    
    inc     ebx
    jmp     @b

.done:
    cinvoke printf, str_newline
    ret
endp

proc compare1 c ptr_a, ptr_b
    mov     eax, [ptr_a]
    mov     eax, dword [eax]
    
    mov     edx, [ptr_b]
    mov     edx, dword [edx]
    
    sub     eax, edx
    ret
endp

proc compare2 c ptr_a, ptr_b
    mov     eax, [ptr_b]
    mov     eax, dword [eax]
    
    mov     edx, [ptr_a]
    mov     edx, dword [edx]
    
    sub     eax, edx
    ret
endp

section '.idata' import data readable
    library msvcrt, 'MSVCRT.DLL'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf',\
            qsort,  'qsort'
