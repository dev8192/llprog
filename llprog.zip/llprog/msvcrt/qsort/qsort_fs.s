format PE Console 4.0
entry start

include 'win32a.inc'
section '.data' data readable writeable
    szFile      db '0files/months.txt', 0
    szModeR     db 'rb', 0
    szModeW     db 'wb', 0
    szNewline   db 13, 10, 0
    szError     db 'Error! Could not open file', 10, 0
    szSuccess   db 'File sorted successfully.', 10, 0

    hFile       dd ?
    cbFile      dd ?
    pBuffer     dd ?
    cLines      dd 0

section '.bss' readable writeable
    pLines      rd 100000

section '.text' code readable executable

start:
    cinvoke fopen, szFile, szModeR
    test    eax, eax
    jz      .error
    mov     [hFile], eax

SEEK_SET = 0
SEEK_CUR = 1
SEEK_END = 2

    cinvoke fseek, [hFile], 0, SEEK_END
    cinvoke ftell, [hFile]
    mov     [cbFile], eax

    cinvoke fseek, [hFile], 0, SEEK_SET

    mov     eax, [cbFile]
    inc     eax
    cinvoke malloc, eax
    mov     [pBuffer], eax

    cinvoke fread, [pBuffer], 1, [cbFile], [hFile]
    cinvoke fclose, [hFile]

    mov     esi, [pBuffer]
    add     esi, [cbFile]
    mov     byte [esi], 0

    mov     esi, [pBuffer]
    mov     edi, pLines
    mov     ebx, 0

    mov     [edi + ebx*4], esi
    inc     ebx

    mov     ecx, [cbFile]
    test    ecx, ecx
    jz      .done_parse

.parse_loop:
    mov     al, [esi]
    cmp     al, 13
    jne     .check_nl
    mov     byte [esi], 0
    jmp     .next_char

.check_nl:
    cmp     al, 10
    jne     .next_char
    mov     byte [esi], 0
    cmp     ecx, 1
    jle     .next_char
    mov     edx, esi
    inc     edx
    mov     [edi + ebx*4], edx
    inc     ebx

.next_char:
    inc     esi
    dec     ecx
    jnz     .parse_loop

.done_parse:
    mov     [cLines], ebx

    cinvoke qsort, pLines, [cLines], 4, compare_lines

    cinvoke fopen, szFile, szModeW
    test    eax, eax
    jz      .error
    mov     [hFile], eax

    mov     ebx, 0
.write_loop:
    cmp     ebx, [cLines]
    jge     .done_write

    mov     eax, [pLines + ebx*4]
    cinvoke fputs, eax, [hFile]
    cinvoke fputs, szNewline, [hFile]

    inc     ebx
    jmp     .write_loop

.done_write:
    cinvoke fclose, [hFile]
    cinvoke printf, szSuccess
    cinvoke exit, 0

.error:
    cinvoke printf, szError
    cinvoke exit, 1

proc compare_lines c p1, p2
    mov     eax, [p1]
    mov     eax, [eax]
    mov     edx, [p2]
    mov     edx, [edx]
    cinvoke strcmp, eax, edx
    ret
endp

section '.idata' import data readable writeable
    library msvcrt,     'MSVCRT.DLL'
    import  msvcrt,\
            exit,       'exit',\
            fclose,     'fclose',\
            fopen,      'fopen',\
            fputs,      'fputs',\
            fread,      'fread',\
            fseek,      'fseek',\
            ftell,      'ftell',\
            malloc,     'malloc',\
            printf,     'printf',\
            qsort,      'qsort',\
            strcmp,     'strcmp'
