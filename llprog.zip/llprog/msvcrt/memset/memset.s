format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    buffer      rb 8
    fmt_str     db '"%s"', 10, 0

section '.text' code readable executable
start:
    stdcall test22
    invoke ExitProcess, 0

; "aaaaaaa"
; "abbbbbb"
; "abccccc"
; "abcdddd"
; "abcdeee"
; "abcdeff"
; "abcdefg"
proc test10
    cinvoke memset, buffer + 0, 'a', 7
    cinvoke printf, fmt_str, buffer
    cinvoke memset, buffer + 1, 'b', 6
    cinvoke printf, fmt_str, buffer
    cinvoke memset, buffer + 2, 'c', 5
    cinvoke printf, fmt_str, buffer

    cinvoke memset, buffer + 6, 'g', 1
    cinvoke printf, fmt_str, buffer
    ret
endp

proc test11 uses ebx esi edi
    mov ebx, buffer
    mov esi, 'a'
    mov edi, 7
@@:
    cinvoke memset, ebx, esi, edi
    cinvoke printf, fmt_str, buffer
    inc ebx
    inc esi
    dec edi
    test edi, edi
    jnz @b
    ret
endp

; "aaaaaaa"
; "abbbbba"
; "abcccba"
; "abcdcba"
proc test20
    cinvoke memset, buffer + 0, 'a', 7
    cinvoke printf, fmt_str, buffer
    cinvoke memset, buffer + 1, 'b', 5
    cinvoke printf, fmt_str, buffer
    cinvoke memset, buffer + 2, 'c', 3
    cinvoke printf, fmt_str, buffer
    cinvoke memset, buffer + 3, 'd', 1
    cinvoke printf, fmt_str, buffer
    ret
endp

proc test21 uses ebx esi edi
    mov ebx, buffer
    mov esi, 'a'
    mov edi, 7
@@:
    cinvoke memset, ebx, esi, edi
    cinvoke printf, fmt_str, buffer
    inc ebx
    inc esi
    sub edi, 2
    test edi, edi
    jge @b
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            memset,         'memset'
