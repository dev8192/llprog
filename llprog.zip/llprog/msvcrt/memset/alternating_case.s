format PE console
entry start

include 'win32a.inc'

CASE_BIT   = 20h
LETTER_COUNT = 4
STR_LEN  = (LETTER_COUNT shl 1) - 1

section '.data' data readable writeable
    fmt_str db '"%s"', 10, 0
    buffer  rb STR_LEN + 1

section '.text' code readable executable
start:
    stdcall test20
    invoke ExitProcess, 0

; aBcDeFgHiJkLmNoPqRsTuVwXyZyXwVuTsRqPoNmLkJiHgFeDcBa
proc test20 uses ebx esi edi
    mov ebx, buffer
    mov esi, 'a'
    mov edi, STR_LEN
.loop:
    cinvoke memset, ebx, esi, edi
    cinvoke printf, fmt_str, buffer
    inc ebx
    inc esi
    xor esi, CASE_BIT
    sub edi, 2
    jg .loop
    ret
endp

section '.idata' import data readable
    library msvcrt,         'msvcrt.dll',\
            kernel32,       'kernel32.dll'
    import  msvcrt,\
            printf,         'printf',\
            memset,         'memset'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
