format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    msg db "Press any key to exit...", 10, 0

section '.code' code readable executable

start:
    cinvoke printf, msg
    cinvoke getch
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import msvcrt,\
        printf, 'printf',\
        getch, '_getch',\
        exit, 'exit'
