format PE console
entry start
include 'win32a.inc'

section '.data' data readable writeable
    prompt          db 'Press a key: ', 0
    str_result      db 10, '%c %d', 10, 0

section '.text' code readable executable
start:
    cinvoke printf, prompt
    cinvoke _getch
    cinvoke printf, str_result, eax, eax

    cinvoke printf, prompt
    cinvoke _getche
    cinvoke printf, str_result, eax, eax

    cinvoke  exit, 0

section '.idata' import data readable writeable
    library msvcrt, 'MSVCRT.DLL'
    import msvcrt,\
           exit, 'exit',\
           printf, 'printf',\
           _getch, '_getch',\
           _getche, '_getche'
