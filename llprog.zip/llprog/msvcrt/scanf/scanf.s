format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    prompt_msg  db 'Enter numeric exit code: ', 0
    format_spec db '%d', 0
    exit_code   dd ? 

section '.text' code readable executable
start:
    cinvoke printf, prompt_msg
    cinvoke scanf, format_spec, exit_code
    cinvoke exit, [exit_code]

section '.idata' import data readable
    library msvcrt,     'msvcrt.dll'
    import  msvcrt,\
            exit,       'exit',\
            printf,     'printf',\
            scanf,      'scanf'
