; working!

format PE CONSOLE 4.0
entry start

include 'win32a.inc'

section '.code' code readable executable
  start:
    ; Pass the ADDRESS of the string (prompt_msg)
    cinvoke printf, prompt_msg
    
    ; Pass the ADDRESS of the format string and the variable
    cinvoke scanf, format_spec, exit_code
    
    ; Exit with the value stored at the exit_code address
    invoke ExitProcess, [exit_code]

section '.data' data readable writeable
    prompt_msg  db 'Enter numeric exit code: ', 0
    format_spec db '%d', 0
    exit_code   dd ? 

section '.idata' import data readable
    library kernel32, 'kernel32.dll', \
            msvcrt,   'msvcrt.dll'

    import kernel32, ExitProcess, 'ExitProcess'
    import msvcrt, printf, 'printf', scanf, 'scanf'
