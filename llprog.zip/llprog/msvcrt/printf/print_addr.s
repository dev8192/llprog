format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt1      db '%p', 10, 0
    fmt2      db '%x', 10, 0
    fmt3      db '%08X', 10, 0
    num1      dd 0xABCD
    num2      dd 0x1234

section '.text' code readable executable
start:
    cinvoke printf, fmt1, num1
    cinvoke printf, fmt1, num2
    cinvoke printf, fmt2, num1
    cinvoke printf, fmt2, num2
    cinvoke printf, fmt3, num1
    cinvoke printf, fmt3, num2
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt,'msvcrt.dll'
    import msvcrt,\
        printf,'printf',\
        exit,'exit'
