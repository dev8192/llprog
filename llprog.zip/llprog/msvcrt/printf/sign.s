format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt1     db "%d", 10, 0
    fmt2     db "%u", 10, 0
    fmt3     db "%x", 10, 0
    num      dd 4294967295

section '.code' code readable executable

start:
    cinvoke printf, fmt1, [num] ; -1
    cinvoke printf, fmt2, [num] ; 4294967295
    cinvoke printf, fmt3, [num] ; ffffffff
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
