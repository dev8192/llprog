format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt     db "%10u", 10, 0
    num1    dd 123         ;        123
    num2    dd 0xFFFFFFFF  ; 4294967295

section '.code' code readable executable
start:
    cinvoke printf, fmt, [num1]
    cinvoke printf, fmt, [num2]
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
