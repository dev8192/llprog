format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt     db "String: %s", 10, "Number: %d", 10, "Hex: 0x%X", 10, 0
    msg     db "Hello FASM", 0
    val     dd 1234
    hex     dd 0xABCDEF

section '.code' code readable executable

start:
    cinvoke printf, \
        fmt, \      ; char *format
        msg, \      ; char *s
        [val], \    ; int d
        [hex]       ; int X

    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'

    import msvcrt,\
           exit, 'exit',\
           printf, 'printf'
