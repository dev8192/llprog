format PE
entry start

include 'win32a.inc'

section '.data' data readable writable
    fmt_d    db '%d', 10, 0
    fmt_u    db '%u', 10, 0
    fmt_x    db '%x', 10, 0
    fmt_X    db '%X', 10, 0

section '.text' code readable executable
start:
    stdcall test10, -1
    stdcall test10, 0x7fffffff
    cinvoke exit, 0

proc test10, num
    cinvoke printf, fmt_d, [num]
    cinvoke printf, fmt_u, [num]
    cinvoke printf, fmt_x, [num]
    cinvoke printf, fmt_X, [num]
    ret
endp

section '.idata' import readable
    library msvcrt, 'msvcrt.dll'
    import msvcrt,\
        printf, 'printf',\
        exit, 'exit'
