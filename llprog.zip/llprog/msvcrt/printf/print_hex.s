format PE console
entry start

include 'win32a.inc'

section '.data' data readable writable
    num     dd 255
    fmt1    db '%d', 10, 0
    fmt2    db '%u', 10, 0
    fmt3    db '%x', 10, 0
    fmt4    db '%X', 10, 0

section '.code' code readable executable
start:
    cinvoke printf, fmt1, [num]
    cinvoke printf, fmt2, [num]
    cinvoke printf, fmt3, [num]
    cinvoke printf, fmt4, [num]
    cinvoke exit, 0

section '.idata' import readable
    library msvcrt, 'msvcrt.dll'
    import msvcrt,\
        printf, 'printf',\
        exit, 'exit'
