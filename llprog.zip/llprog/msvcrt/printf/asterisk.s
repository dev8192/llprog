format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    str1        db "FASM_Assembly", 0
    num1        dd 42
    fmt_s_w     db "[%*s]", 10, 0
    fmt_s_w2    db "[%-*s]", 10, 0
    fmt_s_p     db "[%.*s]", 10, 0
    fmt_d_p     db "[%.*d]", 10, 0
    fmt_s_wp    db "[%*.*s]", 10, 0

; *** test10 ***
; [       FASM_Assembly]
; [FASM_Assembly       ]
; [FASM_Assembly       ]
; *** test20 ***
; [FASM]
; [FASM_Assembly]
; [000042]
; *** test30 ***
; [          FASM_]

section '.text' code readable executable
start:
    stdcall test10
    stdcall test20
    stdcall test30
    invoke ExitProcess, 0

proc test10
    cinvoke puts, '*** test10 ***'
    WIDTH = 20
    cinvoke printf, fmt_s_w, WIDTH, str1
    WIDTH = -20
    cinvoke printf, fmt_s_w, WIDTH, str1
    WIDTH = 20
    cinvoke printf, fmt_s_w2, WIDTH, str1
    ret
endp

proc test20
    cinvoke puts, '*** test20 ***'
    PREC = 4
    cinvoke printf, fmt_s_p, PREC, str1
    PREC = 20
    cinvoke printf, fmt_s_p, PREC, str1
    PREC = 6
    cinvoke printf, fmt_d_p, PREC, [num1]
    ret
endp

proc test30
    cinvoke puts, '*** test30 ***'
    WIDTH = 15
    PREC = 5
    cinvoke printf, fmt_s_wp, WIDTH, PREC, str1
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
