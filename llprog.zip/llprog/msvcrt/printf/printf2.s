format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt     db "%x", 10, 0
example1:
    .num1    db 0x12
    .num2    db 0x34
    .num3    db 0x56
    .num4    db 0x78
example2:
    .num1    dw 0x1234
    .num2    dw 0x5678
example3:
    .num1    dd 0x12345678

section '.text' code readable executable
start:
    stdcall test10
    cinvoke exit, 0

proc test10
    cinvoke printf, fmt, dword [example1.num1]
    cinvoke printf, fmt, dword [example2.num1]
    cinvoke printf, fmt, dword [example3.num1]
    ret
endp

proc test20
    cinvoke puts, "one"
    cinvoke puts, "two"
    cinvoke puts, "three"
    ret
endp

proc test30
    cinvoke printf, "One%c", 10
    cinvoke printf, "Two%c", 10
    cinvoke printf, "Three%c", 10
    ret
endp

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf',\
            puts,   'puts'
