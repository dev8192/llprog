format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt     db "%x", 10, 0
    ; ---- example 1 ----
    ;num1    db 0x12
    ;num2    db 0x34
    ;num3    db 0x56
    ;num4    db 0x78
    ; ---- example 2 ----
    num1    dw 0x1234
    num2    dw 0x5678

section '.code' code readable executable

start:
    cinvoke printf, fmt, dword [num1]
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
