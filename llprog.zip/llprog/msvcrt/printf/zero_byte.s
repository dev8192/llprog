format PE console
entry start

include 'win32a.inc'

section '.data' data readable
    msg1    db 'aaaaa'
    msg2    db 'bbbbb'
    msg3    db 'ccccc', 0
    newline db 10, 0

section '.text' code executable
start:
    cinvoke printf, msg1
    cinvoke printf, newline
    cinvoke printf, msg2
    cinvoke printf, newline
    cinvoke printf, msg3
    cinvoke printf, newline
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            printf, 'printf',\
            exit,   'exit'
