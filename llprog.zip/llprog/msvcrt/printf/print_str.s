format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    str1     db 'abc', 0
    fmt1     db "'%s' '%S'", 10, 0
    str2     du 'abc', 0
    fmt2     du "'%s' '%S'", 10, 0

section '.text' code readable executable
start:
    cinvoke printf, fmt1, str1, str2
    cinvoke wprintf, fmt2, str2, str1
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf',\
            wprintf, 'wprintf'
