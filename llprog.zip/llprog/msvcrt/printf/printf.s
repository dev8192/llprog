format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt     db "%d", 10, 0
    num     dd 1234

section '.code' code readable executable

start:
    cinvoke printf, fmt, [num]
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
