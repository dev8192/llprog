; not working

format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    filename db "CONOUT$", 0
    mode     db "w", 0
    message  db "Hello, console via fwrite!", 0
    msglen   = $ - message
    fileptr  dd ?

section '.code' code readable executable

start:
    cinvoke  fopen, filename, mode
    test    eax, eax
    jz      .done
    mov     [fileptr], eax

    cinvoke  fwrite, message, 1, msglen, [fileptr]

    cinvoke  fclose, [fileptr]

.done:
    cinvoke  exit, 0

section '.idata' import data readable

    library msvcrt, 'msvcrt.dll'

    import msvcrt, \
        fopen, 'fopen', \
        fwrite, 'fwrite', \
        fclose, 'fclose', \
        exit, 'exit'
