format PE console
entry start

include 'win32a.inc'

section '.idata' import data readable writeable
    library msvcrt,'msvcrt.dll'
    import msvcrt,\
      fopen,'fopen',\
      fread,'fread',\
      fclose,'fclose',\
      printf,'printf',\
      exit,'exit'

section '.data' data readable writeable
    filename  db '0files/test.txt',0
    mode      db 'rb',0
    fmt       db '%s',0
    err_msg   db 'error: cannot open file',10,0
    buf       rb 4097
    fp        dd 0

section '.text' code readable executable

start:
    cinvoke fopen, \
        filename, \    ; const char *
        mode           ; const char *
    mov     [fp],eax
    test    eax,eax
    jz      .error

.read:
    cinvoke fread, \
          buf, \    ; void *ptr
          1, \      ; size_t size
          4096, \   ; size_t count
          [fp]      ; FILE *stream
    test    eax,eax
    jz      .close

    mov     byte [buf+eax],0
    cinvoke printf, \
      fmt, \    ; const char *format
      buf       ; const char *arg
    jmp     .read

.close:
    cinvoke fclose,[fp]
    cinvoke exit,0

.error:
    cinvoke printf,err_msg
    cinvoke exit,1
