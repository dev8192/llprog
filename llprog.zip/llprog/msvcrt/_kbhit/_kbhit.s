format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    str_waiting db 'Waiting for a key press', 0
    str_dot     db '.', 0
    str_pressed db 10, '%c %d', 10, 0

section '.text' code readable executable
start:
    cinvoke printf, str_waiting

poll_loop:
    invoke  Sleep, 250
    cinvoke printf, str_dot

    cinvoke _kbhit
    test    eax, eax
    jnz     key_pressed
    jmp     poll_loop

key_pressed:
    cinvoke _getch
    cinvoke printf, str_pressed, eax, eax
    invoke  ExitProcess, 0

section '.idata' import data readable writeable

    library kernel32, 'KERNEL32.DLL',\
            msvcrt, 'MSVCRT.DLL'

    import kernel32,\
           Sleep, 'Sleep',\
           ExitProcess, 'ExitProcess'

    import msvcrt,\
           printf, 'printf',\
           _kbhit, '_kbhit',\
           _getch, '_getch'
