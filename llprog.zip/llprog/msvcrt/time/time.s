format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt db 'Current Unix time: %u seconds since epoch', 10, 0

section '.text' code readable executable
start:
    stdcall PrintTime
    invoke ExitProcess, 0

proc PrintTime
    cinvoke time, 0
    cinvoke printf, fmt, eax
    ret
endp

section '.idata' import data readable writeable

    library kernel32, 'KERNEL32.DLL', \
            msvcrt, 'MSVCRT.DLL'

    import kernel32, \
           ExitProcess, 'ExitProcess'

    import msvcrt, \
           time, 'time', \
           printf, 'printf'
