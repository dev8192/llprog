format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    path     db "c_libs\nested\folder", 0
    fmt_err  db "Error creating directory", 10, 0

section '.code' code readable executable

start:
    mov edi, path

.next_char:
    mov al, [edi]
    test al, al
    jz .final_dir
    
    cmp al, '\'
    je .create_segment
    cmp al, '/'
    je .create_segment
    
    inc edi
    jmp .next_char

.create_segment:
    mov byte [edi], 0
    cinvoke _mkdir, path
    mov byte [edi], '\'
    
    inc edi
    jmp .next_char

.final_dir:
    cinvoke _mkdir, path
    
    ; _mkdir returns 0 on success, -1 on error
    cmp eax, 0
    je .success
    
    ; Check if error is simply "already exists" (EEXIST = 17)
    cinvoke _errno
    mov eax, [eax]
    cmp eax, 17
    je .success

    cinvoke printf, fmt_err
    cinvoke exit, 1

.success:
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'

    import msvcrt,\
           _mkdir, '_mkdir',\
           _errno, '_errno',\
           exit, 'exit',\
           printf, 'printf'
