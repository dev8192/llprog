format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt_ptr db 'Allocated at: %p', 10, 0
    fmt_val db 'Value stored: %d', 10, 0
    fmt_msg db 'Memory freed successfully', 10, 0
    mem_ptr dd ?

section '.text' code readable executable
start:
    push 256
    call [malloc]
    add esp, 4
    mov [mem_ptr], eax

    push eax
    push fmt_ptr
    call [printf]
    add esp, 8

    mov ecx, [mem_ptr]
    mov dword [ecx], 42

    push dword [ecx]
    push fmt_val
    call [printf]
    add esp, 8

    push [mem_ptr]
    call [free]
    add esp, 4

    push fmt_msg
    call [printf]
    add esp, 4

    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL', \
        msvcrt, 'MSVCRT.DLL'

    import kernel32, \
        ExitProcess, 'ExitProcess'

    import msvcrt, \
        malloc, 'malloc', \
        free, 'free', \
        printf, 'printf'
