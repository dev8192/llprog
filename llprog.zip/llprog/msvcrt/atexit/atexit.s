format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    msg1    db "msg1", 10, 0
    msg2    db "msg2", 10, 0
    msg3    db "msg3", 10, 0
    msg4    db "msg4", 10, 0
    msg5    db "msg5", 10, 0

section '.code' code readable executable

print_msg2:
    cinvoke printf, msg2
    ret

print_msg3:
    cinvoke printf, msg3
    ret

print_msg4:
    cinvoke printf, msg4
    ret

start:
    cinvoke printf, msg1
    cinvoke atexit, print_msg2
    cinvoke atexit, print_msg3
    cinvoke atexit, print_msg4
    cinvoke printf, msg5
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'

    import msvcrt,\
           atexit, 'atexit',\
           exit, 'exit',\
           printf, 'printf'
