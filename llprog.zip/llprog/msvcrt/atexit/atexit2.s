format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    msg1            db "msg1", 10
    msg2            db "msg2", 10
    msg3            db "msg3", 10
    msg4            db "msg4", 10
    msg5            db "msg5", 10
    hStdOut         dd ?
    bytes_written   dd ?

section '.code' code readable executable

macro print msg {
    invoke WriteConsoleA, [hStdOut], msg, 5, bytes_written, 0
}

print_msg2:
    print msg2
    ret

print_msg3:
    print msg3
    ret

print_msg4:
    print msg4
    ret

start:
    invoke GetStdHandle, STD_OUTPUT_HANDLE
    mov [hStdOut], eax

    print msg1

    cinvoke atexit, print_msg2
    cinvoke atexit, print_msg3
    cinvoke atexit, print_msg4

    print msg5

    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            msvcrt, 'msvcrt.dll'

    import kernel32,\
           GetStdHandle, 'GetStdHandle',\
           WriteConsoleA, 'WriteConsoleA',\
           ExitProcess, 'ExitProcess'

    import msvcrt,\
           atexit, 'atexit'
