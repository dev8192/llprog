format PE CONSOLE 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt     du 'привет', 10, 0      ; not working

section '.text' code readable executable
start:
    cinvoke wprintf, fmt, esp
    cinvoke wprintf, fmt, esp
    cinvoke wprintf, fmt, esp

    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL', \
            msvcrt, 'MSVCRT.DLL'

    import kernel32, \
           ExitProcess, 'ExitProcess'

    import msvcrt, \
           wprintf, 'wprintf'
