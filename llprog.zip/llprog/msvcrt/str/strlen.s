format PE console
entry start

include 'win32a.inc'

section '.data' data readable
    str1 db 'abc', 0
    str2 du 'abc', 0
    fmt         db '"%s": %d', 10, 0

section '.text' code readable executable
start:
    cinvoke strlen, str1
    cinvoke printf, fmt, str1, eax
    ;cinvoke wcslen, str2
    ;cinvoke printf, fmt, eax
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll', \
            msvcrt, 'msvcrt.dll'
    import kernel32, \
           ExitProcess, 'ExitProcess'
    import msvcrt, \
           printf, 'printf', \
           strlen, 'strlen', \
           wcslen, 'wcslen'
