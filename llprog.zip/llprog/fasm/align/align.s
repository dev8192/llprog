format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    num1    db 1
    num2    db 2
    ;align 8
    num3    db 3

    fmt     db "num1: 0x%08X", 10
            db "num2: 0x%08X", 10
            db "num3: 0x%08X", 10, 0

section '.code' code readable executable
start:
    cinvoke printf, fmt, num1, num2, num3
    invoke  ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            msvcrt, 'msvcrt.dll'

    import  kernel32,\
            ExitProcess, 'ExitProcess'

    import  msvcrt,\
            printf, 'printf'
