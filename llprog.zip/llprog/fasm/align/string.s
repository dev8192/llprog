format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt     db '%x', 10, 0
    msg1    db 'abc'
    msg2    db 'xyz'
    buf     db 4085 dup(0)
    ;buf     db 4086 dup(0)
    ;buf     db 4087 dup(0)
    addr = $

section '.code' code readable executable
start:
    cinvoke printf, fmt, $
    cinvoke printf, fmt, addr
    cinvoke printf, fmt, fmt
    cinvoke printf, fmt, msg1
    cinvoke printf, fmt, msg2
    invoke  ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            msvcrt, 'msvcrt.dll'
    import  kernel32,\
            ExitProcess, 'ExitProcess'
    import  msvcrt,\
            printf, 'printf'
