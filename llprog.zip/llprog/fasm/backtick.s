
macro main {
    display '*** main1 ***', 10
    display 'This is a '
    display `backtick., 10
    display 'done'
}

main
