
include 'display_hex.inc'

db 'START'
rb 0x100

display '$%:  0x'
display_hex $%
display 10

display '$%%: 0x'
display_hex $%%
display 10
