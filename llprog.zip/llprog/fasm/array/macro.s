format PE
entry start

include 'win32a.inc'

macro set_item index, value {
    mov [arr + (index)*4], value
}

macro print_arr index {
    cinvoke printf, fmt, [arr + index * 4]
}

section '.data' data readable writeable
    fmt     db '%d', 10, 0
    arr    dd 0 dup(4)

section '.text' code readable executable
func1:
    mov [arr + 0], 101
    mov [arr + 4], 201
    mov [arr + 8], 301
    mov [arr + 12], 401
    cinvoke printf, fmt, [arr + 0]
    cinvoke printf, fmt, [arr + 4]
    cinvoke printf, fmt, [arr + 8]
    cinvoke printf, fmt, [arr + 12]
    ret

func2:
    set_item 0, 102
    set_item 1, 202
    set_item 2, 302
    set_item 3, 402
    print_arr 0
    print_arr 1
    print_arr 2
    print_arr 3
    ret

start:
    call func1
    call func2
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
