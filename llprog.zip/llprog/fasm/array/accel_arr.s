format PE console
entry start

include 'win32a.inc'

ID_CUT   = 101
ID_COPY  = 102
ID_PASTE = 103

section '.data' data readable writeable
    accelList1:
        db FCONTROL or FVIRTKEY, 0
        dw 'X', ID_CUT
        db FCONTROL or FVIRTKEY, 0
        dw 'C', ID_COPY
        db FCONTROL or FVIRTKEY, 0
        dw 'V', ID_PASTE
    accelList1_sz = $ - accelList1
    accelList2:
        ACCEL FCONTROL or FVIRTKEY, 'X', ID_CUT
        ACCEL FCONTROL or FVIRTKEY, 'C', ID_COPY
        ACCEL FCONTROL or FVIRTKEY, 'V', ID_PASTE
    accelList2_sz = $ - accelList2
    fmt     db "%d", 10, 0

section '.text' code readable executable

start:
    ; 6 * 3 = 18
    cinvoke printf, fmt, accelList1_sz
    cinvoke printf, fmt, accelList2_sz
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
