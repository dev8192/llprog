macro push_item array, value {
    ; If this array's index hasn't been defined yet, start at 0
    if ~ defined array#_index
        array#_index = 0
    end if

    ; Perform the move using the array's specific index
    mov [array + (array#_index)*4], value

    ; Increment only this array's specific index
    array#_index = array#_index + 1
}

section '.data' data readable writeable
    arr        dd 0, 0, 0, 0
    other_arr  dd 0, 0

section '.text' code readable executable
start:
    push_item arr, 100       ; Sets [arr + 0],   arr_index becomes 1
    push_item arr, 200       ; Sets [arr + 4],   arr_index becomes 2
    
    push_item other_arr, 50  ; Sets [other_arr + 0], other_arr_index becomes 1
    
    push_item arr, 300       ; Sets [arr + 8],   arr_index becomes 3 (it remembered!)
