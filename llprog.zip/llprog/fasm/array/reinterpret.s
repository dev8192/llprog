format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_x       db '%x', 10, 0
    fmt_x_space db '%x ', 0
    newline     db 10, 0

section '.text' code readable executable
start:
    stdcall test40
    invoke ExitProcess, 0
    
proc print_bytes uses ebx esi, buf, len
    mov esi, [buf]
    mov eax, [len]
    lea ebx, [esi + eax]
.loop:
    movzx eax, byte [esi]
    cinvoke printf, fmt_x_space, eax
    add esi, 1
    cmp esi, ebx
    jl .loop
    cinvoke printf, newline
    ret
endp
    
proc test10
    cinvoke puts, '*** test10 ***'
    local buf[4]:BYTE
    mov [buf + 0], 0x11
    mov [buf + 1], 0x22
    mov [buf + 2], 0x33
    mov [buf + 3], 0x44
    cinvoke printf, fmt_x, dword [buf]
    stdcall print_bytes, addr buf, 4
    ret
endp

proc test20
    cinvoke puts, '*** test20 ***'
    local buf[4]:BYTE
    mov dword [buf], 0x11223344
    cinvoke printf, fmt_x, dword [buf]
    stdcall print_bytes, addr buf, 4
    ret
endp

proc test30
    cinvoke puts, '*** test30 ***'
    local buf[2]:DWORD
    mov [buf], 0x11223344
    mov [buf + 4], 0x55
    mov [buf + 5], 0x66
    mov [buf + 6], 0x77
    mov [buf + 7], 0x88
    cinvoke printf, fmt_x, dword [buf]
    cinvoke printf, fmt_x, dword [buf + 4]
    stdcall print_bytes, addr buf, 8
    ret
endp

proc test40
    cinvoke puts, '*** test30 ***'
    local buf[2]:QWORD
    mov dword [buf], 0x11223344
    mov dword [buf + 4], 0x55667788
    cinvoke printf, fmt_x, dword [buf]
    cinvoke printf, fmt_x, dword [buf + 4]
    stdcall print_bytes, addr buf, 8
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
