format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_s   db '"%s"', 10, 0
    fmt_x   db '%x', 10, 0
    fmt_dd  db '%2d %2d', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

; ----------------------------------------------------------

proc main1
    cinvoke puts, '*** main1 ***'
    cinvoke printf, fmt_x, esp
    stdcall .func
    cinvoke printf, fmt_x, esp
    ret
endp

proc .func
    sub esp, 8
    mov edx, esp
    mov ecx, 5
    mov eax, 97
.fill:
    mov byte [edx], al
    inc edx
    dec ecx
    jnz .fill
    mov byte [edx], 0
    mov edx, esp
    cinvoke printf, fmt_s, edx
    add esp, 8
    ret
endp

; ----------------------------------------------------------

proc main2
    cinvoke puts, '*** main2 ***'
    cinvoke printf, fmt_x, esp
    stdcall .func, 8, 97, 5
    cinvoke printf, fmt_x, esp
    ret
endp

proc .func, buf_size, fill_char, repeat_cnt
    sub esp, [buf_size]
    mov edx, esp
    mov ecx, [repeat_cnt]
    mov eax, [fill_char]
.fill:
    mov byte [edx], al
    inc edx
    dec ecx
    jnz .fill
    mov byte [edx], 0
    mov edx, esp
    cinvoke printf, fmt_s, edx
    ret
endp

; ----------------------------------------------------------
; algorithm/pow2_round_up.s
; ----------------------------------------------------------
proc main
    cinvoke puts, '*** main10 ***'
    cinvoke printf, fmt_x, esp
    stdcall .func, 5, 97
    cinvoke printf, fmt_x, esp
    ret
endp

proc .func, buf_size, fill_char
    mov eax, [buf_size]
    inc eax
    add eax, 3
    and eax, -4
    sub esp, eax
    mov edx, esp
    mov ecx, [buf_size]
    mov eax, [fill_char]
    test ecx, ecx
    jz .terminate
.fill:
    mov byte [edx], al
    inc edx
    dec ecx
    jnz .fill
.terminate:
    mov byte [edx], 0
    mov edx, esp
    cinvoke printf, fmt_s, edx
    ret
endp

; ----------------------------------------------------------

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
