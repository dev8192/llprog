format PE console
entry start

include 'win32a.inc'

ARRAY_SIZE = 5
section '.data' data readable writeable
    ;arr     dd ARRAY_SIZE dup (7)
    arr     dd ARRAY_SIZE dup (?)
    fmt     db '%d ', 0

section '.code' code readable executable
start:
    xor ebx, ebx
loop1:
    mov     eax, [arr + ebx * 4]
    cmp     ebx, ARRAY_SIZE
    jge     done
    cinvoke printf, fmt, eax
    inc     ebx
    jmp     loop1
done:
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import msvcrt,\
           exit,    'exit',\
           printf,  'printf'
