format PE console
entry start

include 'win32a.inc'

ARRAY_SIZE = 5
section '.data' data readable writeable
    arr1     dd ARRAY_SIZE dup (7)
    arr2     dd ARRAY_SIZE dup (?)
    fmt     db '%d ', 0

section '.code' code readable executable
start:
    stdcall print_arr, arr1, ARRAY_SIZE
    stdcall print_arr, arr2, ARRAY_SIZE
    cinvoke exit, 0

proc print_arr uses ebx esi, arr, count
    mov ebx, [arr]
    mov eax, [count]
    lea esi, [ebx + eax * 4]
@@:
    cmp     ebx, esi
    jge     .done
    cinvoke printf, fmt, [ebx]
    add     ebx, 4
    jmp     @b
.done:
    push 10
    cinvoke printf, esp
    add esp, 4
;    push 10
;    push esp
;    call [printf]
;    add esp, 8
    ret
endp

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import msvcrt,\
           exit,    'exit',\
           printf,  'printf'
