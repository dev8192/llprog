format PE
entry start

include 'win32ax.inc'

ARRAY_SIZE = 5

section '.data' data readable writeable
    buf1        db 5 dup('a'), 5 dup('b'), 5 dup('c'), 0
    buf2        dd ARRAY_SIZE dup (7)
    buf3        dd ARRAY_SIZE dup (?)
    buf4        dd ARRAY_SIZE dup (123456789)
    buf5        db 3 dup (1,2,3)
    buf5_len    = $ - buf5
    fmt_d       db '%d', 10, 0
    fmt_s       db '%s', 10, 0

include '../../util/print_array.data.inc'
include '../../util/print_bytes.data.inc'

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

include '../../util/print_array.text.inc'
include '../../util/print_bytes.text.inc'

proc main1
    cinvoke puts, '*** main1 ***'
    cinvoke printf, fmt_s, buf1
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    stdcall print_array32, buf2, ARRAY_SIZE
    stdcall print_array32, buf3, ARRAY_SIZE
    stdcall print_array32, buf4, ARRAY_SIZE
    ret
endp

proc main
    cinvoke puts, '*** main3 ***'
    cinvoke printf, fmt_d, buf5_len
    stdcall print_bytes, buf5, buf5_len
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
