format PE
entry start

include 'win32a.inc'

item_count = 0

macro push_item array, value {
    mov [array + (item_count)*4], value
    item_count = item_count + 1
}

section '.data' data readable writeable
    fmt     db '%d', 10, 0
    arr    dd 0 dup(4)

section '.text' code readable executable
func1:
    cinvoke printf, fmt, item_count
    push_item arr, 100
    push_item arr, 200
    push_item arr, 300
    push_item arr, 400
    cinvoke printf, fmt, item_count
    
    cinvoke printf, fmt, [arr + 0]
    cinvoke printf, fmt, [arr + 4]
    cinvoke printf, fmt, [arr + 8]
    cinvoke printf, fmt, [arr + 12]
    ret

start:
    call func1
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
