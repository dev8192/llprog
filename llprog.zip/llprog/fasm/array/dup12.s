format PE console 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    pattern   db 5 dup (1,2)
    fmt1       db '%p', 10, 0
    fmt2       db '%d ', 0
    done_msg  db 10, 'Done', 0

section '.code' code readable executable
start:
    cinvoke printf, fmt1, pattern
    cinvoke printf, fmt1, fmt1

    xor ebx, ebx
print_loop:
    movzx eax, byte [pattern + ebx]
    cinvoke printf, fmt2, eax

    inc ebx
    cmp ebx, 10
    jl print_loop

    cinvoke printf, done_msg
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
