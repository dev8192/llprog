format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    points:
        dd 100, 100, 1700, 100
        dd 100, 300, 1700, 300
        dd 100, 500, 1700, 500
        dd 100, 700, 1700, 700
        dd 100, 900, 1700, 900
    
    line_count = 5
    line_size  = 16
    
    fmt db '%x', 10, 0

section '.text' code readable executable
func1:
    mov ebx, 0
    mov esi, points
print_loop:
    cinvoke printf, fmt, esi
    add esi, line_size
    inc ebx
    cmp ebx, line_count
    jl print_loop
    ret

func2:
    cinvoke printf, fmt, points + 0
    cinvoke printf, fmt, points + 16
    cinvoke printf, fmt, points + 32
    cinvoke printf, fmt, points + 48
    cinvoke printf, fmt, points + 64
    ret

start:
    call func1
    call func2
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            msvcrt,   'msvcrt.dll'
    import  kernel32,\
            ExitProcess, 'ExitProcess'
    import  msvcrt,\
            printf, 'printf'
