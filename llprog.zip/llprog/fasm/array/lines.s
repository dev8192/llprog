format PE
entry start

include 'win32ax.inc'

struct LINE
    pt1 POINT
    pt2 POINT
ends

section '.data' data readable writeable
    arr1:
        LINE <100, 100>, <1700, 100>
        LINE <100, 300>, <1700, 300>
        LINE <100, 500>, <1700, 500>
        LINE <100, 700>, <1700, 700>
        LINE <100, 900>, <1700, 900>
    arr1_len = ($ - arr1) / sizeof.LINE
    
    fmt_d       db '%d', 10, 0
    fmt_x       db '%x', 10, 0
    fmt_line    db "%d, %d, %d, %d", 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    cinvoke puts, '*** main1 ***'
    cinvoke printf, fmt_d, arr1_len
    cinvoke printf, fmt_d, dword [arr1]
    cinvoke printf, fmt_d, dword [arr1 + sizeof.LINE * 2 + LINE.pt2.y]
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    mov ebx, arr1_len
    mov esi, arr1
.loop:
    cinvoke printf, fmt_line, [esi + LINE.pt1.x], [esi + LINE.pt1.y],\
        [esi + LINE.pt2.x], [esi + LINE.pt2.y]
    add esi, sizeof.LINE
    dec ebx
    jnz .loop
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
