format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    ;msg db 'Hello', 10
    msg db 'Hello'
    msg_len  = $ - msg

section '.text' code readable executable
start:
    invoke  GetStdHandle, STD_OUTPUT_HANDLE
    invoke  WriteConsole, eax, msg, msg_len, 0, 0
    ; TODO: Why esp?
    ;invoke  WriteConsole, eax, msg, msg_len, esp, 0
    invoke  ExitProcess, 0

; TODO: Does it have to be writeable?
section '.idata' import data readable writeable
    library kernel32,       'kernel32.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess',\
            GetStdHandle,   'GetStdHandle',\
            WriteConsole,   'WriteConsoleA'
