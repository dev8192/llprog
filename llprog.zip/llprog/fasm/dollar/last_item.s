format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_x       db '%x', 10, 0
    last_item = $
    hello       db 'hello', 0

section '.text' code readable executable
start:
    stdcall test10
    invoke ExitProcess, 0
    
proc test10
    cinvoke puts, hello
    cinvoke printf, fmt_x, hello

    cinvoke puts, last_item
    cinvoke printf, fmt_x, last_item
    
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
