format PE
entry start

include 'win32ax.inc'

macro chain [instr] { forward instr }

section '.data' data readable writeable
    fmt_d       db '%d', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    cinvoke puts, '*** main1 ***'
    xor eax, eax
    chain inc eax, inc eax, inc eax
    cinvoke printf, fmt_d, eax

    xor eax, eax
    chain <add eax, 2>, <add eax, 2>, <add eax, 2>
    cinvoke printf, fmt_d, eax
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
