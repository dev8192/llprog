format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    msg_yes     db 'yes', 10, 0
    msg_no      db 'no', 10, 0

section '.text' code readable executable
start:
    stdcall test60
    invoke ExitProcess, 0

proc test10
    cinvoke puts, '*** test10 ***'
    stdcall .print_message, 10, 10
    stdcall .print_message, 10, 15
    ret
endp

proc .print_message, num1, num2
    mov eax, [num1]
    cmp eax, [num2]
    je @f
    cinvoke printf, msg_no
    jmp .done
@@:
    cinvoke printf, msg_yes
.done:
    ret
endp

proc test20
    cinvoke puts, '*** test20 ***'
    stdcall .print_message, 10, 10
    stdcall .print_message, 10, 15
    ret
endp
    
proc .print_message, num1, num2
    mov eax, [num1]
    cmp eax, [num2]
    je @f
    mov ecx, msg_no
    jmp .done
@@:
    mov ecx, msg_yes
.done:
    cinvoke printf, ecx
    ret
endp

proc test30
    cinvoke puts, '*** test30 ***'
    stdcall .print_message, 10, 10
    stdcall .print_message, 10, 15
    ret
endp
    
proc .print_message, num1, num2
    mov eax, [num1]
    cmp eax, [num2]
    mov ecx, msg_no
    mov edx, msg_yes
    cmove ecx, edx
    cinvoke printf, ecx
    ret
endp

proc test40
    cinvoke puts, '*** test40 ***'
    stdcall .print_message, 10, 10
    stdcall .print_message, 10, 15
    ret
endp
    
proc .print_message, num1, num2
    local msg_table[2]:DWORD
    mov [msg_table], msg_no
    mov [msg_table + 4], msg_yes
    mov eax, [num1]
    cmp eax, [num2]
    sete al
    movzx eax, al
    mov ecx, [msg_table + eax * 4]
    cinvoke printf, ecx
    ret
endp

proc test50
    cinvoke puts, '*** test50 ***'
    stdcall .print_message, 10, 10
    stdcall .print_message, 10, 15
    ret
endp

proc .print_message, num1, num2
    mov eax, [num1]
    sub eax, [num2]
    neg eax
    sbb eax, eax
    mov ecx, msg_no
    and ecx, eax
    not eax
    mov edx, msg_yes
    and edx, eax
    or  ecx, edx
    cinvoke printf, ecx
    ret
endp

proc test60
    cinvoke puts, '*** test60 ***'
    stdcall .print_message, 10, 10
    stdcall .print_message, 10, 15
    ret
endp

proc .print_message, num1, num2
    mov eax, [num1]
    sub eax, [num2]     ; 0 if equal, non-zero if not
    neg eax             ; Carry Flag (CF) = 1 if non-zero
    sbb eax, eax        ; EAX = 0xFFFFFFFF if not equal, 0 if equal

    ; --- The XOR Selection Trick ---
    mov ecx, msg_yes    ; Load first option
    mov edx, msg_no     ; Load second option
    xor edx, ecx        ; EDX = The "difference" bits between the two addresses
    and eax, edx        ; EAX = "difference" bits if not equal, 0 if equal
    xor ecx, eax        ; If not equal: ECX = yes XOR (yes XOR no) = no
                        ; If equal:     ECX = yes XOR 0 = yes
    cinvoke printf, ecx
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
