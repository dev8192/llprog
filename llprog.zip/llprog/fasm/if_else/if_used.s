format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    addr1       = $
    if used str1
        str1    db 'str1', 0
    end if
    addr2       = $
    if used str2
        str2    db 'str2', 0
    end if
    addr3       = $
    str3        db 'hello', 0
    fmt_d       db '%d', 10, 0
    fmt_x       db '%x', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc print_hello_proc
    cinvoke puts, str3
    ret
endp

proc main1
    cinvoke puts, '*** main1 ***'
    mov eax, 123
if used print_hello_proc
    mov eax, 456
end if
    cinvoke printf, fmt_d, eax
    stdcall print_hello_proc
    ret
endp

macro print_hello_macro {
    cinvoke puts, str3
}

proc main2
    cinvoke puts, '*** main2 ***'
    mov eax, 123
if used print_hello_macro
    mov eax, 456
end if
    cinvoke printf, fmt_d, eax
    print_hello_macro
    ret
endp

proc main
    cinvoke puts, '*** main3 ***'
    cinvoke puts, str1
   ;cinvoke puts, str2
    cinvoke printf, fmt_x, addr1
    cinvoke printf, fmt_x, addr2
    cinvoke printf, fmt_x, addr3
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
