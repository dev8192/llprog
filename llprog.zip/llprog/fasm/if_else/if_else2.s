
macro example [arg] {
    if arg eq
        display 'empty', 10
    else
        display 'not empty', 10
    end if
}

example
example 333
