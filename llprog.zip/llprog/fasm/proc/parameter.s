format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_xx      db '%x %x', 10, 0
    fmt_f       db '%f', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main1
    cinvoke puts, '*** main1 ***'
    stdcall .func, 0x1234, 0x5678
    stdcall .func, 0x12345678, 0x12345678
endp

proc .func, p1:WORD, p2:WORD
    movzx eax, [p1]
    movzx ecx, [p2]
    cinvoke printf, fmt_xx, eax, ecx
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    stdcall .func, 0x12, 0xAA
    stdcall .func, 0x1234, 0xAABB
    stdcall .func, 0x12345678, 0xAABBCCDD
endp

proc .func, p1:BYTE, p2:BYTE
    movzx eax, [p1]
    movzx ecx, [p2]
    cinvoke printf, fmt_xx, eax, ecx
    ret
endp

proc main
    cinvoke puts, '*** main3 ***'
    locals
        num1 dq 11.5
    endl
    stdcall .func, dword [num1], dword [num1 + 4]
    ret
endp

proc .func num:QWORD
    cinvoke printf, fmt_f, dword [num], dword [num + 4]
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
