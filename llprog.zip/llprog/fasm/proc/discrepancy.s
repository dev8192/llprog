format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt_addr        db '%08x', 10, 0
    fmt_addr_val    db '%08x: %x', 10, 0
    num3            dd 0xCC

section '.text' code readable executable
start:
    stdcall test10
    invoke ExitProcess, 0
    
proc test10
    cinvoke printf, fmt_addr, $
    cinvoke printf, fmt_addr, esp
    stdcall .func, 0xAA
    ret
endp
    
proc .func, num1
    local num2:DWORD
    mov [num2], 0xBB
    lea eax, [num1]
    stdcall .print_vars, eax, [num1]
    lea eax, [num2]
    stdcall .print_vars, eax, [num2]
    stdcall .print_vars, num3, [num3]
    ret
endp
    
proc .print_vars, ptr, num
    cinvoke printf, fmt_addr_val, [ptr], [num]
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
