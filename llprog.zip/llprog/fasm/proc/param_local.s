format PE console
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt__                       db '******: %x', 10, 0
    fmt0                        db 'test0: %x', 10, 0
    fmt1                        db 'test1: %x', 10, 0
    fmt2                        db 'test2: %x', 10, 0
    fmt3                        db 'test3: %x', 10, 0
    fmt4                        db 'test4: %x', 10, 0
    msg_parameters              db '*** parameters ***', 10, 0
    msg_locals                  db '*** locals ***', 10, 0
    msg_parameters_and_locals   db '*** parameters + locals ***', 10, 0

section '.text' code readable executable
start:
    ;stdcall test_parameters
    ;stdcall test_locals
    stdcall test_parameters_and_locals
    invoke ExitProcess, 0

;         5c   60   64   68   6c   70   74
; test0                           (sp) (sp)
; test1                 (sp)  ??   p1  (sp)
; test2            (sp)  ??   p1   p2  (sp)
; test3       (sp)  ??   p1   p2   p3  (sp)
; test4  (sp)  ??   p1   p2   p3   p4  (sp)
; test1                 (v1)  ??   ??  (sp)
; test2            (v1)  v2   ??   ??  (sp)
; test3       (v1)  v2   v3   ??   ??  (sp)
; test4  (v1)  v2   v3   v4   ??   ??  (sp)
; pvv         (v1)  v2   ??   ??   p1  (sp)
; ppv         (v1)  ??   ??   p1   p2  (sp)

proc test00
    cinvoke printf, fmt0, esp
    ret
endp

; ------------------------------------------------------------------------------
; Parameters
; ------------------------------------------------------------------------------
proc test_parameters
    cinvoke printf, msg_parameters
    cinvoke printf, fmt__, esp
    stdcall test00
    cinvoke printf, fmt__, esp
    stdcall test11, 5
    cinvoke printf, fmt__, esp
    stdcall test12, 5, 10
    cinvoke printf, fmt__, esp
    stdcall test13, 5, 10, 15
    cinvoke printf, fmt__, esp
    stdcall test14, 5, 10, 15, 20
    cinvoke printf, fmt__, esp
    ret
endp

proc test11 p1
    cinvoke printf, fmt1, addr p1
    cinvoke printf, fmt1, esp
    ret
endp

proc test12 p1, p2
    cinvoke printf, fmt2, addr p1
    cinvoke printf, fmt2, addr p2
    cinvoke printf, fmt2, esp
    ret
endp

proc test13 p1, p2, p3
    cinvoke printf, fmt3, addr p1
    cinvoke printf, fmt3, addr p2
    cinvoke printf, fmt3, addr p3
    cinvoke printf, fmt3, esp
    ret
endp

proc test14 p1, p2, p3, p4
    cinvoke printf, fmt4, addr p1
    cinvoke printf, fmt4, addr p2
    cinvoke printf, fmt4, addr p3
    cinvoke printf, fmt4, addr p4
    cinvoke printf, fmt4, esp
    ret
endp

; ------------------------------------------------------------------------------
; Locals
; ------------------------------------------------------------------------------
proc test_locals
    cinvoke printf, msg_locals
    cinvoke printf, fmt__, esp
    stdcall test00
    cinvoke printf, fmt__, esp
    stdcall test21
    cinvoke printf, fmt__, esp
    stdcall test22
    cinvoke printf, fmt__, esp
    stdcall test23
    cinvoke printf, fmt__, esp
    stdcall test24
    cinvoke printf, fmt__, esp
    ret
endp

proc test21
    local v1:DWORD
    mov [v1], 5
    cinvoke printf, fmt1, addr v1
    cinvoke printf, fmt1, esp
    ret
endp

proc test22
    local v1:DWORD, v2:DWORD
    mov [v1], 5
    mov [v2], 10
    cinvoke printf, fmt2, addr v1
    cinvoke printf, fmt2, addr v2
    cinvoke printf, fmt2, esp
    ret
endp

proc test23
    local v1:DWORD, v2:DWORD, v3:DWORD
    mov [v1], 5
    mov [v2], 10
    mov [v3], 15
    cinvoke printf, fmt3, addr v1
    cinvoke printf, fmt3, addr v2
    cinvoke printf, fmt3, addr v3
    cinvoke printf, fmt3, esp
    ret
endp

proc test24
    local v1:DWORD, v2:DWORD, v3:DWORD, v4:DWORD
    mov [v1], 5
    mov [v2], 10
    mov [v3], 15
    mov [v4], 15
    cinvoke printf, fmt4, addr v1
    cinvoke printf, fmt4, addr v2
    cinvoke printf, fmt4, addr v3
    cinvoke printf, fmt4, addr v4
    cinvoke printf, fmt4, esp
    ret
endp

; ------------------------------------------------------------------------------
; Parameters + Locals
; ------------------------------------------------------------------------------
proc test_parameters_and_locals
    cinvoke printf, msg_parameters_and_locals
    cinvoke printf, fmt__, esp
    stdcall test00
    cinvoke printf, fmt__, esp
    stdcall test31, 5
    cinvoke printf, fmt__, esp
    stdcall test32, 5, 10
    cinvoke printf, fmt__, esp
    ret
endp

proc test31 p1
    local v1:DWORD, v2:DWORD
    mov [v1], 10
    mov [v2], 15
    cinvoke printf, fmt1, addr p1
    cinvoke printf, fmt1, addr v1
    cinvoke printf, fmt1, addr v2
    cinvoke printf, fmt1, esp
    ret
endp

proc test32 p1, p2
    local v1:DWORD
    mov [v1], 15
    cinvoke printf, fmt2, addr p1
    cinvoke printf, fmt2, addr p2
    cinvoke printf, fmt2, addr v1
    cinvoke printf, fmt2, esp
    ret
endp

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            msvcrt, 'msvcrt.dll'
    import  kernel32,\
            ExitProcess, 'ExitProcess'
    import  msvcrt,\
            printf, 'printf'
