; ------------------------------------------------------------------------------
;           |  5c   60   64   68   6c   70   74   ...   84
; test_0    |                          (sp) main       (bp)
; test_p    |                (sp) rtrn  p1  main
; test_pp   |           (sp) rtrn  p1   p2  main
; test_ppp  |      (sp) rtrn  p1   p2   p3  main
; test_pppp | (sp) rtrn  p1   p2   p3   p4  main
; test_v    |                (v1) (bp) rtrn main
; test_vv   |           (v1)  v2  (bp) rtrn main
; test_vvv  |      (v1)  v2   v3  (bp) rtrn main
; test_vvvv | (v1)  v2   v3   v4  (bp) rtrn main
; test_vvp  |      (v1)  v2  (bp) rtrn  p1  main
; test_vpp  |      (v1) (bp) rtrn  p1   p2  main
; ------------------------------------------------------------------------------

format PE console
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    msg_parameters              db '*** parameters ***', 10, 0
    msg_locals                  db '*** locals ***', 10, 0
    msg_parameters_and_locals   db '*** parameters + locals ***', 10, 0
fmt:
    .test_0                     db 'test_0    : %x', 10, 0
    .test_p                     db 'test_p    : %x', 10, 0
    .test_pp                    db 'test_pp   : %x', 10, 0
    .test_ppp                   db 'test_ppp  : %x', 10, 0
    .test_pppp                  db 'test_pppp : %x', 10, 0
    .test_v                     db 'test_v    : %x', 10, 0
    .test_vv                    db 'test_vv   : %x', 10, 0
    .test_vvv                   db 'test_vvv  : %x', 10, 0
    .test_vvvv                  db 'test_vvvv : %x', 10, 0
    .test_vvp                   db 'test_vvp  : %x', 10, 0
    .test_vpp                   db 'test_vpp  : %x', 10, 0
    .done                       db 'done      : %x', 10, 0

    fmt_esp                     db '     sp   : %x', 10, 0
    fmt_ebp                     db '     bp   : %x', 10, 0
    fmt_v1                      db '     v1   : %x', 10, 0
    fmt_v2                      db '     v2   : %x', 10, 0
    fmt_v3                      db '     v3   : %x', 10, 0
    fmt_v4                      db '     v4   : %x', 10, 0
    fmt_p1                      db '     p1   : %x', 10, 0
    fmt_p2                      db '     p2   : %x', 10, 0
    fmt_p3                      db '     p3   : %x', 10, 0
    fmt_p4                      db '     p4   : %x', 10, 0

section '.text' code readable executable
start:
    stdcall test_parameters
    ;stdcall test_locals
    ;stdcall test_parameters_and_locals
    invoke ExitProcess, 0

proc test_0
    cinvoke printf, fmt_esp, esp
    cinvoke printf, fmt_ebp, ebp
    ret
endp

; ------------------------------------------------------------------------------
; Parameters
; ------------------------------------------------------------------------------
proc test_parameters
    cinvoke printf, msg_parameters
    cinvoke printf, fmt.test_0, esp
    stdcall test_0
    cinvoke printf, fmt.test_p, esp
    stdcall test_p, 5
    cinvoke printf, fmt.test_pp, esp
    stdcall test_pp, 5, 10
    cinvoke printf, fmt.test_ppp, esp
    stdcall test_ppp, 5, 10, 15
    cinvoke printf, fmt.test_pppp, esp
    stdcall test_pppp, 5, 10, 15, 20
    cinvoke printf, fmt.done, esp
    ret
endp

proc test_p p1
    cinvoke printf, fmt_esp, esp
    cinvoke printf, fmt_ebp, ebp
    cinvoke printf, fmt_p1, addr p1
    ret
endp

proc test_pp p1, p2
    cinvoke printf, fmt_esp, esp
    cinvoke printf, fmt_ebp, ebp
    cinvoke printf, fmt_p1, addr p1
    cinvoke printf, fmt_p2, addr p2
    ret
endp

proc test_ppp p1, p2, p3
    cinvoke printf, fmt_esp, esp
    cinvoke printf, fmt_ebp, ebp
    cinvoke printf, fmt_p1, addr p1
    cinvoke printf, fmt_p2, addr p2
    cinvoke printf, fmt_p3, addr p3
    ret
endp

proc test_pppp p1, p2, p3, p4
    cinvoke printf, fmt_esp, esp
    cinvoke printf, fmt_ebp, ebp
    cinvoke printf, fmt_p1, addr p1
    cinvoke printf, fmt_p2, addr p2
    cinvoke printf, fmt_p3, addr p3
    cinvoke printf, fmt_p4, addr p4
    ret
endp

; ------------------------------------------------------------------------------
; Locals
; ------------------------------------------------------------------------------
proc test_locals
    cinvoke printf, msg_locals
    cinvoke printf, fmt.test_0, esp
    stdcall test_0
    cinvoke printf, fmt.test_v, esp
    stdcall test_v
    cinvoke printf, fmt.test_vv, esp
    stdcall test_vv
    cinvoke printf, fmt.test_vvv, esp
    stdcall test_vvv
    cinvoke printf, fmt.test_vvvv, esp
    stdcall test_vvvv
    cinvoke printf, fmt.done, esp
    ret
endp

proc test_v
    local v1:DWORD
    mov [v1], 5
    cinvoke printf, fmt_esp, esp
    cinvoke printf, fmt_v1, addr v1
    cinvoke printf, fmt_ebp, ebp
    ret
endp

proc test_vv
    local v1:DWORD, v2:DWORD
    mov [v1], 5
    mov [v2], 10
    cinvoke printf, fmt_esp, esp
    cinvoke printf, fmt_v1, addr v1
    cinvoke printf, fmt_v2, addr v2
    cinvoke printf, fmt_ebp, ebp
    ret
endp

proc test_vvv
    local v1:DWORD, v2:DWORD, v3:DWORD
    mov [v1], 5
    mov [v2], 10
    mov [v3], 15
    cinvoke printf, fmt_esp, esp
    cinvoke printf, fmt_v1, addr v1
    cinvoke printf, fmt_v2, addr v2
    cinvoke printf, fmt_v3, addr v3
    cinvoke printf, fmt_ebp, ebp
    ret
endp

proc test_vvvv
    local v1:DWORD, v2:DWORD, v3:DWORD, v4:DWORD
    mov [v1], 5
    mov [v2], 10
    mov [v3], 15
    mov [v4], 15
    cinvoke printf, fmt_esp, esp
    cinvoke printf, fmt_v1, addr v1
    cinvoke printf, fmt_v2, addr v2
    cinvoke printf, fmt_v3, addr v3
    cinvoke printf, fmt_v4, addr v4
    cinvoke printf, fmt_ebp, ebp
    ret
endp

; ------------------------------------------------------------------------------
; Parameters + Locals
; ------------------------------------------------------------------------------
proc test_parameters_and_locals
    cinvoke printf, msg_parameters_and_locals
    cinvoke printf, fmt.test_0, esp
    stdcall test_0
    cinvoke printf, fmt.test_vvp, esp
    stdcall test_vvp, 5
    cinvoke printf, fmt.test_vpp, esp
    stdcall test_vpp, 5, 10
    cinvoke printf, fmt.done, esp
    ret
endp

proc test_vvp p1
    local v1:DWORD, v2:DWORD
    mov [v1], 10
    mov [v2], 15
    cinvoke printf, fmt_esp, esp
    cinvoke printf, fmt_v1, addr v1
    cinvoke printf, fmt_v2, addr v2
    cinvoke printf, fmt_ebp, ebp
    cinvoke printf, fmt_p1, addr p1
    ret
endp

proc test_vpp p1, p2
    local v1:DWORD
    mov [v1], 15
    cinvoke printf, fmt_esp, esp
    cinvoke printf, fmt_v1, addr v1
    cinvoke printf, fmt_ebp, ebp
    cinvoke printf, fmt_p1, addr p1
    cinvoke printf, fmt_p2, addr p2
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
