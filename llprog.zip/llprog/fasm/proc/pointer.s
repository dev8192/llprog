format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    num1    dd 50
    fmt_x   db '%x', 10, 0
    fmt_d   db '%d', 10, 0

section '.text' code readable executable
start:
    stdcall test30
    invoke ExitProcess, 0

proc test10
    stdcall .print_addr_and_value, num1, [num1]
    ret
endp
    
proc .print_addr_and_value, ptr_param, num
    cinvoke printf, fmt_x, [ptr_param]
    cinvoke printf, fmt_d, [num]
    ret
endp
    
proc test20
    stdcall .print_values, num1, [num1]
    ret
endp
    
proc .print_values, ptr_param, num
    mov eax, [ptr_param]
    cinvoke printf, fmt_x, [eax]
    cinvoke printf, fmt_d, [num]
    ret
endp
    
proc test30
    cinvoke printf, fmt_d, [num1]
    stdcall .inc_num, num1
    cinvoke printf, fmt_d, [num1]
    stdcall .double_num, num1
    cinvoke printf, fmt_d, [num1]
    ret
endp

proc .inc_num, ptr_param
    mov eax, [ptr_param]
    inc dword [eax]
    ret
endp

proc .double_num, ptr_param
    mov eax, [ptr_param]
    shl dword [eax], 1
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
