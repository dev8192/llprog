format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    num1    dd 0x55
    fmt_x   db '%x', 10, 0

section '.text' code readable executable
start:
    stdcall test20
    invoke ExitProcess, 0
    
proc test10
    stdcall .func, num1, [num1]
    ret
endp
    
proc .func, ptr, num
    cinvoke printf, fmt_x, [ptr]
    cinvoke printf, fmt_x, [num]
    ret
endp
    
proc test20
    stdcall .func, num1, [num1]
    ret
endp
    
proc .func, ptr, num
    mov eax, [ptr]
    cinvoke printf, fmt_x, [eax]
    cinvoke printf, fmt_x, [num]
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
