format PE console
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_addr    db '%x', 10, 0

section '.text' code readable executable
proc test1 p1, p2, p3
    cinvoke printf, fmt_addr, addr p1
    cinvoke printf, fmt_addr, addr p2
    cinvoke printf, fmt_addr, addr p3
    ret
endp

start:
    cinvoke printf, fmt_addr, esp
    stdcall test1, 5, 10, 15
    cinvoke printf, fmt_addr, esp
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
        msvcrt, 'msvcrt.dll'

    import kernel32,\
        ExitProcess, 'ExitProcess'

    import msvcrt,\
        printf, 'printf'
