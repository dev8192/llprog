
proc WindowProc hwnd, wmsg, wparam, lparam
    push ebx esi edi
    ; ...
    pop edi esi ebx
    ret
endp

