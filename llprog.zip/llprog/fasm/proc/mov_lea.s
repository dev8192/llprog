format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    str1 db '', 0
    str2 db 'a', 0
    fmt_x db '%x', 10, 0

section '.text' code readable executable
start:
    stdcall test10
    invoke ExitProcess, 0

proc test10
    cinvoke puts, '*** str1 ***'
    stdcall .print_value, str1
    cinvoke puts, '*** str2 ***'
    stdcall .print_value, str2
    ret
endp

proc .print_value, str_ptr
    lea eax, [str_ptr]
    cinvoke printf, fmt_x, eax
    cinvoke printf, fmt_x, [str_ptr]
    mov eax, [str_ptr]
    cinvoke printf, fmt_x, eax
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
