format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt db '%x', 10, 0

; dff78 -4
; dff74 +4
; dff78 -16
; dff68 +16
; dff78
section '.text' code readable executable

proc example1
    cinvoke printf, fmt, esp
    ret
endp

proc example2 uses ebx esi edi
    cinvoke printf, fmt, esp
    ret
endp

start:
    cinvoke printf, fmt, esp
    call example1
    cinvoke printf, fmt, esp
    call example2
    cinvoke printf, fmt, esp
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt,     'msvcrt.dll'
    import  msvcrt,\
            exit,       'exit',\
            printf,     'printf'
