format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    msg1    db 'hello', 0

section '.text' code readable executable
start:
    cinvoke puts, msg1
    stdcall func1
    invoke  ExitProcess, 0

proc func1
    repeat 10000
        nop
    end repeat
    ret
endp

func2:
    repeat 10000
        nop
    end repeat
    ret

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
