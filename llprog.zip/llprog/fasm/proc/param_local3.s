format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_x       db '%x', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    cinvoke puts, '*** main1 ***'
    cinvoke printf, fmt_x, esp
    stdcall func1
    ret
endp

proc func1
    cinvoke printf, fmt_x, esp
    stdcall func2
    ret
endp

proc func2
    cinvoke printf, fmt_x, esp
    stdcall func3
    ret
endp

proc func3
    cinvoke printf, fmt_x, esp
    stdcall func4
    ret
endp

proc func4
    cinvoke printf, fmt_x, esp
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
