format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt_d       db '%d', 10, 0
    fmt_x       db '%x', 10, 0
    num1        dd ?

section '.text' code readable executable
start:
    stdcall test10
    stdcall test30

    invoke ExitProcess, 0
    
proc test10
    stdcall .func
    cinvoke printf, fmt_d, eax
    ret
endp
    
proc .func
    mov eax, 10
    ret
endp
    
proc test20
    mov [num1], 0x55
    stdcall .func, num1
    ret
endp
    
proc .func, num
    cinvoke printf, fmt_x, [num]
    mov eax, [num]
    cinvoke printf, fmt_x, [eax]
    ret
endp
    
proc test30
    stdcall .func, num1
    cinvoke printf, fmt_d, [num1]
    ret
endp
    
proc .func, num
    mov eax, [num]
    mov dword [eax], 30
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
