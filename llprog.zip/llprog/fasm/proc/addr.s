format PE console
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_addr    db '%x', 10, 0

section '.text' code readable executable
start:
    cinvoke printf, fmt_addr, esp
    stdcall test10, 5, 10, 15
    cinvoke printf, fmt_addr, esp
    invoke ExitProcess, 0

proc test10 p1, p2, p3
    cinvoke printf, fmt_addr, addr p1
    cinvoke printf, fmt_addr, addr p2
    cinvoke printf, fmt_addr, addr p3
    ret
endp

proc test20 p1, p2, p3
    lea eax, [p1]
    cinvoke printf, fmt_addr, eax
    lea eax, [p2]
    cinvoke printf, fmt_addr, eax
    lea eax, [p3]
    cinvoke printf, fmt_addr, eax
    ret
endp

; not working
; proc test30 p1, p2, p3
;     cinvoke printf, fmt_addr, p1
;     cinvoke printf, fmt_addr, p2
;     cinvoke printf, fmt_addr, p3
;     ret
; endp

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
        msvcrt, 'msvcrt.dll'

    import kernel32,\
        ExitProcess, 'ExitProcess'

    import msvcrt,\
        printf, 'printf'
