format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    msg_after  db 'EBX=%08X, ESI=%08X, EDI=%08X', 10, 0

section '.text' code readable executable

proc example1
    mov ebx, 0xAAAAAAAA
    mov esi, 0xAAAAAAAA
    mov edi, 0xAAAAAAAA
    ret
endp

proc example2 uses ebx esi edi
    mov ebx, 0xBBBBBBBB
    mov esi, 0xBBBBBBBB
    mov edi, 0xBBBBBBBB
    ret
endp

proc example3
    push ebx esi edi
    mov ebx, 0xCCCCCCCC
    mov esi, 0xCCCCCCCC
    mov edi, 0xCCCCCCCC
    pop edi esi ebx
    ret
endp

example4:
    push ebx esi edi
    mov ebx, 0xDDDDDDDD
    mov esi, 0xDDDDDDDD
    mov edi, 0xDDDDDDDD
    pop edi esi ebx
    ret

start:
    mov ebx, 0x11111111
    mov esi, 0x11111111
    mov edi, 0x11111111
    
    call example1
    cinvoke printf, msg_after, ebx, esi, edi

    mov ebx, 0x22222222
    mov esi, 0x22222222
    mov edi, 0x22222222
    
    call example2
    cinvoke printf, msg_after, ebx, esi, edi

    mov ebx, 0x33333333
    mov esi, 0x33333333
    mov edi, 0x33333333
    
    call example3
    cinvoke printf, msg_after, ebx, esi, edi

    mov ebx, 0x44444444
    mov esi, 0x44444444
    mov edi, 0x44444444
    
    call example4
    cinvoke printf, msg_after, ebx, esi, edi

    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt,     'msvcrt.dll'
    import  msvcrt,\
            exit,       'exit',\
            printf,     'printf'
