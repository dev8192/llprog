format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_x       db '%x', 10, 0

section '.text' code readable executable
start:
    cinvoke printf, fmt_x, esp
    stdcall test10
    stdcall test11, 0
    stdcall test12
    stdcall test13, 0
    cinvoke printf, fmt_x, esp
    invoke ExitProcess, 0

proc test10
    cinvoke printf, fmt_x, esp
    ret
endp

proc test11 p1
    cinvoke printf, fmt_x, esp
    ret
endp

proc test12
    local v1:DWORD
    cinvoke printf, fmt_x, esp
    ret
endp

proc test13 p1
    local v1:DWORD
    cinvoke printf, fmt_x, esp
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
