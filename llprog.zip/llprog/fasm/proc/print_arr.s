format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt_dec db '%d', 10, 0
    fmt_hex db '%x', 10, 0

    fmt_item db '%d ', 0
    newline   db 10, 0
    
    arr1   dd 10, 20, 30, 40, 50
    arr1_len = $ - arr1
    arr1_cnt = ($ - arr1) / 4

    arr2   dd 333, 444, 555
    arr2_len = $ - arr2
    arr2_cnt = ($ - arr2) / 4

    print_array dd print_arr10

section '.text' code readable executable
start:
;    cinvoke printf, fmt_dec, arr1_len
;    cinvoke printf, fmt_hex, arr1
;    cinvoke printf, fmt_item, [arr1]
;    cinvoke printf, fmt_item, [arr1 + 4]
;    cinvoke printf, fmt_item, [arr1 + 8]
;    cinvoke printf, fmt_item, [arr1 + 12]
;    cinvoke printf, newline
;    cinvoke printf, newline
;    stdcall step10, arr1, arr1_len

    invoke print_array, 0, 0

    invoke print_array, arr1, arr1_cnt
    invoke print_array, arr2, arr2_cnt

    invoke ExitProcess, 0

proc step10 uses ebx, arr, arr_len
    cinvoke printf, fmt_dec, [arr_len]
    cinvoke printf, fmt_hex, [arr]
    mov ebx, [arr]
    cinvoke printf, fmt_hex, ebx
    cinvoke printf, fmt_item, [ebx +  0]
    cinvoke printf, fmt_item, [ebx +  4]
    cinvoke printf, fmt_item, [ebx +  8]
    cinvoke printf, fmt_item, [ebx + 12]
    cinvoke printf, newline
    ret
endp

proc print_arr10 uses ebx esi, arr, count
    mov eax, [count]
    test eax, eax
    je .done
    mov ebx, [arr]
    lea esi, [ebx + eax * 4]
@@:
    cmp     ebx, esi
    jge     .print_newline
    cinvoke printf, fmt_item, [ebx]
    add     ebx, 4
    jmp     @b
.print_newline:
    cinvoke printf, newline
.done:
    ret
endp

; will print even if count is 0
proc print_array20 uses ebx esi, arr, count
    mov esi, [arr]
    mov ebx, [count]
    ;cinvoke printf, fmt_dec, ebx
@@:
    cinvoke printf, fmt_item, [esi]
    add esi, 4
    dec ebx
    test ebx, ebx
    jnz @b
    cinvoke printf, newline
    ret
endp

; will print even if count is 0
proc print_array30 uses ebx esi, arr, len
    mov esi, [arr]
    mov ebx, [arr]
    add ebx, [len]
@@:
    cinvoke printf, fmt_item, [esi]
    add esi, 4
    cmp esi, ebx
    jl @b
    cinvoke printf, newline
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
