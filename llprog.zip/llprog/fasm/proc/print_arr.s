format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt_dec db '%d', 10, 0
    fmt_item db '%d ', 0
    fmt_nl   db 10, 0
    
    arr1   dd 10, 20, 30, 40, 50
    arr1_len = $ - arr1
    arr1_cnt = ($ - arr1) / 4

    arr2   dd 333, 444, 555
    arr2_len = $ - arr2
    arr2_cnt = ($ - arr2) / 4

section '.text' code readable executable

; will print NEWLINE even if count is 0
proc print_arr uses ebx esi, arr, count
    mov ebx, [arr]
    mov eax, [count]
    lea esi, [ebx + eax * 4]
@@:
    cmp     ebx, esi
    jge     .done
    cinvoke printf, fmt, [ebx]
    add     ebx, 4
    jmp     @b
.done:
    push 10
    cinvoke printf, esp
    add esp, 4
    ret
endp

; will print even if count is 0
proc print_array1 uses ebx esi, arr, count
    mov esi, [arr]
    mov ebx, [count]
    ;cinvoke printf, fmt_dec, ebx
@@:
    cinvoke printf, fmt_item, [esi]
    add esi, 4
    dec ebx
    test ebx, ebx
    jnz @b
    cinvoke printf, fmt_nl
    ret
endp

; will print even if count is 0
proc print_array2 uses ebx esi, arr, len
    mov esi, [arr]
    mov ebx, [arr]
    add ebx, [len]
@@:
    cinvoke printf, fmt_item, [esi]
    add esi, 4
    cmp esi, ebx
    jl @b
    cinvoke printf, fmt_nl
    ret
endp

start:
    stdcall print_array1, arr1, arr1_cnt
    stdcall print_array1, arr2, arr2_cnt

    stdcall print_array2, arr1, arr1_len
    stdcall print_array2, arr2, arr2_len

    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
