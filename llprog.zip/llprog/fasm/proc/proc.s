format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt1  db '%d, %d', 10, 0
    fmt2  db '%x', 10, 0
    str_test db 'FASM', 0

section '.text' code readable executable
func_stdcall:
    mov eax, [esp+4]
    mov ecx, [esp+8]
    cinvoke printf, fmt1, eax, ecx
    ret 8

func_cdecl:
    mov eax, [esp+4]
    mov ecx, [esp+8]
    cinvoke printf, fmt1, eax, ecx
    ret

start:
    cinvoke printf, fmt2, esp
    stdcall func_stdcall, 1, 2
    ccall func_cdecl, 3, 4
    cinvoke printf, fmt2, esp

    invoke lstrlen, str_test
    cinvoke printf, fmt2, eax

    stdcall [lstrlen], str_test
    cinvoke printf, fmt2, eax

    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
        msvcrt, 'msvcrt.dll'

    import kernel32,\
        ExitProcess, 'ExitProcess',\
        lstrlen, 'lstrlenA'

    import msvcrt,\
        printf, 'printf'
