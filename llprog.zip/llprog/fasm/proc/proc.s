format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt     db '%d', 10, 0

section '.text' code readable executable
start:
    stdcall test10
    invoke ExitProcess, 0
    
proc test_inc, num
    cinvoke printf, fmt, [num]
    inc     [num]
    cinvoke printf, fmt, [num]
    inc     [num]
    cinvoke printf, fmt, [num]
    ret
endp
    
proc test_add, num
    cinvoke printf, fmt, [num]
    add     [num], 10
    cinvoke printf, fmt, [num]
    add     [num], 10
    cinvoke printf, fmt, [num]
    ret
endp
    
proc test_shift, num
    cinvoke printf, fmt, [num]
    shl     [num], 1
    cinvoke printf, fmt, [num]
    shr     [num], 1
    cinvoke printf, fmt, [num]
    ret
endp
    
proc test_div1, num
    cinvoke printf, fmt, [num]
    mov     eax, [num]
    xor     edx, edx
    mov     ecx, 5
    div     ecx
    mov     [num], eax
    cinvoke printf, fmt, [num]
    mov     eax, [num]
    xor     edx, edx
    mov     ecx, 5
    div     ecx
    mov     [num], eax
    cinvoke printf, fmt, [num]
    ret
endp

proc test_div, num
    cinvoke printf, fmt, [num]
    mov     eax, [num]
    mov     cl, 5
    div     cl
    movzx   eax, al
    mov     [num], eax
    cinvoke printf, fmt, [num]
    mov     eax, [num]
    mov     cl, 5
    div     cl
    movzx   eax, al
    mov     [num], eax
    cinvoke printf, fmt, [num]
    ret
endp

proc test10
    stdcall test_div, 100
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
