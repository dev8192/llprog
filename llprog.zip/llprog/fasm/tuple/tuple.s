format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_tuple   db "('%s', %d)", 10, 0

include 'data4.inc'

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main uses ebx
    cinvoke puts, '*** main1 ***'
    xor ebx, ebx
.loop:
    lea eax, [catalog + ebx * 8]
    cinvoke printf, fmt_tuple, dword [eax], dword [eax + 4]
    inc ebx
    cmp ebx, catalog_len
    jl .loop
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
