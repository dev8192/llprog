format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    sized1      db 111
    sized2      dw 222
    sized3      dd 333
    unsized1:   db 111
    unsized2:   dw 222
    unsized3:   dd 333
    fmt_x       db '%x', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    cinvoke puts, '*** main1 ***'
    mov al, [sized1]
    mov ax, [sized2]
    mov eax, [sized3]

    mov al, [unsized1]
    mov al, [unsized2]
    mov al, [unsized3]

    mov ax, [unsized1]
    mov ax, [unsized2]
    mov ax, [unsized3]

    mov eax, [unsized1]
    mov eax, [unsized2]
    mov eax, [unsized3]
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
