format PE console
entry start
include 'win32a.inc'

section '.data' data readable writeable

    szFmt  db 'Count: %d', 13, 10, 0
    szSkip db 'This will be skipped.', 13, 10, 0
    szDone db 'Done.', 13, 10, 0

section '.code' code readable executable
    start:
        mov ecx, 3
    @@:
        push ecx
        cinvoke printf, szFmt, ecx
        pop ecx
        dec ecx
        jnz @b

        jmp @f
        cinvoke printf, szSkip
    @@:
        cinvoke printf, szDone
        invoke ExitProcess, 0

section '.idata' import data readable

    library kernel32, 'kernel32.dll',\
            msvcrt,   'msvcrt.dll'

    import kernel32,\
           ExitProcess, 'ExitProcess'

    import msvcrt,\
           printf, 'printf'
