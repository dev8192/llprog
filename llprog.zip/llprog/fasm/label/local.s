format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt db '%s', 10, 0

global1:
.str1 db 'one', 0
.str2 db 'two', 0
.str3 db 'three', 0

global2:
.str1 db 'One', 0
.str2 db 'Two', 0
.str3 db 'Three', 0

section '.text' code readable executable
start:
    stdcall test20
    cinvoke exit, 0

proc test10
    cinvoke printf, fmt, global1.str1
    cinvoke printf, fmt, global1.str2
    cinvoke printf, fmt, global1.str3

    cinvoke printf, fmt, global2.str1
    cinvoke printf, fmt, global2.str2
    cinvoke printf, fmt, global2.str3

    ret
endp

test20a:
    cinvoke printf, fmt, .local_str
    cinvoke printf, fmt, test20b.local_str
    ret
.local_str db 'test20a', 0

test20b:
    cinvoke printf, fmt, .local_str
    cinvoke printf, fmt, test20a.local_str
    ret
.local_str db 'test20b', 0

proc test20
    call test20a
    call test20b
    ret
endp

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
