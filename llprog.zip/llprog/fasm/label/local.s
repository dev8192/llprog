format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt db '%s', 10, 0

global1:
.str1 db 'one', 0
.str2 db 'two', 0
.str3 db 'three', 0

global2:
.str1 db 'One', 0
.str2 db 'Two', 0
.str3 db 'Three', 0

section '.text' code readable executable

routine_a:
    cinvoke printf, fmt, .local_str
    ret
.local_str db 'routine_a', 0

routine_b:
    cinvoke printf, fmt, .local_str
    ret
.local_str db 'routine_b', 0

start:
    cinvoke printf, fmt, global1.str1
    cinvoke printf, fmt, global1.str2
    cinvoke printf, fmt, global1.str3

    cinvoke printf, fmt, global2.str1
    cinvoke printf, fmt, global2.str2
    cinvoke printf, fmt, global2.str3

    call routine_a
    call routine_b

    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
