format PE
entry start

include 'win32a.inc'

;how do i get access to .str1 inside the .text section?

section '.data' data readable writeable
    .str1 db 'hello', 10, 0

section '.text' code readable executable
start:
    cinvoke printf, .str1
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
