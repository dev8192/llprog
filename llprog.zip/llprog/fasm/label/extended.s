format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    num1        dd 111
    num2:       dd 222
    num3        dd 333
    num4:       dd 444
    fmt_d       db '%d', 10, 0
    fmt_x       db '%x', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

; -----------------------
; include 'win32a.inc'
; -----------------------
proc main1
   ;cinvoke puts, '*** main1 ***'
    cinvoke printf, fmt_d, [num1]
    cinvoke printf, fmt_d, [num2]
    ret
endp

; -----------------------
; include 'win32ax.inc'
; -----------------------
proc main2
   ;cinvoke puts, '*** main2 ***'
    cinvoke printf, fmt_d, [num3]
    cinvoke printf, fmt_d, dword [num4]
    ret
endp

proc main
   ;cinvoke puts, '*** main3 ***'
    push dword [num2]
    push fmt_d
    call [printf]
    add esp, 8
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
