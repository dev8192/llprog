format PE CONSOLE 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt db '%s', 10, 0

global_one:
.local_str db 'Resolved explicitly as global_one.local_str', 0

global_two:
.local_str db 'Resolved explicitly as global_two.local_str', 0

section '.text' code readable executable
start:
    cinvoke printf, fmt, global_one.local_str
    cinvoke printf, fmt, global_two.local_str

    call routine_a
    call routine_b

    invoke ExitProcess, 0

routine_a:
    cinvoke printf, fmt, .local_str
    ret
.local_str db 'Accessed implicitly inside routine_a using .local_str', 0

routine_b:
    cinvoke printf, fmt, .local_str
    ret
.local_str db 'Accessed implicitly inside routine_b using .local_str', 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll', \
            msvcrt, 'msvcrt.dll'

    import kernel32, ExitProcess, 'ExitProcess'
    import msvcrt, printf, 'printf'
