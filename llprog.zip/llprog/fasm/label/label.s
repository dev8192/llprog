format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    str1        db 'abcdefghijklmnopqrstuvwxyz', 10, 0
    fmt_x       db '%x', 10, 0
    fmt_c       db '%c', 10, 0

section '.text' code readable executable
start:
    stdcall test20
    invoke ExitProcess, 0

proc test10
    cinvoke printf, str1
    cinvoke printf, fmt_x, str1
    cinvoke printf, 0x401000
    ret
endp

proc test20
    cinvoke printf, str1 + 23
    cinvoke printf, 0x401000 + 23
    ret
endp

section '.idata' import data readable
library kernel32,       'kernel32.dll',\
        msvcrt,         'msvcrt.dll'
import  kernel32,\
        ExitProcess,    'ExitProcess'
import  msvcrt,\
        printf,         'printf'
