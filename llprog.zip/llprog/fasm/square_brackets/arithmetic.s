format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt     db '%llx', 10, 0
    hex_val dq ?

section '.text' code readable executable
start:
    mov byte [hex_val], 0x44
    mov byte [hex_val+1], 0x33
    mov byte [hex_val+2], 0x22
    mov byte [hex_val+3], 0x11
    mov byte [hex_val+4], 0xDD
    mov byte [hex_val+5], 0xCC
    mov byte [hex_val+6], 0xBB
    mov byte [hex_val+7], 0xAA

    ; correct (from aa to 44)
    cinvoke printf, fmt, dword [hex_val], dword [hex_val+4] ; aabbccdd11223344
    cinvoke printf, fmt, dword [hex_val+4], dword [hex_val] ; 11223344aabbccdd

    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'

    import msvcrt,\
        exit, 'exit',\
        printf, 'printf'
