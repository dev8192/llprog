format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    num1      dd 0xABCD
    num2      dd 0x1234
    fmt       db '%x', 10, 0

section '.text' code readable executable
start:
    cinvoke printf, fmt, [num1]
    cinvoke printf, fmt, [num2]
    cinvoke printf, fmt, num1
    cinvoke printf, fmt, num2
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt,'msvcrt.dll'
    import msvcrt,\
        printf,'printf',\
        exit,'exit'
