format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    buf     rb 8
    fmt     db '%x', 10, 0

section '.text' code readable executable
start:
    cinvoke memset, buf, 0xAB, 8
    stdcall test10
    invoke ExitProcess, 0
    
proc test10
    xor eax, eax
    mov eax, dword [buf]
    cinvoke printf, fmt, eax
    xor eax, eax
    mov ax, word [buf]
    cinvoke printf, fmt, eax
    xor eax, eax
    mov al, [buf]
    cinvoke printf, fmt, eax
    xor eax, eax
    mov ah, [buf]
    cinvoke printf, fmt, eax
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            memset,         'memset'
