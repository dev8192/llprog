; equ vs '='

format PE console
entry start

include 'win32a.inc'

;LF = 10
LF equ 10

section '.data' data readable
    msg db 'hello', LF, 0

;LF = 10
;LF equ 10

section '.text' code executable
start:
    cinvoke printf, msg
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll', \
            msvcrt,   'msvcrt.dll'
    import kernel32, ExitProcess, 'ExitProcess'
    import msvcrt,   printf, 'printf'
