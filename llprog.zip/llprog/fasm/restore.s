
macro main {
    define level '*'
    display level, 10

    define level '**'
    display level, 10

    define level '***'
    display level, 10
    
    restore level
    display level, 10
    
    restore level
    display level, 10
}

main
