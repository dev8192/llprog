format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    arr0:
    s1          db 'banana', 0
    s2          db 'apple', 0
    s3          db 'cherry', 0
    s4          db 'date', 0
    arr0_len    = $ - arr0
    fmt_s       db '%s', 10, 0
    fmt_str     db '%s ', 0
    fmt_nl      db 10, 0
    fmt_d       db '%d', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

; banana0apple0cherry0date0
proc main uses esi
    cinvoke puts, '*** main1 ***'
    cinvoke printf, fmt_s, arr0
    cinvoke printf, fmt_s, arr0 + 7
    cinvoke printf, fmt_s, arr0 + 13
    cinvoke printf, fmt_s, arr0 + 20
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
