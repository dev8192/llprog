format PE
entry start

include 'win32ax.inc'

macro string_array1 name, [str] {
    common
        name:
    forward
        dd .s#%
    common
        name#_COUNT = ($ - name) / 4
    forward
        .s#% db str, 0
}

macro string_array name, [str] {
    common
        local offset, strings_base
        name:
        offset = 0
    forward
        dd strings_base + offset
        virtual at 0
            db str, 0
            offset = offset + $
        end virtual
    common
        name#_COUNT = ($ - name) / 4
        strings_base:
    forward
        db str, 0
}

section '.data' data readable writeable
    string_array strs_arr, 'banana', 'apple', 'cherry', 'date'
    fmt_s   db '%s', 10, 0
    fmt_d   db '%d', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    cinvoke puts, '*** main1 ***'
    cinvoke printf, fmt_s, dword [strs_arr + 0]
    cinvoke printf, fmt_s, dword [strs_arr + 4]
    cinvoke printf, fmt_s, dword [strs_arr + 8]
    cinvoke printf, fmt_s, dword [strs_arr + 12]
    cinvoke printf, fmt_d, strs_arr_COUNT
    cinvoke printf, fmt_d, offset
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
