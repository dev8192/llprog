format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_res     db 'Pointer offset: arr0 + %d, Length: %d', 10, 0
    
    arr0:
    s1          db 'banana', 0
    s2          db 'apple', 0  
    s3          db 'cherry', 0 
    s4          db 'date', 0   
    arr0_len    = $ - arr0

    current_arr     dd 0
    current_len     dd 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    cinvoke puts, '*** main1 ***'
    local cur_arr:DWORD, cur_len:DWORD
    mov [cur_arr], arr0
    mov [cur_len], arr0_len
    stdcall slice, addr cur_arr, addr cur_len, 0, 4
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    mov     [current_arr], arr0
    mov     [current_len], arr0_len
    stdcall slice, current_arr, current_len, 0, 4
    mov     eax, [current_arr]
    sub     eax, arr0
    cinvoke printf, fmt_res, eax, [current_len]

    mov     [current_arr], arr0
    mov     [current_len], arr0_len
    stdcall slice, current_arr, current_len, 0, 0
    mov     eax, [current_arr]
    sub     eax, arr0
    cinvoke printf, fmt_res, eax, [current_len]

    mov     [current_arr], arr0
    mov     [current_len], arr0_len
    stdcall slice, current_arr, current_len, 1, 2
    mov     eax, [current_arr]
    sub     eax, arr0
    cinvoke printf, fmt_res, eax, [current_len]

    mov     [current_arr], arr0
    mov     [current_len], arr0_len
    stdcall slice, current_arr, current_len, 3, 4
    mov     eax, [current_arr]
    sub     eax, arr0
    cinvoke printf, fmt_res, eax, [current_len]
    ret
endp

proc slice uses ebx edi esi, pArr, pArr_len, start_idx, end_idx
    mov     ecx, [pArr]
    mov     esi, [ecx]
    xor     edx, edx
    mov     ebx, esi
    xor     edi, edi
.loop_find:
    cmp     edx, [start_idx]
    jne     .check_end
    mov     ebx, esi
.check_end:
    cmp     edx, [end_idx]
    jne     .scan_null
    mov     edi, esi
    jmp     .done_scan
.scan_null:
    cmp     byte [esi], 0
    je      .next_string
    inc     esi
    jmp     .scan_null
.next_string:
    inc     esi
    inc     edx
    jmp     .loop_find
.done_scan:
    cmp     edx, [start_idx]
    jne     .calculate_length
    mov     ebx, esi
.calculate_length:
    sub     edi, ebx
    mov     ecx, [pArr]
    mov     [ecx], ebx
    mov     ecx, [pArr_len]
    mov     [ecx], edi
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
