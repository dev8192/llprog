format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    strs_arr    dd .s1, .s2, .s3, .s4
    STR_COUNT   = ($ - strs_arr) / 4
    .s1         db 'banana', 0
    .s2         db 'apple', 0
    .s3         db 'cherry', 0
    .s4         db 'date', 0
    fmt_str     db '%s ', 0
    fmt_nl      db 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main1
    cinvoke puts, '*** main1 ***'
    stdcall .print_strings, strs_arr
    ret
endp

proc .print_strings uses esi, arr
    mov esi, [arr]
    cinvoke printf, fmt_str, dword [esi]
    add esi, 4
    cinvoke printf, fmt_str, dword [esi]
    add esi, 4
    cinvoke printf, fmt_str, dword [esi]
    add esi, 4
    cinvoke printf, fmt_str, dword [esi]
    cinvoke printf, fmt_nl
    ret
endp

proc main
    cinvoke puts, '*** main2 ***'
    stdcall .print_strings, strs_arr, STR_COUNT
    stdcall .print_strings, strs_arr, 0
    ret
endp

proc .print_strings1 uses ebx esi, arr, str_cnt
    mov esi, [arr]
    mov ebx, 0
.loop:
    cmp ebx, [str_cnt]
    jae .done
    cinvoke printf, fmt_str, dword [esi]
    add esi, 4
    inc ebx
    jmp .loop
.done:
    cinvoke printf, fmt_nl
    ret
endp

proc .print_strings uses esi edi, arr, str_cnt
    mov esi, [arr]
    mov edi, [str_cnt]
    shl edi, 2
    add edi, esi
    cmp esi, edi
    jae .done
.loop:
    lodsd
    cinvoke printf, fmt_str, eax
    cmp esi, edi
    jb .loop
    cinvoke printf, fmt_nl
.done:
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
