format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    arr0:
    s1          db 'banana', 0
    s2          db 'apple', 0
    s3          db 'cherry', 0
    s4          db 'date', 0
    arr0_len    = $ - arr0
    arr1        dd s1, s2, s3, s4
    arr1_len    = ($ - arr1) / 4
    arr2        dd s1, s2, s3, s4, 0
    arr3        dd 0
    fmt_str     db '%s ', 0
    fmt_nl      db 10, 0
    fmt_d       db '%d', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main1 uses esi
    cinvoke puts, '*** main1 ***'
    mov esi, arr1
    cinvoke printf, fmt_str, dword [esi]
    add esi, 4
    cinvoke printf, fmt_str, dword [esi]
    add esi, 4
    cinvoke printf, fmt_str, dword [esi]
    add esi, 4
    cinvoke printf, fmt_str, dword [esi]
    cinvoke printf, fmt_nl
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    stdcall .print_strings, arr1, arr1_len
    stdcall .print_strings, arr1, 0
    stdcall .print_strings, arr1, 2
    ret
endp

proc .print_strings uses ebx esi, arr, str_cnt
    mov ebx, [str_cnt]
    test ebx, ebx
    jz .exit
    mov esi, [arr]
.loop:
    cinvoke printf, fmt_str, dword [esi]
    add esi, 4
    dec ebx
    jnz .loop
    cinvoke printf, fmt_nl
.exit:
    ret
endp

proc .print_strings2 uses esi edi, arr, str_cnt
    mov esi, [arr]
    mov edi, [str_cnt]
    shl edi, 2
    add edi, esi
    cmp esi, edi
    jae .done
.loop:
    lodsd
    cinvoke printf, fmt_str, eax
    cmp esi, edi
    jb .loop
    cinvoke printf, fmt_nl
.done:
    ret
endp

proc main3
    cinvoke puts, '*** main3 ***'
    stdcall .print_strings, arr2
    stdcall .print_strings, arr3
    mov [arr2 + 4 * 2], 0
    stdcall .print_strings, arr2
    ret
endp

proc .print_strings uses ebx esi, arr
    mov esi, [arr]
    mov ebx, [esi]
    test ebx, ebx
    jz .exit
.loop:
    cinvoke printf, fmt_str, ebx
    add esi, 4
    mov ebx, [esi]
    test ebx, ebx
    jnz .loop
    cinvoke printf, fmt_nl
.exit:
    ret
endp

proc main
    cinvoke puts, '*** main4 ***'
    stdcall .print_strings, arr0, arr0_len
    stdcall .print_strings, arr0, 0
    ret
endp

proc .print_strings uses esi edi, arr, arr_len
    mov eax, [arr_len]
    test eax, eax
    jz .done
    mov esi, [arr]
    mov edi, esi
    add edi, eax
.loop:
    cinvoke printf, fmt_str, esi
.next:
    lodsb
    test al, al
    jnz .next
    cmp esi, edi
    jb .loop
.print_nl:
    cinvoke printf, fmt_nl
.done:
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
