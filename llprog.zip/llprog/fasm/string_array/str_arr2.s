format PE console
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    str_arr1        db 'one', 0
                    db 'two', 0
                    db 'three', 0
                    db 0
    str_arr2        db 0
                    db 'one', 0
                    db 'two', 0
                    db 'three', 0
                    db 0
    str_arr3        db 'one', 0
                    db 'two', 0
                    db 0
                    db 0
                    db 'five', 0
                    db 0
    str_arr3_len    = $ - str_arr3
    str_arr4        db 'one', 0
                    db 'two', 0
                    db '', 0
                    db '', 0
                    db 'five', 0
                    db 0
    str_arr4_len    = $ - str_arr4
    fmt_s           db '%s', 10, 0
    fmt_d           db '%d', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main1
    cinvoke puts, '*** main1 ***'
    stdcall print_strings, str_arr1
    ret
endp

proc print_strings, str_arr
    mov esi, [str_arr]
.loop:
    cmp byte [esi], 0
    je .done
    cinvoke printf, fmt_s, esi
.next:
    lodsb
    test al, al
    jnz .next
    jmp .loop
.done:
    ret
endp

proc main
    cinvoke puts, '*** main2 ***'
    cinvoke printf, fmt_d, str_arr3_len
    cinvoke printf, fmt_d, str_arr4_len
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
