; not working
format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    num     dq 0x1122334455667788
    fmt     db '%08x', 10, 0

section '.text' code readable executable
example1:       ; 8877665544332211
    movzx       eax, byte [num]
    cinvoke     printf, fmt, eax
    movzx       eax, byte [num + 1]
    cinvoke     printf, fmt, eax
    movzx       eax, byte [num + 2]
    cinvoke     printf, fmt, eax
    movzx       eax, byte [num + 3]
    cinvoke     printf, fmt, eax
    movzx       eax, byte [num + 4]
    cinvoke     printf, fmt, eax
    movzx       eax, byte [num + 5]
    cinvoke     printf, fmt, eax
    movzx       eax, byte [num + 6]
    cinvoke     printf, fmt, eax
    movzx       eax, byte [num + 7]
    cinvoke     printf, fmt, eax
    ret

example2:       ; 8877665544332211
    movzx       eax, word [num]
    cinvoke     printf, fmt, eax
    movzx       eax, word [num + 1]
    cinvoke     printf, fmt, eax
    movzx       eax, word [num + 2]
    cinvoke     printf, fmt, eax
    movzx       eax, word [num + 3]
    cinvoke     printf, fmt, eax
    movzx       eax, word [num + 4]
    cinvoke     printf, fmt, eax
    movzx       eax, word [num + 5]
    cinvoke     printf, fmt, eax
    movzx       eax, word [num + 6]
    cinvoke     printf, fmt, eax
    ret

example3:       ; 8877665544332211
    mov         eax, dword [num]
    cinvoke     printf, fmt, eax
    mov         eax, dword [num + 1]
    cinvoke     printf, fmt, eax
    mov         eax, dword [num + 2]
    cinvoke     printf, fmt, eax
    mov         eax, dword [num + 3]
    cinvoke     printf, fmt, eax
    mov         eax, dword [num + 4]
    cinvoke     printf, fmt, eax
    ret

start:
    ;call example1
    call example2
    ;call example3
    
    cinvoke     exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
