format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt_esp0            db '---------- %x (0)', 10, 0
    fmt_esp1            db '---------- %x (1)', 10, 0
    fmt_esp2            db '---------- %x (2)', 10, 0
    fmt_esp3            db '---------- %x (3)', 10, 0
    fmt_esp4            db '---------- %x (4)', 10, 0
    fmt_esp5            db '---------- %x (5)', 10, 0
    fmt_esp6            db '---------- %x (6)', 10, 0
    fmt_esp7            db '---------- %x (7)', 10, 0
    fmt_esp8            db '---------- %x (8)', 10, 0

    hello               db 'hello', 10, 0
    fmt_rand            db 'rand: %d', 10, 0
    fmt_num             db '%d', 10, 0
    fmt_handle          db 'handle: %d', 10, 0
    fmt_process         db 'process: %d', 10, 0

section '.text' code readable executable
start:
    stdcall test10
    invoke ExitProcess, 0

;include '_param.inc'
include '_no_param.inc'

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            msvcrt,             'msvcrt.dll'
    import  kernel32,\
            GetStdHandle,       'GetStdHandle',\
            GetCurrentProcess,  'GetCurrentProcess',\
            ExitProcess,        'ExitProcess'
    import  msvcrt,\
            rand,               'rand',\
            printf,             'printf'
