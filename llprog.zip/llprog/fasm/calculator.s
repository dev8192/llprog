format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt db '%d', 10, 0

section '.text' code readable executable
func1:
    cinvoke printf, fmt, 5 * 5
    cinvoke printf, fmt, 5 / 2
    cinvoke printf, fmt, 5 / 3
    ret

start:
    call func1
    cinvoke  exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            printf, 'printf',\
            exit,   'exit'
