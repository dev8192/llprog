; not working

format PE64 GUI 5.0
entry start

include 'win64a.inc'
include 'myutils.inc'

section '.text' code readable executable
start:
    show "Hello from custom include!"

    ;mov     rcx, 5
    ;mov     rdx, 7
    ;invoke  add_numbers, rcx, rdx

    ;invoke wsprintfA, buffer, fmt, eax
    ;invoke MessageBoxA, 0, buffer, MY_TITLE, MB_OK

    invoke ExitProcess, 0

section '.data' data readable writeable
    buffer rb 64
    fmt db "Result = %u",0

section '.idata' import data readable writeable
    library kernel32,'kernel32.dll',\
            user32,'user32.dll'

    import kernel32,\
           ExitProcess,'ExitProcess',\
           wsprintfA,'wsprintfA'

    import user32,\
           MessageBoxA,'MessageBoxA'
