format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
include 'data1.inc'
include 'data2.inc'

section '.text' code readable executable
start:
    cinvoke puts, msg1
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            puts,           'puts'
