format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    buffer rb 64
    fmt db "Result = %u",0

include 'utils.data.inc'

section '.text' code readable executable

include 'utils.text.inc'

start:
    show "Hello from custom include!"
    mov     ecx, 5
    mov     edx, 7
    stdcall add_numbers, ecx, edx
    invoke wsprintf, buffer, fmt, eax
    invoke MessageBox, 0, buffer, MY_TITLE, MB_OK
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            user32,         'user32.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  user32,\
            wsprintf,       'wsprintfA',\
            MessageBox,     'MessageBoxA'
