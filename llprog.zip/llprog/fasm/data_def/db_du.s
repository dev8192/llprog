format PE console
entry start

include 'win32a.inc'

; 1000: 61 62 63
; 1003: 78 00 79 00 7A 00
; 1009: ...
section '.data' data readable writeable
    str1    db "abc"
    str2    du "xyz"
    fmt     db "str1: 0x%08X", 10
            db "str2: 0x%08X", 10
            db "fmt: 0x%08X", 10, 0

section '.code' code readable executable
start:
    cinvoke printf, fmt, str1, str2, fmt
    invoke  ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            msvcrt, 'msvcrt.dll'

    import  kernel32,\
            ExitProcess, 'ExitProcess'

    import  msvcrt,\
            printf, 'printf'
