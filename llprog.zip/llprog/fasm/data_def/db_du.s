format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    str1     db 'abc'
    str1_len = $ - str1

    str2     du 'abc'
    str2_len = $ - str2
    
    str3     db 'abc', 0
    str3_len = $ - str3
    
    str4     du 'abc', 0
    str4_len = $ - str4
    
    fmt1     db "%d", 10, 0
    fmt2     db "%08X", 10, 0

section '.text' code readable executable
func1:
    cinvoke printf, fmt1, str1_len ; 3
    cinvoke printf, fmt1, str2_len ; 6
    cinvoke printf, fmt1, str3_len ; 4
    cinvoke printf, fmt1, str4_len ; 8
    ret

func2:
    cinvoke printf, fmt2, str1 ; 00401000
    cinvoke printf, fmt2, str2 ; 00401003
    cinvoke printf, fmt2, str3 ; 00401009
    cinvoke printf, fmt2, str4 ; 0040100D
    cinvoke printf, fmt2, fmt1 ; 00401015
    ret

start:
    call func2
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
