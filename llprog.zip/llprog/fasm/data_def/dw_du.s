format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt_hex     db '%x', 10, 0
    fmt_dec     db '%d', 10, 0
    val1    dw 'ab', 'cd'
    val1_sz = $ - val1
    val2    du 'abcd'
    val2_sz = $ - val2

section '.text' code readable executable
func1:
    cinvoke printf, fmt_dec, val1_sz
    cinvoke printf, fmt_dec, val2_sz
    ret

func2:
    movzx   eax, byte [val1 + 0]
    cinvoke printf, fmt_hex, eax
    movzx   eax, byte [val1 + 1]
    cinvoke printf, fmt_hex, eax
    movzx   eax, byte [val1 + 2]
    cinvoke printf, fmt_hex, eax
    movzx   eax, byte [val1 + 3]
    cinvoke printf, fmt_hex, eax
    ret

start:
    stdcall func2, val1, val1_sz
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
