format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt     db "%x", 10, 0

section '.text' code readable executable
start:
    .rect1 RECT
    .rect2 RECT
    .rect3 RECT
    cinvoke printf, fmt, .rect1
    cinvoke printf, fmt, .rect2
    cinvoke printf, fmt, .rect3

    mov [.btnRect.left]
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
