format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt1     db "%x", 10, 0
    rect_fmt     db "%x %x %x %x", 10, 0

section '.text' code readable executable
func1:
    .rect1 RECT
    .rect2 RECT
    .rect3 RECT
    cinvoke printf, fmt1, .rect1    ; 402000
    cinvoke printf, fmt1, .rect2    ; 402010
    cinvoke printf, fmt1, .rect3    ; 402020
    ret

func2:
    .rect1 RECT
    cinvoke printf, rect_fmt, [.rect1.left], [.rect1.top], [.rect1.right], [.rect1.bottom]
    mov [.rect1.left], 0x12
    mov [.rect1.top], 0x34
    mov [.rect1.right], 0x56
    mov [.rect1.bottom], 0x78
    cinvoke printf, rect_fmt, [.rect1.left], [.rect1.top], [.rect1.right], [.rect1.bottom]
    ret

start:
    call func2
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
