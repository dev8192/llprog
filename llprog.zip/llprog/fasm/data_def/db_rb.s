format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt db 'value: %d, size: %d', 10, 0
    var1 db 16
    var1_sz = $ - var1

;section '.bss' data readable writeable
    var2 rb 16
    var2_sz = $ - var2

section '.text' code readable executable
start:
    stdcall test10
    invoke ExitProcess, 0

proc test10
    movzx eax, byte [var1]
    cinvoke printf, fmt, eax, var1_sz
    movzx eax, byte [var2]
    cinvoke printf, fmt, eax, var2_sz
    ret
endp

section '.idata' import data readable
    library kernel32, 'kernel32.dll', \
            msvcrt, 'msvcrt.dll'

    import kernel32, \
           ExitProcess, 'ExitProcess'

    import msvcrt, \
           printf, 'printf'
