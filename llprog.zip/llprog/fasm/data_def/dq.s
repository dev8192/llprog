format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    num11       dq -1
    num12       dq 18446744073709551615
    num13       dq 0xFFFFFFFFFFFFFFFF
    fmt_llu     db '%llu', 10, 0

    num21       dq 0x11223344_55667788
    num22_hi    dd 0x11223344
    num22_lo    dd 0x55667788
    fmt_xx      db '%x %x', 10, 0

include '../../util/print_bytes.data.inc'

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

include '../../util/print_bytes.text.inc'

proc main1
    cinvoke puts, '*** main1 ***'
    cinvoke printf, fmt_llu, dword [num11], dword [num11 + 4]
    cinvoke printf, fmt_llu, dword [num12], dword [num12 + 4]
    cinvoke printf, fmt_llu, dword [num13], dword [num13 + 4]
    ret
endp

; 0x11223344_55667788 == 1234605616436508552 ?
proc main
    cinvoke puts, '*** main11 ***'
    stdcall print_bytes, num21, 8
    stdcall print_bytes, num22_hi, 8

    cinvoke printf, fmt_llu, dword [num21], dword [num21 + 4]
    cinvoke printf, fmt_llu, [num22_lo], [num22_hi]

    cinvoke printf, fmt_xx, dword [num21 + 4], dword [num21]
    cinvoke printf, fmt_xx, [num22_hi], [num22_lo]
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    local num2:QWORD
    mov dword [num2 + 4], 0x11223344
    mov dword [num2], 0x55667788
    stdcall .print, num21
    stdcall .print, addr num2
    ret
endp

proc .print, num
    mov eax, [num]
    cinvoke printf, fmt_xx, dword [eax + 4], dword [eax]
    ret
endp

proc main3
    cinvoke puts, '*** main3 ***'
    local n_00000001_00000001:QWORD
    local n_00000005_00000001:QWORD
    local n_00000001_00000005:QWORD

    mov dword [n_00000001_00000001 + 4], 0x00000001
    mov dword [n_00000001_00000001], 0x00000001

    mov dword [n_00000005_00000001 + 4], 0x00000005
    mov dword [n_00000005_00000001], 0x00000001

    mov dword [n_00000001_00000005 + 4], 0x00000001
    mov dword [n_00000001_00000005], 0x00000005
    
    stdcall .compare, addr n_00000001_00000001, addr n_00000001_00000001

    stdcall .compare, addr n_00000001_00000001, addr n_00000005_00000001
    stdcall .compare, addr n_00000005_00000001, addr n_00000001_00000001
    
    stdcall .compare, addr n_00000001_00000001, addr n_00000001_00000005
    stdcall .compare, addr n_00000001_00000005, addr n_00000001_00000001
    ret
endp

proc .compare1, p1, p2
    mov eax, [p1]
    mov eax, [eax + 4]
    mov ecx, [p2]
    cmp eax, [ecx + 4]
    jne .high_dwords_not_equal
    
    mov eax, [p1]
    mov eax, [eax]
    mov ecx, [p2]
    cmp eax, [ecx]
    jne .low_dwords_not_equal

    cinvoke puts, 'equal'
    jmp .finish
.high_dwords_not_equal:
    cinvoke puts, 'high dwords are not equal -> not equal'
    jmp .finish
.low_dwords_not_equal:
    cinvoke puts, 'high dwords are equal; low dwords are not equal -> not equal'
.finish:
    ret
endp

proc .compare2, p1, p2
    mov eax, [p1]
    mov ecx, [p2]
    mov edx, [eax]
    xor edx, [ecx]
    mov eax, [eax + 4]
    xor eax, [ecx + 4]
    or  eax, edx
    jnz .not_equal
    cinvoke puts, 'equal'
    jmp .finish
.not_equal:
    cinvoke puts, 'not equal'
.finish:
    ret
endp

proc .compare, p1, p2
    mov eax, [p1]
    movq xmm0, [eax]
    mov eax, [p2]
    movq xmm1, [eax]
    pcmpeqq xmm0, xmm1
    movd eax, xmm0
    cmp eax, -1
    jne .not_equal
    cinvoke puts, 'equal'
    jmp .finish
.not_equal:
    cinvoke puts, 'not equal'
.finish:
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
