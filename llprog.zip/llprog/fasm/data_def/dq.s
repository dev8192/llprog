format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    num1        dq 0x11223344_55667788
    num2_hi     dd 0x11223344
    num2_lo     dd 0x55667788
    fmt_x64     db '%x %x', 10, 0

section '.text' code readable executable
start:
    stdcall test10
    invoke ExitProcess, 0
    
proc test10
    cinvoke printf, fmt_x64, dword [num1 + 4], dword [num1]
    cinvoke printf, fmt_x64, [num2_hi], [num2_lo]
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
