format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt         db "%x%x", 10, 0
    num         dq 0.1  ; 0x3FB999999999999A

section '.code' code readable executable
start:
    cinvoke printf, fmt, dword [num + 4], dword [num]
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
