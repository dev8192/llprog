format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_xx      db '%x%x', 10, 0
    fmt_f       db '%f', 10, 0
    fmt_llu     db '%llu', 10, 0

include '../../util/print_bytes.data.inc'

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

include '../../util/print_bytes.text.inc'

proc main1
    cinvoke puts, '*** main1 ***'
    locals
        num1        dq 0.1
        num2        dq 0x3FB999999999999A
    endl
    cinvoke printf, fmt_xx, dword [num1 + 4], dword [num1]
    cinvoke printf, fmt_xx, dword [num2 + 4], dword [num2]
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    locals
        num1        dq 0.3
    endl
    cinvoke printf, fmt_f, double [num1]
    cinvoke printf, fmt_f, dword [num1], dword [num1 + 4]
    ret
endp

proc main3
    cinvoke puts, '*** main3 ***'
    locals
        num1        dq 18446744073709551615
    endl
    cinvoke printf, fmt_llu, double [num1]
    cinvoke printf, fmt_llu, dword [num1], dword [num1 + 4]
    ret
endp

proc main
    cinvoke puts, '*** main4 ***'
    locals
        num1    dd 15.75
        num2    dq 15.75
    endl
    stdcall print_bytes, addr num1, 4
    stdcall print_bytes, addr num2, 8
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
