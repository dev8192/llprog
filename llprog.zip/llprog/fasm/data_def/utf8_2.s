format PE console
entry start

include 'win32a.inc'

CRYPT_STRING_HEX = 4
CRYPT_STRING_NOCRLF = 0x40000000

section '.data' data readable writeable
    str1     du 'абв'
    str1_len = $ - str1
    
    fmt_num     db "%d", 10, 0
    fmt_str  db '"%s"', 10, 0
    out_buf  rb 256
    out_buf_sz dd 256

section '.text' code readable executable
start:
    cinvoke printf, fmt_num, str1_len
    invoke CryptBinaryToString, str1, str1_len,\
        CRYPT_STRING_HEX or CRYPT_STRING_NOCRLF, out_buf, out_buf_sz
    cinvoke printf, fmt_str, out_buf
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll',\
            crypt32, 'crypt32.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
    import  crypt32,\
            CryptBinaryToString, 'CryptBinaryToStringA'
