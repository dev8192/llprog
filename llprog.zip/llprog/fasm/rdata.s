format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    str1        db 'str1', 0
    fmt_s       db '%s', 10, 0

section '.rdata' data readable
    str2        db 'str2', 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc print_string, str_ptr
    cinvoke printf, fmt_s, [str_ptr]
    mov eax, [str_ptr]
    mov byte [eax], 'S'
    cinvoke printf, fmt_s, [str_ptr]
    ret
endp

proc main
    cinvoke puts, '*** main1 ***'
    stdcall print_string, str1
   ;stdcall print_string, str2
   ;stdcall print_string, 'str3'
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
