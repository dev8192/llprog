format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt     db "%08x", 10, 0
    sep     db "**********", 10, 0

section '.code' code readable executable

start:
    cinvoke printf, fmt, WS_VISIBLE
    cinvoke printf, fmt, WS_OVERLAPPEDWINDOW
    cinvoke printf, fmt, WS_SIZEBOX
    cinvoke printf, fmt, WS_MAXIMIZEBOX
    cinvoke printf, fmt,\
        WS_VISIBLE or WS_OVERLAPPEDWINDOW - WS_SIZEBOX - WS_MAXIMIZEBOX
    cinvoke printf, fmt,\
        WS_VISIBLE + WS_OVERLAPPEDWINDOW - WS_SIZEBOX - WS_MAXIMIZEBOX

    cinvoke printf, sep
    cinvoke printf, fmt, WS_OVERLAPPED
    cinvoke printf, fmt, WS_CAPTION
    cinvoke printf, fmt, WS_SYSMENU
    cinvoke printf, fmt, WS_THICKFRAME
    cinvoke printf, fmt, WS_MINIMIZEBOX
    cinvoke printf, fmt, WS_MAXIMIZEBOX
    cinvoke printf, fmt, WS_OVERLAPPEDWINDOW
    cinvoke printf, fmt,\
        WS_OVERLAPPED or WS_CAPTION or WS_SYSMENU or WS_THICKFRAME or WS_MINIMIZEBOX or WS_MAXIMIZEBOX

    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
