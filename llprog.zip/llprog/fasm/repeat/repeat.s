format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_d db '%d', 10, 0
    arr1:
    repeat 3
        POINT 0x11111111, 0x22222222
    end repeat
    arr1_byte_cnt = $ - arr1
    arr1_len = arr1_byte_cnt / sizeof.POINT
    arr2:
    repeat 2
        POINT 0x11111111, 0x22222222
    end repeat
    repeat 3
        POINT 0x33333333, 0x44444444
        POINT 0x55555555, 0x66666666
    end repeat
    arr2_byte_cnt = $ - arr2
    arr2_len = arr2_byte_cnt / sizeof.POINT

include '../../util/print_bytes.data.inc'

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

include '../../util/print_bytes.text.inc'

proc main1
    cinvoke puts, '*** main1 ***'
    repeat 3
        cinvoke printf, fmt_d, %
    end repeat
    rept 3 num:4 {
        cinvoke printf, fmt_d, num
    }
    ret
endp

proc main
    cinvoke puts, '*** main2 ***'
    cinvoke printf, fmt_d, arr1_len
    stdcall print_bytes, arr1, arr1_byte_cnt
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
