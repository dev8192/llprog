format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt_str db 'String: %s', 10, 0
    fmt_int db 'Value: %d', 10, 0
    
    str1:
        times 10 db '*'
        db 0
    
    str2: times 10 db '*'
        db 0
    
    str3 db 10 dup '*' , 0

section '.text' code readable executable
start:
    cinvoke printf, fmt_str, str1
    cinvoke printf, fmt_str, str2
    cinvoke printf, fmt_str, str3

    xor eax, eax
    times 5 add eax, 10
    cinvoke printf, fmt_int, eax

    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
        msvcrt, 'msvcrt.dll'

    import kernel32,\
        ExitProcess, 'ExitProcess'

    import msvcrt,\
        printf, 'printf'
