format PE console
entry start
include 'win32a.inc'

section '.data' data readable writeable
    fmt db '%d %d %d', 10, 0

section '.code' code readable executable
    start:
        rept 5 num1:10, num2:20, num3:30 {
            cinvoke printf, fmt, num1, num2, num3
        }

        cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit, 'exit',\
            printf, 'printf'
