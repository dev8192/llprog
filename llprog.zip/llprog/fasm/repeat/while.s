format PE CONSOLE 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt db 'Value: %d', 10, 0

    table_start:
    i = 1
    while i <= 5
        dd i * i
        i = i + 1
    end while
    table_end:

section '.text' code readable executable
start:
    mov esi, table_start

print_loop:
    cmp esi, table_end
    je done

    lodsd
    cinvoke printf, fmt, eax

    jmp print_loop

done:
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            msvcrt, 'msvcrt.dll'

    import kernel32,\
           ExitProcess, 'ExitProcess'

    import msvcrt,\
           printf, 'printf'
