format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt   db '%d', 10, 0
    array: times 5 db %
    array_length  = $ - array

section '.text' code readable executable
start:
    cinvoke printf, fmt, array_length
    xor esi, esi

.print_loop:
    movzx eax, byte [array + esi]
    cinvoke printf, fmt, eax
    
    inc esi
    cmp esi, 5
    jl .print_loop

    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
        msvcrt, 'msvcrt.dll'

    import kernel32,\
        ExitProcess, 'ExitProcess'

    import msvcrt,\
        printf, 'printf'
