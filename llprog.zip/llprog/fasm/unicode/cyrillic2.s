format PE
entry start

include 'encoding/utf8.inc'
include 'win32ax.inc'

LC_ALL  = 0

section '.data' data readable writeable
    str1        db 'абв', 0
    str1_len    = $ - str1
    str2        du 'абв', 0
    str2_len    = $ - str2
    str3        du 'abc', 0
    str3_len    = $ - str3
    fmt_s       db '%s', 10, 0
    fmt_sw      du '%s', 10, 0
    locale_utf8     db '.UTF-8', 0

include '../../util/print_bytes.data.inc'

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

PRINT_BYTES_UPPERCASE = 1
include '../../util/print_bytes.text.inc'

proc main1
    cinvoke puts, '*** main1 ***'
    stdcall print_bytes, str1, str1_len
    stdcall print_bytes, str2, str2_len
    stdcall print_bytes, str3, str3_len
    ret
endp

proc main
    cinvoke puts, '*** main2 ***'
   ;cinvoke printf, fmt_s, str1
   ;invoke  SetConsoleOutputCP, CP_UTF8
   ;cinvoke setlocale, LC_ALL, locale_utf8
    cinvoke wprintf, str2
    cinvoke puts, 'done'
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            SetConsoleOutputCP, 'SetConsoleOutputCP',\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            setlocale,      'setlocale',\
            printf,         'printf',\
            wprintf,        'wprintf',\
            puts,           'puts'
