; save with UTF-16 LE:
; .\prog.exe > file.txt
; save with UTF-8 with BOM:
; .\prog.exe | Set-Content -Encoding utf8 file.txt
; save with UTF-8:
; New-Item -Force -Path "file.txt" -Value (.\prog.exe | Out-String)

format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_x       db '%x', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    cinvoke puts, '*** main1 ***'
    cinvoke printf, fmt_x, 0x12345678
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
