format binary as 'txt'

; ------------------------- windows1251 -------------------------
macro main1 {
    display '*** main1 ***'
    db 0xE0, 0xE1, 0xE2, 10
}

; ------------------------- utf8 -------------------------
macro main21 {
    display '*** main21 ***'
    db 'абв', 10
}

macro main22 {
    display '*** main22 ***'
    db 0xD0, 0xB0, 0xD0, 0xB1, 0xD0, 0xB2, 10
}

macro main23 {
    display '*** main23 ***'
    db 0xEF, 0xBB, 0xBF
    db 0xD0, 0xB0, 0xD0, 0xB1, 0xD0, 0xB2, 10
}

; ------------------------- utf16 -------------------------
macro main {
    display '*** main31 ***'
    db 0xFF, 0xFE ; LE
   ;db 0xFE, 0xFF ; BE
    db 0x30, 0x04, 0x31, 0x04, 0x32, 0x04, 10, 0
   ;db 0x04, 0x30, 0x04, 0x31, 0x04, 0x32, 0, 10
}

macro main32 {
    display '*** main32 ***'
   ;dw 0xFEFF
    dw 0xFFFE
   ;dw 0x0430, 0x0431, 0x0432, 10
    dw 0x3004, 0x3104, 0x3204, 0x0A00
}

macro main33 {
    display '*** main33 ***'
    du 0xFEFF
   ;du 0xFFFE
    du 0x0430, 0x0431, 0x0432, 10
   ;du 0x3004, 0x3104, 0x3204, 0x0A00
}

main
