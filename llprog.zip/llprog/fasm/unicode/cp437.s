format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_d       db '%d', 10, 0
    str1        db 0xb9, 10
    str1_len    = $ - str1
    str2        db '╣', 10
    str2_len    = $ - str2

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main1
    cinvoke puts, '*** main1 ***'
   ;invoke SetConsoleOutputCP, 437
    invoke GetConsoleOutputCP
    cinvoke printf, fmt_d, eax
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    local stdout:DWORD, written:DWORD
    invoke GetStdHandle, STD_OUTPUT_HANDLE
    mov [stdout], eax
    cinvoke printf, fmt_d, str1_len
    cinvoke printf, fmt_d, str2_len
    invoke WriteFile, [stdout], str1, str1_len, addr written, 0
    invoke SetConsoleOutputCP, CP_UTF8
    invoke WriteFile, [stdout], str2, str2_len, addr written, 0
    ret
endp

proc main3
    cinvoke puts, '*** main3 ***'
    locals
        buf db 'abc', 0, 'xyz', 0
    endl
    local stdout:DWORD, written:DWORD
    invoke GetStdHandle, STD_OUTPUT_HANDLE
    mov [stdout], eax
    invoke WriteFile, [stdout], addr buf, 8, addr written, 0
    cinvoke printf, fmt_d, [written]
    ret
endp

proc main
    cinvoke puts, '*** main4 ***'
    local stdout:DWORD, written:DWORD, buf[2]:BYTE
    mov [buf + 1], 0
    invoke GetStdHandle, STD_OUTPUT_HANDLE
    mov [stdout], eax
    mov ebx, 0x30
.loop:
    mov [buf], bl
    invoke WriteFile, [stdout], addr buf, 2, addr written, 0
    inc ebx
    cmp ebx, 0x3A
    jb .loop
    ret
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            msvcrt,             'msvcrt.dll'
    import  kernel32,\
            GetConsoleOutputCP, 'GetConsoleOutputCP',\
            SetConsoleOutputCP, 'SetConsoleOutputCP',\
            GetStdHandle,       'GetStdHandle',\
            WriteFile,          'WriteFile',\
            ExitProcess,        'ExitProcess'
    import  msvcrt,\
            printf,             'printf',\
            puts,               'puts'
