format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    rect1       RECT 10, 10, 310, 210
    fmt_rect    db 'Width: %d, Height: %d', 0
    fmt_dn      db '%d', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    cinvoke puts, '*** main1 ***'
    stdcall .func, rect1
    ret
endp

proc .func uses ebx, pRect
    local width:DWORD
    local height:DWORD
    local buf1[128]:BYTE

    mov ebx, [pRect]
    mov eax, [ebx + RECT.right]
    sub eax, [ebx + RECT.left]
    mov [width], eax
    cinvoke printf, fmt_dn, [width]

    mov eax, [ebx + RECT.bottom]
    sub eax, [ebx + RECT.top]
    mov [height], eax
    cinvoke printf, fmt_dn, [height]

    cinvoke wsprintf, addr buf1, fmt_rect, [width], [height]
    cinvoke puts, addr buf1
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            user32,         'user32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  user32,\
            wsprintf,       'wsprintfA'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
