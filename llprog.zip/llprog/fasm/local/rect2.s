format PE GUI 4.0
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    myRect RECT 10, 10, 310, 210  ; Width = 300, Height = 200

section '.code' code readable executable

start:
    ; Pass the ADDRESS of our rectangle to the procedure
    stdcall PrintRectSize, myRect
    invoke  ExitProcess, 0

proc PrintRectSize, pRect
    ; Local variables on the stack
    local width:DWORD
    local height:DWORD
    local buffer[128]:BYTE

    ; Calculate Width: right - left
    mov     ebx, [pRect]          ; EBX = pointer to the RECT
    mov     eax, [ebx + RECT.right]
    sub     eax, [ebx + RECT.left]
    mov     [width], eax          ; Store in local variable

    ; Calculate Height: bottom - top
    mov     eax, [ebx + RECT.bottom]
    sub     eax, [ebx + RECT.top]
    mov     [height], eax         ; Store in local variable

    ; Format the string into our local buffer
    lea     edi, [buffer]         ; Get pointer to local buffer
    invoke  wsprintf, edi, "Width: %d, Height: %d", [width], [height]

    ; Show the result
    invoke  MessageBox, 0, edi, "Rect Size Result", MB_OK
    ret
endp

section '.idata' import data readable
  library kernel32, 'KERNEL32.DLL',\
          user32,   'USER32.DLL'

  import kernel32, ExitProcess, 'ExitProcess'
  import user32,   MessageBox,  'MessageBoxA', \
                   wsprintf,    'wsprintfA'
