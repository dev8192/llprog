format PE GUI 4.0
entry start

include 'win32a.inc'

section '.code' code readable executable

start:
    ; Вызываем нашу процедуру с двумя числами
    stdcall CalculateAndShow, 100, 50
    
    invoke  ExitProcess, 0

; --- Процедура с локальными переменными ---
proc CalculateAndShow, val1, val2
    ; 'local' резервирует место в стеке при вызове функции
    local result:DWORD
    local tempRect:RECT
    local buffer[64]:BYTE  ; Буфер для текста (массив байт)

    ; 1. Выполняем простое сложение
    mov     eax, [val1]
    add     eax, [val2]
    mov     [result], eax    ; Сохраняем в локальную переменную 'result'

    ; 2. Заполняем локальную структуру RECT (просто для примера)
    mov     [tempRect.left], 10
    mov     [tempRect.top], 20

    ; 3. Форматируем строку для вывода (используем наш локальный buffer)
    ; wsprintf запишет текст "Result: 150" прямо в стек
    lea     eax, [buffer]
    invoke  wsprintf, eax, "The sum of %d and %d is: %d", [val1], [val2], [result]
    ;invoke  wsprintf, buffer, "The sum of %d and %d is: %d", [val1], [val2], [result]

    lea     eax, [buffer]
    invoke  MessageBox, 0, eax, "No addr here", MB_OK
    ;invoke  MessageBox, 0, buffer, "Stack Variables Example", MB_OK

    ; Когда процедура закончится (ret), FASM автоматически очистит стек
    ret
endp

section '.idata' import data readable
  library kernel32, 'KERNEL32.DLL',\
          user32,   'USER32.DLL'

  import kernel32, \
         ExitProcess, 'ExitProcess'

  import user32, \
         MessageBox, 'MessageBoxA', \
         wsprintf,   'wsprintfA'
