format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_d     db '%d', 10, 0

section '.text' code readable executable
start:
    stdcall test20
    invoke ExitProcess, 0
    
proc test10
    stdcall .func1
    stdcall .func2
    ret
endp
    
proc .func1
    cinvoke puts, '*** func1 ***'
    local num:DWORD
    mov [num], 123
    cinvoke printf, fmt_d, [num]
    ret
endp

proc .func2
    cinvoke puts, '*** func2 ***'
    local num:DWORD
    cinvoke printf, fmt_d, [num]
    ret
endp

proc test20
    stdcall .func1, 456
    sub esp, 4
    stdcall .func2
    ret
endp

proc .func1, p1
    cinvoke puts, '*** func1 ***'
    cinvoke printf, fmt_d, [p1]
    ret
endp

proc .func2, p1
    cinvoke puts, '*** func2 ***'
    cinvoke printf, fmt_d, [p1]
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
