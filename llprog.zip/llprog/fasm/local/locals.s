format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt_d    db '%d', 10, 0

section '.text' code readable executable
start:
    stdcall test2
    invoke ExitProcess, 0

proc test1
    locals
        num1 rd 1
    endl
    mov [num1], 5
    cinvoke printf, fmt_d, [num1]
    ret
endp

proc test2
    locals
        num1 dd 5
        num2 dd 10
        num3 dd ?
    endl
    mov eax, [num1]
    add eax, [num2]
    mov [num3], eax
    cinvoke printf, fmt_d, [num3]
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
