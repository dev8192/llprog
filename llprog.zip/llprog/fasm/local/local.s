format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    msg db 'Stack Variables Example', 0

section '.text' code readable executable
start:
    stdcall CalculateAndShow, 100, 50
    invoke  ExitProcess, 0

proc CalculateAndShow, val1, val2
    local result:DWORD
    local buffer[64]:BYTE

    mov     eax, [val1]
    add     eax, [val2]
    mov     [result], eax

    invoke  wsprintf, addr buffer,\
        '%d + %d = %d', [val1], [val2], [result]

    invoke  MessageBox, 0, addr buffer, msg, MB_OK
    ret
endp

section '.idata' import data readable
  library kernel32, 'KERNEL32.DLL',\
          user32,   'USER32.DLL'
  import kernel32, \
         ExitProcess, 'ExitProcess'
  import user32, \
         MessageBox, 'MessageBoxA', \
         wsprintf,   'wsprintfA'
