format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_u       db '%u', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main1
    cinvoke puts, '*** main1 ***'
    repeat 5
        cinvoke printf, fmt_u, %
    end repeat
    ret
endp

proc main
    cinvoke puts, '*** main2 ***'
    cinvoke printf, 'Compiled at Unix timestamp: '
    cinvoke printf, fmt_u, %t
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
