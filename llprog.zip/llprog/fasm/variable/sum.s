format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt_d   db '%d', 10, 0
    num1    dd 5
    num2    dd 10

section '.text' code readable executable
start:
    stdcall test2
    invoke ExitProcess, 0

proc test1
    mov eax, [num1]
    add eax, [num2]
    cinvoke printf, fmt_d, eax
    ret
endp

proc test2
    mov eax, 7
    mov ecx, 2
    sub eax, ecx
    cinvoke printf, fmt_d, eax
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
