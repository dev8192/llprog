format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    var1    dd 0xAB
    var1_sz = $ - var1
    var2    db '123', 0
    var2_sz = $ - var2

    fmt_x   db '%x', 10, 0
    fmt_s   db '%s', 10, 0
    fmt_bytes db '%x %x %x %x', 10, 0

section '.text' code readable executable
start:
    stdcall test15
    invoke ExitProcess, 0
    
proc test10
    cinvoke printf, fmt_x, var1_sz
    cinvoke printf, fmt_x, var2_sz
    ret
endp
    
proc test15
    cinvoke printf, fmt_x, [var1]
    cinvoke printf, fmt_x, dword [var2]
    cinvoke printf, fmt_s, var2
    ret
endp

; AB 00 00 00
; 31 32 33 00
proc test20
    stdcall .print_bytes, var1
    stdcall .print_bytes, var2
    ret
endp

proc .print_bytes, buf_addr
    mov eax, [buf_addr]
    movzx eax, byte [eax + 0]
    push eax
    mov eax, [buf_addr]
    movzx eax, byte [eax + 1]
    push eax
    mov eax, [buf_addr]
    movzx eax, byte [eax + 2]
    push eax
    mov eax, [buf_addr]
    movzx eax, byte [eax + 3]
    push eax
    cinvoke printf, fmt_bytes
    add esp, 4 * 4
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
