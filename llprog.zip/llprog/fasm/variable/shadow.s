format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    num         dd 123
    fmt_d       db '%d', 10, 0

section '.text' code readable executable
start:
    stdcall test10
    stdcall test20
    stdcall test10
    invoke ExitProcess, 0
    
proc test10
    cinvoke puts, '*** test10 ***'
    cinvoke printf, fmt_d, [num]
    ret
endp
    
proc test20
    cinvoke puts, '*** test20 ***'
    cinvoke printf, fmt_d, [num]
    local num:DWORD
    cinvoke printf, fmt_d, [num]
    mov [num], 456
    cinvoke printf, fmt_d, [num]
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
