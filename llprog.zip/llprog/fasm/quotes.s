format PE console
entry start

include 'win32a.inc'

dquot = 34
squot = 39

section '.data' data readable
    msg1 db "'hello'", 10, 0
    msg2 db '"hello"', 10, 0
    msg3 db squot, "hello", squot, 10, 0
    msg4 db dquot, 'hello', dquot, 10, 0

section '.text' code executable
start:
    cinvoke printf, msg1
    cinvoke printf, msg2
    cinvoke printf, msg3
    cinvoke printf, msg4
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import msvcrt,   printf, 'printf',\
                     exit,   'exit'
