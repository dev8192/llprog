format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_x       db '%x', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    cinvoke puts, '*** main1 ***'
    stdcall print_message, 1
    stdcall print_message, 2
    stdcall print_message, 3
    stdcall print_message, 4
    stdcall print_message, 5
    stdcall print_message, -3
    stdcall print_message, 0
    ret
endp

proc print_message idx
    mov eax, [idx]
    dec eax
    cmp eax, 7
    ja .invalid_index
    jmp dword [.jump_table + eax * 4]

.jump_table:
    dd .msg1, .msg2, .msg3, .msg4, .msg5

.msg1: cinvoke puts, 'msg1'
         ret
.msg2: cinvoke puts, 'msg2'
         ret
.msg3: cinvoke puts, 'msg3'
         ret
.msg4: cinvoke puts, 'msg4'
         ret
.msg5: cinvoke puts, 'msg5'
         ret
.invalid_index:
    cinvoke puts, 'invalid_index'
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
