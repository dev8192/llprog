format PE console
entry start
include 'win32a.inc'

section '.data' data readable writeable
    fmt db '%d', 10, 0

section '.code' code readable executable
    start:
        repeat 3
            cinvoke printf, fmt, %
        end repeat

        cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit, 'exit',\
            printf, 'printf'
