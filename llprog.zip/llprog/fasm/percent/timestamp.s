format PE console
entry start
include 'win32a.inc'

section '.data' data readable writeable

    szFmt db 'Compiled at Unix timestamp: %u', 13, 10, 0

section '.code' code readable executable

    start:
        cinvoke printf, szFmt, %t
        invoke ExitProcess, 0

section '.idata' import data readable

    library kernel32, 'kernel32.dll',\
            msvcrt,   'msvcrt.dll'

    import kernel32,\
           ExitProcess, 'ExitProcess'

    import msvcrt,\
           printf, 'printf'
