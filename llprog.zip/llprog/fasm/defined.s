format binary as 'txt'

include 'win32a.inc'

struct UPPERCASE
    field1 db ?
ends

;macro UPPERCASE {}
;UPPERCASE db 'uppercase:', 10
;uppercase db 'uppercase:', 10

macro main {
    display '*** main1 ***'
   ;UPPERCASE = 1
   ;UPPERCASE equ 1
   ;uppercase = 1
    if defined UPPERCASE
        db 'HELLO', 10
    else
        db 'hello', 10
    end if
}

main
