format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_x       db '%x', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

; HELLO = 1
; HELLO equ 1
; c:/fasm/fasm.exe -d HELLO=1 fasm/defined.s prog.exe
; c:/fasm/fasm.exe -d hello=1 fasm/defined.s prog.exe ; not working
proc main
    cinvoke puts, '*** main1 ***'
    if defined HELLO
        cinvoke printf, fmt_x, 0x12345678
    end if
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
