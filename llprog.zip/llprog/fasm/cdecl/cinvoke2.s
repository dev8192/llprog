format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt  db '%x', 10, 0

section '.text' code readable executable
example1:
    cinvoke printf, fmt, esp
    cinvoke printf, fmt, esp
    cinvoke printf, fmt, esp
    ret

example2:
    invoke printf, fmt, esp
    invoke printf, fmt, esp
    invoke printf, fmt, esp
    ret

start:
    call example2
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'MSVCRT.DLL'
    import  msvcrt,\
            exit, 'exit',\
            printf, 'printf'
