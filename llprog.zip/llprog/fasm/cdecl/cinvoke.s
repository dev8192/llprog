format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_esp     db 'esp: %x', 10, 0
    fmt_d       db '%d', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main1
    cinvoke puts, '*** main1 ***'
    cinvoke printf, fmt_esp, esp

    push 10
    push fmt_d
    call [printf]
    add esp, 8
    cinvoke printf, fmt_esp, esp
    
    cinvoke printf, fmt_d, 20
    cinvoke printf, fmt_esp, esp
    
    invoke printf, fmt_d, 30
    add esp, 8
    cinvoke printf, fmt_esp, esp
    ret
endp

proc main
    cinvoke puts, '*** main2 ***'
    cinvoke _set_errno, 123
    cinvoke printf, fmt_esp, esp

    invoke _errno
    cinvoke printf, fmt_d, dword [eax]
    cinvoke printf, fmt_esp, esp

    cinvoke _errno
    cinvoke printf, fmt_d, dword [eax]
    cinvoke printf, fmt_esp, esp

    call [_errno]
    cinvoke printf, fmt_d, dword [eax]
    cinvoke printf, fmt_esp, esp
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            _set_errno,     '_set_errno',\
            _errno,         '_errno',\
            printf,         'printf',\
            puts,           'puts'
