format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt_manual  db '(%d) %s', 10, 0
    fmt_cinvoke db '(%d) %s', 10, 0
    str_manual  db 'manual', 0
    str_cinvoke db 'cinvoke', 0

section '.text' code readable executable
start:
    push str_manual
    push 1
    push fmt_manual
    call [printf]
    add esp, 12

    cinvoke printf, fmt_cinvoke, 2, str_cinvoke

    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL', \
        msvcrt, 'MSVCRT.DLL'

    import kernel32, \
        ExitProcess, 'ExitProcess'

    import msvcrt, \
        printf, 'printf'
