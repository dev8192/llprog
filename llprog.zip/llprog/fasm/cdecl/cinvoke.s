format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt_esp     db 'esp: %x', 10, 0
    fmt_d       db '%d', 10, 0

section '.text' code readable executable
start:
    cinvoke printf, fmt_esp, esp
    stdcall test10
    cinvoke printf, fmt_esp, esp
    stdcall test20
    cinvoke printf, fmt_esp, esp
    stdcall test30
    cinvoke printf, fmt_esp, esp
    invoke ExitProcess, 0

proc test10
    push 10
    push fmt_d
    call [printf]
    add esp, 8
    ret
endp

proc test20
    cinvoke printf, fmt_d, 20
    ret
endp

proc test30
    invoke printf, fmt_d, 30
    ;add esp, 8
    ret
endp

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL',\
            msvcrt, 'MSVCRT.DLL'
    import  kernel32,\
            ExitProcess, 'ExitProcess'
    import  msvcrt,\
            printf, 'printf'
