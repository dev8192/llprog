; access violation
format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt  db '%x', 10, 0

section '.text' code readable executable
func:
    invoke printf, fmt, esp
    invoke printf, fmt, esp
    invoke printf, fmt, esp
    ret

start:
    call func
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'MSVCRT.DLL'
    import  msvcrt,\
            exit, 'exit',\
            printf, 'printf'
