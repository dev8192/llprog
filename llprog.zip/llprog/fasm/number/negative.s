format PE console
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_xd      db '%08x %11d', 10, 0
    fmt_xu      db '%08x %11u', 10, 0

section '.text' code readable executable
start:
    stdcall test10
    stdcall test20
    cinvoke exit, 0

proc test10
    cinvoke puts, '*** test20 ***'
    cinvoke printf, fmt_xu, 0, 0
    cinvoke printf, fmt_xu, 0x7FFFFFFF, 2147483647
    cinvoke printf, fmt_xu, 0x80000000, 2147483648
    cinvoke printf, fmt_xu, 0xFFFFFFFF, 4294967295
    ret
endp

proc test20
    cinvoke puts, '*** test10 ***'
    cinvoke printf, fmt_xd, 0, 0
    cinvoke printf, fmt_xd, 0x7FFFFFFF, 2147483647
    cinvoke printf, fmt_xd, 0x80000000, -2147483648
    cinvoke printf, fmt_xd, 0xFFFFFFFF, -1
    ret
endp

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import msvcrt,\
           exit,    'exit',\
           printf,  'printf',\
           puts,    'puts'
