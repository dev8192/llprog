format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt1     db '%d', 10, 0
    fmt2     db '%u', 10, 0

section '.code' code readable executable

start:
    cinvoke printf, fmt1, 0xFFFFFFFF ; -1
    cinvoke printf, fmt2, 0xFFFFFFFF ; 4294967295
    
    cinvoke  exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import msvcrt,\
           exit, 'exit',\
           printf, 'printf'
