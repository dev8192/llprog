format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    num     dd 1010b
    ;num     dd 0b1010 ; not working
    fmt     db '%d', 10, 0

section '.code' code readable executable

start:
    cinvoke printf, fmt, [num]

    cinvoke printf, fmt, 1011b

    mov eax, 1100b
    cinvoke printf, fmt, eax
    
    cinvoke  exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import msvcrt,\
           exit, 'exit',\
           printf, 'printf'
