format PE console
entry start

include 'win32a.inc'

section '.data' data readable writable
    hex_val dq 0xAABBCCDD11223344
    fmt     db 'The value is: %llX', 0
    ;fmt     db 'The value is: %llx', 0

section '.code' code readable executable
start:
    cinvoke printf, fmt, dword [hex_val], dword [hex_val + 4]
    cinvoke exit, 0

section '.idata' import readable
    library msvcrt, 'msvcrt.dll'
    import msvcrt,\
        printf, 'printf',\
        exit, 'exit'
