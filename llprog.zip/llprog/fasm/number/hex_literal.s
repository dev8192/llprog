format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    num1    dd 0xA
    num2    dd 0Bh
    num3    dd $C
    fmt     db '%d ', 0
    nl      db 10, 0

section '.code' code readable executable

start:
    cinvoke printf, fmt, [num1]
    cinvoke printf, fmt, [num2]
    cinvoke printf, fmt, [num3]
    cinvoke printf, nl

    cinvoke printf, fmt, 0xA
    cinvoke printf, fmt, 0Bh
    cinvoke printf, fmt, $C
    cinvoke printf, nl

    mov eax, 0xA
    cinvoke printf, fmt, eax
    mov eax, 0Bh
    cinvoke printf, fmt, eax
    mov eax, $C
    cinvoke printf, fmt, eax
    cinvoke printf, nl
    
    cinvoke  exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import msvcrt,\
           exit, 'exit',\
           printf, 'printf'
