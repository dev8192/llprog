format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    val1 dd -1
    val2 dd 0xFFFFFFFF
    fmt  db 'Value 1 (-1) as hex:         0x%08X', 10
         db 'Value 2 (0xFFFFFFFF) as hex: 0x%08X', 10
         db 'Are the bits identical?      %s', 10, 0
    yes  db 'Yes', 0
    no   db 'No', 0

section '.text' code readable executable
start:
    mov eax, [val1]
    cmp eax, [val2]
    je equal

    mov ebx, no
    jmp print

equal:
    mov ebx, yes

print:
    cinvoke printf, fmt, [val1], [val2], ebx
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            msvcrt, 'msvcrt.dll'

    import kernel32,\
           ExitProcess, 'ExitProcess'

    import msvcrt,\
           printf, 'printf'
