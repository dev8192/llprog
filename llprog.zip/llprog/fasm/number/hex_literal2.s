format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt     db '%x', 10, 0

section '.code' code readable executable

start:
    cinvoke printf, fmt, 11h
    cinvoke printf, fmt, 011h
    ;cinvoke printf, fmt, FFh ; not working
    cinvoke printf, fmt, 0FFh
    
    cinvoke  exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import msvcrt,\
           exit, 'exit',\
           printf, 'printf'
