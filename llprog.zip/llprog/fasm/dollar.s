format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    msg1    db "aaa", 0
    msg1_l  = $ - msg1

    msg2    db "bbbb", 0
    msg2_l  = $ - msg2

    msg3    db "ccccc", 0
    msg3_l  = $ - msg3

    fmt     db "%s: %d", 10, 0

section '.code' code readable executable
start:
    cinvoke printf, fmt, msg1, msg1_l
    cinvoke printf, fmt, msg2, msg2_l
    cinvoke printf, fmt, msg3, msg3_l

    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import msvcrt,\
           exit, 'exit',\
           printf, 'printf'
