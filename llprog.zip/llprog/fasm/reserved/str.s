format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    str1     db 'abc', 0
    str_len = $ - str1
    fmt  db '"%s": %d', 10, 0

section '.text' code readable executable
start:
    cinvoke printf, fmt, str1, str_len
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
