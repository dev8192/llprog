format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt     db '%d', 10, 0
    buf     rb 4

section '.text' code readable executable
start:
    ;stdcall test10, 123
    stdcall test20
    invoke ExitProcess, 0

; byte:             ; error: reserved word used as symbol
;proc test10, byte   ; no error
;    cinvoke printf, fmt, [byte]
;    ;mov byte [buf], 456
;    ;cinvoke printf, fmt, [buf]
;    ret
;endp

proc test20
    mov [buf], 123
    cinvoke printf, fmt, dword [buf]
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
