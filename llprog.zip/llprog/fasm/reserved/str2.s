format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt  db '"%s": %d', 10, 0

section '.text' code readable executable
start:
    jmp print_str
    str1     db 'abc', 0
    str_len = $ - str1
print_str:
    cinvoke printf, fmt, str1, str_len
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
