format PE console
entry start

include 'win32a.inc'

section '.text' code readable executable
start:
    jmp .print_msg
    .str     db 'abc', 0
    str_len = $ - .str
    fmt  db '"%s": %d', 10, 0
.print_msg:
    cinvoke printf, fmt, .str, str_len
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
