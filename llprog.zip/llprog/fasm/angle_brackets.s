format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    str1    db 'hello', 10, 0

section '.text' code readable executable
start:
    stdcall test1
    invoke ExitProcess, 0

proc test1
    cinvoke printf, <'%d + %d = %d', 10, 0>, 5, 1, 6
    cinvoke printf, <'%d + %d = %d', 10, 0>, 5, 2, 7
    cinvoke printf, <'%d + %d = %d', 10>, 5, 3, 8
    cinvoke printf, <'%d + %d = %d', 10>, 5, 4, 9
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
