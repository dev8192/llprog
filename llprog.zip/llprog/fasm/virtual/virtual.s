format PE
entry start

include 'win32a.inc'

NULL = 0
BUFFER_SIZE = 256
NAME_SIZE = 32
DEMO_ID = 1337

virtual at ebx
    VData.Id dd ?
    VData.Name rb NAME_SIZE
end virtual

section '.data' data readable writeable
    fmt_str db "ID: %d, Name: %s", 0
    out_buf rb BUFFER_SIZE
    cap db "Virtual Demo", 0
    val_name db "FASM User", 0

section '.text' code readable executable
start:
    invoke GetProcessHeap
    invoke HeapAlloc, eax, HEAP_ZERO_MEMORY, BUFFER_SIZE
    mov ebx, eax
    
    mov [VData.Id], DEMO_ID
    
    lea eax, [VData.Name]
    invoke lstrcpy, eax, val_name
    
    lea eax, [VData.Name]
    cinvoke wsprintf, out_buf, fmt_str, \
        [VData.Id], eax
        
    invoke MessageBox, NULL, out_buf, cap, MB_OK
    
    invoke GetProcessHeap
    invoke HeapFree, eax, 0, ebx

    invoke ExitProcess, 0

section '.idata' import data readable

    library kernel32, 'KERNEL32.DLL', \
        user32, 'USER32.DLL'

    import kernel32, \
        ExitProcess, 'ExitProcess', \
        GetProcessHeap, 'GetProcessHeap', \
        HeapAlloc, 'HeapAlloc', \
        HeapFree, 'HeapFree', \
        lstrcpy, 'lstrcpyA'

    import user32, \
        MessageBox, 'MessageBoxA', \
        wsprintf, 'wsprintfA'
