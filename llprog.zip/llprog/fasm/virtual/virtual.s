format PE
entry start

include 'win32a.inc'

BUFFER_SIZE = 256

virtual at ebx
    VData.Id    dd ?
    VData.Name  rb 32
end virtual

section '.data' data readable writeable
    fmt_d       db "%d", 10, 0
    fmt_x       db "%x", 10, 0
    fmt_s       db "%s", 10, 0
    val_name    db "FASM User", 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    invoke GetProcessHeap
    invoke HeapAlloc, eax, HEAP_ZERO_MEMORY, BUFFER_SIZE
    mov ebx, eax
    
    mov [VData.Id], 1337
    
    lea eax, [VData.Name]
    invoke lstrcpy, eax, val_name
    
    cinvoke printf, fmt_d, [VData.Id]
    cinvoke printf, fmt_x, dword [VData.Name] ; 4d534146 -> FASM

    lea eax, [VData.Name]
    cinvoke printf, fmt_s, eax
    
    invoke GetProcessHeap
    invoke HeapFree, eax, 0, ebx
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess',\
            GetProcessHeap, 'GetProcessHeap',\
            HeapAlloc,      'HeapAlloc',\
            HeapFree,       'HeapFree',\
            lstrcpy,        'lstrcpyA'
    import  msvcrt,\
            printf,         'printf'
