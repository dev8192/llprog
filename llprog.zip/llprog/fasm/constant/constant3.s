format PE console
entry start
include 'win32a.inc'

section '.data' data readable writeable
    fmt db '%08x', 10, 0

section '.text' code readable executable
start:
    num = (0x1234 shl 16) or 0x5678
    cinvoke printf, fmt, num    ; 12345678

    num = num and 0xFFFFFF00
    cinvoke printf, fmt, num    ; 12345600
    
    num = num or 0xFF
    cinvoke printf, fmt, num    ; 123456FF
    
    num = num shr 16
    cinvoke printf, fmt, num    ; 00001234
    
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
