format PE console

include 'win32a.inc'

section '.text' code readable executable
    cinvoke printf, fmt
    cinvoke exit, 0

section '.data' data readable writeable
    fmt     db "no entry start", 10, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
