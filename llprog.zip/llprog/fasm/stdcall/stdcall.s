format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt_name db "func%d", 10, 0
    fmt_sum db "%d", 10, 0

section '.text' code readable executable
proc func1
    cinvoke printf, fmt_name, 1
    ret
endp
proc func2 p1, p2
    cinvoke printf, fmt_name, 2
    mov eax, [p1]
    add eax, [p2]
    cinvoke printf, fmt_sum, eax
    ret
endp

start:
    call func1
    stdcall func2, 100, 200
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
