format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt     db '%s (print_message)', 10, 0

section '.text' code readable executable
start:
    stdcall test10
    stdcall test20
    stdcall test30
    invoke ExitProcess, 0

proc print_message, msg
    cinvoke printf, fmt, [msg]
    ret
endp

; ----------------------------------------------------------
; Direct call
; ----------------------------------------------------------
proc test10
    cinvoke puts, 'test10'
    ret
endp

; ----------------------------------------------------------
; Simple callback
; Use of imported library functions as a callback
; ----------------------------------------------------------
proc test20
    stdcall .func, print_message
    stdcall .func, [puts]
    ret
endp
    
proc .func, callback
    stdcall [callback], 'test20'
    ret
endp

; ----------------------------------------------------------
; Default callback
; ---------------------------------------------------------- 
proc test30
    stdcall .func, print_message
    stdcall .func, 0
    ret
endp
    
proc .func, callback
    cmp [callback], 0
    jz .def_callback
    stdcall [callback], 'test30'
    jmp .done
.def_callback:
    cinvoke puts, 'test30 (default)'
.done:
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
