format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt_x   db '%x', 10, 0
    num_d   dd 0x12345678
    num_w   dw 0x1234
    num_b   db 0x12

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

; ----------------------------
; No need for size override
; ----------------------------
proc main10
    mov eax, -1
    mov ecx, num_d
    mov al, [ecx]
    cinvoke printf, fmt_x, eax
    
    mov eax, -1
    mov ecx, num_d
    mov ax, [ecx]
    cinvoke printf, fmt_x, eax
    
    mov eax, -1
    mov ecx, num_d
    mov eax, [ecx]
    cinvoke printf, fmt_x, eax
    ret
endp

; ----------------------------
; No need for size override
; ----------------------------
proc main15
    mov eax, -1
    mov al, [num_b]
    cinvoke printf, fmt_x, eax
    
    mov eax, -1
    mov ax, [num_w]
    cinvoke printf, fmt_x, eax
    
    mov eax, -1
    mov eax, [num_d]
    cinvoke printf, fmt_x, eax
    ret
endp
    
proc main20
    mov eax, -1
    mov al, byte [num_d]
    cinvoke printf, fmt_x, eax
    
    mov eax, -1
    mov ax, word [num_d]
    cinvoke printf, fmt_x, eax
    
    mov eax, -1
    mov eax, [num_d]
    cinvoke printf, fmt_x, eax
    ret
endp
    
proc main
    mov eax, -1
    mov al, byte [num_b]
    cinvoke printf, fmt_x, eax
    
    mov eax, -1
    mov ax, word [num_b]
    cinvoke printf, fmt_x, eax
    
    mov eax, -1
    mov eax, [num_b]
    cinvoke printf, fmt_x, eax
    ret
endp

section '.idata' import data readable
library kernel32,       'kernel32.dll',\
        msvcrt,         'msvcrt.dll'
import  kernel32,\
        ExitProcess,    'ExitProcess'
import  msvcrt,\
        printf,         'printf'
