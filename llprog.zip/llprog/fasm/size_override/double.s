format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_f       db '%f', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    cinvoke puts, '*** main1 ***'
    locals
        num1 dq 0.123456
    endl
    cinvoke printf, fmt_f, double [num1]
    cinvoke printf, fmt_f, dword [num1], dword [num1 + 4]
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
