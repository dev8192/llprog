format PE
entry start

include 'win32ax.inc'
;include 'win32a.inc'

section '.data' data readable writeable
    fmt_dn      db '%d', 10, 0
    num1:       dd 123

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
   ;cinvoke printf, fmt_dn, dword [num1]
    cinvoke printf, fmt_dn, [num1]
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
