format PE console
entry start

include 'win32a.inc'

MASK_ALL_ONES = -1
SHIFT_63      = 63
SHIFT_32      = 32

section '.data' data readable writeable

    fmt_hex db '%X', 10, 0

section '.text' code readable executable

start:
    cinvoke printf, fmt_hex, MASK_ALL_ONES shr SHIFT_63
    cinvoke printf, fmt_hex, MASK_ALL_ONES shr SHIFT_32
    invoke ExitProcess, 0

section '.idata' import data readable

    library msvcrt, 'MSVCRT.DLL', \
        kernel32, 'KERNEL32.DLL'

    import msvcrt, \
        printf, 'printf'

    import kernel32, \
        ExitProcess, 'ExitProcess'
