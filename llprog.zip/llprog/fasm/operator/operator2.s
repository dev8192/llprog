format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt     db "%x", 10, 0

section '.text' code readable executable
start:
    stdcall test30
    cinvoke exit, 0

proc test10
    cinvoke printf, fmt, (-34)
    cinvoke printf, fmt, (-34) and 0xFFFF
    ret
endp

proc test20
    cinvoke printf, fmt, -1
    cinvoke printf, fmt, (-1) shr 1
    cinvoke printf, fmt, not (1 shl 31)
    ret
endp



proc test30
    ;cinvoke printf, fmt, 1 shl 32 ; value out of range
    cinvoke printf, fmt, 1 shl 31 ; okay
    cinvoke printf, fmt, 0x80000000 shr 31
    cinvoke printf, fmt, 0x80000000_00000000 shr 63
    cinvoke printf, fmt, (-1) shr 63 ; ffffffff, but why?
    ret
endp

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
