; FASM Manual
; 1.2.4 Numerical expressions

format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt     db "%08x", 10, 0
    fmt2     db "%d", 10, 0

num = 0xFF
num2 = 0xFF00

section '.code' code readable executable
example1:
    cinvoke printf, fmt, num
    cinvoke printf, fmt, not num
    ret

example2:
    cinvoke printf, fmt2, 10 + 5
    cinvoke printf, fmt2, 13 / 5
    ;cinvoke printf, fmt2, 13 / 0
    cinvoke printf, fmt2, 13 mod 5
    ret

; 00000000ffffffff      32-bit
; ffffffffffffffff      64-bit
example3:
    cinvoke printf, fmt, 0xFF            ; 000000ff
    cinvoke printf, fmt, 0xFF shl  4     ; 00000ff0
    cinvoke printf, fmt, 0xFF shl  8     ; 0000ff00
    cinvoke printf, fmt, 0xFF shl 12     ; 000ff000
    cinvoke printf, fmt, 0xFF shl 16     ; 00ff0000
    cinvoke printf, fmt, 0xFF shl 20     ; 0ff00000
    cinvoke printf, fmt, 0xFF shl 24     ; ff000000
    ret

example4:
    cinvoke printf, fmt,\
        0x78 or\
        0x56 shl 8 or\
        0x34 shl 16 or\
        0x12 shl 24

    cinvoke printf, fmt,\
        0x78 or\
        (0x56 shl 8) or\
        (0x34 shl 16) or\
        (0x12 shl 24)

    ret

start:
    call example4
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
