format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt     db "%x", 10, 0
    num1    dd (-34)
    num2    dd (-34) and 0xFFFF

section '.text' code readable executable
start:
    cinvoke printf, fmt, [num1]
    cinvoke printf, fmt, [num2]
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
