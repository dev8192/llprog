macro enum [name] {
  common
    local counter
    counter = 0
  forward
    name = counter
    counter = counter + 1
}

; Usage:
enum Red, Green, Blue, Alpha
; Red = 0, Green = 1, Blue = 2, Alpha = 3
