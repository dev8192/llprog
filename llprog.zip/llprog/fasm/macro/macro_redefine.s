
macro hello {
    display 'hello'
}

macro hello {
    display 'goodbye'
}

hello
