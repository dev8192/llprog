format PE
entry start

include 'win32a.inc'

macro print msg, len {
    invoke WriteConsole, [hStdOut], msg, len, bw, 0
}

section '.data' data readable writeable
    msg1    db 'aaa', 10
    msg1_l  = $ - msg1

    msg2    db 'bbbbbb', 10
    msg2_l  = $ - msg2

    msg3    db 'ccccccccc', 10
    msg3_l  = $ - msg3

    hStdOut dd ?
    bw      dd ?

section '.text' code readable executable
start:
    invoke GetStdHandle, STD_OUTPUT_HANDLE
    mov [hStdOut], eax

    print msg1, msg1_l
    print msg2, msg2_l
    print msg3, msg3_l

    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32,       'kernel32.dll'
    import  kernel32,\
            GetStdHandle,   'GetStdHandle',\
            WriteConsole,   'WriteConsoleA',\
            ExitProcess,    'ExitProcess'
