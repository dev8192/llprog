format PE
entry start

include 'win32ax.inc'

macro create_greeter macro_name, greeting {
    macro macro_name user \{
        cinvoke printf, msg_fmt, greeting, user
    \}
}

create_greeter say_hello, msg_hello
create_greeter say_goodbye, msg_goodbye

section '.data' data readable writeable
    msg_fmt         db '%s, %s!', 10, 0
    msg_hello       db 'Hello', 0
    msg_goodbye     db 'Goodbye', 0
    user1           db 'Alice', 0
    user2           db 'Bob', 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    cinvoke puts, '*** main1 ***'
    cinvoke printf, msg_fmt, msg_hello, user1
    cinvoke printf, msg_fmt, msg_hello, user2
    cinvoke printf, msg_fmt, msg_goodbye, user1
    cinvoke printf, msg_fmt, msg_goodbye, user2
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    say_hello user1
    say_hello user2
    say_goodbye user1
    say_goodbye user2
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
