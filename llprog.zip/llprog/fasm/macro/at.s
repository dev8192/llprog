
macro hello@world {
    display 'hello world'
}

hello@world
