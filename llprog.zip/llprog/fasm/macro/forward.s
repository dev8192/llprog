; 'forward' block executes at least once, even if no arguments are provided

macro example name, [arg] {
    common
    display 'example', `name, ':'
    forward
    display ' forward'
    common
    display 10
}

example 0
example 1, 5
example 2, 5, 10
example 3, 5, 10, 15
