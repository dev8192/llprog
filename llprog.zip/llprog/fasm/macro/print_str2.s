format PE
entry start

include 'win32a.inc'

macro print msg, len {
    cinvoke printf, fmt, msg, len
}

section '.data' data readable writeable
    fmt     db '%s: %d', 10, 0

    msg1    db 'aaa', 0
    msg1_l  = $ - msg1 - 1

    msg2    db 'bbbbbb', 0
    msg2_l  = $ - msg2 - 1

    msg3    db 'ccccccccc', 0
    msg3_l  = $ - msg3 - 1

section '.text' code readable executable
start:
    print msg1, msg1_l
    print msg2, msg2_l
    print msg3, msg3_l

    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
