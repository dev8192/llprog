format PE
entry start

include 'win32a.inc'

macro create_func num {
    proc func#num
        locals
            buf rb num
        endl
        cinvoke printf, fmt_d, num
        ret
    endp
}

create_func 4
create_func 8

section '.data' data readable writeable
    fmt_d    db '%d', 10, 0

section '.text' code readable executable
start:
    stdcall test1
    invoke ExitProcess, 0

proc test1
    stdcall func4
    stdcall func8
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
