
macro macro1 {
    display 'hello'
}
;func = macro1
;func equ macro1
;define func macro1
macro func { macro1 }
func
