
macro print_default [arg] {
;    forward
    common
    display '--- print_default ---', 10
}

macro print_forward2 [arg] {
    common
    display '--- print_forward2 ---', 10
    forward
    display arg, ' '
    common
    display 10
}

macro print_reverse [arg] {
    common
    display '--- print_reverse ---', 10
    reverse
    display arg, ' '
}

; ------------------------- entry point -------------------------

macro main {
    display '*** main1 ***', 10
    display 'example:', 10
    print_default
    display 'example:', 10
    print_default 'one'
    display 'example:', 10
    print_default 'one', 'two'
    display 'example:', 10
    print_default 'one', 'two', 'three'
}

macro main10 {
    display '*** main10 ***', 10
    print_default 'one', 'two', 'three'
    print_common 'one', 'two', 'three'
    print_forward 'one', 'two', 'three'
    print_reverse 'one', 'two', 'three'
}

main
