format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_addr_and_size     db 'addr: %x (%d)', 10, 0
    fmt_addr     db 'addr: %x', 10, 0
    fmt_esp db 'esp: %x', 10, 0
    fmt_esp_before db 'esp before: %x', 10, 0
    fmt_esp_after db 'esp after: %x', 10, 0
    buf1    rb 32
    buf1_sz = $ - buf1

section '.text' code readable executable
start:
    stdcall test20
    invoke ExitProcess, 0
    
proc test10
    cinvoke puts, "*** test10 ***"
    stdcall .default_buffer, buf1, buf1_sz
    stdcall .default_buffer, 0, 0
    ret
endp

proc .default_buffer, buf, buf_size
    cinvoke printf, fmt_addr_and_size, [buf], [buf_size]
    ret
endp
    
proc test11
    cinvoke puts, "*** test11 ***"
    stdcall .default_buffer, buf1, buf1_sz
    stdcall .default_buffer, 0, 0
    ret
endp

proc .default_buffer, buf, buf_size
    mov eax, [buf]
    test eax, eax
    jnz  .done
    cinvoke puts, "Let's allocate a default buffer here!"
.done:
    cinvoke printf, fmt_addr_and_size, [buf], [buf_size]
    ret
endp

proc test20
    cinvoke puts, "*** test20 ***"
    cinvoke printf, fmt_addr, buf1
    stdcall .run_and_check_esp, buf1, buf1_sz
    stdcall .run_and_check_esp, 0, 0
    ret
endp

proc .run_and_check_esp, buf, buf_size
    cinvoke puts, "*** run_and_check_esp ***"
    cinvoke printf, fmt_esp_before, esp
    stdcall .default_buffer, [buf], [buf_size]
    cinvoke printf, fmt_esp_after, esp
    ret
endp

; ----------------------------------------------------------
;  40   44   48   4c   50   54   58   5c   60   64
;  ??   ??   ??   ??   v1  (bp) rtrn  p1   p2  main
;                     (sp)
;  ??   ??   ??   ??   v1  (bp) rtrn  p1   p2  main
; (sp)
; ----------------------------------------------------------
proc .default_buffer, buf, buf_size
    DEF_BUF_SZ = 16
    local   def_buf:DWORD
    mov     eax, [buf]
    test    eax, eax
    jnz     .done
    cinvoke printf, fmt_esp, esp
    sub     esp, DEF_BUF_SZ
    mov     [buf], esp
    mov     [buf_size], DEF_BUF_SZ
    mov     [def_buf], 1
.done:
    cinvoke printf, fmt_addr_and_size, [buf], [buf_size]
    mov     eax, [def_buf]
    test    eax, eax
    jz      .exit
    add     esp, DEF_BUF_SZ
.exit:
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
