function test0() {
    console.log('no param')
}
function test1(p1) {
    console.log(p1)
}
function test2(p1, p2) {
    console.log(p1 + p2)
}
function test3(p1, p2, p3) {
    console.log(p1 + p2 + p3)
}
test0()
test1(5)
test2(5, 10)
test3(5, 10, 15)
