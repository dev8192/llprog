format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
fmt:
    .test10     db 'test10', 10, 0
    .test20     db 'test20', 10, 0
    .test30     db 'test30', 10, 0

section '.text' code readable executable
start:
    stdcall test20
    invoke ExitProcess, 0
    
proc test10
    push fmt.test10
    call [printf]
    add esp, 4
    ret
endp
    
proc test20
    cinvoke printf, fmt.test20
    ret
endp
    
proc test30
    cinvoke printf, fmt.test30
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
