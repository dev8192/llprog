format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt  db '%d', 10, 0

section '.text' code readable executable
test1:
    mov eax, [esp+4]
    cinvoke printf, fmt, eax
    ret 4

test2:
    mov eax, [esp+4]
    add eax, [esp+8]
    cinvoke printf, fmt, eax
    ret 8

test3:
    mov eax, [esp+4]
    add eax, [esp+8]
    add eax, [esp+12]
    cinvoke printf, fmt, eax
    ret 12

start:
    stdcall test1, 10
    stdcall test2, 5, 15
    stdcall test3, 5, 10, 15

    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
        msvcrt, 'msvcrt.dll'

    import kernel32,\
        ExitProcess, 'ExitProcess'

    import msvcrt,\
        printf, 'printf'
