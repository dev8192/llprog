format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt  db '%d %d %d', 10, 0

section '.text' code readable executable
example1:
    mov eax, [esp+4]
    mov ebx, [esp+8]
    mov ecx, [esp+12]
    cinvoke printf, fmt, eax, ebx, ecx
    ;cinvoke printf, fmt, [esp+4], [esp+8], [esp+12]
    ret 12

proc example2 p1, p2, p3
    cinvoke printf, fmt, [p1], [p2], [p3]
    ret
endp

start:
    stdcall example1, 5, 10, 15
    stdcall example2, 5, 10, 15
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
        msvcrt, 'msvcrt.dll'

    import kernel32,\
        ExitProcess, 'ExitProcess'

    import msvcrt,\
        printf, 'printf'
