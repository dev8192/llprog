format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt     db '%d %d', 10, 0

section '.text' code readable executable
start:
    stdcall test10, 2, 3
    stdcall test20, 4, 5
    invoke ExitProcess, 0
    
proc test10, num1, num2
    cinvoke printf, fmt, [num1], [num2]
    ret
endp
    
proc test20 num1, num2
    cinvoke printf, fmt, [num1], [num2]
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
