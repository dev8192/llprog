format PE console
entry start
include 'win32a.inc'

section '.data' data readable writeable
    fmt db 'test #%d', 10, 0

section '.code' code readable executable

test1:
    cinvoke printf, fmt, 1
    ret

test2:
    cinvoke printf, fmt, 2
    ret

test3:
    cinvoke printf, fmt, 3
    ret

start:
    call test1
    call test2
    call test3

    invoke ExitProcess, 0

section '.idata' import data readable

    library kernel32, 'kernel32.dll',\
            msvcrt,   'msvcrt.dll'

    import kernel32,\
           ExitProcess, 'ExitProcess'

    import msvcrt,\
           printf, 'printf'
