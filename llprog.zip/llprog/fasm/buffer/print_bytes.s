format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_x_space db '%x ', 0
    newline     db 10, 0

section '.text' code readable executable
start:
    stdcall test10
    invoke ExitProcess, 0
    
proc test10
    cinvoke puts, '*** test10 ***'
    local buf[4]:BYTE
    mov [buf + 0], 0x11
    mov [buf + 1], 0x22
    mov [buf + 2], 0x33
    mov [buf + 3], 0x44
    stdcall .print_bytes, addr buf, 4
    ret
endp

proc .print_bytes uses esi, buf, len
    mov esi, [buf]
    mov eax, [len]
    lea ebx, [esi + eax]
.loop:
    movzx eax, byte [esi]
    cinvoke printf, fmt_x_space, eax
    add esi, 1
    cmp esi, ebx
    jl .loop
    cinvoke printf, newline
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
