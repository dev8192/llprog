format PE
entry start

include 'win32ax.inc'

struct Player1
  hp dd ?
  mp dd ?
ends

Player2.hp = 0
sizeof.Player2.hp = 4
Player2.mp = 4
sizeof.Player2.mp = 4
sizeof.Player2 = 8

struc Player2 val_hp, val_mp {
  .hp dd val_hp
  .mp dd val_mp
}

section '.data' data readable writeable
    fmt_d       db '%d', 10, 0
    fmt_player  db '%d %d', 10, 0
    p1          Player2 5, 10

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    cinvoke puts, '*** main1 ***'
    cinvoke printf, fmt_player, [p1.hp], [p1.mp]
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
