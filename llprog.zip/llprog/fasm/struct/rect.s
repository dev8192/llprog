format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    rect1 RECT
    rect2 RECT 20, 20, 200, 200
    rect3:
        .left   dd 30
        .top    dd 30
        .right  dd 300
        .bottom dd 300
    rect4:
        rect4.left   dd 40
        rect4.top    dd 40
        rect4.right  dd 400
        rect4.bottom dd 400

    fmt_num     db '%d', 10, 0
    fmt_addr    db '%x', 10, 0
    fmt_rect    db '%d %d %d %d', 10, 0

section '.text' code readable executable
func1:
    cinvoke printf, fmt_num, sizeof.RECT   
    ret

func2:
    mov [rect1.left], 10
    mov [rect1.top], 10
    mov [rect1.right], 100
    mov [rect1.bottom], 100
    cinvoke printf, fmt_rect,\
        [rect1.left], [rect1.top], [rect1.right], [rect1.bottom]
    cinvoke printf, fmt_rect,\
        [rect2.left], [rect2.top], [rect2.right], [rect2.bottom]
    cinvoke printf, fmt_rect,\
        [rect3.left], [rect3.top], [rect3.right], [rect3.bottom]
    cinvoke printf, fmt_rect,\
        [rect4.left], [rect4.top], [rect4.right], [rect4.bottom]
    ret

func3:
    cinvoke printf, fmt_addr, rect1
    cinvoke printf, fmt_addr, rect2
    cinvoke printf, fmt_addr, rect3
    cinvoke printf, fmt_addr, rect4
    ret

start:
    call func1
    call func2
    call func3
    invoke ExitProcess, 0

section '.idata' import data readable writeable
    library kernel32,           'kernel32.dll',\
            msvcrt,             'msvcrt.dll'
    import  kernel32,\
            ExitProcess,        'ExitProcess'
    import  msvcrt,\
            printf,             'printf'
