format PE console
include 'win32a.inc'

struct Point
    x   dd ?
    y   dd ?
ends

struct Rect
    left    dd ?
    top     dd ?
    right   dd ?
    bottom  dd ?
ends

section '.data' data readable writeable

    pt      rb Point.size
    rc      rb Rect.size

    dW1      dd 0
    dH1      dd 0

    szPt    db 'Point: x=%d y=%d', 13, 10, 0
    szRc    db 'Rect:  left=%d top=%d right=%d bottom=%d', 13, 10, 0
    szDim   db 'Size:  w=%d h=%d', 13, 10, 0

    buf     rb 128
    written dd 0
    hOut    dd 0

section '.code' code readable executable

start:
    invoke  GetStdHandle, STD_OUTPUT_HANDLE
    mov     [hOut], eax

    mov     esi, pt
    mov     [esi + Point.x], 42
    mov     [esi + Point.y], 99

    mov     eax, [esi + Point.x]
    mov     ecx, [esi + Point.y]
    invoke  wsprintf, buf, szPt, eax, ecx
    invoke  lstrlen, buf
    invoke  WriteConsole, [hOut], buf, eax, written, 0

    mov     edi, rc
    mov     [edi + Rect.left],   10
    mov     [edi + Rect.top],    20
    mov     [edi + Rect.right],  300
    mov     [edi + Rect.bottom], 200

    mov     eax, [edi + Rect.left]
    mov     ecx, [edi + Rect.top]
    mov     edx, [edi + Rect.right]
    mov     ebx, [edi + Rect.bottom]
    invoke  wsprintf, buf, szRc, eax, ecx, edx, ebx
    invoke  lstrlen, buf
    invoke  WriteConsole, [hOut], buf, eax, written, 0

    mov     eax, [edi + Rect.right]
    sub     eax, [edi + Rect.left]
    mov     [dW1], eax

    mov     eax, [edi + Rect.bottom]
    sub     eax, [edi + Rect.top]
    mov     [dH1], eax

    invoke  wsprintf, buf, szDim, [dW1], [dH1]
    invoke  lstrlen, buf
    invoke  WriteConsole, [hOut], buf, eax, written, 0

    invoke  ExitProcess, 0

section '.idata' import data readable writeable

    library kernel32, 'kernel32.dll', \
            user32,   'user32.dll'

    import kernel32, \
        GetStdHandle,  'GetStdHandle',  \
        WriteConsole,  'WriteConsoleA', \
        lstrlen,       'lstrlenA',      \
        ExitProcess,   'ExitProcess'

    import user32, \
        wsprintf,      'wsprintfA'
