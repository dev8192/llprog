format PE
entry start

include 'win32ax.inc'

struct PERSON_v1
    name    dd ?
    age     db ?
ends

section '.data' data readable writeable
    fmt_d       db '%d', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    cinvoke puts, '*** main1 ***'
    cinvoke printf, fmt_d, sizeof.PERSON_v1
    cinvoke printf, fmt_d, sizeof.PERSON_v1.name
    cinvoke printf, fmt_d, sizeof.PERSON_v1.age
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            lstrcpy,        'lstrcpyA',\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
