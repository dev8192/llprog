format PE console
entry start

include 'win32a.inc'

struct PERSON
    name    dd ?
    age     db 33
ends

section '.data' data readable writeable
    fmt     db "%d", 10, 0

section '.text' code readable executable
start:
    cinvoke printf, fmt, sizeof.PERSON
    cinvoke printf, fmt, sizeof.PERSON.name
    cinvoke printf, fmt, sizeof.PERSON.age
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
