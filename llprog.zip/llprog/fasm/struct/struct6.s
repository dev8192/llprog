format PE console
entry start

include 'win32a.inc'

struct PLAYER
    x      dd ?
    y      dd ?
    health dd ?
    score  dd ?
ends

section '.data' data readable writeable
    p1 PLAYER
    fmt db 'Player pos: %d,%d | Health: %d | Score: %d', 10, 0

section '.text' code readable executable
start:
    mov [p1.x], 150
    mov [p1.y], 200
    mov [p1.health], 100
    mov [p1.score], 1337

    push [p1.score]
    push [p1.health]
    push [p1.y]
    push [p1.x]
    push fmt
    call [printf]
    add esp, 20

    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL', \
        msvcrt, 'MSVCRT.DLL'

    import kernel32, \
        ExitProcess, 'ExitProcess'

    import msvcrt, \
        printf, 'printf'
