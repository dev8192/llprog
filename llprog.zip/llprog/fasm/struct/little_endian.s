format PE
entry start

include 'win32ax.inc'

struct HTTPAPI_VERSION
    HttpApiMajor    dw ?
    HttpApiMinor    dw ?
ends

section '.data' data readable writeable
    fmt_x           db '%x', 10, 0
    http_ver1       dd 0x12345678
    http_ver2       db 0x78, 0x56, 0x34, 0x12
    http_ver3       HTTPAPI_VERSION 0x5678, 0x1234
    http_ver4       = 0x12345678

include '../../util/print_bytes.data.inc'

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

include '../../util/print_bytes.text.inc'

proc main
    cinvoke puts, '*** main1 ***'
    cinvoke printf, fmt_x, dword [http_ver1] ; 12345678
    cinvoke printf, fmt_x, dword [http_ver2] ; 12345678
    cinvoke printf, fmt_x, dword [http_ver3] ; 12345678
    cinvoke printf, fmt_x, http_ver4         ; 12345678

    stdcall print_bytes, http_ver1, 4       ; 78 56 34 12
    stdcall print_bytes, http_ver2, 4       ; 78 56 34 12
    stdcall print_bytes, http_ver3, 4       ; 78 56 34 12
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
