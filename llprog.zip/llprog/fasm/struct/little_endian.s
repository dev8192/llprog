format PE
entry start

include 'win32ax.inc'

struct HTTPAPI_VERSION
    HttpApiMajor    dw ?
    HttpApiMinor    dw ?
ends

section '.data' data readable writeable
    fmt_x           db '%x', 10, 0
    http_ver1       HTTPAPI_VERSION 0x12, 0x34
    http_ver2       dd 0x00340012
    http_ver3       db 0x12, 0x00, 0x34, 0x00
    http_ver4       = 0x00340012

include '../../util/print_bytes.data.inc'

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

include '../../util/print_bytes.text.inc'

proc main
    cinvoke puts, '*** main1 ***'
    stdcall print_bytes, http_ver1, 4
    stdcall print_bytes, http_ver2, 4
    stdcall print_bytes, http_ver3, 4

    cinvoke printf, fmt_x, dword [http_ver1]
    cinvoke printf, fmt_x, dword [http_ver2]
    cinvoke printf, fmt_x, dword [http_ver3]
    cinvoke printf, fmt_x, http_ver4
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
