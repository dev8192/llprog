format PE console
entry start

include 'win32a.inc'

struct LINE
    start POINT
    end POINT
ends

section '.data' data readable writeable
    line1   LINE <10, 20>, <30, 40>
    line2   LINE
    fmt     db "%d, %d, %d, %d", 10, 0

section '.text' code readable executable
start:
    cinvoke printf, fmt, \
        [line1.start.x],    [line1.start.y], \
        [line1.end.x],      [line1.end.y]

    mov     [line2.start.x], 11
    mov     [line2.start.y], 21
    mov     [line2.end.x], 31
    mov     [line2.end.y], 41

    cinvoke printf, fmt, \
        [line2.start.x],    [line2.start.y], \
        [line2.end.x],      [line2.end.y]

    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
