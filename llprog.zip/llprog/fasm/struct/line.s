format PE
entry start

include 'win32ax.inc'

struct LINE
    pt1 POINT
    pt2 POINT
ends

section '.data' data readable writeable
    line1       LINE <10, 20>, <30, 40>
    fmt_d       db "%d", 10, 0
    fmt_line    db "%d, %d, %d, %d", 10, 0

include '../../util/print_bytes.data.inc'

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

include '../../util/print_bytes.text.inc'

proc main1
    cinvoke puts, '*** main1 ***'
    cinvoke printf, fmt_d, sizeof.POINT     ; 8
    cinvoke printf, fmt_d, sizeof.LINE      ; 16
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    cinvoke printf, fmt_line, [line1.pt1.x], [line1.pt1.y],\
        [line1.pt2.x], [line1.pt2.y]
    ret
endp

proc main
    cinvoke puts, '*** main3 ***'
    local line1:LINE
    mov [line1.pt1.x], 11
    mov [line1.pt1.y], 21
    mov [line1.pt2.x], 31
    mov [line1.pt2.y], 41
    cinvoke printf, fmt_line, [line1.pt1.x], [line1.pt1.y],\
        [line1.pt2.x], [line1.pt2.y]
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
