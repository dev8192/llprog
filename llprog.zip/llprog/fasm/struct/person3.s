format PE
entry start

include 'win32ax.inc'

struct PERSON
    name    rb 15
    age     db ?
ends

section '.data' data readable writeable
    fmt_s       db '%s', 10, 0
    fmt_d       db '%d', 10, 0
    fmt_x       db '%x', 10, 0
    person1     PERSON
    name1       db 'John Doe', 0

include '../../util/print_bytes.data.inc'

section '.code' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

include '../../util/print_bytes.text.inc'

proc main3
    cinvoke puts, '*** main3 ***'
    mov [person1.age], 32
    invoke lstrcpy, person1.name, name1
    stdcall print_bytes, person1, sizeof.PERSON
    ret
endp

proc person_init uses ebx, buf, name, age
    mov ebx, [buf]
    lea eax, [ebx + PERSON.name]
    invoke lstrcpy, eax, [name]
    mov eax, [age]
    mov [ebx + PERSON.age], al
    ret
endp

proc person_print uses ebx, person
    mov ebx, [person]
    movzx eax, [ebx + PERSON.age]
    cinvoke printf, fmt_d, eax
    lea eax, [ebx + PERSON.name]
    cinvoke printf, fmt_s, eax
    ret
endp

proc main
    cinvoke puts, '*** main4 ***'
    local person2:PERSON
    stdcall person_init, addr person2, name1, 32
    stdcall person_print, addr person2
    stdcall print_bytes, addr person2, sizeof.PERSON
    ret
endp

proc main41
    cinvoke puts, '*** main41 ***'
    local person2:PERSON
    stdcall .func, addr person2.age
    lea eax, [person2 + PERSON.age]
    stdcall .func, eax
    ret
endp

proc .func, person
    cinvoke printf, fmt_x, [person]
    ret
endp

proc main5
    cinvoke puts, '*** main5 ***'
    local person2:PERSON

    cinvoke printf, fmt_x, addr person2
    cinvoke printf, fmt_x, addr person2.name
    cinvoke printf, fmt_x, addr person2.age

    lea eax, [person2]
    cinvoke printf, fmt_x, eax
    lea eax, [person2.name]
    cinvoke printf, fmt_x, eax
    lea eax, [person2.age]
    cinvoke printf, fmt_x, eax
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            lstrcpy,        'lstrcpyA',\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
