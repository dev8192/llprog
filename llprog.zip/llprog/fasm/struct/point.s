format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    point1          POINT 10, 20
    fmt_point       db '%d %d', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    cinvoke puts, '*** main1 ***'
    cinvoke printf, fmt_point, [point1.x], [point1.y]
    mov [point1.x], 15
    mov [point1.y], 25
    cinvoke printf, fmt_point, [point1.x], [point1.y]
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    stdcall .print_point, point1
    ret
endp

proc .print_point, point
    mov eax, [point]
    cinvoke printf, fmt_point, [eax + POINT.x], [eax + POINT.y]
    ret
endp

proc main3
    cinvoke puts, '*** main3 ***'
    stdcall .print_point, point1
    ret
endp

proc .print_point, point
    mov edx, [point]
    virtual at edx
        pt POINT
    end virtual
    cinvoke printf, fmt_point, [pt.x], [pt.y]
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
