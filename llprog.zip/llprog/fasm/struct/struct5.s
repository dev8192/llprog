format PE console
entry start

include 'win32a.inc'

struct PLAYER
    x  dd ?
    y  dd ?
    hp dd ?
ends

section '.data' data readable writeable
    fmt db 'Player at (%d, %d) has %d HP.', 10, 0

section '.code' code readable executable
start:
    push    ebp
    mov     ebp, esp
    sub     esp, 24

    virtual at ebp-12
        p1 PLAYER
    end virtual

    virtual at ebp-24
        p2 PLAYER
    end virtual

    mov     [p1.x], 10
    mov     [p1.y], 20
    mov     [p1.hp], 100

    mov     [p2.x], 45
    mov     [p2.y], 90
    mov     [p2.hp], 250

    cinvoke printf, fmt, [p1.x], [p1.y], [p1.hp]
    cinvoke printf, fmt, [p2.x], [p2.y], [p2.hp]

    mov     esp, ebp
    pop     ebp

    invoke  ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL',\
            msvcrt, 'MSVCRT.DLL'

    import  kernel32,\
            ExitProcess, 'ExitProcess'

    import  msvcrt,\
            printf, 'printf'
