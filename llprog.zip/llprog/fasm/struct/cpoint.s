format PE
entry start

include 'win32ax.inc'

struct CPOINT POINT
    color dd ?
ends

section '.data' data readable writeable
    pt1             CPOINT 10, 20, 0xff0000
    fmt_dn          db '%d', 10, 0
    fmt_cpoint      db '%d, %d, %x', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    cinvoke puts, '*** main1 ***'
    cinvoke printf, fmt_dn, sizeof.POINT  ; 8
    cinvoke printf, fmt_dn, sizeof.CPOINT ; 12
    cinvoke printf, fmt_cpoint, [pt1.x], [pt1.y], [pt1.color]
    add [pt1.x], 5
    add [pt1.y], 5
    cinvoke printf, fmt_cpoint, [pt1.x], [pt1.y], [pt1.color]
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
