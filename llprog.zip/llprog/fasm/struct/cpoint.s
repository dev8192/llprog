format PE console
entry start

include 'win32a.inc'

; 3.1.1 Structures
; The definition of structure may be based
; on some of the already defined structure types and
; it inherits all the fields from that structure

struct CPOINT POINT
    color dd ?
ends

section '.data' data readable writeable
    cpoint   CPOINT 10, 20, 0xff0000
    fmt1     db "%d", 10, 0
    fmt2     db "%d, %d, %x", 10, 0

section '.text' code readable executable
start:
    cinvoke printf, fmt1, sizeof.POINT  ; 8
    cinvoke printf, fmt1, sizeof.CPOINT ; 12
    cinvoke printf, fmt2, \
        [cpoint.x], [cpoint.y], [cpoint.color]

    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
