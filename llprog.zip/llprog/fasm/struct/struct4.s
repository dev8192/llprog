; works
format PE console
entry start

include 'win32a.inc'

struct PLAYER
    x  dd ?
    y  dd ?
    hp dd ?
ends

section '.data' data readable writeable
    p1 PLAYER
    fmt db 'Player at (%d, %d) has %d HP.', 10, 0

section '.code' code readable executable
start:
    mov     [p1.x], 10
    mov     [p1.y], 20
    mov     [p1.hp], 100

    cinvoke printf, fmt, [p1.x], [p1.y], [p1.hp]

    invoke  ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL',\
            msvcrt, 'MSVCRT.DLL'

    import  kernel32,\
            ExitProcess, 'ExitProcess'

    import  msvcrt,\
            printf, 'printf'
