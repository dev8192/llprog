format PE
entry start

include 'win32ax.inc'

struct PLAYER
    pos     POINT
    health  dd ?
    score   dd ?
ends

section '.data' data readable writeable
    p1          PLAYER
    p2          PLAYER <21, 22>, 23, 24
    p3          PLAYER <31, 32>, 33, 34
    fmt_player  db 'Player {', 10
                db '  pos: POINT {', 10
                db '    x: %d,', 10
                db '    y: %d', 10
                db '  },', 10
                db '  health: %d,', 10
                db '  score: %d', 10
                db '}', 10, 0
    fmt_s       db '%s', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    cinvoke puts, '*** main1 ***'
    mov [p1.pos.x], 11
    mov [p1.pos.y], 12
    mov [p1.health], 13
    mov [p1.score], 14
    cinvoke printf, fmt_player, [p1.pos.x], [p1.pos.y], [p1.health], [p1.score]
    cinvoke printf, fmt_player, [p2.pos.x], [p2.pos.y], [p2.health], [p2.score]
    cinvoke printf, fmt_player, [p3.pos.x], [p3.pos.y], [p3.health], [p3.score]
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
