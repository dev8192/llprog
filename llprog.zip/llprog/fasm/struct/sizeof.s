format PE
entry start

include 'win32ax.inc'

struct HTTPAPI_VERSION
    HttpApiMajor    dw ?
    HttpApiMinor    dw ?
ends

section '.data' data readable writeable
    fmt_d       db '%d', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    cinvoke puts, '*** main1 ***'
    cinvoke printf, fmt_d, sizeof.RECT
    cinvoke printf, fmt_d, sizeof.HTTPAPI_VERSION
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
