format PE
entry start

include 'win32ax.inc'

struct PLAYER
    x      dd ?
    y      dd ?
    health dd ?
    score  dd ?
ends

section '.data' data readable writeable
    p1          PLAYER
    p2          PLAYER 21, 22, 23, 24
   ;p3          PLAYER x: 31, y: 32, health: 33, score: 34
    fmt_player  db 'Player {', 10
                db '  pos: %d, %d,', 10
                db '  health: %d,', 10
                db '  score: %d', 10
                db '}', 10, 0
    fmt_s       db '%s', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    cinvoke puts, '*** main1 ***'
    mov [p1.x], 11
    mov [p1.y], 12
    mov [p1.health], 13
    mov [p1.score], 14
    cinvoke printf, fmt_player, [p1.x], [p1.y], [p1.health], [p1.score]
    cinvoke printf, fmt_player, [p2.x], [p2.y], [p2.health], [p2.score]
   ;cinvoke printf, fmt_player, [p3.x], [p3.y], [p3.health], [p3.score]
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
