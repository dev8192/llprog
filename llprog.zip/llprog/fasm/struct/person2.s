format PE
entry start

include 'win32ax.inc'

struct PERSON
    age  dd ?
    name dd ?
ends

section '.data' data readable writeable
    person1         PERSON
    name1           db 'Alice', 0
    fmt_person      db 'PERSON {', 10
                    db '  Name : "%s"', 10
                    db '  Age  : %d', 10
                    db '}', 0

    fmt_person_buf_sz = $ - fmt_person + 30

    fmt_person_buf  rb fmt_person_buf_sz
    fmt_s           db '%s', 10, 0
    fmt_d           db '%d', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    cinvoke puts, '*** main1 ***'
    mov [person1.age], 28
    mov [person1.name], name1
    cinvoke wsprintf, fmt_person_buf, fmt_person, [person1.name], [person1.age]
    cinvoke printf, fmt_s, fmt_person_buf
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            user32,         'user32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            lstrcpy,        'lstrcpyA',\
            ExitProcess,    'ExitProcess'
    import  user32,\
            wsprintf,       'wsprintfA'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
