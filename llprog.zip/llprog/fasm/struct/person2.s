format PE console
entry start

include 'win32a.inc'

struct PERSON
    age  dd ?
    name dd ?
ends

section '.data' data readable writeable
    my_person PERSON
    sz_name   db "Alice", 0
    fmt       db "Name: %s", 10, \
                 "Age: %d", 10, 0

section '.text' code readable executable
start:
    mov     [my_person.age], 28
    mov     [my_person.name], sz_name

    cinvoke printf, fmt, \
        [my_person.name], \
        [my_person.age]

    invoke  ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll', \
            msvcrt, 'msvcrt.dll'

    import  kernel32, \
            ExitProcess, 'ExitProcess'

    import  msvcrt, \
            printf, 'printf'
