format PE
entry start

include 'win32ax.inc'

struct EXAMPLE
    field1    dd ?
    field2    rb 4
ends

section '.data' data readable writeable
    fmt_x       db '%x', 10, 0
    fmt_d       db '%d', 10, 0
    str1        db 'abc', 0
    str2        db 'xyz', 0
    ex1         EXAMPLE
    fmt_ex      db  'EXAMPLE {', 10,\
                    '  field1 : %s', 10,\
                    '  field2 : %s', 10,\
                    '}', 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main1
    cinvoke puts, '*** main1 ***'
    local buf1[64]:BYTE
    cinvoke printf, fmt_d, sizeof.EXAMPLE
    mov [ex1.field1], str1
    cinvoke strcpy, ex1.field2, str2
    cinvoke sprintf, addr buf1, fmt_ex, [ex1.field1], ex1.field2
    cinvoke puts, addr buf1
    ret
endp

proc main2 uses ebx
    cinvoke puts, '*** main2 ***'
    local buf1[64]:BYTE
    sub esp, sizeof.EXAMPLE
    mov ebx, esp
    mov [ebx + EXAMPLE.field1], str1
    lea eax, [ebx + EXAMPLE.field2]
    cinvoke strcpy, eax, str2
    mov eax, [ebx + EXAMPLE.field1]
    lea ecx, [ebx + EXAMPLE.field2]
    cinvoke sprintf, addr buf1, fmt_ex, eax, ecx
    cinvoke puts, addr buf1
    add esp, sizeof.EXAMPLE
    ret
endp

proc main uses ebx
    cinvoke puts, '*** main3 ***'
    local buf1[64]:BYTE, hHeap:DWORD
    invoke GetProcessHeap
    mov [hHeap], eax
    invoke HeapAlloc, [hHeap], 0, sizeof.EXAMPLE
    mov ebx, eax
    mov [ebx + EXAMPLE.field1], str1
    lea eax, [ebx + EXAMPLE.field2]
    cinvoke strcpy, eax, str2
    mov eax, [ebx + EXAMPLE.field1]
    lea ecx, [ebx + EXAMPLE.field2]
    cinvoke sprintf, addr buf1, fmt_ex, eax, ecx
    cinvoke puts, addr buf1
    invoke HeapFree, [hHeap], 0, ebx
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            GetProcessHeap, 'GetProcessHeap',\
            HeapAlloc,      'HeapAlloc',\
            HeapFree,       'HeapFree',\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            strcpy,         'strcpy',\
            sprintf,        'sprintf',\
            printf,         'printf',\
            puts,           'puts'
