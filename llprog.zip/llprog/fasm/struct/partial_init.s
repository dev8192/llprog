format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    rect0       RECT
    rect1       RECT 111
    rect2       RECT 111, 222
    rect3       RECT 111, 222, 333
    rect4       RECT 111, 222, 333, 444
    fmt_rect    db '%d %d %d %d', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc print_rect rect
    mov eax, [rect]
    cinvoke printf, fmt_rect,\
        [eax + RECT.left], [eax + RECT.top],\
        [eax + RECT.right], [eax + RECT.bottom]
    ret
endp

proc main
    cinvoke puts, '*** main1 ***'
    stdcall print_rect, rect0
    stdcall print_rect, rect1
    stdcall print_rect, rect2
    stdcall print_rect, rect3
    stdcall print_rect, rect4
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
