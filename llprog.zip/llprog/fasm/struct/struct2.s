format PE console
include 'win32a.inc'

struct Point
    x   dd ?
    y   dd ?
ends

struct Rect
    left    dd ?
    top     dd ?
    right   dd ?
    bottom  dd ?
ends

section '.data' data readable writeable

    pt      Point
    rc      Rect

    dWidth      dd 0
    dHeight      dd 0

    szPt    db 'Point: x=%d y=%d', 13, 10, 0
    szRc    db 'Rect:  left=%d top=%d right=%d bottom=%d', 13, 10, 0
    szDim   db 'Size:  w=%d h=%d', 13, 10, 0

    buf     rb 128
    written dd 0
    hOut    dd 0

section '.code' code readable executable

start:
    invoke  GetStdHandle, STD_OUTPUT_HANDLE
    mov     [hOut], eax

    mov     [pt.x], 42
    mov     [pt.y], 99

    invoke  wsprintf, buf, szPt, [pt.x], [pt.y]
    invoke  lstrlen, buf
    invoke  WriteConsole, [hOut], buf, eax, written, 0

    mov     [rc.left],   10
    mov     [rc.top],    20
    mov     [rc.right],  300
    mov     [rc.bottom], 200

    invoke  wsprintf, buf, szRc, [rc.left], [rc.top], [rc.right], [rc.bottom]
    invoke  lstrlen, buf
    invoke  WriteConsole, [hOut], buf, eax, written, 0

    mov     eax, [rc.right]
    sub     eax, [rc.left]
    mov     [dWidth], eax

    mov     eax, [rc.bottom]
    sub     eax, [rc.top]
    mov     [dHeight], eax

    invoke  wsprintf, buf, szDim, [dWidth], [dHeight]
    invoke  lstrlen, buf
    invoke  WriteConsole, [hOut], buf, eax, written, 0

    invoke  ExitProcess, 0

section '.idata' import data readable writeable

    library kernel32, 'kernel32.dll', \
            user32,   'user32.dll'

    import kernel32, \
        GetStdHandle,  'GetStdHandle',  \
        WriteConsole,  'WriteConsoleA', \
        lstrlen,       'lstrlenA',      \
        ExitProcess,   'ExitProcess'

    import user32, \
        wsprintf,      'wsprintfA'
