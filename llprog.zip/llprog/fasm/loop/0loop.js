
function while1() {
    console.log('*** while1 ***')
    let i = 0
    while (true) {
        if (i >= 5) break
        console.log(`msg ${i}`)
        i++
    }
}

function while2() {
    console.log('*** while2 ***')
    let i = 0
    while (i < 5) {
        console.log(`msg ${i}`)
        i++
    }
}

function do_while() {
    console.log('*** do_while ***')
    let i = 0
    do {
        console.log(`msg ${i}`)
        i++
    } while (i < 5)
}

while1()
while2()
do_while()
