format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    buf     rb 27
    fmt     db '%s', 10, 0

section '.text' code readable executable
start:
    stdcall test10
    invoke ExitProcess, 0
    
proc test10
    mov ecx, 0
    mov eax, 'a'
.loop:
    mov [buf + ecx], al
    inc eax
    inc ecx
    cmp ecx, 26
    jl .loop
    cinvoke printf, fmt, buf
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
