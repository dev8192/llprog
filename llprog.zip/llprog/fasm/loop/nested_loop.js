function test() {
    const GRID_SIZE = 3
    for (let esi = 0; esi < GRID_SIZE; esi++) {
        for (let edi = 0; edi < GRID_SIZE; edi++) {
            console.log(esi, edi)
        }
    }
}

function test1() {
    const GRID_SIZE = 0
    let esi = 0
    do {
        let edi = 0
        do {
            console.log(esi, edi)
            edi++
        } while (edi < GRID_SIZE)
        esi++
    } while (esi < GRID_SIZE)
}

test()
