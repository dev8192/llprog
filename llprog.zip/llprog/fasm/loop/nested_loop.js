function test() {
    const GRID_SIZE = 3
    for (let esi = 0; esi < GRID_SIZE; esi++) {
        for (let edi = 0; edi < GRID_SIZE; edi++) {
            console.log(esi, edi)
        }
    }
}

test()
