format PE console
entry start

include 'win32a.inc'

GRID_SIZE = 3

section '.data' data readable writeable
    fmt     db "%d %d", 10, 0

section '.text' code readable executable
start:
    mov esi, 0
.row_loop:
    mov edi, 0
.col_loop:
    cinvoke printf, fmt, esi, edi
    inc edi
    cmp edi, GRID_SIZE
    jl .col_loop
    inc esi
    cmp esi, GRID_SIZE
    jl .row_loop
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
