format PE console
entry start

include 'win32a.inc'

GRID_WIDTH = 4
GRID_HEIGHT = 3

; (0 0) (1 0) (2 0)
; (0 1) (1 1) (2 1)
; (0 2) (1 2) (2 2)
; (0 3) (1 3) (2 3)

section '.data' data readable writeable
    fmt     db '(%d %d) ', 0
    newline db 10, 0

section '.text' code readable executable
func1:
    xor esi, esi
.outer_loop:
    xor edi, edi
.inner_loop:
    cinvoke printf, fmt, edi, esi
    inc edi
    cmp edi, GRID_WIDTH
    jl .inner_loop
    cinvoke printf, newline
    inc esi
    cmp esi, GRID_HEIGHT
    jl .outer_loop
    ret

proc nested_loop2 height, width
    mov eax, [width]
    test eax, eax
    jz .outer_loop_end
    xor esi, esi
.outer_loop:
    cmp esi, [height]
    jge .outer_loop_end
    xor edi, edi
.inner_loop:
    cmp edi, [width]
    jge .inner_loop_end
    cinvoke printf, fmt, edi, esi
    inc edi
    jmp .inner_loop
.inner_loop_end:
    cinvoke printf, newline
    inc esi
    jmp .outer_loop
.outer_loop_end:
    ret
endp

start:
    stdcall nested_loop2, 3, 4
    ;stdcall nested_loop2, 1, 1
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
