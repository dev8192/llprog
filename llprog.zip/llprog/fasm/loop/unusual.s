format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_x           db '%x', 10, 0
    buf1            db '5', 0
    newline         db 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    cinvoke puts, '*** main1 ***'
    stdcall .func
    ret
endp

proc .func
    cinvoke printf, buf1
    dec     byte [buf1]
    cmp     byte [buf1], '0'
    jg      .func
    cinvoke printf, newline
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    mov [buf1], 'a'
    stdcall .func
    ret
endp

proc .func
    cinvoke printf, buf1
    inc     byte [buf1]
    cmp     byte [buf1], 'z'
    jle      .func
    cinvoke printf, newline
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
