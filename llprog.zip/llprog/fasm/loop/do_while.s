format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt0    db '*** do while ***', 10, 0
    fmt     db 'msg #%d', 10, 0

section '.code' code readable executable
start:
    cinvoke printf, fmt0
    xor     ebx, ebx
loop1:
    cinvoke printf, fmt, ebx
    inc     ebx
    cmp     ebx, 5
    jl      loop1
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
