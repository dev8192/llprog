format PE console
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_u   db '%u', 10, 0
    fmt_x   db '%x', 10, 0

section '.text' code readable executable
start:
    call test10
    call test20
    cinvoke exit, 0

proc test10
    cinvoke puts, 'test10'
    mov ecx, 5
.loop:
    push ecx
    cinvoke printf, fmt_u, ecx
    pop ecx
    loop .loop
    ret
endp

proc test20 uses ebx
    cinvoke puts, 'test10'
    mov ecx, 0xFFFFFFFF
    xor ebx, ebx
.loop:
    inc ebx
    loop .loop
    cinvoke printf, fmt_u, ebx
    cinvoke printf, fmt_x, ebx
    ret
endp

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf',\
            puts,   'puts'
