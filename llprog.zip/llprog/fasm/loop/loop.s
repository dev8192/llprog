format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt0    db '*** loop #%d ***', 10, 0
    fmt     db 'msg #%d', 10, 0

section '.code' code readable executable
test1:
    cinvoke printf, fmt0, 1
    mov ecx, 5
.loop:
    push ecx
    cinvoke printf, fmt, ecx
    pop ecx
    loop     .loop
    ret

test2:
    cinvoke printf, fmt0, 2
    mov ecx, 5
.loop:
    push ecx
    cinvoke printf, fmt, ecx
    pop ecx
    loop     .loop
    ret

start:
    call test1
    call test2

    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
