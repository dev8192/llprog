
macro main1 {
    display '*** main1 ***', 10
    define msg_id 2

    match =1, msg_id \{ msg equ 'one' \}
    match =2, msg_id \{ msg equ 'two' \}

    display msg
}

macro main2 {
    display '*** main2 ***', 10
    define msg_id 1

    match =1, msg_id \{
        display 'msg1'
    \}
    match =2, msg_id \{
        display 'msg2'
    \}
}

macro main3 {
    display '*** main3 ***', 10
    match +,+ \{ display '++' \}
    match +,- \{ display '+-' \}
}

macro main {
    display '*** main4 ***', 10
    match w1-w2, 97-'bc' \{
        display w1, w2
    \}
}

main
