include 'win32ax.inc'

; --- CONFIGURATION ---
; define TITLE_MODE 1  ; Uncomment this for GetCommandLine
define TITLE_MODE 0    ; Default

; --- LOGIC ---
match =1, TITLE_MODE { _TITLE equ invoke GetCommandLine }
match =0, TITLE_MODE { _TITLE equ "Static Title" }

.code
  start:
    invoke MessageBox, \
           HWND_DESKTOP, \
           "Message", \
           _TITLE, \
           MB_OK

    invoke ExitProcess, 0
.end start
