; not working
format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    result      dq ?
    fmt_str     db 'Result: %.2f', 10, 0

section '.text' code readable executable
start:
    mov         eax, 10.5
    fld         qword [eax]
    fadd        2.5
    fstp        [result]
    cinvoke     printf, fmt_str, dword [result], dword [result+4]
    cinvoke     exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
