format PE console
entry start

include 'win32ax.inc'   ; this works
;include 'win32a.inc'   ; this doesn't

section '.data' data readable writeable
    fmt         db 'hello 111', 10, 0

section '.code' code readable executable

start:
    cinvoke printf, fmt
    cinvoke printf, 'hello 222'
    cinvoke  exit, 0

section '.idata' import data readable
  library msvcrt, 'MSVCRT.DLL'
  import msvcrt,    printf, 'printf',\
                    exit,   'exit'
