format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    str1        db 'abc', 0
    str1_len    = $ - str1
    str2        dw 'a', 'b', 'c', 0
    str2_len    = $ - str2
    str3        dd 'a', 'b', 'c', 0
    str3_len    = $ - str3

    str4        dw 'ab', 0
    str4_len    = $ - str4

    str5        dd 'abcd', 0
    str5_len    = $ - str5
    
    fmt_dd      db '%d : %d', 10, 0

section '.text' code readable executable
start:
    stdcall test10
    invoke ExitProcess, 0
    
proc test10
    cinvoke printf, fmt_dd, 1, str1_len
    cinvoke printf, fmt_dd, 2, str2_len
    cinvoke printf, fmt_dd, 3, str3_len
    cinvoke printf, fmt_dd, 4, str4_len
    cinvoke printf, fmt_dd, 5, str5_len
    ret
endp

section '.idata' import data readable
library kernel32,       'kernel32.dll',\
        msvcrt,         'msvcrt.dll'
import  kernel32,\
        ExitProcess,    'ExitProcess'
import  msvcrt,\
        printf,         'printf'
