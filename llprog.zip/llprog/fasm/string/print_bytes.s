format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_x_space db '%x ', 0
    newline     db 10, 0

section '.text' code readable executable
start:
    stdcall test10
    invoke ExitProcess, 0
    
proc test10
    stdcall .print_bytes, ''
    stdcall .print_bytes, 'a'
    stdcall .print_bytes, 'abc'
    ret
endp

proc .print_bytes uses esi, str_ptr
    mov esi, [str_ptr]
    cmp byte [esi], 0
    jz .exit
.loop:
    movzx eax, byte [esi]
    cinvoke printf, fmt_x_space, eax
    add esi, 1
    cmp byte [esi], 0
    jnz .loop
    cinvoke printf, newline
.exit:
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
