format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    item1       db 'item1', 0
    fmt_d       db '%d', 10, 0
    last_item = $

section '.text' code readable executable
start:
    stdcall test10
    invoke ExitProcess, 0
    
proc test10
    cinvoke puts, item1
    cinvoke puts, 'item2'
    cinvoke puts, last_item
    cinvoke printf, fmt_d, dword [last_item]
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
