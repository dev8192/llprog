format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    item1       db 'item1', 0
    item2       db 'item2', 0
    fmt_x       db '%x', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc print_addr, p1
    cinvoke printf, fmt_x, [p1]
    ret
endp

; ----------------------------
; 401000
; 401006
; 402038
; 402051
; 40206a
; 0x6a - 0x51 = 25
; 0x51 - 0x38 = 25
; ----------------------------
proc main10
    cinvoke printf, fmt_x, item1
    cinvoke printf, fmt_x, item2
    cinvoke printf, fmt_x, 'item2'
    cinvoke printf, fmt_x, 'item2'
    cinvoke printf, fmt_x, 'item2'
    ret
endp

; ----------------------------
; 401000
; 401006
; 402026
; 402036
; 402046
; ----------------------------
proc main20
    stdcall print_addr, item1
    stdcall print_addr, item2
    stdcall print_addr, 'item2'
    stdcall print_addr, 'item2'
    stdcall print_addr, 'item2'
    ret
endp

proc main
    stdcall print_addr, ''      ; 40202a    11
    stdcall print_addr, ''      ; 402035    11
    stdcall print_addr, ''      ; 402040    11
    stdcall print_addr, ''      ; 40204b    11
    stdcall print_addr, ''      ; 402056
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
