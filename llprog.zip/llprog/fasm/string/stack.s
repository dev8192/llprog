format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt_str db '%s', 10, 0
    fmt_hex db '%x ', 0

section '.text' code readable executable
test10:
    push 0x636261
    ;push 'xyz'
    cinvoke printf, fmt_str, esp
    add esp, 4
    ret

; abcdefghijklmnopqrstuvwxyz
test20:
    push 'yz'
    push 'uvwx'
    push 'qrst'
    push 'mnop'
    push 'ijkl'
    push 'efgh'
    push 'abcd'
    cinvoke printf, fmt_str, esp
    add esp, 7 * 4
    ret

proc test30 uses ebx
    push 'yz'
    push 'uvwx'
    push 'qrst'
    push 'mnop'
    push 'ijkl'
    push 'efgh'
    push 'abcd'
;    movzx eax, byte [esp + 0]
;    cinvoke printf, fmt_hex, eax
;    movzx eax, byte [esp + 1]
;    cinvoke printf, fmt_hex, eax
;    movzx eax, byte [esp + 2]
;    cinvoke printf, fmt_hex, eax
    xor ebx, ebx
@@:
    movzx eax, byte [esp + ebx]
    cinvoke printf, fmt_hex, eax
    inc ebx
    cmp ebx, 7 * 4
    jl @b
    add esp, 7 * 4
    ret
endp

start:
    call test30
    cinvoke  exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            printf, 'printf',\
            exit,   'exit'
