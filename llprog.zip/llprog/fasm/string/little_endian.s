format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    str1    db 'head'
    str2    db 68h, 65h, 61h, 64h
    fmt_x   db '%08x', 10, 0
    fmt_c   db '%c', 10, 0

section '.text' code readable executable
start:
    stdcall test3
    invoke ExitProcess, 0

proc test1
    mov eax, dword [str1]
    cinvoke printf, fmt_x, eax
    mov eax, dword [str2]
    cinvoke printf, fmt_x, eax
    
    mov eax, dword [str1]
    movzx eax, al
    cinvoke printf, fmt_c, eax
    ret
endp

proc test2
    mov eax, dword [str1]
    cmp eax, 'head'
    jne .not_found
    cinvoke puts, 'found'
    jmp .exit
.not_found:
    cinvoke puts, 'not found'
.exit:
    ret
endp

proc test3
    mov eax, 'a'
    cinvoke printf, fmt_x, eax
    mov eax, 'ab'
    cinvoke printf, fmt_x, eax
    mov eax, 'abc'
    cinvoke printf, fmt_x, eax
    mov eax, 'abcd'
    cinvoke printf, fmt_x, eax
    ret
endp

proc test4
    mov eax, 'a'
    movzx eax, al
    cinvoke printf, fmt_c, eax
    mov eax, 'ab'
    movzx eax, al
    cinvoke printf, fmt_c, eax
    mov eax, 'abc'
    movzx eax, al
    cinvoke printf, fmt_c, eax
    mov eax, 'abcd'
    movzx eax, al
    cinvoke printf, fmt_c, eax
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
