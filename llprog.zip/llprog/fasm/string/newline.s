format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    msg     db 'hello', 0
    newline db 10, 0

section '.text' code readable executable
start:
    stdcall test10
    stdcall test20
    stdcall test30
    cinvoke exit, 0

proc test10
    cinvoke printf, msg
    cinvoke printf, newline
    ret
endp

proc test20
    cinvoke printf, msg
    push 10
    cinvoke printf, esp
    add esp, 4
    ret
endp

proc test30
    cinvoke printf, msg
    push 10
    push esp
    call [printf]
    add esp, 8
    ret
endp

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
