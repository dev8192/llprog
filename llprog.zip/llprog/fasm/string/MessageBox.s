format PE console
entry start

include 'win32a.inc'
;include 'win32ax.inc'

section '.data' data readable writeable
    msg1     db 'Message 1',0
    title1   db 'Title 1',0

section '.text' code readable executable
start:
    invoke  MessageBox, 0, msg1, title1, 0
    invoke  MessageBox, 0, 'Message 2', 'Title 2', 0
    invoke  ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll', \
            user32,  'user32.dll'
    import  kernel32, ExitProcess,  'ExitProcess'
    import  user32,   MessageBox,  'MessageBoxA'
