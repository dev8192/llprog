format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt_x   db '%x', 10, 0
    fmt_4x  db '%x %x %x %x', 10, 0

section '.text' code readable executable
start:
    stdcall test20
    invoke ExitProcess, 0
    
proc test10
    mov eax, 'abcd'
    cinvoke printf, fmt_x, eax
    mov eax, 0x64636261
    cinvoke printf, fmt_x, eax
    ret
endp
    
proc test20
    local v1:DWORD, v2:DWORD, v3:DWORD, v4:DWORD
   ;mov eax, 'abcd'
    mov eax, 0x64636261

    movzx ecx, al
    mov [v1], ecx

    shr eax, 8
    movzx ecx, al
    mov [v2], ecx

    shr eax, 8
    movzx ecx, al
    mov [v3], ecx

    shr eax, 8
    movzx ecx, al
    mov [v4], ecx

    cinvoke printf, fmt_4x, [v1], [v2], [v3], [v4]
    ret
endp

section '.idata' import data readable
library kernel32,       'kernel32.dll',\
        msvcrt,         'msvcrt.dll'
import  kernel32,\
        ExitProcess,    'ExitProcess'
import  msvcrt,\
        printf,         'printf'
