format PE
entry start

include 'win32a.inc'

WINDOW_WIDTH equ 650
WINDOW_HEIGHT equ 300
PEN_WIDTH equ 30
NUM_POINTS equ 2
BLACK_COLOR equ 0x00000000

section '.data' data readable writeable
    wc WNDCLASS
    msg MSG
    ps PAINTSTRUCT
    logbrush LOGBRUSH
    hPenArr dd 5 dup(0)

    class_name db 'ExampleWindow', 0

points:
    dd 100, 100, 1700, 100
    dd 100, 300, 1700, 300
    dd 100, 500, 1700, 500
    dd 100, 700, 1700, 700
    dd 100, 900, 1700, 900

    pen_styles dd PS_SOLID, PS_DASH, PS_DOT, PS_DASHDOT, PS_DASHDOTDOT
    fmt_wmpaint db 'wmpaint', 10, 0
    msg1 db 'msg1', 10, 0
    fmt_num db '%d', 10, 0

section '.text' code readable executable
start:
    invoke GetModuleHandle, NULL
    mov [wc.hInstance], eax
    mov [wc.style], CS_HREDRAW or CS_VREDRAW
    mov [wc.lpfnWndProc], WindowProc
    invoke LoadCursor, NULL, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.hbrBackground], COLOR_WINDOW + 1
    mov [wc.lpszClassName], class_name
    invoke RegisterClass, wc
    invoke CreateWindowEx, 0, class_name, class_name,\
        WS_OVERLAPPEDWINDOW or WS_VISIBLE or WS_MAXIMIZE,\
        CW_USEDEFAULT, CW_USEDEFAULT, WINDOW_WIDTH, WINDOW_HEIGHT,\
        NULL, NULL, [wc.hInstance], NULL

msg_loop:
    invoke GetMessage, msg, NULL, 0, 0
    test eax, eax
    jle end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp msg_loop

end_loop:
    xor ebx, ebx
@@:
    invoke DeleteObject, [hPenArr + ebx]
    add edx, 4
    cmp edx, 5
    jl @b
    invoke ExitProcess, [msg.wParam]

proc WindowProc uses ebx esi, hwnd, wmsg, wparam, lparam
    cmp [wmsg], WM_CREATE
    je .wm_create
    cmp [wmsg], WM_PAINT
    je .wm_paint
    cmp [wmsg], WM_DESTROY
    je .wm_destroy
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret

.wm_create:
    cinvoke printf, fmt_wmpaint
    mov [logbrush.lbStyle], BS_SOLID
    mov [logbrush.lbColor], BLACK_COLOR
    xor esi, esi
@@:
    mov eax, PS_GEOMETRIC
    lea ebx, [pen_styles + esi * 4]
    or eax, [ebx]
    invoke ExtCreatePen, eax, PEN_WIDTH, logbrush, 0, NULL
    mov [hPenArr + esi * 4], eax
    inc esi
    cmp esi, 5
    jl @b
    xor eax, eax
    ret

.wm_paint:
    cinvoke printf, fmt_wmpaint
    invoke BeginPaint, [hwnd], ps
    xor ebx, ebx
    mov esi, points
@@:
    invoke SelectObject, [ps.hdc], [hPenArr + ebx * 4]
    invoke Polyline, [ps.hdc], esi, NUM_POINTS
    add esi, 16
    inc ebx
    cmp ebx, 5
    jl @b

    invoke EndPaint, [hwnd], ps
    xor eax, eax
    ret

.wm_destroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    ret
endp

section '.idata' import data readable writeable
    library kernel32,           'kernel32.dll',\
            user32,             'user32.dll',\
            gdi32,              'gdi32.dll',\
            msvcrt,             'msvcrt.dll'
    import  kernel32,\
            GetModuleHandle,    'GetModuleHandleA',\
            ExitProcess,        'ExitProcess'
    import  user32,\
            LoadIcon,           'LoadIconA',\
            LoadCursor,         'LoadCursorA',\
            RegisterClass,      'RegisterClassA',\
            CreateWindowEx,     'CreateWindowExA',\
            GetMessage,         'GetMessageA',\
            TranslateMessage,   'TranslateMessage',\
            DispatchMessage,    'DispatchMessageA',\
            DefWindowProc,      'DefWindowProcA',\
            BeginPaint,         'BeginPaint',\
            EndPaint,           'EndPaint',\
            PostQuitMessage,    'PostQuitMessage'
    import  gdi32,\
            ExtCreatePen,       'ExtCreatePen',\
            SelectObject,       'SelectObject',\
            DeleteObject,       'DeleteObject',\
            Polyline,           'Polyline'
    import  msvcrt,\
            printf,             'printf'
