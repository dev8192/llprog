format PE
entry start

include 'win32a.inc'

WINDOW_WIDTH equ 650
WINDOW_HEIGHT equ 300
PEN_WIDTH equ 150
NUM_POINTS equ 3
BLACK_COLOR equ 0x00000000

section '.data' data readable writeable
    wc WNDCLASS
    msg MSG
    ps PAINTSTRUCT
    logbrush LOGBRUSH
    hwnd dd ?
    hPen dd ?
    hOldPen dd ?

    class_name db 'ExampleWindow', 0

    SHAPE_WIDTH = 400
    SHAPE_HEIGHT = 400
    GAP = 200
    POS_Y1 = 200
    POS_Y2 = POS_Y1 + SHAPE_HEIGHT
    POS_X1 = 50
    POS_X2 = POS_X1 + SHAPE_WIDTH
    POS_X3 = POS_X2 + GAP
    POS_X4 = POS_X3 + SHAPE_WIDTH
    POS_X5 = POS_X4 + GAP
    POS_X6 = POS_X5 + SHAPE_WIDTH

    pts1 dd POS_X1, POS_Y1, POS_X2, POS_Y1, POS_X2, POS_Y2
    pts2 dd POS_X3, POS_Y1, POS_X4, POS_Y1, POS_X4, POS_Y2
    pts3 dd POS_X5, POS_Y1, POS_X6, POS_Y1, POS_X6, POS_Y2

;    pts1 dd POS_X1, POS_Y1, POS_X1, POS_Y2, POS_X2, POS_Y2
;    pts2 dd POS_X3, POS_Y1, POS_X3, POS_Y2, POS_X4, POS_Y2
;    pts3 dd POS_X5, POS_Y1, POS_X5, POS_Y2, POS_X6, POS_Y2

    fmt_wmpaint db 'wmpaint', 10, 0

section '.text' code readable executable
start:
    invoke GetModuleHandle, NULL
    mov [wc.hInstance], eax
    mov [wc.style], CS_HREDRAW or CS_VREDRAW
    mov [wc.lpfnWndProc], WindowProc
    invoke LoadCursor, NULL, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.hbrBackground], COLOR_WINDOW + 1
    mov [wc.lpszClassName], class_name
    invoke RegisterClass, wc
    invoke CreateWindowEx, 0, class_name, class_name,\
        WS_OVERLAPPEDWINDOW or WS_VISIBLE or WS_MAXIMIZE,\
        CW_USEDEFAULT, CW_USEDEFAULT, WINDOW_WIDTH, WINDOW_HEIGHT,\
        NULL, NULL, [wc.hInstance], NULL
    mov [hwnd], eax

msg_loop:
    invoke GetMessage, msg, NULL, 0, 0
    cmp eax, 0
    je end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp msg_loop

end_loop:
    invoke ExitProcess, [msg.wParam]

proc WindowProc hwnd_wnd, wmsg, wparam, lparam
    cmp [wmsg], WM_PAINT
    je .wm_paint
    cmp [wmsg], WM_DESTROY
    je .wm_destroy
    invoke DefWindowProc, [hwnd_wnd], [wmsg], [wparam], [lparam]
    ret

.wm_paint:
    cinvoke printf, fmt_wmpaint
    invoke BeginPaint, [hwnd_wnd], ps

    mov [logbrush.lbStyle], BS_SOLID
    mov [logbrush.lbColor], BLACK_COLOR

    invoke ExtCreatePen,\
        PS_GEOMETRIC or PS_SOLID or PS_ENDCAP_FLAT or PS_JOIN_BEVEL,\
        PEN_WIDTH, logbrush, 0, NULL
    mov [hPen], eax
    invoke SelectObject, [ps.hdc], [hPen]
    mov [hOldPen], eax
    invoke Polyline, [ps.hdc], pts1, NUM_POINTS
    invoke SelectObject, [ps.hdc], [hOldPen]
    invoke DeleteObject, [hPen]

    invoke ExtCreatePen,\
        PS_GEOMETRIC or PS_SOLID or PS_ENDCAP_ROUND or PS_JOIN_ROUND,\
        PEN_WIDTH, logbrush, 0, NULL
    mov [hPen], eax
    invoke SelectObject, [ps.hdc], [hPen]
    mov [hOldPen], eax
    invoke Polyline, [ps.hdc], pts2, NUM_POINTS
    invoke SelectObject, [ps.hdc], [hOldPen]
    invoke DeleteObject, [hPen]

    invoke ExtCreatePen,\
        PS_GEOMETRIC or PS_SOLID or PS_ENDCAP_SQUARE or PS_JOIN_MITER,\
        PEN_WIDTH, logbrush, 0, NULL
    mov [hPen], eax
    invoke SelectObject, [ps.hdc], [hPen]
    mov [hOldPen], eax
    invoke Polyline, [ps.hdc], pts3, NUM_POINTS
    invoke SelectObject, [ps.hdc], [hOldPen]
    invoke DeleteObject, [hPen]

    invoke EndPaint, [hwnd_wnd], ps
    xor eax, eax
    ret

.wm_destroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    ret
endp

section '.idata' import data readable writeable
    library kernel32,           'kernel32.dll',\
            user32,             'user32.dll',\
            gdi32,              'gdi32.dll',\
            msvcrt,             'msvcrt.dll'
    import  kernel32,\
            GetModuleHandle,    'GetModuleHandleA',\
            ExitProcess,        'ExitProcess'
    import  user32,\
            LoadIcon,           'LoadIconA',\
            LoadCursor,         'LoadCursorA',\
            RegisterClass,      'RegisterClassA',\
            CreateWindowEx,     'CreateWindowExA',\
            GetMessage,         'GetMessageA',\
            TranslateMessage,   'TranslateMessage',\
            DispatchMessage,    'DispatchMessageA',\
            DefWindowProc,      'DefWindowProcA',\
            BeginPaint,         'BeginPaint',\
            EndPaint,           'EndPaint',\
            PostQuitMessage,    'PostQuitMessage'
    import  gdi32,\
            ExtCreatePen,       'ExtCreatePen',\
            SelectObject,       'SelectObject',\
            DeleteObject,       'DeleteObject',\
            Polyline,           'Polyline'
    import  msvcrt,\
            printf,             'printf'
