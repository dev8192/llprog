format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    wc WNDCLASS
    msg MSG
    ps PAINTSTRUCT
    lb LOGBRUSH
    class_name db 'ExtPenClass', 0
    window_name db 'ExtCreatePen PS_USERSTYLE Demo', 0

    ; draw a dash 30 units long
    ; leave a gap of 10 units
    ; draw a dot 5 units long
    ; leave a gap of 10 units
    ;dash_pattern dd 30, 10, 5, 10

    ; ---- --- -- - -- ---
    SEP = 10
    DASH_COUNT = 12
    dash_pattern dd 40, SEP, 30, SEP, 20, SEP, 10, SEP, 20, SEP, 30, SEP

section '.text' code readable executable
start:
    invoke GetModuleHandle, NULL
    mov [wc.hInstance], eax
    mov [wc.style], CS_HREDRAW or CS_VREDRAW
    mov [wc.lpfnWndProc], WindowProc
    invoke LoadCursor, NULL, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.hbrBackground], COLOR_WINDOW + 1
    mov [wc.lpszClassName], class_name
    invoke RegisterClass, wc

    invoke CreateWindowEx, 0, class_name, window_name, \
        WS_VISIBLE or WS_OVERLAPPEDWINDOW or WS_MAXIMIZE, \
        CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, \
        NULL, NULL, [wc.hInstance], NULL

.msg_loop:
    invoke GetMessage, msg, NULL, 0, 0
    test eax, eax
    je .end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp .msg_loop

.end_loop:
    invoke ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp [wmsg], WM_PAINT
    je .wm_paint
    cmp [wmsg], WM_DESTROY
    je .wm_destroy
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret

.wm_paint:
    invoke BeginPaint, [hwnd], ps
    
    PEN_COLOR = 0x000000FF
    mov [lb.lbStyle], BS_SOLID
    mov [lb.lbColor], PEN_COLOR
    mov [lb.lbHatch], 0

    PEN_WIDTH = SEP
    invoke ExtCreatePen, PS_GEOMETRIC or PS_USERSTYLE or PS_ENDCAP_FLAT, \
        PEN_WIDTH, lb, DASH_COUNT, dash_pattern
    invoke SelectObject, [ps.hdc], eax
    push eax

    LINE_START_X = 50
    LINE_START_Y = 100
    LINE_END_X = 1200
    LINE_END_Y = 100
    invoke MoveToEx, [ps.hdc], LINE_START_X, LINE_START_Y, NULL
    invoke LineTo, [ps.hdc], LINE_END_X, LINE_END_Y

    pop eax
    invoke SelectObject, [ps.hdc], eax
    invoke DeleteObject, eax

    invoke EndPaint, [hwnd], ps
    xor eax, eax
    ret

.wm_destroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    ret
endp

section '.idata' import data readable
    library kernel32, 'kernel32.dll', \
        user32, 'user32.dll', \
        gdi32, 'gdi32.dll'

    import kernel32, \
        ExitProcess, 'ExitProcess', \
        GetModuleHandle, 'GetModuleHandleA'

    import user32, \
        BeginPaint, 'BeginPaint', \
        CreateWindowEx, 'CreateWindowExA', \
        DefWindowProc, 'DefWindowProcA', \
        DispatchMessage, 'DispatchMessageA', \
        EndPaint, 'EndPaint', \
        GetMessage, 'GetMessageA', \
        LoadCursor, 'LoadCursorA', \
        LoadIcon, 'LoadIconA', \
        PostQuitMessage, 'PostQuitMessage', \
        RegisterClass, 'RegisterClassA', \
        TranslateMessage, 'TranslateMessage'

    import gdi32, \
        DeleteObject, 'DeleteObject', \
        ExtCreatePen, 'ExtCreatePen', \
        LineTo, 'LineTo', \
        MoveToEx, 'MoveToEx', \
        SelectObject, 'SelectObject'
