format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    className db 'ExtCreatePenClass', 0
    windowName db 'PS_ALTERNATE Example', 0
    wc WNDCLASS
    msg MSG
    ps PAINTSTRUCT
    lb LOGBRUSH

section '.text' code readable executable
start:
    mov [wc.style], CS_HREDRAW or CS_VREDRAW
    mov [wc.lpfnWndProc], WindowProc
    invoke GetModuleHandle, NULL
    mov [wc.hInstance], eax
    invoke LoadCursor, NULL, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.hbrBackground], COLOR_WINDOW + 1
    mov [wc.lpszClassName], className
    invoke RegisterClass, wc

    invoke CreateWindowEx, 0, className, windowName, \
        WS_VISIBLE or WS_OVERLAPPEDWINDOW,\
        CW_USEDEFAULT, CW_USEDEFAULT, 300, 150,\
        NULL, NULL, [wc.hInstance], NULL

.msg_loop:
    invoke GetMessage, msg, NULL, 0, 0
    test eax, eax
    jz .end_loop
    invoke DispatchMessage, msg
    jmp .msg_loop

.end_loop:
    invoke ExitProcess, [msg.wParam]

proc WindowProc uses ebx esi edi, hwnd, wmsg, wparam, lparam
    cmp [wmsg], WM_PAINT
    je .on_paint
    cmp [wmsg], WM_DESTROY
    je .on_destroy
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    jmp .finish

.on_paint:
    invoke BeginPaint, [hwnd], ps
    mov [lb.lbStyle], BS_SOLID
    invoke ExtCreatePen, PS_COSMETIC or PS_ALTERNATE, 1, lb, 0, NULL
    mov ebx, eax
    invoke SelectObject, [ps.hdc], ebx
    mov esi, eax
    invoke MoveToEx, [ps.hdc], 20, 50, NULL
    invoke LineTo, [ps.hdc], 260, 50
    invoke SelectObject, [ps.hdc], esi
    invoke DeleteObject, ebx
    invoke EndPaint, [hwnd], ps
    xor eax, eax
    jmp .finish

.on_destroy:
    invoke PostQuitMessage, 0
    xor eax, eax

.finish:
    ret
endp

section '.idata' import data readable
    library kernel32, 'kernel32.dll', \
            user32, 'user32.dll', \
            gdi32, 'gdi32.dll'

    import kernel32, \
           GetModuleHandle, 'GetModuleHandleA', \
           ExitProcess, 'ExitProcess'

    import user32, \
           RegisterClass, 'RegisterClassA', \
           CreateWindowEx, 'CreateWindowExA', \
           DefWindowProc, 'DefWindowProcA', \
           GetMessage, 'GetMessageA', \
           DispatchMessage, 'DispatchMessageA', \
           BeginPaint, 'BeginPaint', \
           EndPaint, 'EndPaint', \
           PostQuitMessage, 'PostQuitMessage', \
           LoadCursor, 'LoadCursorA'

    import gdi32, \
           ExtCreatePen, 'ExtCreatePen', \
           SelectObject, 'SelectObject', \
           MoveToEx, 'MoveToEx', \
           LineTo, 'LineTo', \
           DeleteObject, 'DeleteObject'
