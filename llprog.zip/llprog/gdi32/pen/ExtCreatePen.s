format PE GUI 4.0
entry start

include 'win32a.inc'

WINDOW_WIDTH equ 650
WINDOW_HEIGHT equ 300
PEN_WIDTH equ 20
NUM_POINTS equ 3
BLACK_COLOR equ 0x00000000

section '.data' data readable writeable

    wc WNDCLASS
    msg MSG
    ps PAINTSTRUCT
    logbrush LOGBRUSH
    hinstance dd ?
    hwnd dd ?
    hPen dd ?
    hOldPen dd ?

    class_name db 'PenCapJoinDemo', 0
    window_title db 'ExtCreatePen Caps and Joins', 0

    pts1 dd 50, 50, 150, 50, 150, 150
    pts2 dd 250, 50, 350, 50, 350, 150
    pts3 dd 450, 50, 550, 50, 550, 150

section '.code' code readable executable
start:
    invoke GetModuleHandle, NULL
    mov [hinstance], eax

    mov [wc.style], CS_HREDRAW or CS_VREDRAW
    mov [wc.lpfnWndProc], WindowProc
    mov [wc.cbClsExtra], 0
    mov [wc.cbWndExtra], 0
    mov eax, [hinstance]
    mov [wc.hInstance], eax
    invoke LoadIcon, NULL, IDI_APPLICATION
    mov [wc.hIcon], eax
    invoke LoadCursor, NULL, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.hbrBackground], COLOR_WINDOW + 1
    mov [wc.lpszMenuName], NULL
    mov [wc.lpszClassName], class_name
    invoke RegisterClass, wc

    invoke CreateWindowEx, 0, class_name, window_title, \
        WS_VISIBLE or WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, \
        CW_USEDEFAULT, WINDOW_WIDTH, WINDOW_HEIGHT, NULL, NULL, \
        [hinstance], NULL
    mov [hwnd], eax

msg_loop:
    invoke GetMessage, msg, NULL, 0, 0
    cmp eax, 0
    je end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp msg_loop

end_loop:
    invoke ExitProcess, [msg.wParam]

proc WindowProc hwnd_wnd, wmsg, wparam, lparam
    cmp [wmsg], WM_PAINT
    je .wm_paint
    cmp [wmsg], WM_DESTROY
    je .wm_destroy
    invoke DefWindowProc, [hwnd_wnd], [wmsg], [wparam], [lparam]
    jmp .finish

.wm_paint:
    invoke BeginPaint, [hwnd_wnd], ps

    mov [logbrush.lbStyle], BS_SOLID
    mov [logbrush.lbColor], BLACK_COLOR
    mov [logbrush.lbHatch], 0

    invoke ExtCreatePen, PS_GEOMETRIC or PS_SOLID or PS_ENDCAP_FLAT or PS_JOIN_BEVEL, \
        PEN_WIDTH, logbrush, 0, NULL
    mov [hPen], eax
    invoke SelectObject, [ps.hdc], [hPen]
    mov [hOldPen], eax
    invoke Polyline, [ps.hdc], pts1, NUM_POINTS
    invoke SelectObject, [ps.hdc], [hOldPen]
    invoke DeleteObject, [hPen]

    invoke ExtCreatePen, PS_GEOMETRIC or PS_SOLID or PS_ENDCAP_ROUND or PS_JOIN_ROUND, \
        PEN_WIDTH, logbrush, 0, NULL
    mov [hPen], eax
    invoke SelectObject, [ps.hdc], [hPen]
    mov [hOldPen], eax
    invoke Polyline, [ps.hdc], pts2, NUM_POINTS
    invoke SelectObject, [ps.hdc], [hOldPen]
    invoke DeleteObject, [hPen]

    invoke ExtCreatePen, PS_GEOMETRIC or PS_SOLID or PS_ENDCAP_SQUARE or PS_JOIN_MITER, \
        PEN_WIDTH, logbrush, 0, NULL
    mov [hPen], eax
    invoke SelectObject, [ps.hdc], [hPen]
    mov [hOldPen], eax
    invoke Polyline, [ps.hdc], pts3, NUM_POINTS
    invoke SelectObject, [ps.hdc], [hOldPen]
    invoke DeleteObject, [hPen]

    invoke EndPaint, [hwnd_wnd], ps
    xor eax, eax
    jmp .finish

.wm_destroy:
    invoke PostQuitMessage, 0
    xor eax, eax

.finish:
    ret
endp

section '.idata' import data readable writeable
    library kernel32, 'KERNEL32.DLL', \
        user32, 'USER32.DLL', \
        gdi32, 'GDI32.DLL'
    import kernel32, \
        GetModuleHandle, 'GetModuleHandleA', \
        ExitProcess, 'ExitProcess'
    import user32, \
        LoadIcon, 'LoadIconA', \
        LoadCursor, 'LoadCursorA', \
        RegisterClass, 'RegisterClassA', \
        CreateWindowEx, 'CreateWindowExA', \
        GetMessage, 'GetMessageA', \
        TranslateMessage, 'TranslateMessage', \
        DispatchMessage, 'DispatchMessageA', \
        DefWindowProc, 'DefWindowProcA', \
        BeginPaint, 'BeginPaint', \
        EndPaint, 'EndPaint', \
        PostQuitMessage, 'PostQuitMessage'
    import gdi32, \
        ExtCreatePen, 'ExtCreatePen', \
        SelectObject, 'SelectObject', \
        DeleteObject, 'DeleteObject', \
        Polyline, 'Polyline'
