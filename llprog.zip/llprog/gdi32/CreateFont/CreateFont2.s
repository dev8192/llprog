format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    hFont       dd ?
    wc          WNDCLASS
    msg         MSG
    ps          PAINTSTRUCT
    rect        RECT
    _class      db 'ExampleWindow', 0
    _title      db 'Example Window', 0
    _text       db 'hello world', 0
    _fontface   db 'hello444', 0

section '.text' code readable executable
start:
    mov [wc.style], CS_HREDRAW or CS_VREDRAW
    mov [wc.lpfnWndProc], WindowProc
    invoke LoadIcon, 0, IDI_APPLICATION
    mov [wc.hIcon], eax
    invoke LoadCursor, 0, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.hbrBackground], COLOR_WINDOW + 1
    mov [wc.lpszClassName], _class
    invoke RegisterClass, wc

    invoke  CreateWindowEx, 0, _class, _title,\
            WS_OVERLAPPEDWINDOW or WS_VISIBLE,\
            CW_USEDEFAULT, CW_USEDEFAULT, 400, 300,\
            0, 0, 0, 0

.msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    test eax, eax
    jz .end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp .msg_loop
.end_loop:
    invoke ExitProcess, [msg.wParam]

proc WindowProc, hwnd, wmsg, wparam, lparam
    cmp     [wmsg], WM_CREATE
    je      .wm_create
    cmp     [wmsg], WM_PAINT
    je      .wm_paint
    cmp     [wmsg], WM_DESTROY
    je      .wm_destroy
    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret

.wm_create:
    invoke  CreateFont, -48, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,\
            ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,\
            DEFAULT_QUALITY, FIXED_PITCH or FF_MODERN, _fontface
    mov     [hFont], eax
    xor     eax, eax
    ret

.wm_paint:
    invoke  BeginPaint, [hwnd], ps
    stdcall draw_text, [hwnd]
    invoke  EndPaint, [hwnd], ps
    xor     eax, eax
    ret

.wm_destroy:
    invoke  DeleteObject, [hFont]
    invoke  PostQuitMessage, 0
    xor     eax, eax
    ret
endp

proc draw_text1, hwnd
    invoke  SelectObject, [ps.hdc], [hFont]
    push    eax
    invoke  GetClientRect, [hwnd], rect
    invoke  DrawText, [ps.hdc], _text, -1, rect,\
            DT_CENTER or DT_VCENTER or DT_SINGLELINE
    pop     eax
    invoke  SelectObject, [ps.hdc], eax
    ret
endp

proc draw_text, hwnd
    invoke  GetClientRect, [hwnd], rect
    invoke  DrawText, [ps.hdc], _text, -1, rect,\
            DT_CENTER or DT_VCENTER or DT_SINGLELINE
    ret
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            user32,             'user32.dll',\
            gdi32,              'gdi32.dll',\
            msvcrt,             'msvcrt.dll'
    import  kernel32,\
            GetModuleHandle,    'GetModuleHandleA',\
            ExitProcess,        'ExitProcess'
    import  user32,\
            LoadIcon,           'LoadIconA',\
            LoadCursor,         'LoadCursorA',\
            RegisterClass,      'RegisterClassA',\
            CreateWindowEx,     'CreateWindowExA',\
            GetMessage,         'GetMessageA',\
            TranslateMessage,   'TranslateMessage',\
            DispatchMessage,    'DispatchMessageA',\
            DefWindowProc,      'DefWindowProcA',\
            BeginPaint,         'BeginPaint',\
            GetClientRect,      'GetClientRect',\
            DrawText,           'DrawTextA',\
            EndPaint,           'EndPaint',\
            PostQuitMessage,    'PostQuitMessage'
    import  gdi32,\
            CreateFont,         'CreateFontA',\
            SelectObject,       'SelectObject',\
            DeleteObject,       'DeleteObject'
    import  msvcrt,\
            puts,               'puts'
