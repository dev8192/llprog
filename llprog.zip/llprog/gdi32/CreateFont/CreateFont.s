format PE
entry start

include 'win32ax.inc'

LANG_ENGLISH_US = 0x0409
ERROR_SUCCESS   = 0

section '.data' data readable writeable
    fmt_success db 'Success: %x', 10, 0
    fmt_err     db "Error %u (0x%X): '%s'", 10, 0
    buffer      rb 256
    font_name1  db 'Consolas', 0
    font_name2  db 'hello333', 0
   ;font_name3  db 9000000 dup('a'), 0

section '.text' code readable executable
start:
    stdcall main
    invoke  ExitProcess, 0

proc create_font uses ebx, cHeight, cWidth, cEscapement, cOrientation, cWeight,\
        bItalic, bUnderline, bStrikeOut, iCharSet, iOutPrecision,\
        iClipPrecision, iQuality, iPitchAndFamily, pszFaceName

    invoke  SetLastError, ERROR_SUCCESS
    invoke  CreateFont, [cHeight], [cWidth], [cEscapement], [cOrientation], [cWeight],\
            [bItalic], [bUnderline], [bStrikeOut], [iCharSet], [iOutPrecision],\
            [iClipPrecision], [iQuality], [iPitchAndFamily], [pszFaceName]
    test    eax, eax
    jz      .error
    cinvoke printf, fmt_success, eax
    jmp     .done
.error:
    invoke  GetLastError
    mov     ebx, eax
    invoke  FormatMessage,\
            FORMAT_MESSAGE_FROM_SYSTEM + FORMAT_MESSAGE_MAX_WIDTH_MASK,\
            0, eax, LANG_ENGLISH_US, buffer, 256, 0
    cinvoke printf, fmt_err, ebx, ebx, buffer
.done:
    ret
endp

; ----------------------------------------------------------
; no error
; ----------------------------------------------------------
proc main
    stdcall create_font, 60, 0, 0, 0, FW_BOLD,\
            0, 0, 0, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,\
            CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FIXED_PITCH, font_name2
    stdcall create_font, 60, 0, 0, 0, FW_BOLD,\
            0, 0, 0, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,\
            CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FIXED_PITCH, 0
    stdcall create_font, -48, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,\
            ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,\
            DEFAULT_QUALITY, FIXED_PITCH or FF_MODERN, 0
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            gdi32,          'gdi32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess',\
            FormatMessage,  'FormatMessageA',\
            GetLastError,   'GetLastError',\
            SetLastError,   'SetLastError'
    import  gdi32,\
            CreateFont,     'CreateFontA'
    import  msvcrt,\
            printf,         'printf'
