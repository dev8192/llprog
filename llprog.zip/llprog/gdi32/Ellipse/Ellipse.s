format PE GUI
entry start

include 'win32a.inc'

section '.data' data readable writeable
    class_name db 'EllipseClass', 0
    title      db 'Ellipse Example', 0
    wc         WNDCLASSEX
    msg        MSG
    ps         PAINTSTRUCT

section '.text' code readable executable
start:
    mov     [wc.cbSize], sizeof.WNDCLASSEX
    mov     [wc.lpfnWndProc], WindowProc
    mov     [wc.style], CS_HREDRAW + CS_VREDRAW
    mov     [wc.hbrBackground], COLOR_WINDOW + 1
    mov     [wc.lpszClassName], class_name

    invoke  GetModuleHandle, 0
    mov     [wc.hInstance], eax

    invoke  LoadCursor, 0, IDC_ARROW
    mov     [wc.hCursor], eax

    invoke  RegisterClassEx, wc

    invoke  CreateWindowEx, 0, class_name, title, WS_VISIBLE + WS_OVERLAPPEDWINDOW, 128, 128, 400, 300, 0, 0, [wc.hInstance], 0

  .msg_loop:
    invoke  GetMessage, msg, 0, 0, 0
    test    eax, eax
    je      .end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     .msg_loop

  .end_loop:
    invoke  ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp     [wmsg], WM_PAINT
    je      .wm_paint
    cmp     [wmsg], WM_DESTROY
    je      .wm_destroy

    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret

  .wm_paint:
    invoke  BeginPaint, [hwnd], ps
    ;invoke  Ellipse, eax, 50, 50, 330, 200
    invoke  Ellipse, \
        eax, \          ; HDC hdc
        50, \           ; int left
        50, \           ; int top
        200, \          ; int right
        200             ; int bottom
    invoke  EndPaint, [hwnd], ps
    xor     eax, eax
    ret

  .wm_destroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
    ret
endp

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL',\
            user32, 'USER32.DLL',\
            gdi32, 'GDI32.DLL'

    import  kernel32,\
            GetModuleHandle, 'GetModuleHandleA',\
            ExitProcess, 'ExitProcess'

    import  user32,\
            RegisterClassEx, 'RegisterClassExA',\
            CreateWindowEx, 'CreateWindowExA',\
            DefWindowProc, 'DefWindowProcA',\
            GetMessage, 'GetMessageA',\
            TranslateMessage, 'TranslateMessage',\
            DispatchMessage, 'DispatchMessageA',\
            LoadCursor, 'LoadCursorA',\
            PostQuitMessage, 'PostQuitMessage',\
            BeginPaint, 'BeginPaint',\
            EndPaint, 'EndPaint'

    import  gdi32,\
            Ellipse, 'Ellipse'
