format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    cls_name db 'CircleClass', 0
    wnd_name db 'Circle', 0
    wc WNDCLASSEX
    msg MSG
    hwnd dd ?
    ps PAINTSTRUCT
    rect RECT

section '.text' code readable executable
start:
    invoke GetModuleHandle, NULL
    mov [wc.hInstance], eax
    mov [wc.cbSize], sizeof.WNDCLASSEX
    mov [wc.style], CS_HREDRAW or CS_VREDRAW
    mov [wc.lpfnWndProc], WindowProc
    mov [wc.hbrBackground], COLOR_WINDOW + 1
    mov [wc.lpszClassName], cls_name

    invoke LoadCursor, NULL, IDC_ARROW
    mov [wc.hCursor], eax

    invoke RegisterClassEx, wc

    invoke CreateWindowEx, 0, cls_name, wnd_name, \
        WS_OVERLAPPEDWINDOW or WS_VISIBLE, \
        CW_USEDEFAULT, CW_USEDEFAULT, 300, 300, \
        NULL, NULL, [wc.hInstance], NULL
    mov [hwnd], eax

msg_loop:
    invoke GetMessage, msg, NULL, 0, 0
    test eax, eax
    jz end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp msg_loop

end_loop:
    invoke ExitProcess, [msg.wParam]

proc WindowProc wnd, wmsg, wparam, lparam
    cmp [wmsg], WM_DESTROY
    je .wmdestroy
    cmp [wmsg], WM_PAINT
    je .wmpaint

.defwndproc:
    invoke DefWindowProc, [wnd], [wmsg], [wparam], [lparam]
    ret

.wmpaint:
    invoke BeginPaint, [wnd], ps
    invoke GetClientRect, [wnd], rect
    invoke Ellipse, [ps.hdc], [rect.left], [rect.top], [rect.right], [rect.bottom]
    invoke EndPaint, [wnd], ps
    xor eax, eax
    ret

.wmdestroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    ret
endp

section '.idata' import data readable writeable
    library kernel32, 'kernel32.dll', \
        user32, 'user32.dll', \
        gdi32, 'gdi32.dll'

    import kernel32, \
        GetModuleHandle, 'GetModuleHandleA', \
        ExitProcess, 'ExitProcess'

    import user32, \
        LoadCursor, 'LoadCursorA', \
        RegisterClassEx, 'RegisterClassExA', \
        CreateWindowEx, 'CreateWindowExA', \
        GetMessage, 'GetMessageA', \
        TranslateMessage, 'TranslateMessage', \
        DispatchMessage, 'DispatchMessageA', \
        DefWindowProc, 'DefWindowProcA', \
        BeginPaint, 'BeginPaint', \
        GetClientRect, 'GetClientRect', \
        EndPaint, 'EndPaint', \
        PostQuitMessage, 'PostQuitMessage'

    import gdi32, \
        Ellipse, 'Ellipse'
