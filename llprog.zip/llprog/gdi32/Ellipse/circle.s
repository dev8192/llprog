format PE
entry start

include 'win32a.inc'

CIRCLE_DIAMETER = 500
COLOR_RED = 0x0000FF
WINDOW_STYLE = WS_VISIBLE or WS_OVERLAPPED or WS_CAPTION or WS_SYSMENU

section '.data' data readable writeable
    className db 'RedCircle', 0
    windowName db 'Circle', 0
    wc WNDCLASS
    msg MSG
    rect RECT 0, 0, CIRCLE_DIAMETER, CIRCLE_DIAMETER
    ps PAINTSTRUCT
    hBrush dd ?
    hOldBrush dd ?
    hOldPen dd ?
    fmt_num db '%d %d', 10, 0
    pos_x dd ?
    pos_y dd ?

section '.code' code readable executable
start:
    invoke GetModuleHandle, 0
    mov [wc.hInstance], eax
    mov [wc.style], CS_HREDRAW or CS_VREDRAW
    mov [wc.lpfnWndProc], WindowProc
    invoke LoadCursor, 0, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.hbrBackground], COLOR_WINDOW + 1
    mov [wc.lpszClassName], className
    invoke RegisterClass, wc

    invoke AdjustWindowRect, rect, WINDOW_STYLE, FALSE

    invoke GetSystemMetrics, SM_CXSCREEN
    mov esi, [rect.right]
    sub esi, [rect.left]
    sub eax, esi
    shr eax, 1
    mov [pos_x], eax

    invoke GetSystemMetrics, SM_CYSCREEN
    mov edi, [rect.bottom]
    sub edi, [rect.top]
    sub eax, edi
    shr eax, 1
    mov [pos_y], eax
    
    ;cinvoke printf, fmt_num, [pos_x], [pos_y]
    ;invoke ExitProcess, 0

    invoke CreateWindowEx, 0, className, windowName, WINDOW_STYLE,\
        [pos_x], [pos_y], esi, edi, 0, 0, [wc.hInstance], 0

.msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    cmp eax, 0
    jle .end_loop
    invoke DispatchMessage, msg
    jmp .msg_loop

.end_loop:
    invoke ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp [wmsg], WM_PAINT
    je .wm_paint
    cmp [wmsg], WM_DESTROY
    je .wm_destroy
.defwindowproc:
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret

.wm_paint:
    invoke BeginPaint, [hwnd], ps
    stdcall DrawCircle30, ps
    invoke EndPaint, [hwnd], ps
    xor eax, eax
    ret

.wm_destroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    ret
endp

proc DrawCircle10, ps
    invoke Ellipse, [ps.hdc], 0, 0, CIRCLE_DIAMETER, CIRCLE_DIAMETER
    ret
endp

proc DrawCircle20, ps
    invoke CreateSolidBrush, COLOR_RED
    mov [hBrush], eax
    invoke SelectObject, [ps.hdc], eax
    mov [hOldBrush], eax
    invoke Ellipse, [ps.hdc], 0, 0, CIRCLE_DIAMETER, CIRCLE_DIAMETER
    invoke SelectObject, [ps.hdc], [hOldBrush]
    invoke DeleteObject, [hBrush]
    ret
endp

proc DrawCircle30, ps
    invoke CreateSolidBrush, COLOR_RED
    mov [hBrush], eax
    invoke SelectObject, [ps.hdc], eax
    mov [hOldBrush], eax
    invoke GetStockObject, NULL_PEN
    invoke SelectObject, [ps.hdc], eax
    mov [hOldPen], eax
    invoke Ellipse, [ps.hdc], 0, 0, CIRCLE_DIAMETER, CIRCLE_DIAMETER
    invoke SelectObject, [ps.hdc], [hOldBrush]
    invoke DeleteObject, [hBrush]
    invoke SelectObject, [ps.hdc], [hOldPen]
    ret
endp

section '.idata' import data readable
    library kernel32,               'kernel32.dll',\
            user32,                 'user32.dll',\
            gdi32,                  'gdi32.dll',\
            msvcrt,                 'msvcrt.dll'
    import  kernel32,\
            GetModuleHandle,        'GetModuleHandleA',\
            ExitProcess,            'ExitProcess'
    import  user32,\
            RegisterClass,          'RegisterClassA',\
            AdjustWindowRect,       'AdjustWindowRect',\
            GetSystemMetrics,       'GetSystemMetrics',\
            CreateWindowEx,         'CreateWindowExA',\
            GetMessage,             'GetMessageA',\
            TranslateMessage,       'TranslateMessage',\
            DispatchMessage,        'DispatchMessageA',\
            DefWindowProc,          'DefWindowProcA',\
            PostQuitMessage,        'PostQuitMessage',\
            LoadCursor,             'LoadCursorA',\
            BeginPaint,             'BeginPaint',\
            EndPaint,               'EndPaint'
    import  gdi32,\
            GetStockObject,         'GetStockObject',\
            CreateSolidBrush,       'CreateSolidBrush',\
            CreatePen,              'CreatePen',\
            SelectObject,           'SelectObject',\
            DeleteObject,           'DeleteObject',\
            Ellipse,                'Ellipse'
    import  msvcrt,\
            printf,                 'printf'
