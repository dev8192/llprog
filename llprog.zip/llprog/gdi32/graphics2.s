format PE GUI 4.0
entry start

section '.code' code readable executable
start:
    ; 1. Get the Device Context for the whole screen
    push 0
    call [GetDC]
    mov edi, eax    ; EDI = HDC

    ; 2. Draw Green Square
    push 0x00FF00   ; Color: Green
    call [CreateSolidBrush]
    push eax        ; Save brush for cleanup
    push eax        ; Select it
    push edi
    call [SelectObject]

    push 200        ; bottom
    push 200        ; right
    push 50         ; top
    push 50         ; left
    push edi
    call [Rectangle]
    call [DeleteObject]

    ; 3. Draw Red Circle
    push 0x0000FF   ; Color: Red
    call [CreateSolidBrush]
    push eax
    push eax
    push edi
    call [SelectObject]

    push 200        ; bottom
    push 400        ; right
    push 50         ; top
    push 250        ; left
    push edi
    call [Ellipse]
    call [DeleteObject]

    ; 4. Cleanup and Exit
    push 0
    push edi
    call [ReleaseDC]
    
    push 0
    call [ExitProcess]

; --- Minimal Import Table ---
section '.idata' import data readable
    dd 0,0,0, rva k_name, rva k_table
    dd 0,0,0, rva u_name, rva u_table
    dd 0,0,0, rva g_name, rva g_table
    dd 0,0,0,0,0

    k_table: ExitProcess dd rva _ExitProcess
             dd 0
    u_table: GetDC       dd rva _GetDC
             ReleaseDC   dd rva _ReleaseDC
             dd 0
    g_table: Rectangle   dd rva _Rectangle
             Ellipse     dd rva _Ellipse
             CreateSolidBrush dd rva _CreateSolidBrush
             SelectObject     dd rva _SelectObject
             DeleteObject     dd rva _DeleteObject
             dd 0

    k_name db 'kernel32.dll',0
    u_name db 'user32.dll',0
    g_name db 'gdi32.dll',0

    _ExitProcess      dw 0
                      db 'ExitProcess',0
    _GetDC            dw 0
                      db 'GetDC',0
    _ReleaseDC        dw 0
                      db 'ReleaseDC',0
    _Rectangle        dw 0
                      db 'Rectangle',0
    _Ellipse          dw 0
                      db 'Ellipse',0
    _CreateSolidBrush dw 0
                      db 'CreateSolidBrush',0
    _SelectObject     dw 0
                      db 'SelectObject',0
    _DeleteObject     dw 0
                      db 'DeleteObject',0