; this works!!!!!!!!!!!1

format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
  _class      db 'FASM_Drawing',0
  _title      db 'Assembly Drawing Demo',0
  
  wc          WNDCLASSEX
  msg         MSG
  ps          PAINTSTRUCT
  
  hGreenBrush dd ?
  hRedBrush   dd ?

section '.code' code readable executable

start:
    mov     [wc.cbSize], sizeof.WNDCLASSEX
    mov     [wc.lpfnWndProc], WindowProc
    mov     [wc.style], CS_HREDRAW + CS_VREDRAW
    invoke  GetModuleHandle, 0
    mov     [wc.hInstance], eax
    mov     [wc.lpszClassName], _class
    invoke  LoadCursor, 0, IDC_ARROW
    mov     [wc.hCursor], eax
    mov     [wc.hbrBackground], COLOR_WINDOW + 1
    invoke  RegisterClassEx, wc

    ;dwStyle = WS_VISIBLE
    dwStyle = WS_VISIBLE + WS_SYSMENU

    invoke  CreateWindowEx, 0, _class, _title, dwStyle, \
            100, 100, 400, 300, 0, 0, [wc.hInstance], 0

    msg_loop:
    invoke  GetMessage, msg, 0, 0, 0
    test    eax, eax
    jz      end_prog
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     msg_loop

    end_prog:
    invoke  ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp     [wmsg], WM_PAINT
    je      .draw
    cmp     [wmsg], WM_DESTROY
    je      .close
    
    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret

.draw:
    invoke  BeginPaint, [hwnd], ps
    mov     edi, eax ; EDI = Device Context (HDC)

    invoke  CreateSolidBrush, 0x00FF00 ; Green
    mov     [hGreenBrush], eax
    invoke  SelectObject, edi, [hGreenBrush]
    ; (HDC, Left, Top, Right, Bottom)
    invoke  Rectangle, edi, 50, 50, 150, 150
    invoke  DeleteObject, [hGreenBrush]

    invoke  CreateSolidBrush, 0x0000FF ; Red
    mov     [hRedBrush], eax
    invoke  SelectObject, edi, [hRedBrush]
    ; (HDC, Left, Top, Right, Bottom)
    invoke  Ellipse, edi, 200, 50, 300, 150
    invoke  DeleteObject, [hRedBrush]

    invoke  EndPaint, [hwnd], ps
    xor     eax, eax
    ret

.close:
    invoke  PostQuitMessage, 0
    xor     eax, eax
    ret
endp

section '.idata' import data readable
    library kernel32,           'KERNEL32.DLL',\
            user32,             'USER32.DLL',\
            gdi32,              'GDI32.DLL'
    import  kernel32,\
            GetModuleHandle,    'GetModuleHandleA',\
            ExitProcess,        'ExitProcess'
    import  user32,\
            RegisterClassEx,    'RegisterClassExA',\
            CreateWindowEx,     'CreateWindowExA',\
            GetMessage,         'GetMessageA',\
            TranslateMessage,   'TranslateMessage',\
            DispatchMessage,    'DispatchMessageA',\
            PostQuitMessage,    'PostQuitMessage',\
            BeginPaint,         'BeginPaint',\
            EndPaint,           'EndPaint',\
            DefWindowProc,      'DefWindowProcA',\
            LoadCursor,         'LoadCursorA'
    import  gdi32,\
            CreateSolidBrush,   'CreateSolidBrush',\
            SelectObject,       'SelectObject',\
            Rectangle,          'Rectangle',\
            Ellipse,            'Ellipse',\
            DeleteObject,       'DeleteObject'
