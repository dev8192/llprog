format PE
entry start

include 'win32a.inc'

HIT_MARGIN = 8
MIN_SIZE = 50
HTCLIENT = 1

DRAG_LEFT   = 1
DRAG_RIGHT  = 2
DRAG_TOP    = 4
DRAG_BOTTOM = 8

section '.data' data readable writeable
    mainClass db 'MainWndClass', 0
    mainTitle db 'Resizable Rectangle', 0
    fmt db '%dx%d', 0
    
    wc WNDCLASSEX
    msg MSG
    ps PAINTSTRUCT
    rect RECT 100, 100, 400, 300
    
    dragState dd 0
    hoverState dd 0
    
    hCurArrow dd ?
    hCurWE dd ?
    hCurNS dd ?
    hCurNWSE dd ?
    hCurNESW dd ?
    hActiveCursor dd ?
    
    strBuf rb 64

section '.text' code readable executable
start:
    invoke GetModuleHandle, NULL
    mov [wc.hInstance], eax
    mov [wc.cbSize], sizeof.WNDCLASSEX
    mov [wc.style], CS_HREDRAW or CS_VREDRAW
    mov [wc.lpfnWndProc], WindowProc
    invoke LoadCursor, NULL, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.hbrBackground], COLOR_WINDOW + 1
    mov [wc.lpszClassName], mainClass
    invoke RegisterClassEx, wc

    invoke CreateWindowEx, 0, mainClass, mainTitle, \
        WS_VISIBLE or WS_OVERLAPPEDWINDOW or WS_MAXIMIZE, \
        CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, \
        NULL, NULL, [wc.hInstance], NULL

.msg_loop:
    invoke GetMessage, msg, NULL, 0, 0
    test eax, eax
    jz .end_loop
    invoke DispatchMessage, msg
    jmp .msg_loop

.end_loop:
    invoke ExitProcess, [msg.wParam]

proc WindowProc uses ebx esi edi, hwnd, wmsg, wparam, lparam
    cmp [wmsg], WM_CREATE
    je .on_create
    cmp [wmsg], WM_PAINT
    je .on_paint
    cmp [wmsg], WM_MOUSEMOVE
    je .on_mousemove
    cmp [wmsg], WM_LBUTTONDOWN
    je .on_lbuttondown
    cmp [wmsg], WM_LBUTTONUP
    je .on_lbuttonup
    cmp [wmsg], WM_SETCURSOR
    je .on_setcursor
    cmp [wmsg], WM_DESTROY
    je .on_destroy
.defproc:
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret

.on_create:
    invoke LoadCursor, NULL, IDC_ARROW
    mov [hCurArrow], eax
    mov [hActiveCursor], eax
    invoke LoadCursor, NULL, IDC_SIZEWE
    mov [hCurWE], eax
    invoke LoadCursor, NULL, IDC_SIZENS
    mov [hCurNS], eax
    invoke LoadCursor, NULL, IDC_SIZENWSE
    mov [hCurNWSE], eax
    invoke LoadCursor, NULL, IDC_SIZENESW
    mov [hCurNESW], eax
    xor eax, eax
    ret

.on_paint:
    invoke BeginPaint, [hwnd], ps
    invoke GetStockObject, BLACK_PEN
    invoke SelectObject, [ps.hdc], eax
    invoke GetStockObject, NULL_BRUSH
    invoke SelectObject, [ps.hdc], eax
    invoke Rectangle, [ps.hdc],\
        [rect.left], [rect.top], [rect.right], [rect.bottom]
    
    mov eax, [rect.right]
    sub eax, [rect.left]
    mov ebx, [rect.bottom]
    sub ebx, [rect.top]
    cinvoke sprintf, strBuf, fmt, eax, ebx
    
    invoke SetBkMode, [ps.hdc], TRANSPARENT
    invoke DrawText, [ps.hdc], strBuf, -1, rect,\
        DT_CENTER or DT_VCENTER or DT_SINGLELINE
    invoke EndPaint, [hwnd], ps
    xor eax, eax
    ret

.on_mousemove:
    movsx esi, word [lparam]
    mov eax, [lparam]
    shr eax, 16
    movsx edi, ax

    cmp [dragState], 0
    jne .drag_active

    stdcall GetHitState, esi, edi
    mov [hoverState], eax
    stdcall UpdateCursor, eax
    ret

.drag_active:
    test [dragState], DRAG_LEFT
    jz .drag_r
    mov eax, [rect.right]
    sub eax, MIN_SIZE
    cmp esi, eax
    jle .set_l
    mov esi, eax
.set_l:
    mov [rect.left], esi
.drag_r:
    test [dragState], DRAG_RIGHT
    jz .drag_t
    mov eax, [rect.left]
    add eax, MIN_SIZE
    cmp esi, eax
    jge .set_r
    mov esi, eax
.set_r:
    mov [rect.right], esi
.drag_t:
    test [dragState], DRAG_TOP
    jz .drag_b
    mov eax, [rect.bottom]
    sub eax, MIN_SIZE
    cmp edi, eax
    jle .set_t
    mov edi, eax
.set_t:
    mov [rect.top], edi
.drag_b:
    test [dragState], DRAG_BOTTOM
    jz .drag_done
    mov eax, [rect.top]
    add eax, MIN_SIZE
    cmp edi, eax
    jge .set_b
    mov edi, eax
.set_b:
    mov [rect.bottom], edi
.drag_done:
    invoke InvalidateRect, [hwnd], NULL, TRUE
    xor eax, eax
    ret

.on_lbuttondown:
    movsx esi, word [lparam]
    mov eax, [lparam]
    shr eax, 16
    movsx edi, ax
    stdcall GetHitState, esi, edi
    test eax, eax
    jz .defproc
    mov [dragState], eax
    invoke SetCapture, [hwnd]
    xor eax, eax
    ret

.on_lbuttonup:
    cmp [dragState], 0
    je .defproc
    mov [dragState], 0
    invoke ReleaseCapture
    xor eax, eax
    ret

.on_setcursor:
    mov eax, [lparam]
    and eax, 0FFFFh
    cmp eax, HTCLIENT
    jne .defproc
    cmp [dragState], 0
    jne .set_active
    cmp [hoverState], 0
    je .defproc
.set_active:
    invoke SetCursor, [hActiveCursor]
    mov eax, TRUE
    ret

.on_destroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    ret
endp ; WindowProc

proc GetHitState uses ebx esi edi, x, y
    mov esi, [x]
    mov edi, [y]
    xor ebx, ebx

    mov eax, [rect.left]
    sub eax, HIT_MARGIN
    cmp esi, eax
    jl .done
    mov eax, [rect.right]
    add eax, HIT_MARGIN
    cmp esi, eax
    jg .done
    mov eax, [rect.top]
    sub eax, HIT_MARGIN
    cmp edi, eax
    jl .done
    mov eax, [rect.bottom]
    add eax, HIT_MARGIN
    cmp edi, eax
    jg .done

    mov eax, esi
    sub eax, [rect.left]
    cdq
    xor eax, edx
    sub eax, edx
    cmp eax, HIT_MARGIN
    jg .chk_right
    or ebx, DRAG_LEFT
.chk_right:
    mov eax, esi
    sub eax, [rect.right]
    cdq
    xor eax, edx
    sub eax, edx
    cmp eax, HIT_MARGIN
    jg .chk_top
    or ebx, DRAG_RIGHT
.chk_top:
    mov eax, edi
    sub eax, [rect.top]
    cdq
    xor eax, edx
    sub eax, edx
    cmp eax, HIT_MARGIN
    jg .chk_bottom
    or ebx, DRAG_TOP
.chk_bottom:
    mov eax, edi
    sub eax, [rect.bottom]
    cdq
    xor eax, edx
    sub eax, edx
    cmp eax, HIT_MARGIN
    jg .done
    or ebx, DRAG_BOTTOM
.done:
    mov eax, ebx
    ret
endp ; GetHitState

proc UpdateCursor uses ebx, state
    mov eax, [state]
    test eax, eax
    jz .arrow
    cmp eax, DRAG_LEFT
    je .we
    cmp eax, DRAG_RIGHT
    je .we
    cmp eax, DRAG_TOP
    je .ns
    cmp eax, DRAG_BOTTOM
    je .ns
    cmp eax, DRAG_TOP or DRAG_LEFT
    je .nwse
    cmp eax, DRAG_BOTTOM or DRAG_RIGHT
    je .nwse
    cmp eax, DRAG_TOP or DRAG_RIGHT
    je .nesw
    cmp eax, DRAG_BOTTOM or DRAG_LEFT
    je .nesw
.we:
    mov eax, [hCurWE]
    jmp .done
.ns:
    mov eax, [hCurNS]
    jmp .done
.nwse:
    mov eax, [hCurNWSE]
    jmp .done
.nesw:
    mov eax, [hCurNESW]
    jmp .done
.arrow:
    mov eax, [hCurArrow]
.done:
    mov [hActiveCursor], eax
    invoke SetCursor, eax
    ret
endp

section '.idata' import data readable
    library kernel32, 'kernel32.dll', \
            user32, 'user32.dll', \
            gdi32, 'gdi32.dll', \
            msvcrt, 'msvcrt.dll'

    import kernel32, \
           GetModuleHandle, 'GetModuleHandleA', \
           ExitProcess, 'ExitProcess'

    import user32, \
           RegisterClassEx, 'RegisterClassExA', \
           CreateWindowEx, 'CreateWindowExA', \
           DefWindowProc, 'DefWindowProcA', \
           GetMessage, 'GetMessageA', \
           DispatchMessage, 'DispatchMessageA', \
           PostQuitMessage, 'PostQuitMessage', \
           LoadCursor, 'LoadCursorA', \
           SetCursor, 'SetCursor', \
           SetCapture, 'SetCapture', \
           ReleaseCapture, 'ReleaseCapture', \
           InvalidateRect, 'InvalidateRect', \
           BeginPaint, 'BeginPaint', \
           EndPaint, 'EndPaint', \
           DrawText, 'DrawTextA'

    import gdi32, \
           GetStockObject, 'GetStockObject', \
           SelectObject, 'SelectObject', \
           SetBkMode, 'SetBkMode', \
           Rectangle, 'Rectangle'

    import msvcrt, \
           sprintf, 'sprintf'
