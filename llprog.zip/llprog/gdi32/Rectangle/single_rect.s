format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    class_name db 'ExampleWindow', 0
    window_name db 'Example Window', 0
    wc WNDCLASS
    msg MSG
    ps PAINTSTRUCT
    rect RECT
    hPen dd ?
    hOldPen dd ?
    hBrush dd ?
    hOldBrush dd ?

section '.text' code readable executable
start:
    invoke GetModuleHandle, 0
    mov [wc.hInstance], eax
    mov [wc.style], CS_HREDRAW or CS_VREDRAW
    mov [wc.lpfnWndProc], WindowProc
    invoke LoadCursor, 0, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.hbrBackground], COLOR_WINDOW + 1
    mov [wc.lpszClassName], class_name
    invoke RegisterClass, wc

    invoke CreateWindowEx, 0, class_name, window_name,\
        WS_VISIBLE or WS_OVERLAPPEDWINDOW or WS_MAXIMIZE,\
        CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,\
        0, 0, [wc.hInstance], 0

.msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    test eax, eax
    jle .end_loop
    invoke DispatchMessage, msg
    jmp .msg_loop

.end_loop:
    invoke ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp [wmsg], WM_PAINT
    je .wm_paint
    cmp [wmsg], WM_DESTROY
    je .wm_destroy
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret

.wm_paint:
    stdcall DrawRect30, [hwnd]
    ret

.wm_destroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    ret
endp

; ------------------------------------------------------------------------------
; Basic example
; ------------------------------------------------------------------------------
proc DrawRect10, hwnd
    invoke BeginPaint, [hwnd], ps
    invoke Rectangle, [ps.hdc], 500, 100, 300, 600
    invoke EndPaint, [hwnd], ps
    xor eax, eax
    ret
endp

; ------------------------------------------------------------------------------
; Add a RECT struct
; ------------------------------------------------------------------------------
proc DrawRect20, hwnd
    invoke BeginPaint, [hwnd], ps
    mov [rect.left], 100
    mov [rect.top], 100
    mov [rect.right], 500
    mov [rect.bottom], 500
    invoke Rectangle, [ps.hdc],\
        [rect.left], [rect.top], [rect.right], [rect.bottom]
    invoke EndPaint, [hwnd], ps
    xor eax, eax
    ret
endp

; ------------------------------------------------------------------------------
; Add a pen and store it in a register
; ------------------------------------------------------------------------------
proc DrawRect30 uses ebx esi, hwnd
    invoke BeginPaint, [hwnd], ps
    ;invoke CreatePen, PS_SOLID, 10, 0x0000FF
    invoke CreatePen, PS_DASH, 1, 0x00FF00
    ;invoke CreatePen, PS_DOT, 1, 0xFF0000
    mov ebx, eax
    invoke SelectObject, [ps.hdc], ebx
    mov esi, eax
    invoke Rectangle, [ps.hdc], 50, 50, 200, 200
    invoke SelectObject, [ps.hdc], esi
    invoke DeleteObject, ebx
    invoke EndPaint, [hwnd], ps
    xor eax, eax
    ret
endp

; ------------------------------------------------------------------------------
; Add a pen and store it in memory
; ------------------------------------------------------------------------------
proc DrawRect35, hwnd
    invoke BeginPaint, [hwnd], ps
    invoke CreatePen, PS_SOLID, 10, 0x0000FF
    mov [hPen], eax
    invoke SelectObject, [ps.hdc], [hPen]
    mov [hOldPen], eax
    invoke Rectangle, [ps.hdc], 50, 50, 200, 200
    invoke SelectObject, [ps.hdc], [hOldPen]
    invoke DeleteObject, [hPen]
    invoke EndPaint, [hwnd], ps
    xor eax, eax
    ret
endp

; ------------------------------------------------------------------------------
; Add a brush
; ------------------------------------------------------------------------------
proc DrawRect36, hwnd
    invoke BeginPaint, [hwnd], ps
    invoke CreateSolidBrush, 0xEEEEEE
    mov [hBrush], eax
    invoke SelectObject, [ps.hdc], [hBrush]
    mov [hOldBrush], eax
    invoke Rectangle, [ps.hdc], 50, 50, 200, 200
    invoke SelectObject, [ps.hdc], [hOldBrush]
    invoke DeleteObject, [hBrush]
    invoke EndPaint, [hwnd], ps
    xor eax, eax
    ret
endp

; ------------------------------------------------------------------------------
; Pen + brush; Invisible pen
; ------------------------------------------------------------------------------
proc DrawRect37, hwnd
    invoke BeginPaint, [hwnd], ps
    ;invoke CreatePen, PS_SOLID, 10, 0x000000
    invoke CreatePen, PS_NULL, 1, 0x000000
    mov [hPen], eax
    invoke SelectObject, [ps.hdc], [hPen]
    mov [hOldPen], eax
    
    invoke CreateSolidBrush, 0x888888
    mov [hBrush], eax
    invoke SelectObject, [ps.hdc], [hBrush]
    mov [hOldBrush], eax

    invoke Rectangle, [ps.hdc], 50, 50, 200, 200
    invoke SelectObject, [ps.hdc], [hOldPen]
    invoke SelectObject, [ps.hdc], [hOldBrush]
    invoke DeleteObject, [hPen]
    invoke DeleteObject, [hBrush]
    invoke EndPaint, [hwnd], ps
    xor eax, eax
    ret
endp

; ------------------------------------------------------------------------------
; Add GetClientRect()
; ------------------------------------------------------------------------------
proc DrawRect40, hwnd
    invoke BeginPaint, [hwnd], ps
    invoke GetClientRect, [hwnd], rect

    invoke CreatePen, PS_NULL, 1, 0x000000
    mov [hPen], eax
    invoke SelectObject, [ps.hdc], [hPen]
    mov [hOldPen], eax
    
    invoke CreateSolidBrush, 0x888888
    mov [hBrush], eax
    invoke SelectObject, [ps.hdc], [hBrush]
    mov [hOldBrush], eax

    add [rect.right], 1
    add [rect.bottom], 1
    invoke Rectangle, [ps.hdc],\
        [rect.left], [rect.top], [rect.right], [rect.bottom]
    
    invoke SelectObject, [ps.hdc], [hOldPen]
    invoke SelectObject, [ps.hdc], [hOldBrush]
    invoke DeleteObject, [hPen]
    invoke DeleteObject, [hBrush]

    invoke EndPaint, [hwnd], ps
    xor eax, eax
    ret
endp

; ------------------------------------------------------------------------------
; Add offsets
; ------------------------------------------------------------------------------
proc DrawRect50, hwnd
    invoke BeginPaint, [hwnd], ps
    invoke GetClientRect, [hwnd], rect

    invoke CreatePen, PS_NULL, 1, 0x000000
    mov [hPen], eax
    invoke SelectObject, [ps.hdc], [hPen]
    mov [hOldPen], eax
    
    invoke CreateSolidBrush, 0xEEEEEE
    mov [hBrush], eax
    invoke SelectObject, [ps.hdc], [hBrush]
    mov [hOldBrush], eax

    RECT_MARGIN = 25
    mov ecx, [rect.right]
    sub ecx, RECT_MARGIN
    mov edx, [rect.bottom]
    sub edx, RECT_MARGIN
    invoke Rectangle, [ps.hdc], RECT_MARGIN, RECT_MARGIN, ecx, edx
    
    invoke SelectObject, [ps.hdc], [hOldPen]
    invoke SelectObject, [ps.hdc], [hOldBrush]
    invoke DeleteObject, [hPen]
    invoke DeleteObject, [hBrush]

    invoke EndPaint, [hwnd], ps
    xor eax, eax
    ret
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            user32,             'user32.dll',\
            gdi32,              'gdi32.dll'
    import  kernel32,\
            ExitProcess,        'ExitProcess',\
            GetModuleHandle,    'GetModuleHandleA'
    import  user32,\
            BeginPaint,         'BeginPaint',\
            CreateWindowEx,     'CreateWindowExA',\
            DefWindowProc,      'DefWindowProcA',\
            DispatchMessage,    'DispatchMessageA',\
            EndPaint,           'EndPaint',\
            GetClientRect,      'GetClientRect',\
            GetMessage,         'GetMessageA',\
            LoadCursor,         'LoadCursorA',\
            PostQuitMessage,    'PostQuitMessage',\
            RegisterClass,      'RegisterClassA'
    import  gdi32,\
            CreatePen,          'CreatePen',\
            CreateSolidBrush,   'CreateSolidBrush',\
            DeleteObject,       'DeleteObject',\
            Rectangle,          'Rectangle',\
            SelectObject,       'SelectObject'
