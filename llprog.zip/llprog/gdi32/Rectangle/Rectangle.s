format PE GUI 4.0
entry start

include 'win32a.inc'

RECT_MARGIN = 25
WS_WINDOW_STYLE = WS_VISIBLE or WS_OVERLAPPEDWINDOW or WS_MAXIMIZE

section '.data' data readable writeable
    wc WNDCLASSEX
    msg MSG
    ps PAINTSTRUCT
    rect RECT
    class_name db 'MaxRectClass', 0
    window_name db 'Maximized Rectangle', 0

section '.text' code readable executable
start:
    invoke GetModuleHandle, NULL
    mov [wc.hInstance], eax
    mov [wc.cbSize], sizeof.WNDCLASSEX
    mov [wc.style], CS_HREDRAW or CS_VREDRAW
    mov [wc.lpfnWndProc], WindowProc
    mov [wc.cbClsExtra], 0
    mov [wc.cbWndExtra], 0
    invoke LoadIcon, NULL, IDI_APPLICATION
    mov [wc.hIcon], eax
    mov [wc.hIconSm], eax
    invoke LoadCursor, NULL, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.hbrBackground], COLOR_WINDOW + 1
    mov [wc.lpszMenuName], NULL
    mov [wc.lpszClassName], class_name
    invoke RegisterClassEx, wc

    invoke CreateWindowEx, 0, class_name, window_name, \
        WS_WINDOW_STYLE, CW_USEDEFAULT, CW_USEDEFAULT, \
        CW_USEDEFAULT, CW_USEDEFAULT, NULL, NULL, \
        [wc.hInstance], NULL

.msg_loop:
    invoke GetMessage, msg, NULL, 0, 0
    test eax, eax
    je .end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp .msg_loop

.end_loop:
    invoke ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp [wmsg], WM_PAINT
    je .wm_paint
    cmp [wmsg], WM_DESTROY
    je .wm_destroy
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret

.wm_paint:
    invoke BeginPaint, [hwnd], ps
    invoke GetClientRect, [hwnd], rect
    mov ecx, [rect.right]
    sub ecx, RECT_MARGIN
    mov edx, [rect.bottom]
    sub edx, RECT_MARGIN
    invoke Rectangle, [ps.hdc], RECT_MARGIN, RECT_MARGIN, ecx, edx
    invoke EndPaint, [hwnd], ps
    xor eax, eax
    ret

.wm_destroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    ret
endp

section '.idata' import data readable
    library kernel32, 'kernel32.dll', \
        user32, 'user32.dll', \
        gdi32, 'gdi32.dll'

    import kernel32, \
        ExitProcess, 'ExitProcess', \
        GetModuleHandle, 'GetModuleHandleA'

    import user32, \
        BeginPaint, 'BeginPaint', \
        CreateWindowEx, 'CreateWindowExA', \
        DefWindowProc, 'DefWindowProcA', \
        DispatchMessage, 'DispatchMessageA', \
        EndPaint, 'EndPaint', \
        GetClientRect, 'GetClientRect', \
        GetMessage, 'GetMessageA', \
        LoadCursor, 'LoadCursorA', \
        LoadIcon, 'LoadIconA', \
        PostQuitMessage, 'PostQuitMessage', \
        RegisterClassEx, 'RegisterClassExA', \
        TranslateMessage, 'TranslateMessage'

    import gdi32, \
        Rectangle, 'Rectangle'
