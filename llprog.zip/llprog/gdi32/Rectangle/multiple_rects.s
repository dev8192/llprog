format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    class_name db 'ExampleWindow', 0
    window_name db 'Example Window', 0
    wc WNDCLASS
    msg MSG
    ps PAINTSTRUCT
    rect RECT
    hPen dd ?
    hOldPen dd ?
    hBrush dd ?
    hOldBrush dd ?

section '.text' code readable executable
start:
    invoke GetModuleHandle, 0
    mov [wc.hInstance], eax
    mov [wc.style], CS_HREDRAW or CS_VREDRAW
    mov [wc.lpfnWndProc], WindowProc
    invoke LoadCursor, 0, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.hbrBackground], COLOR_WINDOW + 1
    mov [wc.lpszClassName], class_name
    invoke RegisterClass, wc

    invoke CreateWindowEx, 0, class_name, window_name,\
        WS_VISIBLE or WS_OVERLAPPEDWINDOW or WS_MAXIMIZE,\
        CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,\
        0, 0, [wc.hInstance], 0

.msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    test eax, eax
    jle .end_loop
    invoke DispatchMessage, msg
    jmp .msg_loop

.end_loop:
    invoke ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp [wmsg], WM_PAINT
    je .wm_paint
    cmp [wmsg], WM_DESTROY
    je .wm_destroy
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret

.wm_paint:
    stdcall DoExample10, [hwnd]
    ret

.wm_destroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    ret
endp

; ------------------------------------------------------------------------------
; Basic example
; ------------------------------------------------------------------------------
proc DrawSquare, hdc, left, top, size, hPen
    invoke SelectObject, [hdc], [hPen]
    mov [hOldPen], eax
    
    invoke CreateSolidBrush, 0x888888
    mov [hBrush], eax
    invoke SelectObject, [hdc], [hBrush]
    mov [hOldBrush], eax

    mov eax, [left]
    add eax, [size]
    mov ecx, [top]
    add ecx, [size]
    invoke Rectangle, [hdc], [left], [top], eax, ecx
    invoke SelectObject, [hdc], [hOldPen]
    invoke SelectObject, [hdc], [hOldBrush]
    invoke DeleteObject, [hPen]
    invoke DeleteObject, [hBrush]
    ret
endp

proc DoExample10, hwnd
    invoke BeginPaint, [hwnd], ps
    invoke CreatePen, PS_SOLID, 10, 0x000000
    stdcall DrawSquare, [ps.hdc], 50, 50, 200, eax
    invoke CreatePen, PS_NULL, 1, 0x000000
    stdcall DrawSquare, [ps.hdc], 50, 250, 200, eax
    invoke EndPaint, [hwnd], ps
    xor eax, eax
    ret
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            user32,             'user32.dll',\
            gdi32,              'gdi32.dll'
    import  kernel32,\
            ExitProcess,        'ExitProcess',\
            GetModuleHandle,    'GetModuleHandleA'
    import  user32,\
            BeginPaint,         'BeginPaint',\
            CreateWindowEx,     'CreateWindowExA',\
            DefWindowProc,      'DefWindowProcA',\
            DispatchMessage,    'DispatchMessageA',\
            EndPaint,           'EndPaint',\
            GetClientRect,      'GetClientRect',\
            GetMessage,         'GetMessageA',\
            LoadCursor,         'LoadCursorA',\
            PostQuitMessage,    'PostQuitMessage',\
            RegisterClass,      'RegisterClassA'
    import  gdi32,\
            CreatePen,          'CreatePen',\
            CreateSolidBrush,   'CreateSolidBrush',\
            DeleteObject,       'DeleteObject',\
            Rectangle,          'Rectangle',\
            SelectObject,       'SelectObject'
