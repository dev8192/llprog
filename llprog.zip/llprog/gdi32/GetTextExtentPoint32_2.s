format PE
entry start

include 'win32a.inc'

WIN_W = 500
WIN_H = 300
FONT1_H = -24
FONT2_H = -36
FONT_W = 0
FONT_ESC = 0
FONT_ORIENT = 0
STR1_LEN = 13
STR2_LEN = 13
BUF_SIZE = 64
PAD_X = 20
TXT1_Y = 20
DIM1_Y = 50
TXT2_Y = 100
DIM2_Y = 140

section '.data' data readable writeable
    hInstance dd ?
    hwndMain dd ?
    hFont1 dd ?
    hFont2 dd ?
    wc WNDCLASS
    msg MSG
    ps PAINTSTRUCT
    sz SIZE
    _class db 'MeasureWin', 0
    _title db 'GetTextExtentPoint32 Demo', 0
    _text1 db 'one two three', 0
    _text2 db 'four five six', 0
    _face1 db 'Courier New', 0
    _fmt db 'W: %d, H: %d', 0
    _buf rb BUF_SIZE

section '.text' code readable executable
start:
    invoke GetModuleHandle, NULL
    mov [hInstance], eax
    mov [wc.style], CS_HREDRAW or CS_VREDRAW
    mov [wc.lpfnWndProc], WindowProc
    mov eax, [hInstance]
    mov [wc.hInstance], eax
    invoke LoadCursor, NULL, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.hbrBackground], COLOR_WINDOW + 1
    mov [wc.lpszClassName], _class
    invoke RegisterClass, wc

    invoke CreateWindowEx, 0, _class, _title,\
            WS_OVERLAPPEDWINDOW or WS_VISIBLE,\
            CW_USEDEFAULT, CW_USEDEFAULT, WIN_W, WIN_H,\
            NULL, NULL, [hInstance], NULL
    mov [hwndMain], eax

.msg_loop:
    invoke GetMessage, msg, NULL, 0, 0
    or eax, eax
    jz .end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp .msg_loop
.end_loop:
    invoke ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp [wmsg], WM_CREATE
    je .wmcreate
    cmp [wmsg], WM_PAINT
    je .wmpaint
    cmp [wmsg], WM_DESTROY
    je .wmdestroy
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret

.wmcreate:
    invoke CreateFont, FONT1_H, FONT_W, FONT_ESC, FONT_ORIENT, FW_NORMAL,\
            FALSE, FALSE, FALSE, ANSI_CHARSET,\
            OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,\
            DEFAULT_QUALITY, VARIABLE_PITCH or FF_SWISS, _face1
    mov [hFont1], eax
    invoke CreateFont, FONT2_H, FONT_W, FONT_ESC, FONT_ORIENT, FW_BOLD,\
            FALSE, FALSE, FALSE, ANSI_CHARSET,\
            OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,\
            DEFAULT_QUALITY, FIXED_PITCH or FF_MODERN, _face1
    mov [hFont2], eax
    xor eax, eax
    ret

.wmpaint:
    invoke BeginPaint, [hwnd], ps
    invoke SetBkMode, [ps.hdc], TRANSPARENT

    invoke SelectObject, [ps.hdc], [hFont1]
    push eax
    invoke GetTextExtentPoint32, [ps.hdc], _text1, STR1_LEN, sz
    invoke TextOut, [ps.hdc], PAD_X, TXT1_Y, _text1, STR1_LEN
    cinvoke wsprintf, _buf, _fmt, [sz.cx], [sz.cy]
    mov ecx, eax
    invoke TextOut, [ps.hdc], PAD_X, DIM1_Y, _buf, ecx
    pop eax
    invoke SelectObject, [ps.hdc], eax

    invoke SelectObject, [ps.hdc], [hFont1]
    push eax
    invoke GetTextExtentPoint32, [ps.hdc], _text2, STR2_LEN, sz
    invoke TextOut, [ps.hdc], PAD_X, TXT2_Y, _text2, STR2_LEN
    cinvoke wsprintf, _buf, _fmt, [sz.cx], [sz.cy]
    mov ecx, eax
    invoke TextOut, [ps.hdc], PAD_X, DIM2_Y, _buf, ecx
    pop eax
    invoke SelectObject, [ps.hdc], eax

    invoke EndPaint, [hwnd], ps
    xor eax, eax
    ret

.wmdestroy:
    invoke DeleteObject, [hFont1]
    invoke DeleteObject, [hFont2]
    invoke PostQuitMessage, 0
    xor eax, eax
    ret
endp

section '.idata' import data readable
    library kernel32,               'kernel32.dll',\
            user32,                 'user32.dll',\
            gdi32,                  'gdi32.dll'
    import  kernel32,\
            GetModuleHandle,        'GetModuleHandleA',\
            ExitProcess,            'ExitProcess'
    import  user32,\
            LoadIcon,               'LoadIconA',\
            LoadCursor,             'LoadCursorA',\
            RegisterClass,          'RegisterClassA',\
            CreateWindowEx,         'CreateWindowExA',\
            GetMessage,             'GetMessageA',\
            TranslateMessage,       'TranslateMessage',\
            DispatchMessage,        'DispatchMessageA',\
            DefWindowProc,          'DefWindowProcA',\
            BeginPaint,             'BeginPaint',\
            EndPaint,               'EndPaint',\
            wsprintf,               'wsprintfA',\
            PostQuitMessage,        'PostQuitMessage'
    import  gdi32,\
            CreateFont,             'CreateFontA',\
            SelectObject,           'SelectObject',\
            GetTextExtentPoint32,   'GetTextExtentPoint32A',\
            TextOut,                'TextOutA',\
            SetBkMode,              'SetBkMode',\
            DeleteObject,           'DeleteObject'
