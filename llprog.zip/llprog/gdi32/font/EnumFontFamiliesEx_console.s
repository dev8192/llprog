format PE CONSOLE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    lf      LOGFONT
    fmt     db '%s', 10, 0

section '.text' code readable executable

start:
    mov     [lf.lfCharSet], DEFAULT_CHARSET
    invoke  GetDC, NULL
    push    eax
    invoke  EnumFontFamiliesEx, eax, lf, \
            EnumFontFamExProc, NULL, NULL
    pop     eax
    invoke  ReleaseDC, NULL, eax
    invoke  ExitProcess, NULL

proc EnumFontFamExProc1, lpelfe, lpntme, FontType, lParam
    mov     eax, [lpelfe]
    virtual at eax
        .logfont LOGFONT
    end virtual
    lea     ecx, [.logfont.lfFaceName]
    cinvoke printf, fmt, ecx
    mov     eax, TRUE
    ret
endp

proc EnumFontFamExProc, lpelfe, lpntme, FontType, lParam
    mov     eax, [lpelfe]
    lea     ecx, [eax + LOGFONT.lfFaceName]
    cinvoke printf, fmt, ecx
    mov     eax, TRUE
    ret
endp

section '.idata' import data readable
    library kernel32, 'kernel32.dll', \
            user32, 'user32.dll', \
            gdi32, 'gdi32.dll', \
            msvcrt, 'msvcrt.dll'

    import  kernel32, \
            ExitProcess, 'ExitProcess'

    import  user32, \
            GetDC, 'GetDC', \
            ReleaseDC, 'ReleaseDC'

    import  gdi32, \
            EnumFontFamiliesEx, 'EnumFontFamiliesExA'

    import  msvcrt, \
            printf, 'printf'
