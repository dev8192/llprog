format PE
entry start

include 'win32a.inc'

MAX_FONTS               equ 2000
LINE_HEIGHT             equ 30
FONT_SIZE               equ 24
X_MARGIN                equ 10
WINDOW_WIDTH            equ 800
WINDOW_HEIGHT           equ 600
LOGFONT_FACENAME_OFFSET equ 28
MAX_BUFFER_SIZE         equ 256

LF_FACESIZE = 32    ; wingdi.h

section '.data' data readable writeable
    _class          db 'FontViewClass', 0
    _title          db 'System Fonts', 0
    _text           db 'The quick brown fox jumps over the lazy dog', 0
    _format         db '%s: %s', 0

    wc              WNDCLASSEX
    msg             MSG
    ps              PAINTSTRUCT
    lf_enum         LOGFONT

    hinst           dd ?
    hmainwnd        dd ?
    hdc_screen      dd ?

    font_count      dd 0
    font_names      rb MAX_FONTS * LF_FACESIZE

    y_scroll        dd 0
    page_size       dd 0
    max_scroll      dd 0

    buffer          rb MAX_BUFFER_SIZE

section '.text' code readable executable
start:
    invoke GetModuleHandle, NULL
    mov [hinst], eax
    mov [wc.cbSize], sizeof.WNDCLASSEX
    mov [wc.style], CS_HREDRAW or CS_VREDRAW
    mov [wc.lpfnWndProc], WindowProc
    mov [wc.cbClsExtra], 0
    mov [wc.cbWndExtra], 0
    mov eax, [hinst]
    mov [wc.hInstance], eax
    invoke LoadCursor, NULL, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.hbrBackground], COLOR_WINDOW + 1
    mov [wc.lpszMenuName], NULL
    mov [wc.lpszClassName], _class
    mov [wc.hIcon], NULL
    mov [wc.hIconSm], NULL

    invoke RegisterClassEx, wc

    invoke CreateWindowEx, 0, _class, _title,\
        WS_VISIBLE or WS_OVERLAPPEDWINDOW or WS_VSCROLL, \
        CW_USEDEFAULT, CW_USEDEFAULT, WINDOW_WIDTH, WINDOW_HEIGHT, \
        NULL, NULL, [hinst], NULL
    mov [hmainwnd], eax

msg_loop:
    invoke GetMessage, msg, NULL, 0, 0
    test eax, eax
    jz end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp msg_loop

end_loop:
    invoke ExitProcess, [msg.wParam]

proc EnumFontFamExProc lpelfe, lpntme, fonttype, lparam
    mov eax, [font_count]
    cmp eax, MAX_FONTS
    jae .done

    mov esi, [lpelfe]
    add esi, LOGFONT_FACENAME_OFFSET
    
    mov edi, font_names
    mov eax, [font_count]
    imul eax, LF_FACESIZE
    add edi, eax
    
    mov ecx, LF_FACESIZE
    rep movsb

    inc [font_count]
.done:
    mov eax, 1
    ret
endp

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp [wmsg], WM_CREATE
    je .on_create
    cmp [wmsg], WM_SIZE
    je .on_size
    cmp [wmsg], WM_VSCROLL
    je .on_vscroll
    cmp [wmsg], WM_PAINT
    je .on_paint
    cmp [wmsg], WM_DESTROY
    je .on_destroy

.def_proc:
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    jmp .finish

.on_create:
    invoke GetDC, NULL
    mov [hdc_screen], eax
    mov [lf_enum.lfCharSet], DEFAULT_CHARSET
    invoke EnumFontFamiliesEx, [hdc_screen], lf_enum, EnumFontFamExProc, 0, 0
    invoke ReleaseDC, NULL, [hdc_screen]
    xor eax, eax
    jmp .finish

.on_size:
    mov eax, [lparam]
    shr eax, 16
    xor edx, edx
    mov ecx, LINE_HEIGHT
    div ecx
    mov [page_size], eax

    mov eax, [font_count]
    sub eax, [page_size]
    jns .set_max
    xor eax, eax
.set_max:
    mov [max_scroll], eax
    invoke SetScrollRange, [hwnd], SB_VERT, 0, eax, TRUE

    mov ecx, [y_scroll]
    cmp ecx, [max_scroll]
    jle .size_done
    mov ecx, [max_scroll]
    mov [y_scroll], ecx
    invoke SetScrollPos, [hwnd], SB_VERT, ecx, TRUE
.size_done:
    xor eax, eax
    jmp .finish

.on_vscroll:
    mov eax, [wparam]
    movzx edx, ax
    shr eax, 16

    mov ecx, [y_scroll]

    cmp edx, SB_LINEUP
    jne .chk_ld
    dec ecx
    jmp .apply
.chk_ld:
    cmp edx, SB_LINEDOWN
    jne .chk_pu
    inc ecx
    jmp .apply
.chk_pu:
    cmp edx, SB_PAGEUP
    jne .chk_pd
    sub ecx, [page_size]
    jmp .apply
.chk_pd:
    cmp edx, SB_PAGEDOWN
    jne .chk_th
    add ecx, [page_size]
    jmp .apply
.chk_th:
    cmp edx, SB_THUMBPOSITION
    je .set_pos
    cmp edx, SB_THUMBTRACK
    je .set_pos
    jmp .finish
.set_pos:
    mov ecx, eax
.apply:
    test ecx, ecx
    jns .chk_max
    xor ecx, ecx
.chk_max:
    cmp ecx, [max_scroll]
    jle .save
    mov ecx, [max_scroll]
.save:
    cmp ecx, [y_scroll]
    je .finish
    mov [y_scroll], ecx
    invoke SetScrollPos, [hwnd], SB_VERT, ecx, TRUE
    invoke InvalidateRect, [hwnd], NULL, TRUE
    xor eax, eax
    jmp .finish

.on_paint:
    invoke BeginPaint, [hwnd], ps
    invoke SetBkMode, [ps.hdc], TRANSPARENT

    mov ecx, [y_scroll]
    xor edi, edi
.paint_loop:
    cmp edi, [page_size]
    jg .paint_done
    cmp ecx, [font_count]
    jge .paint_done

    mov eax, ecx
    imul eax, LF_FACESIZE
    add eax, font_names
    
    push ecx
    push edi
    push eax

    invoke CreateFont, FONT_SIZE, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, \
        DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, \
        DEFAULT_QUALITY, DEFAULT_PITCH or FF_DONTCARE, eax
    
    pop edx
    push eax
    invoke SelectObject, [ps.hdc], eax
    push eax

    cinvoke wsprintf, buffer, _format, edx, _text
    invoke lstrlen, buffer
    
    mov edx, edi
    imul edx, LINE_HEIGHT
    invoke TextOut, [ps.hdc], X_MARGIN, edx, buffer, eax

    pop eax
    invoke SelectObject, [ps.hdc], eax
    pop eax
    invoke DeleteObject, eax

    pop edi
    pop ecx
    inc edi
    inc ecx
    jmp .paint_loop

.paint_done:
    invoke EndPaint, [hwnd], ps
    xor eax, eax
    jmp .finish

.on_destroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    jmp .finish

.finish:
    ret
endp

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL', \
        user32, 'USER32.DLL', \
        gdi32, 'GDI32.DLL'
    import kernel32, \
        GetModuleHandle, 'GetModuleHandleA', \
        lstrlen, 'lstrlenA', \
        ExitProcess, 'ExitProcess'
    import user32, \
        RegisterClassEx, 'RegisterClassExA', \
        CreateWindowEx, 'CreateWindowExA', \
        LoadCursor, 'LoadCursorA', \
        GetMessage, 'GetMessageA', \
        TranslateMessage, 'TranslateMessage', \
        DispatchMessage, 'DispatchMessageA', \
        DefWindowProc, 'DefWindowProcA', \
        GetDC, 'GetDC', \
        ReleaseDC, 'ReleaseDC', \
        SetScrollRange, 'SetScrollRange', \
        SetScrollPos, 'SetScrollPos', \
        InvalidateRect, 'InvalidateRect', \
        BeginPaint, 'BeginPaint', \
        EndPaint, 'EndPaint', \
        PostQuitMessage, 'PostQuitMessage', \
        wsprintf, 'wsprintfA'
    import gdi32, \
        EnumFontFamiliesEx, 'EnumFontFamiliesExA', \
        CreateFont, 'CreateFontA', \
        SelectObject, 'SelectObject', \
        DeleteObject, 'DeleteObject', \
        SetBkMode, 'SetBkMode', \
        TextOut, 'TextOutA'
