format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    cross_x         dd 300
    cross_y         dd 200
    cross_size      dd 100
    cross_thickness dd 30
    ;cross_color     dd 0x00FF0000
    cross_color     dd 0x0000FF00

    _class          db 'CrossWindow', 0
    _title          db 'Draw Cross', 0

    wc              WNDCLASS
    msg             MSG
    ps              PAINTSTRUCT

    hmainwnd        dd ?
    hpen            dd ?
    holdpen         dd ?

section '.text' code readable executable
start:
    invoke GetModuleHandle, 0
    mov [wc.hInstance], eax
    mov [wc.lpfnWndProc], WindowProc
    invoke LoadCursor, NULL, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.hbrBackground], COLOR_WINDOW + 1
    mov [wc.lpszClassName], _class
    invoke RegisterClass, wc
    invoke CreateWindowEx, 0, _class, _title, WS_VISIBLE or WS_OVERLAPPEDWINDOW, \
        CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, \
        NULL, NULL, [wc.hInstance], NULL
    mov [hmainwnd], eax

msg_loop:
    invoke GetMessage, msg, NULL, 0, 0
    test eax, eax
    jz end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp msg_loop

end_loop:
    invoke ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp [wmsg], WM_PAINT
    je .on_paint
    cmp [wmsg], WM_DESTROY
    je .on_destroy

.def_proc:
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    jmp .finish

.on_paint:
    invoke BeginPaint, [hwnd], ps
    
    invoke CreatePen, PS_SOLID, [cross_thickness], [cross_color]
    mov [hpen], eax
    invoke SelectObject, [ps.hdc], [hpen]
    mov [holdpen], eax

    mov eax, [cross_x]
    sub eax, [cross_size]
    invoke MoveToEx, [ps.hdc], eax, [cross_y], NULL

    mov eax, [cross_x]
    add eax, [cross_size]
    invoke LineTo, [ps.hdc], eax, [cross_y]

    mov eax, [cross_y]
    sub eax, [cross_size]
    invoke MoveToEx, [ps.hdc], [cross_x], eax, NULL

    mov eax, [cross_y]
    add eax, [cross_size]
    invoke LineTo, [ps.hdc], [cross_x], eax

    invoke SelectObject, [ps.hdc], [holdpen]
    invoke DeleteObject, [hpen]

    invoke EndPaint, [hwnd], ps
    xor eax, eax
    jmp .finish

.on_destroy:
    invoke PostQuitMessage, 0
    xor eax, eax

.finish:
    ret
endp

section '.idata' import data readable

    library kernel32, 'KERNEL32.DLL', \
        user32, 'USER32.DLL', \
        gdi32, 'GDI32.DLL'

    import kernel32, \
        GetModuleHandle, 'GetModuleHandleA', \
        ExitProcess, 'ExitProcess'

    import user32, \
        RegisterClass, 'RegisterClassA', \
        CreateWindowEx, 'CreateWindowExA', \
        LoadCursor, 'LoadCursorA', \
        GetMessage, 'GetMessageA', \
        TranslateMessage, 'TranslateMessage', \
        DispatchMessage, 'DispatchMessageA', \
        DefWindowProc, 'DefWindowProcA', \
        PostQuitMessage, 'PostQuitMessage', \
        BeginPaint, 'BeginPaint', \
        EndPaint, 'EndPaint'

    import gdi32, \
        CreatePen, 'CreatePen', \
        SelectObject, 'SelectObject', \
        DeleteObject, 'DeleteObject', \
        MoveToEx, 'MoveToEx', \
        LineTo, 'LineTo'
