; not working
format PE console
entry start

include 'win32a.inc'

section '.text' code readable executable

start:
    invoke GetConsoleWindow
    mov [hConsole], eax

    invoke GetDC, [hConsole]
    mov [hdcDest], eax

    invoke GetDC, 0
    mov [hdcSrc], eax

    invoke BitBlt, [hdcDest], 10, 10, 200, 200, [hdcSrc], 0, 0, SRCCOPY

    invoke ReleaseDC, 0, [hdcSrc]
    invoke ReleaseDC, [hConsole], [hdcDest]

    invoke ExitProcess, 0

section '.data' data readable writeable

    hConsole dd ?
    hdcDest  dd ?
    hdcSrc   dd ?

section '.idata' import data readable writeable

    library kernel32, 'kernel32.dll', \
            user32,   'user32.dll', \
            gdi32,    'gdi32.dll'

    import kernel32, \
           ExitProcess, 'ExitProcess'

    import user32, \
           GetConsoleWindow, 'GetConsoleWindow', \
           GetDC, 'GetDC', \
           ReleaseDC, 'ReleaseDC'

    import gdi32, \
           BitBlt, 'BitBlt'
