format PE GUI 4.0
entry start

include 'win32a.inc'

section '.text' code readable executable

start:
    invoke GetModuleHandleA, 0
    mov [wc.hInstance], eax
    mov [wc.style], CS_HREDRAW or CS_VREDRAW
    mov [wc.lpfnWndProc], WindowProc
    mov [wc.hbrBackground], COLOR_WINDOW+1
    mov [wc.lpszClassName], className

    invoke RegisterClassA, wc

    invoke CreateWindowExA, 0, className, titleName, WS_VISIBLE or WS_OVERLAPPEDWINDOW, \
        CW_USEDEFAULT, CW_USEDEFAULT, 400, 300, 0, 0, [wc.hInstance], 0
    mov [hwnd], eax

msg_loop:
    invoke GetMessageA, msg, 0, 0, 0
    test eax, eax
    jz end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessageA, msg
    jmp msg_loop

end_loop:
    invoke ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp [wmsg], WM_PAINT
    je .wm_paint
    cmp [wmsg], WM_DESTROY
    je .wm_destroy

.defwndproc:
    invoke DefWindowProcA, [hwnd], [wmsg], [wparam], [lparam]
    ret

.wm_paint:
    invoke BeginPaint, [hwnd], ps
    mov [hdc], eax

    invoke GetClientRect, [hwnd], rect

    mov eax, [rect.right]
    sub eax, [rect.left]
    mov [bmpWidth], eax

    mov eax, [rect.bottom]
    sub eax, [rect.top]
    mov [bmpHeight], eax

    invoke CreateCompatibleDC, [hdc]
    mov [memDC], eax

    invoke CreateCompatibleBitmap, [hdc], [bmpWidth], [bmpHeight]
    mov [hBitmap], eax

    invoke SelectObject, [memDC], [hBitmap]
    mov [hOldBitmap], eax

    ;invoke CreateSolidBrush, 0x00FF0000 ; blue
    ;invoke CreateSolidBrush, 0x0000FF00 ; green
    invoke CreateSolidBrush, 0x000000FF ; red
    mov [hBrush], eax

    invoke FillRect, [memDC], rect, [hBrush]

    invoke BitBlt, [hdc], 0, 0, [bmpWidth], [bmpHeight], [memDC], 0, 0, SRCCOPY

    invoke SelectObject, [memDC], [hOldBitmap]
    invoke DeleteObject, [hBitmap]
    invoke DeleteObject, [hBrush]
    invoke DeleteDC, [memDC]

    invoke EndPaint, [hwnd], ps
    xor eax, eax
    ret

.wm_destroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    ret
endp

section '.data' data readable writeable

    className db 'BitBltClass', 0
    titleName db 'BitBlt Example', 0

    wc WNDCLASS
    msg MSG
    hwnd dd 0

    ps PAINTSTRUCT
    rect RECT
    hdc dd 0
    memDC dd 0
    hBitmap dd 0
    hOldBitmap dd 0
    hBrush dd 0
    bmpWidth dd 0
    bmpHeight dd 0

section '.idata' import data readable

    library kernel32, 'KERNEL32.DLL',\
        user32, 'USER32.DLL',\
        gdi32, 'GDI32.DLL'

    import kernel32,\
        GetModuleHandleA, 'GetModuleHandleA',\
        ExitProcess, 'ExitProcess'

    import user32,\
        RegisterClassA, 'RegisterClassA',\
        CreateWindowExA, 'CreateWindowExA',\
        GetMessageA, 'GetMessageA',\
        TranslateMessage, 'TranslateMessage',\
        DispatchMessageA, 'DispatchMessageA',\
        DefWindowProcA, 'DefWindowProcA',\
        PostQuitMessage, 'PostQuitMessage',\
        BeginPaint, 'BeginPaint',\
        EndPaint, 'EndPaint',\
        FillRect, 'FillRect',\
        GetClientRect, 'GetClientRect'

    import gdi32,\
        CreateCompatibleDC, 'CreateCompatibleDC',\
        CreateCompatibleBitmap, 'CreateCompatibleBitmap',\
        SelectObject, 'SelectObject',\
        DeleteObject, 'DeleteObject',\
        DeleteDC, 'DeleteDC',\
        BitBlt, 'BitBlt',\
        CreateSolidBrush, 'CreateSolidBrush'
