format PE console
entry start

include 'win32a.inc'

WINDOW_WIDTH equ 400
WINDOW_HEIGHT equ 400
CAPTURE_X equ 10
CAPTURE_Y equ 10
CAPTURE_WIDTH equ 45
CAPTURE_HEIGHT equ 45
DEST_X equ 50
DEST_Y equ 50

section '.data' data readable writeable
    wc WNDCLASS
    msg MSG
    ps PAINTSTRUCT
    class_name db 'ScreenCaptureClass', 0

section '.text' code readable executable
start:
    invoke GetModuleHandle, 0
    mov [wc.hInstance], eax
    mov [wc.lpfnWndProc], WindowProc
    invoke LoadCursor, 0, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.lpszClassName], class_name
    mov [wc.hbrBackground], COLOR_WINDOW+1
    invoke RegisterClass, wc
    invoke CreateWindowEx, 0, class_name, class_name,\
        WS_OVERLAPPEDWINDOW or WS_VISIBLE, CW_USEDEFAULT, CW_USEDEFAULT,\
        WINDOW_WIDTH, WINDOW_HEIGHT, 0, 0, [wc.hInstance], 0
msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    test eax, eax
    jle end_loop
    invoke DispatchMessage, msg
    jmp msg_loop
end_loop:
    invoke ExitProcess, [msg.wParam]

proc WindowProc uses ebx esi, hwnd, wmsg, wparam, lparam
    cmp [wmsg], WM_PAINT
    je .wmpaint
    cmp [wmsg], WM_DESTROY
    je .wmdestroy
.defwndproc:
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret
.wmpaint:
    invoke BeginPaint, [hwnd], ps
    mov ebx, eax
    invoke GetDC, 0
    mov esi, eax
    invoke BitBlt, ebx, DEST_X, DEST_Y, CAPTURE_WIDTH, CAPTURE_HEIGHT,\
        esi, CAPTURE_X, CAPTURE_Y, SRCCOPY
    invoke ReleaseDC, 0, esi
    invoke EndPaint, [hwnd], ps
    xor eax, eax
    ret
.wmdestroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    ret
endp

section '.idata' import data readable

    library kernel32, 'KERNEL32.DLL',\
        user32, 'USER32.DLL',\
        gdi32, 'GDI32.DLL'

    import kernel32,\
        GetModuleHandle, 'GetModuleHandleA',\
        ExitProcess, 'ExitProcess'

    import user32,\
        LoadCursor, 'LoadCursorA',\
        RegisterClass, 'RegisterClassA',\
        CreateWindowEx, 'CreateWindowExA',\
        GetMessage, 'GetMessageA',\
        DispatchMessage, 'DispatchMessageA',\
        DefWindowProc, 'DefWindowProcA',\
        BeginPaint, 'BeginPaint',\
        EndPaint, 'EndPaint',\
        GetDC, 'GetDC',\
        ReleaseDC, 'ReleaseDC',\
        PostQuitMessage, 'PostQuitMessage'
    import gdi32,\
        BitBlt, 'BitBlt'
