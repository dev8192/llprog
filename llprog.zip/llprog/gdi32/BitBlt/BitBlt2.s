; does nothing
format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    hwnd        dd ?
    hdc         dd ?
    hMemDC      dd ?
    hBitmap     dd ?
    hOldBitmap  dd ?
    hBrush      dd ?
    hOldBrush   dd ?

section '.text' code readable executable
start:
    invoke  GetConsoleWindow
    mov     [hwnd], eax

    invoke  GetDC, [hwnd]
    mov     [hdc], eax

    invoke  CreateCompatibleDC, [hdc]
    mov     [hMemDC], eax

    invoke  CreateCompatibleBitmap, [hdc], 200, 200
    mov     [hBitmap], eax

    invoke  SelectObject, [hMemDC], [hBitmap]
    mov     [hOldBitmap], eax

    invoke  CreateSolidBrush, 0x000000FF
    mov     [hBrush], eax

    invoke  SelectObject, [hMemDC], [hBrush]
    mov     [hOldBrush], eax

    invoke  Rectangle, [hMemDC], 0, 0, 200, 200

    invoke  BitBlt, [hdc], 50, 50, 200, 200, [hMemDC], 0, 0, SRCCOPY

    invoke  Sleep, 5000

    invoke  SelectObject, [hMemDC], [hOldBrush]
    invoke  DeleteObject, [hBrush]
    invoke  SelectObject, [hMemDC], [hOldBitmap]
    invoke  DeleteObject, [hBitmap]
    invoke  DeleteDC, [hMemDC]
    invoke  ReleaseDC, [hwnd], [hdc]

    invoke  ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL',\
        user32, 'USER32.DLL',\
        gdi32, 'GDI32.DLL'

    import kernel32,\
        ExitProcess, 'ExitProcess',\
        GetConsoleWindow, 'GetConsoleWindow',\
        Sleep, 'Sleep'

    import user32,\
        GetDC, 'GetDC',\
        ReleaseDC, 'ReleaseDC'

    import gdi32,\
        BitBlt, 'BitBlt',\
        CreateCompatibleBitmap, 'CreateCompatibleBitmap',\
        CreateCompatibleDC, 'CreateCompatibleDC',\
        CreateSolidBrush, 'CreateSolidBrush',\
        DeleteDC, 'DeleteDC',\
        DeleteObject, 'DeleteObject',\
        Rectangle, 'Rectangle',\
        SelectObject, 'SelectObject'
