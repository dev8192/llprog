format PE
entry start

include 'win32a.inc'

X_POS            = 50
Y_POS_OPAQUE     = 50
Y_POS_TRANSP     = 100
COLOR_YELLOW     = 0x00FFFF
COLOR_BLACK      = 0x000000
WINDOW_WIDTH     = 400
WINDOW_HEIGHT    = 300

section '.data' data readable writeable
    className       db 'BkModeClass', 0
    windowName      db 'SetBkMode Demonstration', 0
    msgOpaque       db 'This is OPAQUE mode'
    msgOpaqueLen    = $ - msgOpaque
    msgTransp       db 'This is TRANSPARENT mode'
    msgTranspLen    = $ - msgTransp

    wc              WNDCLASS
    msg             MSG
    ps              PAINTSTRUCT

section '.text' code readable executable
start:
    invoke GetModuleHandle, NULL
    mov [wc.hInstance], eax
    mov [wc.style], CS_HREDRAW or CS_VREDRAW
    mov [wc.lpfnWndProc], WindowProc
    invoke LoadIcon, NULL, IDI_APPLICATION
    mov [wc.hIcon], eax
    invoke LoadCursor, NULL, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.hbrBackground], COLOR_WINDOW + 1
    mov [wc.lpszClassName], className
    invoke RegisterClass, wc

    invoke CreateWindowEx, NULL, className, windowName,\
           WS_VISIBLE or WS_OVERLAPPEDWINDOW,\
           CW_USEDEFAULT, CW_USEDEFAULT, WINDOW_WIDTH, WINDOW_HEIGHT,\
           NULL, NULL, [wc.hInstance], NULL

msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    test eax, eax
    jz end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp msg_loop

end_loop:
    invoke ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp [wmsg], WM_PAINT
    je .on_paint
    cmp [wmsg], WM_DESTROY
    je .on_destroy
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret

.on_paint:
    invoke BeginPaint, [hwnd], ps
    invoke SetTextColor, [ps.hdc], COLOR_BLACK
    invoke SetBkColor, [ps.hdc], COLOR_YELLOW
    ;invoke SetBkMode, [ps.hdc], OPAQUE
    invoke TextOut, [ps.hdc], X_POS, Y_POS_OPAQUE,\
           msgOpaque, msgOpaqueLen
    ;invoke SetBkMode, [ps.hdc], TRANSPARENT
    invoke TextOut, [ps.hdc], X_POS, Y_POS_TRANSP,\
           msgTransp, msgTranspLen
    invoke EndPaint, [hwnd], ps
    xor eax, eax
    ret

.on_destroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    ret
endp

section '.idata' import data readable writeable
    library kernel32,           'KERNEL32.DLL',\
            user32,             'USER32.DLL',\
            gdi32,              'GDI32.DLL'
    import  kernel32,\
            GetModuleHandle,    'GetModuleHandleA',\
            ExitProcess,        'ExitProcess'
    import  user32,\
            RegisterClass,      'RegisterClassA',\
            CreateWindowEx,     'CreateWindowExA',\
            GetMessage,         'GetMessageA',\
            TranslateMessage,   'TranslateMessage',\
            DispatchMessage,    'DispatchMessageA',\
            DefWindowProc,      'DefWindowProcA',\
            PostQuitMessage,    'PostQuitMessage',\
            BeginPaint,         'BeginPaint',\
            EndPaint,           'EndPaint',\
            LoadIcon,           'LoadIconA',\
            LoadCursor,         'LoadCursorA'
    import  gdi32,\
            SetBkMode,          'SetBkMode',\
            SetBkColor,         'SetBkColor',\
            SetTextColor,       'SetTextColor',\
            TextOut,            'TextOutA'
