format PE console
entry start

include 'win32a.inc'

WINDOW_WIDTH equ 600
WINDOW_HEIGHT equ 400
RECT_LEFT equ 100
RECT_TOP equ 100
RECT_RIGHT equ 500
RECT_BOTTOM equ 300
ELLIPSE_WIDTH equ 50
ELLIPSE_HEIGHT equ 50

section '.data' data readable writeable
    wc WNDCLASS
    msg MSG
    ps PAINTSTRUCT
    class_name db 'RoundRectClass', 0

section '.text' code readable executable
start:
    invoke GetModuleHandle, 0
    mov [wc.hInstance], eax
    mov [wc.lpfnWndProc], WindowProc
    invoke LoadCursor, 0, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.lpszClassName], class_name
    mov [wc.hbrBackground], COLOR_WINDOW+1
    invoke RegisterClass, wc
    invoke CreateWindowEx, 0, class_name, class_name, \
        WS_OVERLAPPEDWINDOW or WS_VISIBLE, CW_USEDEFAULT, CW_USEDEFAULT, \
        WINDOW_WIDTH, WINDOW_HEIGHT, 0, 0, [wc.hInstance], 0
msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    test eax, eax
    jz end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp msg_loop
end_loop:
    invoke ExitProcess, [msg.wParam]

proc WindowProc uses ebx, hwnd, wmsg, wparam, lparam
    cmp [wmsg], WM_PAINT
    je .wmpaint
    cmp [wmsg], WM_DESTROY
    je .wmdestroy
.defwndproc:
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret
.wmpaint:
    invoke BeginPaint, [hwnd], ps
    mov ebx, eax
    invoke GetStockObject, GRAY_BRUSH
    invoke SelectObject, ebx, eax
    invoke RoundRect, ebx, RECT_LEFT, RECT_TOP, \
        RECT_RIGHT, RECT_BOTTOM, ELLIPSE_WIDTH, ELLIPSE_HEIGHT
    invoke EndPaint, [hwnd], ps
    xor eax, eax
    ret
.wmdestroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    ret
endp

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL',\
        user32, 'USER32.DLL',\
        gdi32, 'GDI32.DLL'

    import kernel32,\
        GetModuleHandle, 'GetModuleHandleA',\
        ExitProcess, 'ExitProcess'

    import user32,\
        LoadCursor, 'LoadCursorA',\
        RegisterClass, 'RegisterClassA',\
        CreateWindowEx, 'CreateWindowExA',\
        GetMessage, 'GetMessageA',\
        TranslateMessage, 'TranslateMessage',\
        DispatchMessage, 'DispatchMessageA',\
        DefWindowProc, 'DefWindowProcA',\
        BeginPaint, 'BeginPaint',\
        EndPaint, 'EndPaint',\
        PostQuitMessage, 'PostQuitMessage'

    import gdi32,\
        GetStockObject, 'GetStockObject',\
        SelectObject, 'SelectObject',\
        RoundRect, 'RoundRect'
