format PE console
entry start

include 'win32a.inc'

DESKTOPHORZRES = 118
DESKTOPVERTRES = 117

section '.data' data readable writeable
    fmt    db '%d x %d', 10, 0
    hdc    dd ?
    width  dd ?
    height dd ?

section '.text' code readable executable
start:
    invoke  GetDC, 0
    mov     [hdc], eax

    invoke  GetDeviceCaps, [hdc], DESKTOPHORZRES
    mov     [width], eax
    invoke  GetDeviceCaps, [hdc], DESKTOPVERTRES
    mov     [height], eax

    invoke  ReleaseDC, 0, [hdc]

    cinvoke printf, fmt, [width], [height]

    invoke  ExitProcess, 0

section '.idata' import data readable writeable
    library kernel32, 'KERNEL32.DLL',\
        user32, 'USER32.DLL',\
        gdi32, 'GDI32.DLL',\
        msvcrt, 'MSVCRT.DLL'

    import kernel32,\
        ExitProcess, 'ExitProcess'

    import user32,\
        GetDC, 'GetDC',\
        ReleaseDC, 'ReleaseDC'

    import gdi32,\
        GetDeviceCaps, 'GetDeviceCaps'

    import msvcrt,\
        printf, 'printf'
