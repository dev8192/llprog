format PE
entry start

include 'win32a.inc'

POLL_DELAY equ 10
KEY_PRESSED_MASK equ 0x8000

section '.data' data readable writeable
    fmt db 'RGB(%d, %d, %d) #%02x%02x%02x', 10, 0
    point POINT
    was_pressed dd FALSE

section '.text' code readable executable
start:
    invoke SetProcessDPIAware

.msg_loop:
    invoke Sleep, POLL_DELAY
    
    invoke GetAsyncKeyState, VK_ESCAPE
    test ax, KEY_PRESSED_MASK
    jnz end_loop
    
    invoke GetAsyncKeyState, VK_LBUTTON
    test ax, KEY_PRESSED_MASK
    jz .not_pressed
    
    cmp [was_pressed], TRUE
    je .msg_loop
    
    mov [was_pressed], TRUE
    stdcall GetAndPrintPixel
    jmp .msg_loop
    
.not_pressed:
    mov [was_pressed], FALSE
    jmp .msg_loop
    
end_loop:
    invoke ExitProcess, 0

proc GetAndPrintPixel
    local hdc:DWORD, color:DWORD, red:DWORD, green:DWORD, blue:DWORD
    
    invoke GetCursorPos, point
    invoke GetDC, 0
    mov [hdc], eax
    
    invoke GetPixel, [hdc], [point.x], [point.y]
    mov [color], eax
    
    invoke ReleaseDC, 0, [hdc]
    
    mov eax, [color]
    movzx ecx, al
    mov [red], ecx
    movzx ecx, ah
    mov [green], ecx
    shr eax, 16
    movzx ecx, al
    mov [blue], ecx
    
    cinvoke printf, fmt,\
        [red], [green], [blue],\
        [red], [green], [blue]
    ret
endp

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            user32, 'user32.dll',\
            gdi32, 'gdi32.dll',\
            msvcrt, 'msvcrt.dll'
    import  kernel32,\
            Sleep, 'Sleep',\
            ExitProcess, 'ExitProcess'
    import  user32,\
            GetAsyncKeyState, 'GetAsyncKeyState',\
            GetCursorPos, 'GetCursorPos',\
            SetProcessDPIAware, 'SetProcessDPIAware',\
            GetDC, 'GetDC',\
            ReleaseDC, 'ReleaseDC'
    import  gdi32,\
            GetPixel, 'GetPixel'
    import  msvcrt,\
            printf, 'printf'
