format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    clsName db 'TriClass', 0
    title   db 'Equilateral Triangle', 0

    wc WNDCLASS
    msg MSG
    ps PAINTSTRUCT
    hwnd dd 0

    points:
        dd 200, 50
        dd 300, 223
        dd 100, 223

section '.text' code readable executable
start:
    invoke  GetModuleHandle, 0
    mov     [wc.hInstance], eax

    invoke  LoadCursor, 0, IDC_ARROW
    mov     [wc.hCursor], eax

    mov     [wc.lpfnWndProc], WindowProc
    mov     [wc.hbrBackground], COLOR_WINDOW+1
    mov     [wc.lpszClassName], clsName

    invoke  RegisterClass, wc
    invoke  CreateWindowEx, 0, clsName, title, WS_OVERLAPPEDWINDOW + WS_VISIBLE,\
        100, 100, 400, 350, 0, 0, [wc.hInstance], 0
    mov     [hwnd], eax

msg_loop:
    invoke  GetMessage, msg, 0, 0, 0
    test    eax, eax
    jz      end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     msg_loop

end_loop:
    invoke  ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp     [wmsg], WM_PAINT
    je      .wmpaint
    cmp     [wmsg], WM_DESTROY
    je      .wmdestroy

    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret

.wmpaint:
    invoke  BeginPaint, [hwnd], ps
    invoke  Polygon, eax, points, 3
    invoke  EndPaint, [hwnd], ps
    xor     eax, eax
    ret

.wmdestroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
    ret
endp

section '.idata' import data readable
    library kernel32,           'KERNEL32.DLL',\
            user32,             'USER32.DLL',\
            gdi32,              'GDI32.DLL'
    import  kernel32,\
            ExitProcess,        'ExitProcess',\
            GetModuleHandle,    'GetModuleHandleA'
    import  user32,\
            BeginPaint,         'BeginPaint',\
            CreateWindowEx,     'CreateWindowExA',\
            DefWindowProc,      'DefWindowProcA',\
            DispatchMessage,    'DispatchMessageA',\
            EndPaint,           'EndPaint',\
            GetMessage,         'GetMessageA',\
            LoadCursor,         'LoadCursorA',\
            PostQuitMessage,    'PostQuitMessage',\
            RegisterClass,      'RegisterClassA',\
            TranslateMessage,   'TranslateMessage'
    import  gdi32,\
            Polygon,            'Polygon'
