format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    text1       db 'one two three', 0
    text2       db 'four five six', 0
    fmt_string  db 'Width: %ld px, Height: %ld px', 10, 0
    hdc         dd 0
    text_size   SIZE

section '.text' code readable executable
start:
    stdcall main
    invoke  ExitProcess, 0

proc main
    stdcall get_text_extent_point, text1, 13
    stdcall get_text_extent_point, text2, 13
    ret
endp

proc get_text_extent_point, text, text_len
    invoke GetDC, 0
    mov [hdc], eax
    invoke GetTextExtentPoint32, [hdc], [text], [text_len], text_size
    cinvoke printf, fmt_string, [text_size.cx], [text_size.cy]
    invoke ReleaseDC, 0, [hdc]
    ret
endp

section '.idata' import data readable
    library kernel32,               'kernel32.dll',\
            user32,                 'user32.dll',\
            gdi32,                  'gdi32.dll',\
            msvcrt,                 'msvcrt.dll'
    import  kernel32,\
            ExitProcess,            'ExitProcess'
    import  user32,\
            GetDC,                  'GetDC',\
            ReleaseDC,              'ReleaseDC'
    import  gdi32,\
            GetTextExtentPoint32,   'GetTextExtentPoint32A'
    import  msvcrt,\
            printf,                 'printf'
