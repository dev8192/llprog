format PE
entry start

include 'win32ax.inc'

LANG_ENGLISH_US = 0x0409
ERROR_SUCCESS   = 0

section '.data' data readable writeable
    text1       db 'one two three', 0
    text2       db 'four five six', 0
    fmt_string  db 'Width: %ld px, Height: %ld px', 10, 0
    hdc         dd 0
    text_size   SIZE
    fmt_success db 'Success: %x', 10, 0
    fmt_err     db "Error %u (0x%X): '%s'", 10, 0
    buffer      rb 256

section '.text' code readable executable
start:
    stdcall test3
    invoke  ExitProcess, 0

proc get_text_extent_point, text, text_len
    local hdc:DWORD
    invoke  GetDC, 0
    mov     [hdc], eax
    stdcall __get_text_extent_point, [hdc], [text], [text_len], text_size
    invoke  ReleaseDC, 0, [hdc]
    ret
endp

proc __get_text_extent_point uses ebx, hdc, lpString, c, psizl
    mov     ebx, [psizl]
    invoke  SetLastError, ERROR_SUCCESS
    invoke  GetTextExtentPoint32, [hdc], [lpString], [c], ebx
    test    eax, eax
    jz      .error
    cinvoke printf, fmt_string, [ebx + SIZE.cx], [ebx + SIZE.cy]
    jmp     .done
.error:
    invoke  GetLastError
    mov     ebx, eax
    invoke  FormatMessage,\
            FORMAT_MESSAGE_FROM_SYSTEM + FORMAT_MESSAGE_MAX_WIDTH_MASK,\
            0, eax, LANG_ENGLISH_US, buffer, 256, 0
    cinvoke printf, fmt_err, ebx, ebx, buffer
.done:
    ret
endp

; -----------------------------------------------
; No error
; -----------------------------------------------
proc test1
    stdcall get_text_extent_point, text1, 13
    stdcall get_text_extent_point, text2, 13
    ret
endp

; -----------------------------------------------
; Error 87 (0x57): 'The parameter is incorrect. '
; -----------------------------------------------
proc test2
    stdcall __get_text_extent_point, 0, text1, 13, text_size
    ret
endp

; -----------------------------------------------
; Error 0 (0x0): 'The operation completed successfully. '
; -----------------------------------------------
proc test3
    local hdc:DWORD
    invoke  GetDC, 0
    mov     [hdc], eax
    stdcall __get_text_extent_point, [hdc], text1, 13, 0
    invoke  ReleaseDC, 0, [hdc]
    ret
endp

section '.idata' import data readable
    library kernel32,               'kernel32.dll',\
            user32,                 'user32.dll',\
            gdi32,                  'gdi32.dll',\
            msvcrt,                 'msvcrt.dll'
    import  kernel32,\
            ExitProcess,            'ExitProcess',\
            FormatMessage,          'FormatMessageA',\
            GetLastError,           'GetLastError',\
            SetLastError,           'SetLastError'
    import  user32,\
            GetDC,                  'GetDC',\
            ReleaseDC,              'ReleaseDC'
    import  gdi32,\
            GetTextExtentPoint32,   'GetTextExtentPoint32A'
    import  msvcrt,\
            printf,                 'printf'
