format PE console
entry start

include 'win32a.inc'

SRC_X equ 0
SRC_Y equ 0
SRC_W equ 50
SRC_H equ 50
DST_W equ 150
DST_H equ 150
BPP equ 32
BYTES_PER_PIXEL equ 4
RGB_MASK equ 0FFFFFFh

section '.data' data readable writeable
    wc WNDCLASS
    msg MSG
    hwnd dd ?
    hdcScreen dd ?
    hdcMem dd ?
    hBitmap dd ?
    pBits dd ?
    bmi BITMAPINFO
    ps PAINTSTRUCT

    className db 'MagnifierClass', 0
    windowName db 'Pixel Magnifier', 0

    fileName db 'pixels.txt', 0
    fileMode db 'w', 0
    hexFormat db '%06X ', 0
    newline db 10, 0

section '.text' code readable executable

start:
    invoke  GetModuleHandle, NULL
    mov     [wc.hInstance], eax
    mov     [wc.style], CS_HREDRAW or CS_VREDRAW
    mov     [wc.lpfnWndProc], WindowProc
    invoke  LoadCursor, NULL, IDC_ARROW
    mov     [wc.hCursor], eax
    mov     [wc.hbrBackground], COLOR_WINDOW + 1
    mov     [wc.lpszClassName], className
    invoke  RegisterClass, wc

    invoke  CreateWindowEx, 0, className, windowName, \
        WS_OVERLAPPEDWINDOW or WS_VISIBLE, \
        CW_USEDEFAULT, CW_USEDEFAULT, 200, 200, \
        NULL, NULL, [wc.hInstance], NULL
    mov     [hwnd], eax

    invoke  GetDC, NULL
    mov     [hdcScreen], eax

    invoke  CreateCompatibleDC, [hdcScreen]
    mov     [hdcMem], eax

    mov     [bmi.bmiHeader.biSize], sizeof.BITMAPINFOHEADER
    mov     [bmi.bmiHeader.biWidth], SRC_W
    mov     [bmi.bmiHeader.biHeight], -SRC_H
    mov     [bmi.bmiHeader.biPlanes], 1
    mov     [bmi.bmiHeader.biBitCount], BPP
    mov     [bmi.bmiHeader.biCompression], BI_RGB

    invoke  CreateDIBSection, [hdcMem], bmi, DIB_RGB_COLORS, \
        pBits, NULL, 0
    mov     [hBitmap], eax

    invoke  SelectObject, [hdcMem], [hBitmap]

    invoke  BitBlt, [hdcMem], 0, 0, SRC_W, SRC_H, \
        [hdcScreen], SRC_X, SRC_Y, SRCCOPY

    invoke  ReleaseDC, NULL, [hdcScreen]

    stdcall SavePixelsToFile

msg_loop:
    invoke  GetMessage, msg, NULL, 0, 0
    test    eax, eax
    jz      end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     msg_loop

end_loop:
    invoke  DeleteDC, [hdcMem]
    invoke  DeleteObject, [hBitmap]
    invoke  ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp     [wmsg], WM_PAINT
    je      .wm_paint
    cmp     [wmsg], WM_DESTROY
    je      .wm_destroy

    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret

.wm_paint:
    invoke  BeginPaint, [hwnd], ps
    invoke  SetStretchBltMode, eax, COLORONCOLOR
    invoke  StretchBlt, [ps.hdc], 0, 0, DST_W, DST_H, \
        [hdcMem], 0, 0, SRC_W, SRC_H, SRCCOPY
    invoke  EndPaint, [hwnd], ps
    xor     eax, eax
    ret

.wm_destroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
    ret
endp

proc SavePixelsToFile
    local   fileHandle:DWORD

    cinvoke fopen, fileName, fileMode
    test    eax, eax
    jz      .done
    mov     [fileHandle], eax

    mov     ecx, SRC_H
    mov     esi, [pBits]
.row_loop:
    push    ecx
    mov     ecx, SRC_W
.col_loop:
    push    ecx

    mov     eax, [esi]
    and     eax, RGB_MASK

    cinvoke fprintf, [fileHandle], hexFormat, eax

    add     esi, BYTES_PER_PIXEL

    pop     ecx
    dec     ecx
    jnz     .col_loop

    cinvoke fprintf, [fileHandle], newline

    pop     ecx
    dec     ecx
    jnz     .row_loop

    cinvoke fclose, [fileHandle]
.done:
    ret
endp

section '.idata' import data readable writeable
    library kernel32, 'KERNEL32.DLL', \
        user32, 'USER32.DLL', \
        gdi32, 'GDI32.DLL', \
        msvcrt, 'MSVCRT.DLL'

    import  kernel32, \
        ExitProcess, 'ExitProcess', \
        GetModuleHandle, 'GetModuleHandleA'

    import  user32, \
        BeginPaint, 'BeginPaint', \
        CreateWindowEx, 'CreateWindowExA', \
        DefWindowProc, 'DefWindowProcA', \
        DispatchMessage, 'DispatchMessageA', \
        EndPaint, 'EndPaint', \
        GetDC, 'GetDC', \
        GetMessage, 'GetMessageA', \
        LoadCursor, 'LoadCursorA', \
        PostQuitMessage, 'PostQuitMessage', \
        RegisterClass, 'RegisterClassA', \
        ReleaseDC, 'ReleaseDC', \
        TranslateMessage, 'TranslateMessage'

    import  gdi32, \
        BitBlt, 'BitBlt', \
        CreateCompatibleDC, 'CreateCompatibleDC', \
        CreateDIBSection, 'CreateDIBSection', \
        DeleteDC, 'DeleteDC', \
        DeleteObject, 'DeleteObject', \
        SelectObject, 'SelectObject', \
        SetStretchBltMode, 'SetStretchBltMode', \
        StretchBlt, 'StretchBlt'

    import  msvcrt, \
        fclose, 'fclose', \
        fopen, 'fopen', \
        fprintf, 'fprintf'
