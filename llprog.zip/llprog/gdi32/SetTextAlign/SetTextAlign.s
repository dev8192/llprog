format PE
entry start

include 'win32a.inc'

CROSS_SIZE = 15

section '.data' data readable writeable
    className db 'TextAlignDemo', 0
    windowTitle db 'SetTextAlign Demonstration', 0

    txtLT db 'TA_LEFT | TA_TOP'
    lenLT = $ - txtLT
    txtCT db 'TA_CENTER | TA_TOP'
    lenCT = $ - txtCT
    txtRT db 'TA_RIGHT | TA_TOP'
    lenRT = $ - txtRT

    txtLB db 'TA_LEFT | TA_BASELINE'
    lenLB = $ - txtLB
    txtCB db 'TA_CENTER | TA_BASELINE'
    lenCB = $ - txtCB
    txtRB db 'TA_RIGHT | TA_BASELINE'
    lenRB = $ - txtRB

    txtLBt db 'TA_LEFT | TA_BOTTOM'
    lenLBt = $ - txtLBt
    txtCBt db 'TA_CENTER | TA_BOTTOM'
    lenCBt = $ - txtCBt
    txtRBt db 'TA_RIGHT | TA_BOTTOM'
    lenRBt = $ - txtRBt

    txtUpdate1 db 'TA_UPDATECP '
    lenUpdate1 = $ - txtUpdate1
    txtUpdate2 db 'advances current position without using X and Y arguments'
    lenUpdate2 = $ - txtUpdate2

    align 4
    test_data:
        dd 150, 100, TA_LEFT or TA_TOP, txtLT, lenLT
        dd 400, 100, TA_CENTER or TA_TOP, txtCT, lenCT
        dd 650, 100, TA_RIGHT or TA_TOP, txtRT, lenRT
        dd 150, 200, TA_LEFT or TA_BASELINE, txtLB, lenLB
        dd 400, 200, TA_CENTER or TA_BASELINE, txtCB, lenCB
        dd 650, 200, TA_RIGHT or TA_BASELINE, txtRB, lenRB
        dd 150, 300, TA_LEFT or TA_BOTTOM, txtLBt, lenLBt
        dd 400, 300, TA_CENTER or TA_BOTTOM, txtCBt, lenCBt
        dd 650, 300, TA_RIGHT or TA_BOTTOM, txtRBt, lenRBt
    test_data_end:

    wc WNDCLASS
    msg MSG
    ps PAINTSTRUCT
    hdc dd ?

    fmt_align db 'fmt_align: %x', 10, 0

section '.text' code readable executable
start:
    invoke GetModuleHandle, 0
    mov [wc.hInstance], eax
    invoke LoadCursor, 0, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.style], CS_HREDRAW or CS_VREDRAW
    mov [wc.lpfnWndProc], WindowProc
    mov [wc.hbrBackground], COLOR_WINDOW + 1
    mov [wc.lpszClassName], className
    invoke RegisterClass, wc
    invoke CreateWindowEx, 0, className, windowTitle,\
        WS_OVERLAPPEDWINDOW or WS_VISIBLE,\
        CW_USEDEFAULT, CW_USEDEFAULT,\
        850, 500, 0, 0, [wc.hInstance], 0

msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    test eax, eax
    jz end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp msg_loop

end_loop:
    invoke ExitProcess, [msg.wParam]

proc WindowProc uses esi edi ebx, hwnd, msg, wparam, lparam
    cmp [msg], WM_DESTROY
    je .wmdestroy
    cmp [msg], WM_PAINT
    je .wmpaint

.wmdefault:
    invoke DefWindowProc, [hwnd], [msg], [wparam], [lparam]
    ret

.wmpaint:
    invoke BeginPaint, [hwnd], ps
    mov [hdc], eax
    invoke GetTextAlign, [hdc]
    cinvoke printf, fmt_align, eax
    invoke SetBkMode, [hdc], TRANSPARENT
    mov esi, test_data

.draw_loop:                                         ; 150 100
    mov eax, [esi]
    sub eax, CROSS_SIZE
    invoke MoveToEx, [hdc], eax, [esi + 4], 0       ; 135 100

    mov eax, [esi]
    add eax, CROSS_SIZE
    invoke LineTo, [hdc], eax, [esi + 4]            ; 165 100

    mov eax, [esi + 4]
    sub eax, CROSS_SIZE
    invoke MoveToEx, [hdc], [esi], eax, 0           ; 150 85

    mov eax, [esi + 4]
    add eax, CROSS_SIZE
    invoke LineTo, [hdc], [esi], eax                ; 150 115

    invoke SetTextAlign, [hdc], [esi + 8]
    invoke TextOut, [hdc], [esi], [esi + 4], [esi + 12], [esi + 16]
    invoke GetTextAlign, [hdc]
    cinvoke printf, fmt_align, eax

    add esi, 20
    cmp esi, test_data_end
    jne .draw_loop

    invoke MoveToEx, [hdc], 150, 400, 0
    invoke SetTextAlign, [hdc], TA_LEFT or TA_TOP or TA_UPDATECP
    invoke TextOut, [hdc], 0, 0, txtUpdate1, lenUpdate1
    invoke TextOut, [hdc], 0, 0, txtUpdate2, lenUpdate2
    invoke GetTextAlign, [hdc]
    cinvoke printf, fmt_align, eax
    invoke EndPaint, [hwnd], ps
    xor eax, eax
    ret

.wmdestroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    ret
endp

section '.idata' import data readable writeable
    library kernel32, 'kernel32.dll',\
            user32, 'user32.dll',\
            gdi32, 'gdi32.dll',\
            msvcrt, 'msvcrt.dll'
    import  kernel32,\
            GetModuleHandle, 'GetModuleHandleW',\
            ExitProcess, 'ExitProcess'
    import user32,\
            RegisterClass, 'RegisterClassA',\
            CreateWindowEx, 'CreateWindowExA',\
            DefWindowProc, 'DefWindowProcA',\
            GetMessage, 'GetMessageA',\
            TranslateMessage, 'TranslateMessage',\
            DispatchMessage, 'DispatchMessageA',\
            LoadCursor, 'LoadCursorA',\
            PostQuitMessage, 'PostQuitMessage',\
            BeginPaint, 'BeginPaint',\
            EndPaint, 'EndPaint'
    import  gdi32,\
            GetTextAlign, 'GetTextAlign',\
            SetTextAlign, 'SetTextAlign',\
            TextOut, 'TextOutA',\
            MoveToEx, 'MoveToEx',\
            LineTo, 'LineTo',\
            SetBkMode, 'SetBkMode'
    import  msvcrt,\
            printf, 'printf'
