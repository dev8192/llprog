format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt     db "%x", 10, 0

section '.text' code readable executable
func1:
    cinvoke printf, fmt, TA_LEFT       ; 00000
    cinvoke printf, fmt, TA_RIGHT      ; 00010
    cinvoke printf, fmt, TA_CENTER     ; 00110
    cinvoke printf, fmt, TA_TOP        ; 00000
    cinvoke printf, fmt, TA_BOTTOM     ; 01000
    cinvoke printf, fmt, TA_BASELINE   ; 11000
    ret

func2:
    cinvoke printf, fmt, TA_LEFT or TA_TOP        ; 00000 00
    cinvoke printf, fmt, TA_CENTER or TA_TOP      ; 00110 06
    cinvoke printf, fmt, TA_RIGHT or TA_TOP       ; 00010 02
    cinvoke printf, fmt, TA_LEFT or TA_BASELINE   ; 11000 18
    cinvoke printf, fmt, TA_CENTER or TA_BASELINE ; 11110 1e
    cinvoke printf, fmt, TA_RIGHT or TA_BASELINE  ; 11010 1a
    cinvoke printf, fmt, TA_LEFT or TA_BOTTOM     ; 01000 08
    cinvoke printf, fmt, TA_CENTER or TA_BOTTOM   ; 01110 0e
    cinvoke printf, fmt, TA_RIGHT or TA_BOTTOM    ; 01010 0a
    ret

start:
    call func1
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
