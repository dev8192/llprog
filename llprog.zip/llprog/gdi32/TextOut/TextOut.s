format PE GUI 4.0
entry start

include 'win32a.inc'

section '.text' code readable executable

start:
    invoke  GetModuleHandle, 0
    mov     [wc.hInstance], eax

    invoke  LoadCursor, 0, IDC_ARROW
    mov     [wc.hCursor], eax

    invoke  RegisterClassEx, wc
    invoke  CreateWindowEx, 0, class_name, window_title, WS_VISIBLE + WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, 500, 300, 0, 0, [wc.hInstance], 0

msg_loop:
    invoke  GetMessage, msg, 0, 0, 0
    cmp     eax, 0
    je      end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     msg_loop

end_loop:
    invoke  ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp     [wmsg], WM_PAINT
    je      .wm_paint
    cmp     [wmsg], WM_DESTROY
    je      .wm_destroy

  .def_proc:
    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret

  .wm_paint:
    invoke  BeginPaint, [hwnd], ps
    invoke  TextOut, [ps.hdc], 20, 20, text_out_str, text_out_len
    invoke  DrawText, [ps.hdc], draw_text_str, -1, rect, DT_WORDBREAK or DT_CENTER
    invoke  EndPaint, [hwnd], ps
    xor     eax, eax
    ret

  .wm_destroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
    ret
endp

section '.data' data readable writeable

class_name      db 'DemonstrationClass', 0
window_title    db 'TextOut vs DrawText', 0

text_out_str    db 'TextOut ignores bounding boundaries and will not wrap long lines of text.', 0
text_out_len    = $ - text_out_str - 1

draw_text_str   db 'DrawText can format text inside a bounding rectangle. '
                db 'It automatically wraps words and can align text, like this centered paragraph.', 0

wc              WNDCLASSEX sizeof.WNDCLASSEX, 0, WindowProc, 0, 0, 0, 0, 0, COLOR_WINDOW+1, 0, class_name, 0
msg             MSG
ps              PAINTSTRUCT
rect            RECT 20, 80, 250, 250

section '.idata' import data readable writeable

    library kernel32, 'KERNEL32.DLL',\
            user32, 'USER32.DLL',\
            gdi32, 'GDI32.DLL'

    import kernel32,\
           GetModuleHandle, 'GetModuleHandleA',\
           ExitProcess, 'ExitProcess'

    import user32,\
           RegisterClassEx, 'RegisterClassExA',\
           CreateWindowEx, 'CreateWindowExA',\
           GetMessage, 'GetMessageA',\
           TranslateMessage, 'TranslateMessage',\
           DispatchMessage, 'DispatchMessageA',\
           DefWindowProc, 'DefWindowProcA',\
           PostQuitMessage, 'PostQuitMessage',\
           BeginPaint, 'BeginPaint',\
           EndPaint, 'EndPaint',\
           DrawText, 'DrawTextA',\
           LoadCursor, 'LoadCursorA'

    import gdi32,\
           TextOut, 'TextOutA'
