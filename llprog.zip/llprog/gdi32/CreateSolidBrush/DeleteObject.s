format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt1 db 'Brush created. Handle: %08X', 10, 0
    fmt2 db 'DeleteObject returned: %d', 10, 0
    hBrush dd ?

section '.text' code readable executable
start:
    invoke CreateSolidBrush, 0x000000FF
    mov [hBrush], eax
    cinvoke printf, fmt1, eax

    invoke DeleteObject, [hBrush]
    cinvoke printf, fmt2, eax

    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
        gdi32, 'gdi32.dll',\
        msvcrt, 'msvcrt.dll'

    import kernel32,\
        ExitProcess, 'ExitProcess'

    import gdi32,\
        CreateSolidBrush, 'CreateSolidBrush',\
        DeleteObject, 'DeleteObject'

    import msvcrt,\
        printf, 'printf'
