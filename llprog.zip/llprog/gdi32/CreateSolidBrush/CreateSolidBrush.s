format PE GUI 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    className db 'BrushApp', 0
    wc WNDCLASS
    msg MSG

section '.text' code readable executable
start:
    invoke GetModuleHandle, 0
    mov [wc.hInstance], eax

    invoke LoadCursor, 0, IDC_ARROW
    mov [wc.hCursor], eax

    ;invoke CreateSolidBrush, 0x000000FF ; red
    ;invoke CreateSolidBrush, 0x0000FF00 ; green
    invoke CreateSolidBrush, 0x00FF0000 ; blue
    mov [wc.hbrBackground], eax

    mov [wc.lpfnWndProc], WindowProc
    mov [wc.lpszClassName], className

    invoke RegisterClass, wc

    invoke CreateWindowEx, 0, className, className, WS_VISIBLE or WS_OVERLAPPEDWINDOW, \
        CW_USEDEFAULT, CW_USEDEFAULT, 400, 300, 0, 0, [wc.hInstance], 0

msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    test eax, eax
    jz end_loop
    invoke DispatchMessage, msg
    jmp msg_loop

end_loop:
    invoke ExitProcess, [msg.wParam]

WindowProc:
    mov eax, [esp+8]
    cmp eax, WM_DESTROY
    je .wmdestroy
    jmp [DefWindowProc]
.wmdestroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    ret 16

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
        user32, 'user32.dll',\
        gdi32, 'gdi32.dll'

    import kernel32,\
        GetModuleHandle, 'GetModuleHandleA',\
        ExitProcess, 'ExitProcess'

    import user32,\
        LoadCursor, 'LoadCursorA',\
        RegisterClass, 'RegisterClassA',\
        CreateWindowEx, 'CreateWindowExA',\
        GetMessage, 'GetMessageA',\
        DispatchMessage, 'DispatchMessageA',\
        DefWindowProc, 'DefWindowProcA',\
        PostQuitMessage, 'PostQuitMessage'

    import gdi32,\
        CreateSolidBrush, 'CreateSolidBrush'
