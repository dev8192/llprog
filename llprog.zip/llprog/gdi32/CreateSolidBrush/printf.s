format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt     db "%x", 10, 0

section '.code' code readable executable

start:
    invoke CreateSolidBrush, 0x000000FF ; red
    cinvoke printf, fmt, eax
    
    invoke CreateSolidBrush, 0x0000FF00 ; green
    cinvoke printf, fmt, eax

    invoke CreateSolidBrush, 0x00FF0000 ; blue
    cinvoke printf, fmt, eax
    
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll',\
            gdi32, 'gdi32.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
    import gdi32,\
            CreateSolidBrush, 'CreateSolidBrush'
