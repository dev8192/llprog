format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt1   db 'Brush created. Handle: %08X', 10, 0
    fmt2   db '%d', 10, 0
    fmtErr db 'Error message: %s', 0
    hBrush dd ?
    errCode dd ?
    errStr rb 256

section '.text' code readable executable
start:
    invoke CreateSolidBrush, 0x000000FF
    mov [hBrush], eax
    cinvoke printf, fmt1, eax

    invoke DeleteObject, [hBrush]
    cinvoke printf, fmt2, eax

    invoke DeleteObject, [hBrush]
    cinvoke printf, fmt2, eax

    invoke GetLastError
    mov     [errCode], eax
    cinvoke printf, fmt2, eax
    invoke FormatMessage, 0x1200, 0, [errCode], 0, errStr, 256, 0
    cinvoke printf, fmtErr, errStr

    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
        gdi32, 'gdi32.dll',\
        msvcrt, 'msvcrt.dll'

    import kernel32,\
        ExitProcess, 'ExitProcess',\
        FormatMessage, 'FormatMessageA',\
        GetLastError, 'GetLastError'

    import gdi32,\
        CreateSolidBrush, 'CreateSolidBrush',\
        DeleteObject, 'DeleteObject'

    import msvcrt,\
        printf, 'printf'
