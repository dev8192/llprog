format PE
entry start

include 'win32a.inc'

RECT_LEFT equ 50
RECT_TOP equ 50
RECT_RIGHT equ 350
RECT_BOTTOM equ 200
RED_COLOR equ 0x000000FF
BLUE_COLOR equ 0x00FF0000
WINDOW_WIDTH equ 400
WINDOW_HEIGHT equ 300
DC_BRUSH equ 18
DC_PEN equ 19

section '.data' data readable writeable
    wc WNDCLASS
    msg MSG
    ps PAINTSTRUCT
    hinstance dd ?
    hwnd dd ?
    class_name db 'DCPenDemoClass', 0
    window_title db 'SetDCPenColor Demo', 0
    fmt_num db '%d', 10, 0

section '.text' code readable executable
start:
    invoke GetModuleHandle, NULL
    mov [hinstance], eax
    mov [wc.style], CS_HREDRAW or CS_VREDRAW
    mov [wc.lpfnWndProc], WindowProc
    mov [wc.cbClsExtra], 0
    mov [wc.cbWndExtra], 0
    mov eax, [hinstance]
    mov [wc.hInstance], eax
    invoke LoadIcon, NULL, IDI_APPLICATION
    mov [wc.hIcon], eax
    invoke LoadCursor, NULL, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.hbrBackground], COLOR_WINDOW + 1
    mov [wc.lpszMenuName], NULL
    mov [wc.lpszClassName], class_name
    invoke RegisterClass, wc

    invoke CreateWindowEx, 0, class_name, window_title,\
        WS_VISIBLE or WS_OVERLAPPEDWINDOW, CW_USEDEFAULT,\
        CW_USEDEFAULT, WINDOW_WIDTH, WINDOW_HEIGHT, NULL, NULL,\
        [hinstance], NULL
    mov [hwnd], eax

msg_loop:
    invoke GetMessage, msg, NULL, 0, 0
    cmp eax, 0
    je end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp msg_loop

end_loop:
    invoke ExitProcess, [msg.wParam]

proc WindowProc hwnd_wnd, wmsg, wparam, lparam
    cmp [wmsg], WM_PAINT
    je .wm_paint
    cmp [wmsg], WM_DESTROY
    je .wm_destroy
    invoke DefWindowProc, [hwnd_wnd], [wmsg], [wparam], [lparam]
    jmp .finish

.wm_paint:
    invoke BeginPaint, [hwnd_wnd], ps
;    invoke GetStockObject, DC_PEN
    cinvoke printf, fmt_num, eax
;    invoke SelectObject, [ps.hdc], eax
;    invoke SetDCPenColor, [ps.hdc], RED_COLOR
;    invoke GetStockObject, DC_BRUSH
    cinvoke printf, fmt_num, eax
;    invoke SelectObject, [ps.hdc], eax
;    invoke SetDCBrushColor, [ps.hdc], BLUE_COLOR
    invoke Rectangle, [ps.hdc], RECT_LEFT, RECT_TOP, RECT_RIGHT, RECT_BOTTOM
    invoke EndPaint, [hwnd_wnd], ps
    xor eax, eax
    jmp .finish

.wm_destroy:
    invoke PostQuitMessage, 0
    xor eax, eax

.finish:
    ret
endp

section '.idata' import data readable writeable
    library kernel32, 'KERNEL32.DLL',\
            user32, 'USER32.DLL',\
            gdi32, 'GDI32.DLL',\
            msvcrt, 'MSVCRT.DLL'
    import  kernel32,\
            GetModuleHandle, 'GetModuleHandleA',\
            ExitProcess, 'ExitProcess'
    import  user32,\
            LoadIcon, 'LoadIconA',\
            LoadCursor, 'LoadCursorA',\
            RegisterClass, 'RegisterClassA',\
            CreateWindowEx, 'CreateWindowExA',\
            GetMessage, 'GetMessageA',\
            TranslateMessage, 'TranslateMessage',\
            DispatchMessage, 'DispatchMessageA',\
            DefWindowProc, 'DefWindowProcA',\
            BeginPaint, 'BeginPaint',\
            EndPaint, 'EndPaint',\
            PostQuitMessage, 'PostQuitMessage'
    import  gdi32,\
            GetStockObject, 'GetStockObject',\
            SelectObject, 'SelectObject',\
            SetDCPenColor, 'SetDCPenColor',\
            SetDCBrushColor, 'SetDCBrushColor',\
            Rectangle, 'Rectangle'
    import  msvcrt,\
            printf, 'printf'
