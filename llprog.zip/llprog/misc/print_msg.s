format PE console
entry start

include 'win32a.inc'

LF = 10

section '.data' data readable
    msg1    db 'one',   LF, 0
    msg2    db 'two',   LF, 0
    msg3    db 'three ', \
               'four',  LF, \
               'five',  LF, 0

section '.text' code executable
start:
    cinvoke printf, msg1
    cinvoke printf, msg2
    cinvoke printf, msg3
    
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll', \
            msvcrt,   'msvcrt.dll'
    import kernel32, ExitProcess, 'ExitProcess'
    import msvcrt,   printf, 'printf'
