format PE console
entry start

include 'win32a.inc'

section '.data' data readable
    msg1    db 'aaaaa'
    msg2    db 'bbbbb'
    msg3    db 'ccccc', 0

section '.text' code executable
start:
    cinvoke printf, msg1
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import msvcrt,   printf, 'printf',\
                     exit,   'exit'
