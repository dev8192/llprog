format PE CONSOLE
entry start

include 'win32a.inc'

EXCEPTION_CONTINUE_EXECUTION equ -1
CONTEXT_EIP_OFFSET           equ 0xB8

section '.data' data readable writeable
    szBefore    db 'szBefore', 10, 0
    szRecovered db 'szRecovered', 10, 0
    hVeh        dd 0

section '.code' code readable executable
start:
    invoke  AddVectoredExceptionHandler, 1, veh_handler
    mov     [hVeh], eax

    cinvoke printf, szBefore

    xor     eax, eax
    mov     dword [eax], 0

safe_landing:
    cinvoke printf, szRecovered
    invoke  RemoveVectoredExceptionHandler, [hVeh]
    invoke  ExitProcess, 0

;veh_handler:
;    mov     eax, [esp + 4]
;    mov     eax, [eax + 4]
;    mov     dword [eax + CONTEXT_EIP_OFFSET], safe_landing
;    mov     eax, EXCEPTION_CONTINUE_EXECUTION
;    ret     4

proc veh_handler pExceptionInfo
    ; pExceptionInfo is a pointer to an EXCEPTION_POINTERS structure
    ; EXCEPTION_POINTERS contains:
    ;   +0: Pointer to EXCEPTION_RECORD
    ;   +4: Pointer to CONTEXT structure

    mov     eax, [pExceptionInfo]     ; EAX = pExceptionInfo
    mov     eax, [eax + 4]            ; EAX = pExceptionInfo->ContextRecord
    
    mov     dword [eax + CONTEXT_EIP_OFFSET], safe_landing
    mov     eax, EXCEPTION_CONTINUE_EXECUTION
    ret
endp

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL',\
            msvcrt,   'MSVCRT.DLL'

    import  kernel32,\
            AddVectoredExceptionHandler, 'AddVectoredExceptionHandler',\
            RemoveVectoredExceptionHandler, 'RemoveVectoredExceptionHandler',\
            ExitProcess, 'ExitProcess'

    import  msvcrt,\
            printf, 'printf'
