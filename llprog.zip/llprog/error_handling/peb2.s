format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    peb_main dd 0
    peb_sec  dd 0
    fmt      db 'Main thread PEB address:      0x%08X', 10
             db 'Secondary thread PEB address: 0x%08X', 10, 0

section '.text' code readable executable
start:
    mov eax, [fs:0x30]
    mov [peb_main], eax

    invoke CreateThread, 0, 0, ThreadProc, 0, 0, 0
    mov ebx, eax

    invoke WaitForSingleObject, ebx, -1
    invoke CloseHandle, ebx

    cinvoke printf, fmt, [peb_main], [peb_sec]

    invoke ExitProcess, 0

ThreadProc:
    mov eax, [fs:0x30]
    mov [peb_sec], eax
    ret 4

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            msvcrt, 'msvcrt.dll'

    import kernel32,\
           CreateThread, 'CreateThread',\
           WaitForSingleObject, 'WaitForSingleObject',\
           CloseHandle, 'CloseHandle',\
           ExitProcess, 'ExitProcess'

    import msvcrt,\
           printf, 'printf'
