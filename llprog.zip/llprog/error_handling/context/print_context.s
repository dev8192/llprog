format PE console
entry start

include 'win32a.inc'

EXCEPTION_CONTINUE_EXECUTION = -1
CONTEXT_EIP_OFFSET           = 0xB8

section '.data' data readable writeable
    fmt_regs    db 'EAX: %08X', 10
                db 'EBX: %08X', 10
                db 'ECX: %08X', 10
                db 'EDX: %08X', 10
                db 'ESI: %08X', 10
                db 'EDI: %08X', 10
                db 'EBP: %08X', 10
                db 'ESP: %08X', 10
                db 'EIP: %08X', 10
                db 'EFL: %08X', 10, 0
    fmt         db '%x', 10, 0
    msg_done    db 'Execution finished normally.', 10, 0

section '.text' code readable executable
start:
    invoke SetUnhandledExceptionFilter, exception_handler
    mov eax, 0x11111111
    mov ebx, 0x22222222
    mov ecx, 0x33333333
    mov edx, 0x44444444
    mov esi, 0x55555555
    mov edi, 0x66666666
trigger_exception:
    ud2
safe_landing:
    cinvoke printf, msg_done
    invoke ExitProcess, 0

proc exception_handler uses ebx, pExceptionInfo
    mov eax, [pExceptionInfo]
    mov ebx, [eax + 4]

    cinvoke printf, fmt_regs, \
        dword [ebx + 0xB0], \
        dword [ebx + 0xA4], \
        dword [ebx + 0xAC], \
        dword [ebx + 0xA8], \
        dword [ebx + 0xA0], \
        dword [ebx + 0x9C], \
        dword [ebx + 0xB4], \
        dword [ebx + 0xC4], \
        dword [ebx + 0xB8], \
        dword [ebx + 0xC0]
    cinvoke printf, fmt, trigger_exception
    cinvoke printf, fmt, safe_landing

    ;add dword [ebx + CONTEXT_EIP_OFFSET], 2
    mov     dword [ebx + CONTEXT_EIP_OFFSET], safe_landing
    mov eax, EXCEPTION_CONTINUE_EXECUTION
    ret
endp

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
        msvcrt, 'msvcrt.dll'

    import kernel32,\
        ExitProcess, 'ExitProcess',\
        SetUnhandledExceptionFilter, 'SetUnhandledExceptionFilter'

    import msvcrt,\
        printf, 'printf'
