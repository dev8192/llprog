format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt db 'PEB Address (Thread %u): 0x%08X', 10, 0
    thread_id dd 1
    thread_handles dd 0, 0, 0 

section '.code' code readable executable
start:
    invoke CreateThread, 0, 0, thread_func, 0, 0, 0
    mov [thread_handles], eax

    invoke CreateThread, 0, 0, thread_func, 0, 0, 0
    mov [thread_handles+4], eax
    
    invoke CreateThread, 0, 0, thread_func, 0, 0, 0
    mov [thread_handles+8], eax

    invoke WaitForMultipleObjects, 3, thread_handles, TRUE, INFINITE

    invoke ExitProcess, 0

thread_func:
    push ebp
    mov ebp, esp

    push eax
    push ebx
    push ecx
    push edx

    mov eax, dword ptr fs:[30h]  ; Get PEB address from TEB
    mov ebx, [thread_id]
    cinvoke printf, fmt, ebx, eax
    inc dword [thread_id]

    pop edx
    pop ecx
    pop ebx
    pop eax

    mov esp, ebp
    pop ebp
    ret

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            msvcrt, 'msvcrt.dll'

    import kernel32,\
           CreateThread, 'CreateThread',\
           WaitForMultipleObjects, 'WaitForMultipleObjects',\
           ExitProcess, 'ExitProcess'

    import msvcrt,\
           printf, 'printf'
