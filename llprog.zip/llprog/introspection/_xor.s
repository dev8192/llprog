
; ------------------------------------------------------------------------------
; B8 00 00 00 00
; 31 C0 
; ------------------------------------------------------------------------------
proc test33 uses ebx esi edi
    jmp .target_end
.target_start:
    mov eax, 0
    xor eax, eax
.target_end:
    stdcall introspect, .target_start, .target_end
    ret
endp

; ------------------------------------------------------------------------------
; 31 C0 
; 31 C9 
; 31 D2 
; 31 DB 
; 31 E4 
; 31 ED 
; 31 F6 
; 31 FF 
; ------------------------------------------------------------------------------
proc test34 uses ebx esi edi
    jmp .target_end
.target_start:
    xor eax, eax
    xor ecx, ecx
    xor edx, edx
    xor ebx, ebx
    xor esp, esp
    xor ebp, ebp
    xor esi, esi
    xor edi, edi
.target_end:
    stdcall introspect, .target_start, .target_end
    ret
endp
