
; ------------------------------------------------------------------------------

main:
    jmp main.run

.func1:
    xor eax, eax

.func2:
    xor eax, eax

.run:
    stdcall introspect, .func1, .func2
    stdcall introspect, .func2, .run
    ret
