
; ------------------------------------------------------------------------------
; ------------------------------------------------------------------------------

main:
    jmp main.run

proc .func10
    ret
endp

proc .func11
    ret
endp

.run:
    stdcall introspect, .func10, .func11
    stdcall introspect, .func11, .run
    ret
