
; ------------------------------------------------------------------------------
; 3 ways to check if the entire 16-bit AX register is zero
;
; TODO: what is the difference between 'or al, ah' and 'or ah, al'?

main1:
    jmp main.run
.func1:
    or al, ah   ; 08 E0
.func2:
    or ah, al   ; 08 C4
.run:
    stdcall introspect, .func1, .func2
    stdcall introspect, .func2, .run
    ret

; ------------------------------------------------------------------------------

main:
    jmp main.run
.func1:
    or al, ah       ; 08 E0
.func2:
    test ax, ax     ; 66 85 C0 
.func3:
    cmp ax, 0       ; 66 83 F8 00 
.run:
    stdcall introspect, .func1, .func2
    stdcall introspect, .func2, .func3
    stdcall introspect, .func3, .run
    ret
