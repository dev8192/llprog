
; ------------------------------------------------------------------------------
; 68 04 10 40 00 68 29 10 40 00 FF 15 80 30 40 00 83 C4 08 
; FF 35 08 10 40 00 FF 35 04 10 40 00 68 29 10 40 00 FF 15 80 30 40 00 83 C4 0C 
; ------------------------------------------------------------------------------
main:
    jmp main.run

.func1:
    cinvoke printf, fmt_llu, num64
.func2:
    push 0x00401004             ; 68 04 10 40 00
    push 0x00401029             ; 68 29 10 40 00
    call dword ptr [0x00403080] ; FF 15 80 30 40 00
    add esp, 8                  ; 83 C4 08
.func3:
    cinvoke printf, fmt_llu, dword [num64], dword [num64 + 4]
.func4:
    push dword ptr [0x00401008]     ; FF 35 08 10 40 00
    push dword ptr [0x00401004]     ; FF 35 04 10 40 00
    push 0x00401029                 ; 68 29 10 40 00
    call dword ptr [0x00403080]     ; FF 15 80 30 40 00
    add esp, 12                     ; 83 C4 0C

.run:
    stdcall introspect, .func1, .func2
    stdcall introspect, .func2, .run
    ret
