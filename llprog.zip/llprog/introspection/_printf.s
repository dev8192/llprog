
; ------------------------------------------------------------------------------
; 68 09 10 40 00 FF 15 80 30 40 00 83 C4 04 68 0F 10 40 00 FF 15 80 30 40 00 83 C4 04 C3 
; ------------------------------------------------------------------------------

main:
    jmp main.run

proc .func10
    cinvoke printf, msg1
    cinvoke printf, msg2
    ret
endp

proc .func11
    push 0x00401009             ; 68 09 10 40 00 
    call dword [0x00403080]     ; FF 15 80 30 40 00 
    add esp, 4                  ; 83 C4 04 
    push 0x0040100F             ; 68 0F 10 40 00 
    call dword [0x00403080]     ; FF 15 80 30 40 00 
    add esp, 4                  ; 83 C4 04 
    ret                         ; C3
endp

.run:
    stdcall introspect, .func10, .func11
    stdcall introspect, .func11, .run
    ret
