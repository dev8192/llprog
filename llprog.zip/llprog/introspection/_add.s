
; ------------------------------------------------------------------------------
; 81 C1 78 56 34 12
; 81 C2 78 56 34 12
; 81 C3 78 56 34 12
; 81 C4 78 56 34 12
; 81 C5 78 56 34 12
; 81 C6 78 56 34 12
; 81 C7 78 56 34 12
; ------------------------------------------------------------------------------
proc test10
    jmp .target_end
.target_start:
    add ecx, 0x12345678
    add edx, 0x12345678
    add ebx, 0x12345678
    add esp, 0x12345678
    add ebp, 0x12345678
    add esi, 0x12345678
    add edi, 0x12345678
.target_end:
    stdcall introspect, .target_start, .target_end
    ret
endp

; ------------------------------------------------------------------------------
; 05 78 56 34 12
; 83 C0 FF
; 83 C4 04
; ------------------------------------------------------------------------------
proc test11
    jmp .target_end
.target_start:
    add eax, 0x12345678
    add eax, 0xffffffff
    add esp, 4
.target_end:
    stdcall introspect, .target_start, .target_end
    ret
endp
