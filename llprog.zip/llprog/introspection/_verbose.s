
; ------------------------------------------------------------------------------

main1:
    jmp main.run

proc .func10
    lodsb
    lods byte [esi]
    ret
endp

proc .func11
    lodsw
    lods word [esi]
    ret
endp

proc .func12
    lodsd
    lods dword [esi]
    ret
endp

.run:
    stdcall introspect, .func10, .func11
    stdcall introspect, .func11, .func12
    stdcall introspect, .func12, .run
    ret

; ------------------------------------------------------------------------------

main:
    jmp main.run

proc .func10
    cmpsb                   ; A6
    cmps byte [esi],[edi]   ; A6
    ret                     ; C3
endp

proc .func11
    cmpsw                   ; 66 A7
    cmps word [esi],[edi]   ; 66 A7
    ret                     ; C3
endp

proc .func12
    cmpsd                   ; A7
    cmps dword [esi],[edi]  ; A7
    ret                     ; C3
endp

.run:
    stdcall introspect, .func10, .func11
    stdcall introspect, .func11, .func12
    stdcall introspect, .func12, .run
    ret
