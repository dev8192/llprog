format PE CONSOLE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    szMsg       db 'hello', 10, 0
    szFmtByte   db '%02X ', 0
    szNewline   db 10, 0

section '.code' code readable executable
start:
target_start:
; 68 00 10 40 00 
; FF 15 80 30 40 00
; 83 C4 04
    cinvoke printf, szMsg
target_end:
    mov     esi, target_start
print_loop:
    movzx   eax, byte [esi]
    cinvoke printf, szFmtByte, eax
    inc     esi
    cmp     esi, target_end
    jb      print_loop
    cinvoke printf, szNewline
    invoke  ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL',\
            msvcrt,   'MSVCRT.DLL'

    import  kernel32,\
            ExitProcess, 'ExitProcess'

    import  msvcrt,\
            printf, 'printf'
