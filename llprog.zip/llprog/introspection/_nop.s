
; ------------------------------------------------------------------------------
; 90 90 90
; ------------------------------------------------------------------------------
proc test10
    jmp .target_end
.target_start:
    nop
    nop
    nop
.target_end:
    stdcall introspect, .target_start, .target_end
    ret
endp
