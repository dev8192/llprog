format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    msg         db 'hello', 10, 0
    fmt_byte    db '%02X ', 0
    newline     db 10, 0
    fmt_hex     db '%x', 10, 0

section '.text' code readable executable
start:
    stdcall test30
    invoke  ExitProcess, 0

proc introspect uses esi, start_addr, end_addr
    mov     esi, [start_addr]
@@:
    movzx   eax, byte [esi]
    cinvoke printf, fmt_byte, eax
    inc     esi
    cmp     esi, [end_addr]
    jl      @b
    cinvoke printf, newline
    ret
endp

include '_call.s'

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
