format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    num1        dd 123
    msg         db 'msg', 10, 0
    msg1        db 'msg1', 10, 0
    msg2        db 'msg2', 10, 0
    fmt_byte    db '%02X ', 0
    newline     db 10, 0
    fmt_hex     db '%x', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke  ExitProcess, 0

proc introspect uses esi, start_addr, end_addr
    mov     esi, [start_addr]
@@:
    movzx   eax, byte [esi]
    cinvoke printf, fmt_byte, eax
    inc     esi
    cmp     esi, [end_addr]
    jl      @b
    cinvoke printf, newline
    ret
endp

include '_printf.s'

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            putchar,        'putchar'
