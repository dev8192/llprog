
; ------------------------------------------------------------------------------
; B8 FF FF FF FF
; B8 FF FF FF FF
; ------------------------------------------------------------------------------
proc test30
    jmp .target_end
.target_start:
    mov eax, -1
    mov eax, 0xffffffff
.target_end:
    stdcall introspect, .target_start, .target_end
    ret
endp

; ------------------------------------------------------------------------------
; B8 78 56 34 12
; ------------------------------------------------------------------------------
proc test31
    jmp .target_end
.target_start:
    mov eax, 0x12345678
.target_end:
    stdcall introspect, .target_start, .target_end
    ret
endp

; ------------------------------------------------------------------------------
; B8 FF FF FF FF 
; B9 FF FF FF FF 
; BA FF FF FF FF 
; BB FF FF FF FF 
; BC FF FF FF FF 
; BD FF FF FF FF 
; BE FF FF FF FF 
; BF FF FF FF FF 
; ------------------------------------------------------------------------------
proc test32 uses ebx esi edi
    jmp .target_end
.target_start:
    mov eax, -1
    mov ecx, -1
    mov edx, -1
    mov ebx, -1
    mov esp, -1
    mov ebp, -1
    mov esi, -1
    mov edi, -1
.target_end:
    stdcall introspect, .target_start, .target_end
    ret
endp
