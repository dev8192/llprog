
; ------------------------------------------------------------------------------

main1:
    cinvoke puts, '*** main1 ***'
    jmp main.run

.func10:
    mov eax, -1             ; B8 FF FF FF FF

.func11:
    mov eax, 0xffffffff     ; B8 FF FF FF FF

.run:
    stdcall introspect, .func10, .func11
    stdcall introspect, .func11, .run
    ret

; ------------------------------------------------------------------------------

main2:
    cinvoke puts, '*** main2 ***'
    jmp main.run

.func10:
    mov ecx, 0x12345678     ; B9 78 56 34 12

.func11:
    mov ecx, 0              ; B9 00 00 00 00

.func12:
    mov ecx, eax            ; 89 C1

.run:
    stdcall introspect, .func10, .func11
    stdcall introspect, .func11, .func12
    stdcall introspect, .func12, .run
    ret

; ------------------------------------------------------------------------------

main3:
    cinvoke puts, '*** main3 ***'
    jmp main.run

.func10:
    mov [num1], 0x12345678     ; C7 05 00 10 40 00 78 56 34 12 

.func11:
    mov [num1], 0              ; C7 05 00 10 40 00 00 00 00 00 

.func12:
    mov [num1], eax            ; A3 00 10 40 00 

.run:
    stdcall introspect, .func10, .func11
    stdcall introspect, .func11, .func12
    stdcall introspect, .func12, .run
    ret

; ------------------------------------------------------------------------------

main:
    cinvoke puts, '*** main4 ***'
    jmp main.run

.func1:                 ; 10 bytes
    mov [num1], 0       ; C7 05 00 10 40 00 00 00 00 00 

.func2:                 ; 7 bytes
    xor eax, eax        ; 31 C0 
    mov [num1], eax     ; A3 00 10 40 00

.run:
    stdcall introspect, .func1, .func2
    stdcall introspect, .func2, .run
    ret

; ------------------------------------------------------------------------------

main5:
    cinvoke puts, '*** main5 ***'
    jmp main.run

.func1:
    mov eax, -1     ; B8 FF FF FF FF
.func2:
    mov ecx, -1     ; B9 FF FF FF FF
.func3:
    mov edx, -1     ; BA FF FF FF FF
.func4:
    mov ebx, -1     ; BB FF FF FF FF
.func5:
    mov esp, -1     ; BC FF FF FF FF
.func6:
    mov ebp, -1     ; BD FF FF FF FF
.func7:
    mov esi, -1     ; BE FF FF FF FF
.func8:
    mov edi, -1     ; BF FF FF FF FF

.run:
    stdcall introspect, .func1, .func2
    stdcall introspect, .func2, .func3
    stdcall introspect, .func3, .func4
    stdcall introspect, .func4, .func5
    stdcall introspect, .func5, .func6
    stdcall introspect, .func6, .func7
    stdcall introspect, .func7, .func8
    stdcall introspect, .func8, .run
    ret

; ------------------------------------------------------------------------------

proc test32 uses ebx esi edi
    jmp .target_end
.target_start:
.target_end:
    stdcall introspect, .target_start, .target_end
    ret
endp
