
; ------------------------------------------------------------------------------
; ------------------------------------------------------------------------------

main:
    jmp main.run

proc .func10
    mov eax, 7
    mov ecx, 2
    sub eax, ecx
    cinvoke printf, fmt_hex, eax
    ret
endp

proc .func11
    mov eax, 7                ; B8 07 00 00 00
    mov ecx, 2                ; B9 02 00 00 00
    sub eax, ecx              ; 29 C8
    push eax                  ; 50
    push 0x401013             ; 68 13 10 40 00
    call dword ptr [0x403080] ; FF 15 80 30 40 00
    add esp, 8                ; 83 C4 08
    ret                       ; C3
endp

.run:
    stdcall introspect, .func10, .func11
    stdcall introspect, .func11, .run
    ret
