
; ------------------------------------------------------------------------------

main:
    jmp main.run

.func1:
    bsf eax, ecx    ; 0F BC C1

.func2:
    bsr eax, ecx    ; 0F BD C1

.run:
    stdcall introspect, .func1, .func2
    stdcall introspect, .func2, .run
    ret
