
; ------------------------------------------------------------------------------
6A 61                FF 15 88 30 40 00 83 C4 04 C3 
E8 02 00 00 00 61 00 FF 15 88 30 40 00 83 C4 04 C3
; ------------------------------------------------------------------------------

main:
    jmp main.run

proc .func10
    cinvoke putchar, 97
    ret
endp

proc .func11
    push 0x61               ; 6A 61
    call dword [0x403088]   ; FF 15 88 30 40 00
    add esp, 4              ; 83 C4 04
    ret                     ; C3
endp

proc .func12
    cinvoke putchar, 'a'
    ret
endp

.run:
    stdcall introspect, .func10, .func11
    stdcall introspect, .func11, .run
    ret
