
; ------------------------------------------------------------------------------
; 55 89 E5 8D 55 08 52 68 0F 10 40 00 FF 15 80 30 40 00 83 C4 08 C9 C2 0C 00 
;
; 55                | push ebp          | Save the old base pointer.
; 89 E5             | mov ebp, esp      | Set up the stack frame.
; 8D 55 08          | lea edx, [ebp+8]  | Load address of the first argument into edx.
; 52                | push edx          | Push that argument onto the stack.
; 68 0F 10 40 00    | push 0x0040100F   | Push a pointer to a string (at 0x40100F).
; FF 15 80 30 40 00 | call [0x00403080] | Call a function (likely printf or scanf).
; 83 C4 08          | add esp, 8        | Clean up the 2 arguments from the stack.
; C9                | leave             | Restore the stack and base pointer.
; C2 0C 00          | ret 12            | Return and pop 12 bytes of arguments.
; ------------------------------------------------------------------------------

proc snippet1 p1, p2, p3
    cinvoke printf, fmt_hex, addr p1
    ret
endp

proc snippet2 p1, p2, p3
    lea edx, [p1]
    cinvoke printf, fmt_hex, edx
    ret
endp

proc test0
    stdcall introspect, snippet1, snippet2
    stdcall introspect, snippet2, test0
    ret
endp
