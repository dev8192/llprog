
; ------------------------------------------------------------------------------
; C3 
; 
; 55       | push ebp     |
; 89 E5    | mov ebp, esp |
; C9       | leave        |
; C2 04 00 | ret 4        | ret imm16 (Near Return with Immediate)
; 
; 55 89 E5 C9 C2 08 00 
; 55 89 E5 C9 C2 0C 00 
; ------------------------------------------------------------------------------

main10:
    jmp main.run

proc .func10
    ret
endp

proc .func11 p1
    ret
endp

proc .func12 p1, p2
    ret
endp

proc .func13 p1, p2, p3
    ret
endp

.run:
    stdcall introspect, .func10, .func11
    stdcall introspect, .func11, .func12
    stdcall introspect, .func12, .func13
    stdcall introspect, .func13, .run
    ret

; ------------------------------------------------------------------------------
; 55 89 E5 8D 55 08 52 68 0F 10 40 00 FF 15 80 30 40 00 83 C4 08 C9 C2 04 00
; ------------------------------------------------------------------------------ 
main333:
    jmp main.run

proc .func10 p1
    cinvoke printf, fmt_hex, addr p1
    ret
endp

.func11:
    push ebp                    ; 55
    mov ebp, esp                ; 89 E5
    lea edx, [ebp+8]            ; 8D 55 08
    push edx                    ; 52
    push fmt_hex                ; 68 0F 10 40 00
;   call [printf]               ; FF 15 80 30 40 00
    call dword [0x00403080]     ; FF 15 80 30 40 00
    add esp, 8                  ; 83 C4 08
    leave                       ; C9
    ret 4                       ; C2 04 00

.run:
    stdcall introspect, .func10, .func11
    stdcall introspect, .func11, .run
    ret

; ------------------------------------------------------------------------------
; 55 89 E5 83 EC 08 
; 8D 55 F8 52 68 0F 10 40 00 FF 15 80 30 40 00 83 C4 08 
; 8D 55 FC 52 68 0F 10 40 00 FF 15 80 30 40 00 83 C4 08 
; C9 C3 
; 55       | PUSH EBP           |
; 89 E5    | MOV EBP, ESP       |
; 83 EC 08 | SUB ESP, 0x8       |
; 8D 55 F8 | LEA EAX, [EBP-0x8] |
; ...
; 8D 55 FC | LEA EAX, [EBP-0x4] |
; ...
; C9       | LEAVE              |
; C3       | RET                |
; ------------------------------------------------------------------------------

main3334:
    jmp main.run

proc .func10
    local buf1[4]:BYTE
    local buf2[4]:BYTE
    cinvoke printf, fmt_hex, addr buf1
    cinvoke printf, fmt_hex, addr buf2
    ret
endp

.func11:
    push ebp
    mov ebp, esp
    sub esp, 0x8
    lea edx, [EBP-0x8]
    cinvoke printf, fmt_hex, edx
    lea edx, [EBP-0x4]
    cinvoke printf, fmt_hex, edx
    leave
    ret

.run:
    stdcall introspect, .func10, .func11
    stdcall introspect, .func11, .run
    ret

; ------------------------------------------------------------------------------
; 53 56 57 5F 5E 5B C3
; ------------------------------------------------------------------------------

main:
    jmp main.run

proc .func10 uses ebx esi edi
    ret
endp

.func11:
    push ebx
    push esi
    push edi
    pop edi
    pop esi
    pop ebx
    ret

.func12:
    push ebx esi edi
    pop edi esi ebx
    ret

.run:
    stdcall introspect, .func10, .func11
    stdcall introspect, .func11, .func12
    stdcall introspect, .func12, .run
    ret
