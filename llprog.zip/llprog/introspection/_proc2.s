
; ------------------------------------------------------------------------------
; C3 
;
; 55 89 E5 C9 C2 04 00 
; 55       | push ebp     |
; 89 E5    | mov ebp, esp |
; C9       | leave        |
; C2 04 00 | ret 4        |
;
; 55 89 E5 83 EC 04 C9 C3 
; 55       | push ebp     |
; 89 E5    | mov ebp, esp |
; 83 EC 04 | sub esp, 4   |
; C9       | leave        |
; C3       | ret          |
;
; 55 89 E5 83 EC 04 C9 C2 04 00 
; 55       | push ebp     |
; 89 E5    | mov ebp, esp |
; 83 EC 04 | sub esp, 4   |
; C9       | leave        |
; C2 04 00 | ret 4        |
; 
; ------------------------------------------------------------------------------

main:
    jmp main.run

proc .func10
    ret
endp

proc .func11 p1
    ret
endp

proc .func12
    local v1:DWORD
    ret
endp

proc .func13 p1
    local v1:DWORD
    ret
endp

.run:
    stdcall introspect, .func10, .func11
    stdcall introspect, .func11, .func12
    stdcall introspect, .func12, .func13
    stdcall introspect, .func13, .run
    ret
