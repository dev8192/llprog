
; ------------------------------------------------------------------------------
; 68 57 20 40 00 C3 
; 6A 01 68 0F 10 40 00 FF 15 80 30 40 00 83 C4 08 
; 6A 02 68 0F 10 40 00 FF 15 80 30 40 00 83 C4 08 C3 
; 
; 68 57 20 40 00    | push 0x00402057
; C3                | ret
; 6A 01             | push 1
; 68 0F 10 40 00    | push 0x0040100F
; FF 15 80 30 40 00 | call dword [0x00403080]
; 83 C4 08          | add esp, 8
; 6A 02             | push 2
; 68 0F 10 40 00    | push 0x0040100F
; FF 15 80 30 40 00 | call dword [0x00403080]
; 83 C4 08          | add esp, 8
; C3                | ret
; 
; ------------------------------------------------------------------------------

main:
    jmp main.run

proc .func10
    push .func10_msg2
    ret
    cinvoke printf, fmt_hex, 1
.func10_msg2:
    cinvoke printf, fmt_hex, 2
    ret
endp

.func20:
    push .func20_msg2
    ret
    cinvoke printf, fmt_hex, 1
.func20_msg2:
    cinvoke printf, fmt_hex, 2
    ret

.run:
    stdcall introspect, .func10, .func20
    stdcall introspect, .func20, .run
    ret
