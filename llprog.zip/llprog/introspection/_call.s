
; ------------------------------------------------------------------------------
; 68 00 10 40 00 FF 15 80 30 40 00 83 C4 04
; ------------------------------------------------------------------------------

main10:
    cinvoke printf, fmt_hex, msg
    cinvoke printf, fmt_hex, printf
    jmp main.run

.func10:
    cinvoke printf, msg

.func20:
    push msg        ; 68 00 10 40 00
    call [printf]   ; FF 15 80 30 40 00
    add esp, 4      ; 83 C4 04

.run:
    stdcall introspect, .func10, .func20
    stdcall introspect, .func20, .run
    ret

; ------------------------------------------------------------------------------
; 68 00 10 40 00
; FF 15 80 30 40 00
; 83 C4 04
; ------------------------------------------------------------------------------

main:
    cinvoke printf, fmt_hex, printf
    cinvoke printf, fmt_hex, $
    mov eax, [printf]
    cinvoke printf, fmt_hex, eax
    jmp .run

.func10:
    call [printf]

.func20:
    call .func20

.func30:
    call 0

.run:
    stdcall introspect, .func10, .func20
    stdcall introspect, .func20, .func30
    stdcall introspect, .func30, .run
    ret

; ------------------------------------------------------------------------------

; FF 34 19
; 
; 0011 0100 0001 1001
; 
; 00 110 100      00 011 001
; mod reg r/m     scale index base
; 
; 
; FF 34 19 68 0F 10 40 00 FF 15 80 30 40 00 83 C4 08 
; 
; FF 34 19            | push dword ptr [ecx + ebx] | Pushes a value from an array indexed by ebx.
; 68 0F 10 40 00      | push 0x40100F              | Pushes a constant (likely fmt_hex).
; FF 15 80 30 40 00   | call dword ptr [0x403080]  | Calls printf (indirect call via IAT).
; 83 C4 08            | add esp, 8                 | Cleans up 2 arguments (8 bytes) from the stack.

; ------------------------------------------------------------------------------
proc test30
    jmp .print
.snippet1:
    cinvoke printf, fmt_hex, dword [ecx + ebx]
.snippet2:
    push dword [ecx + ebx]
    push fmt_hex
    call [printf]
    add esp, 8
.print:
    stdcall introspect, .snippet1, .snippet2
    stdcall introspect, .snippet2, .print
    ret
endp

; what about
; mov eax, 0x12345678
; call eax
; ?
