
; ------------------------------------------------------------------------------
; 68 00 10 40 00
; FF 15 80 30 40 00
; 83 C4 04
; ------------------------------------------------------------------------------
proc test10
    cinvoke printf, fmt_hex, msg
    cinvoke printf, fmt_hex, printf
    jmp .print
.snippet1:
    cinvoke printf, msg
.snippet2:
    push msg
    call [printf]
    add esp, 4
.print:
    stdcall introspect, .snippet1, .snippet2
    stdcall introspect, .snippet2, .print
    ret
endp

; ------------------------------------------------------------------------------
; 68 00 10 40 00
; FF 15 80 30 40 00
; 83 C4 04
; ------------------------------------------------------------------------------
proc test20
    cinvoke printf, fmt_hex, msg
    cinvoke printf, fmt_hex, printf
    jmp .print
.snippet1:
    call [printf]
.snippet2:
    call printf
.snippet3:
    call 0x12345678
.print:
    stdcall introspect, .snippet1, .snippet2
    stdcall introspect, .snippet2, .snippet3
    stdcall introspect, .snippet3, .print
    ret
endp


what about
mov eax, 0x12345678
call eax
?
