
; ------------------------------------------------------------------------------
; 68 04 10 40 00 FF 15 80 30 40 00 83 C4 04 C3 
; 68 04 10 40 00 FF 15 80 30 40 00 83 C4 04 C3 
; ------------------------------------------------------------------------------
main:
    jmp main.run

proc .func10
    cinvoke printf, msg
    ret
endp

proc .func11
    push 0x00401004             ; 68 04 10 40 00
    call dword [0x00403080]     ; FF 15 80 30 40 00
    add esp, 4                  ; 83 C4 04
    ret                         ; C3
endp


; ------------------------------------------------------------------------------
; FF 35 00 10 40 00 68 13 10 40 00 FF 15 80 30 40 00 83 C4 08 C3 
; FF 35 00 10 40 00 68 13 10 40 00 FF 15 80 30 40 00 83 C4 08 C3 
; ------------------------------------------------------------------------------
proc .func12
    cinvoke printf, fmt_hex, [num1]
    ret
endp

proc .func13
    push dword [0x00401000]     ; FF 35 00 10 40 00
    push 0x00401013             ; 68 13 10 40 00
    call dword [0x00403080]     ; FF 15 80 30 40 00
    add esp, 8                  ; 83 C4 08
    ret                         ; C3
endp

.run:
    stdcall introspect, .func10, .func11
    stdcall introspect, .func11, .func12
    stdcall introspect, .func12, .func13
    stdcall introspect, .func13, .run
    ret
