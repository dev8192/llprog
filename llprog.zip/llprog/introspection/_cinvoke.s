
; ------------------------------------------------------------------------------
; 66 FF 33 FF 15 80 30 40 00 83 C4 04 C3
; ------------------------------------------------------------------------------

main:
    jmp main.run

proc .func10
    cinvoke printf, [ebx + SYSTEM_INFO.wProcessorArchitecture]
    ret
endp

proc .func11
    cinvoke printf, word [ebx]
    ret
endp

.run:
    stdcall introspect, .func10, .func11
    stdcall introspect, .func11, .run
    ret
