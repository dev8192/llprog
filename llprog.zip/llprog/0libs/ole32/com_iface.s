format PE
entry start

include 'win32ax.inc'

struc GUID def {
    match d1-d2-d3-d4-d5, def
    \{
        .Data1 dd 0x\#d1
        .Data2 dw 0x\#d2
        .Data3 dw 0x\#d3
        .Data4 db 0x\#d4 shr 8,\
                  0x\#d4 and 0FFh
        .Data5 db 0x\#d5 shr 40,\
                  0x\#d5 shr 32 and 0FFh,\
                  0x\#d5 shr 24 and 0FFh,\
                  0x\#d5 shr 16 and 0FFh,\
                  0x\#d5 shr 8 and 0FFh,\
                  0x\#d5 and 0FFh
    \}
}

interface ITaskBarList,\
        QueryInterface,\
        AddRef,\
        Release,\
        HrInit,\
        AddTab,\
        DeleteTab,\
        ActivateTab,\
        SetActiveAlt

; CLSCTX
CLSCTX_INPROC_SERVER        = 0x1
CLSCTX_INPROC_HANDLER       = 0x2
CLSCTX_LOCAL_SERVER         = 0x4
CLSCTX_INPROC_SERVER16      = 0x8
CLSCTX_REMOTE_SERVER        = 0x10
CLSCTX_INPROC_HANDLER16     = 0x20
CLSCTX_INPROC_SERVERX86     = 0x40
CLSCTX_INPROC_HANDLERX86    = 0x80
CLSCTX_ESERVER_HANDLER      = 0x100
CLSCTX_NO_CODE_DOWNLOAD     = 0x400
CLSCTX_NO_CUSTOM_MARSHAL    = 0x1000
CLSCTX_ENABLE_CODE_DOWNLOAD = 0x2000
CLSCTX_NO_FAILURE_LOG       = 0x4000
CLSCTX_DISABLE_AAA          = 0x8000
CLSCTX_ENABLE_AAA           = 0x10000
CLSCTX_FROM_DEFAULT_CONTEXT = 0x20000

S_OK                    = 0x00000000
REGDB_E_CLASSNOTREG     = 0x80040154
CLASS_E_NOAGGREGATION   = 0x80040110
E_NOINTERFACE           = 0x80004002
E_POINTER               = 0x80004003

ID_EXIT = IDCANCEL
ID_SHOW = 100
ID_HIDE = 101

IDD_COMDEMO = 1

section '.data' data readable writeable
    CLSID_TaskbarList   GUID 56FDF344-FD6D-11D0-958A-006097C9A090
    IID_ITaskbarList    GUID 56FDF342-FD6D-11D0-958A-006097C9A090
    ShellTaskBar        ITaskBarList

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    cinvoke puts, '*** main1 ***'
    invoke CoInitialize, 0
    invoke CoCreateInstance, CLSID_TaskbarList, 0,\
            CLSCTX_INPROC_SERVER, IID_ITaskbarList, ShellTaskBar
    invoke GetModuleHandle, 0
    invoke DialogBoxParam, eax, IDD_COMDEMO, HWND_DESKTOP, COMDemo, 0
    cominvk ShellTaskBar, Release
    ret
endp

proc COMDemo uses ebx esi edi, hwnd, msg, wparam, lparam
    cmp    [msg], WM_INITDIALOG
    je    .wm_initdialog
    cmp    [msg], WM_COMMAND
    je    .wm_command
    cmp    [msg], WM_CLOSE
    je    .wm_close
    xor    eax, eax
    jmp    .finish
.wm_initdialog:
    jmp    .processed
.wm_command:
    cmp [wparam], BN_CLICKED shl 16 + ID_EXIT
    je .wm_close
    cmp [wparam], BN_CLICKED shl 16 + ID_SHOW
    je .show
    cmp [wparam], BN_CLICKED shl 16 + ID_HIDE
    je .hide
    jmp .processed
.show:
   ;stdcall show_comcall1, [hwnd]
    stdcall show_comcall2, [hwnd]
   ;stdcall show_cominvk, [hwnd]
    jmp    .processed
.hide:
   ;stdcall hide_comcall1, [hwnd]
    stdcall hide_comcall2, [hwnd]
   ;stdcall hide_cominvk, [hwnd]
    jmp    .processed
.wm_close:
    invoke EndDialog, [hwnd], 0
.processed:
    mov eax, 1
.finish:
    ret
endp

proc show_comcall1, hwnd
    comcall [ShellTaskBar], ITaskBarList, HrInit
    comcall [ShellTaskBar], ITaskBarList, AddTab, [hwnd]
    comcall [ShellTaskBar], ITaskBarList, ActivateTab, [hwnd]
    ret
endp

proc hide_comcall1, hwnd
    comcall [ShellTaskBar], ITaskBarList, HrInit
    comcall [ShellTaskBar], ITaskBarList, DeleteTab, [hwnd]
    ret
endp

proc show_comcall2, hwnd
    mov ebx, [ShellTaskBar]
    comcall ebx, ITaskBarList, HrInit
    comcall ebx, ITaskBarList, AddTab, [hwnd]
    comcall ebx, ITaskBarList, ActivateTab, [hwnd]
    ret
endp

proc hide_comcall2, hwnd
    mov ebx, [ShellTaskBar]
    comcall ebx, ITaskBarList, HrInit
    comcall ebx, ITaskBarList, DeleteTab, [hwnd]
    ret
endp

proc show_cominvk, hwnd
    cominvk ShellTaskBar, HrInit
    cominvk ShellTaskBar, AddTab, [hwnd]
    cominvk ShellTaskBar, ActivateTab, [hwnd]
    ret
endp

proc hide_cominvk, hwnd
    cominvk ShellTaskBar, HrInit
    cominvk ShellTaskBar, DeleteTab, [hwnd]
    ret
endp

section '.rsrc' resource data readable
    directory RT_DIALOG, dialogs
    resource dialogs,\
        IDD_COMDEMO, LANG_ENGLISH + SUBLANG_DEFAULT, comdemo
    dialog comdemo, 'Taskbar item control', 70, 70, 170, 24, WS_CAPTION + WS_POPUP + WS_SYSMENU + DS_MODALFRAME
        dialogitem 'BUTTON', 'Show', ID_SHOW, 4, 4, 45, 15, WS_VISIBLE + WS_TABSTOP
        dialogitem 'BUTTON', 'Hide', ID_HIDE, 54, 4, 45, 15, WS_VISIBLE + WS_TABSTOP
        dialogitem 'BUTTON', 'Exit', ID_EXIT, 120, 4, 45, 15, WS_VISIBLE + WS_TABSTOP
    enddialog

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            msvcrt,             'msvcrt.dll',\
            user32,             'user32.dll',\
            ole32,              'ole32.dll'
    import  kernel32,\
            GetModuleHandle,    'GetModuleHandleA',\
            ExitProcess,        'ExitProcess'
    import  msvcrt,\
            printf,             'printf',\
            puts,               'puts'
    import  user32,\
            DialogBoxParam,     'DialogBoxParamA',\
            EndDialog,          'EndDialog'
    import  ole32,\
            CoInitialize,       'CoInitialize',\
            CoCreateInstance,   'CoCreateInstance'
