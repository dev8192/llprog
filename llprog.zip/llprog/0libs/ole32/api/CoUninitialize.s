format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_x       db '%x', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    cinvoke puts, '*** main1 ***'
    invoke CoInitialize, 0
    ; S_OK (0) = Success
    ; S_FALSE (1) = Success (COM was already turned on before this)
    test eax, eax
    js .com_failed
    cinvoke printf, msg_success    
    invoke CoUninitialize
.com_failed:
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
