format PE
entry start

include 'win32ax.inc'

struc GUID def {
    match d1-d2-d3-d4-d5, def
    \{
        .Data1 dd 0x\#d1
        .Data2 dw 0x\#d2
        .Data3 dw 0x\#d3
        .Data4 db 0x\#d4 shr 8,\
                  0x\#d4 and 0FFh
        .Data5 db 0x\#d5 shr 40,\
                  0x\#d5 shr 32 and 0FFh,\
                  0x\#d5 shr 24 and 0FFh,\
                  0x\#d5 shr 16 and 0FFh,\
                  0x\#d5 shr 8 and 0FFh,\
                  0x\#d5 and 0FFh
    \}
}

interface ITaskBarList,\
        QueryInterface,\
        AddRef,\
        Release,\
        HrInit,\
        AddTab,\
        DeleteTab,\
        ActivateTab,\
        SetActiveAlt

; CLSCTX
CLSCTX_INPROC_SERVER        = 0x1
CLSCTX_INPROC_HANDLER       = 0x2
CLSCTX_LOCAL_SERVER         = 0x4
CLSCTX_INPROC_SERVER16      = 0x8
CLSCTX_REMOTE_SERVER        = 0x10
CLSCTX_INPROC_HANDLER16     = 0x20
CLSCTX_INPROC_SERVERX86     = 0x40
CLSCTX_INPROC_HANDLERX86    = 0x80
CLSCTX_ESERVER_HANDLER      = 0x100
CLSCTX_NO_CODE_DOWNLOAD     = 0x400
CLSCTX_NO_CUSTOM_MARSHAL    = 0x1000
CLSCTX_ENABLE_CODE_DOWNLOAD = 0x2000
CLSCTX_NO_FAILURE_LOG       = 0x4000
CLSCTX_DISABLE_AAA          = 0x8000
CLSCTX_ENABLE_AAA           = 0x10000
CLSCTX_FROM_DEFAULT_CONTEXT = 0x20000

S_OK                    = 0x00000000
REGDB_E_CLASSNOTREG     = 0x80040154
CLASS_E_NOAGGREGATION   = 0x80040110
E_NOINTERFACE           = 0x80004002
E_POINTER               = 0x80004003

ID_EXIT = IDCANCEL
ID_SHOW = 100
ID_HIDE = 101

IDD_COMDEMO = 1

LANG_ENGLISH_US = 0x0409
ERR_BUF_SZ = 256

section '.data' data readable writeable
    fmt_err             db "Error %d (0x%X): '%s'", 10, 0
    err_buf             rb ERR_BUF_SZ
    CLSID_TaskbarList   GUID 56FDF344-FD6D-11D0-958A-006097C9A090
    IID_ITaskbarList    GUID 56FDF342-FD6D-11D0-958A-006097C9A090
    guid1               GUID 11111111-1111-1111-1111-111111111111
    ShellTaskBar        ITaskBarList
    ShellTaskBar_len    = $ - ShellTaskBar
    fmt_d               db '%d', 10, 0
    msg_success         db 'success', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main1
    cinvoke puts, '*** main1 ***'
    cinvoke printf, fmt_d, ShellTaskBar_len
    ret
endp

proc CoCreateInstance_func uses ebx, rclsid, pUnkOuter, dwClsContext, riid, ppv
    invoke CoCreateInstance, [rclsid], [pUnkOuter],\
           [dwClsContext], [riid], [ppv]
    mov ebx, eax
    test eax, eax
    jnz .error
    cinvoke printf, msg_success
    jmp .done
.error:
   ;and ebx, 0xFFFF
    invoke  FormatMessage,\
            FORMAT_MESSAGE_FROM_SYSTEM + FORMAT_MESSAGE_MAX_WIDTH_MASK,\
            0, ebx, LANG_ENGLISH_US, err_buf, ERR_BUF_SZ, 0
    cinvoke printf, fmt_err, ebx, ebx, err_buf
.done:
    mov eax, ebx
    ret
endp

; --------------------------------------------------------------------
; success
; --------------------------------------------------------------------
proc main1
    cinvoke puts, '*** main1 ***'
    invoke CoInitialize, 0
    stdcall CoCreateInstance_func, CLSID_TaskbarList, 0,\
            CLSCTX_INPROC_SERVER, IID_ITaskbarList, ShellTaskBar
    invoke CoUninitialize
    ret
endp

; --------------------------------------------------------------------
; Error -2147221008 (0x800401F0): 'CoInitialize has not been called. '
; --------------------------------------------------------------------
proc main11
    cinvoke puts, '*** main11 ***'
    stdcall CoCreateInstance_func, CLSID_TaskbarList, 0,\
            CLSCTX_INPROC_SERVER, IID_ITaskbarList, ShellTaskBar
    ret
endp

; --------------------------------------------------------------------
; Error -2147221008 (0x800401F0): 'CoInitialize has not been called. '
; --------------------------------------------------------------------
proc main
    cinvoke puts, '*** main12 ***'
    invoke CoInitialize, 0
    invoke CoUninitialize
    stdcall CoCreateInstance_func, CLSID_TaskbarList, 0,\
            CLSCTX_INPROC_SERVER, IID_ITaskbarList, ShellTaskBar
    ret
endp

; --------------------------------------------------------------------
; Error -2147024809 (0x80070057): 'The parameter is incorrect. '
; --------------------------------------------------------------------
proc main2
    cinvoke puts, '*** main2 ***'
    invoke CoInitialize, 0
    stdcall CoCreateInstance_func, CLSID_TaskbarList, 0,\
            CLSCTX_INPROC_SERVER, IID_ITaskbarList, 0
    stdcall CoCreateInstance_func, CLSID_TaskbarList, 0,\
            CLSCTX_INPROC_SERVER, 0, ShellTaskBar
    ret
endp

; --------------------------------------------------------------------
; -1073741819 Access Violation
; --------------------------------------------------------------------
proc main3
    cinvoke puts, '*** main3 ***'
    invoke CoInitialize, 0
    stdcall CoCreateInstance_func, 0, 0,\
            CLSCTX_INPROC_SERVER, IID_ITaskbarList, ShellTaskBar
    ret
endp

; --------------------------------------------------------------------
; Error -2147221164 (0x80040154): 'Class not registered '
; --------------------------------------------------------------------
proc main4
    cinvoke puts, '*** main4 ***'
    invoke CoInitialize, 0
    stdcall CoCreateInstance_func, CLSID_TaskbarList, 0,\
            0, IID_ITaskbarList, ShellTaskBar
    stdcall CoCreateInstance_func, guid1, 0,\
            CLSCTX_INPROC_SERVER, IID_ITaskbarList, ShellTaskBar
    ret
endp

; --------------------------------------------------------------------
; Error -2147467262 (0x80004002): 'No such interface supported '
; --------------------------------------------------------------------
proc main5
    cinvoke puts, '*** main5 ***'
    invoke CoInitialize, 0
    stdcall CoCreateInstance_func, CLSID_TaskbarList, 0,\
            CLSCTX_INPROC_SERVER, guid1, ShellTaskBar
    ret
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            msvcrt,             'msvcrt.dll',\
            ole32,              'ole32.dll'
    import  kernel32,\
            FormatMessage,      'FormatMessageA',\
            ExitProcess,        'ExitProcess'
    import  msvcrt,\
            printf,             'printf',\
            puts,               'puts'
    import  ole32,\
            CoInitialize,       'CoInitialize',\
            CoUninitialize,     'CoUninitialize',\
            CoCreateInstance,   'CoCreateInstance'
