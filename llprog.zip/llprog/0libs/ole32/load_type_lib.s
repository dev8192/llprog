format PE GUI 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    ; Path to the target system file containing the type layout database
    lib_path         dw 'C',':','\','W','i','n','d','o','w','s','\','S','y','s','t','e','m','3','2','\','a','c','t','x','p','r','x','y','.','d','l','l',0
    
    pTypeLib         dd ?   ; Stores the pointer to the loaded ITypeLib object
    pTypeAttr        dd ?   ; Stores the pointer to the TLIBATTR properties block
    
    ; Setup blank 16-byte memory buffers to receive our destination data
    discovered_guid  db 16 dup (0) 
    
    ; Output string format variables for demonstration
    fmt_string       db 'Extracted Binary GUID Matrix From actxprxy.dll Successful!',0

section '.code' code readable executable
start:
    ; 1. Initialize the COM engine on this thread
    invoke CoInitialize, NULL
    test eax, eax
    js exit_program

    ; 2. Load the binary file as a raw Type Library structure 
    invoke LoadTypeLib, lib_path, pTypeLib
    test eax, eax
    js uninit_com

    ; 3. Execute the GetLibAttr method manually from the ITypeLib structure table
    ; Inside the binary ITypeLib layout, GetLibAttr is method index #3 (Offset = 12 bytes)
    mov eax, [pTypeLib]
    mov edx, [eax]
    push pTypeAttr          ; Pass address of the property block receiver pointer
    push [pTypeLib]         ; Pass the mandatory "this" reference pointer
    call dword [edx + 12]   ; Execute GetLibAttr
    test eax, eax
    js release_lib

    ; 4. Copy the binary GUID string natively out of the generated attribute block
    ; The 16-byte GUID is located exactly at offset +0 inside the TLIBATTR structure.
    mov esi, [pTypeAttr]    ; Point ESI to the newly populated attribute block
    mov edi, discovered_guid ; Point EDI to our blank array
    mov ecx, 4              ; Move 4 dwords (16 bytes total)
    rep movsd               ; Copy the raw bytes directly across RAM

    ; SUCCESS: [discovered_guid] now contains the true system binary data matrix!
    invoke MessageBoxA, NULL, fmt_string, "FASM Extractor Output", MB_OK or MB_ICONINFORMATION

release_attr:
    ; Always call ReleaseTLibAttr (VMT method index #7, Offset = 28 bytes) to free the block
    mov eax, [pTypeLib]
    mov edx, [eax]
    push [pTypeAttr]
    push [pTypeLib]
    call dword [edx + 28]

release_lib:
    ; Call Release (VMT method index #2, Offset = 8 bytes) to unload the type library
    mov eax, [pTypeLib]
    mov edx, [eax]
    push [pTypeLib]
    call dword [edx + 8]

uninit_com:
    invoke CoUninitialize

exit_program:
    invoke ExitProcess, 0

section '.idata' import data readable
  library kernel32,'KERNEL32.DLL',\
          user32,'USER32.DLL',\
          ole32,'OLE32.DLL',\
          oleaut32,'OLEAUT32.DLL'

  import kernel32, ExitProcess,'ExitProcess'
  import user32, MessageBoxA,'MessageBoxA'
  import ole32, CoInitialize,'CoInitialize', CoUninitialize,'CoUninitialize'
  import oleaut32, LoadTypeLib,'LoadTypeLib'
