format PE console
entry start

include 'win32a.inc'

CLSCTX_INPROC_SERVER equ 1
EXIT_SUCCESS equ 0
TRUE equ 1

macro comcall object, interface, method, [arg]
{
    common
    if ~ arg eq
        reverse
        pushd arg
        common
    end if
    mov eax, object
    push eax
    mov eax, [eax]
    call [eax + interface.#method]
}

interface IShellLinkA, \
    QueryInterface, \
    AddRef, \
    Release, \
    GetPath, \
    GetIDList, \
    SetIDList, \
    GetDescription, \
    SetDescription, \
    GetWorkingDirectory, \
    SetWorkingDirectory, \
    GetArguments, \
    SetArguments, \
    GetHotkey, \
    SetHotkey, \
    GetShowCmd, \
    SetShowCmd, \
    GetIconLocation, \
    SetIconLocation, \
    SetRelativePath, \
    Resolve, \
    SetPath

interface IPersistFile, \
    QueryInterface, \
    AddRef, \
    Release, \
    GetClassID, \
    IsDirty, \
    Load, \
    Save, \
    SaveCompleted, \
    GetCurFile

section '.data' data readable writeable

    CLSID_ShellLink  dd 0x00021401
                     dw 0x0000, 0x0000
                     db 0xC0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x46

    IID_IShellLinkA  dd 0x000214EE
                     dw 0x0000, 0x0000
                     db 0xC0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x46

    IID_IPersistFile dd 0x0000010B
                     dw 0x0000, 0x0000
                     db 0xC0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x46

    pShellLink       dd 0
    pPersistFile     dd 0

    szTarget         db 'C:\Windows\System32\notepad.exe', 0
    szLinkPath       du 'test_shortcut.lnk', 0

    msgSuccess       db 'Shortcut created successfully.', 10, 0
    msgError         db 'COM Error: 0x%08X', 10, 0

section '.text' code readable executable

proc start
    invoke CoInitialize, 0
    test eax, eax
    js .print_err

    invoke CoCreateInstance, CLSID_ShellLink, 0, \
                             CLSCTX_INPROC_SERVER, IID_IShellLinkA, pShellLink
    test eax, eax
    js .print_err

    cominvk dword [pShellLink], IShellLinkA.SetPath, szTarget
    test eax, eax
    js .print_err

    cominvk dword [pShellLink], IShellLinkA.QueryInterface, \
                                IID_IPersistFile, pPersistFile
    test eax, eax
    js .print_err

    comcall dword [pPersistFile], IPersistFile, Save, szLinkPath, TRUE
    test eax, eax
    js .print_err

    cinvoke printf, msgSuccess
    jmp .cleanup

.print_err:
    cinvoke printf, msgError, eax

.cleanup:
    cmp dword [pPersistFile], 0
    je .check_link
    cominvk dword [pPersistFile], IPersistFile.Release

.check_link:
    cmp dword [pShellLink], 0
    je .exit
    cominvk dword [pShellLink], IShellLinkA.Release

.exit:
    invoke CoUninitialize
    invoke ExitProcess, EXIT_SUCCESS
endp

section '.idata' import data readable

    library kernel32, 'kernel32.dll', \
            ole32, 'ole32.dll', \
            msvcrt, 'msvcrt.dll'

    import kernel32, \
           ExitProcess, 'ExitProcess'

    import ole32, \
           CoInitialize, 'CoInitialize', \
           CoCreateInstance, 'CoCreateInstance', \
           CoUninitialize, 'CoUninitialize'

    import msvcrt, \
           printf, 'printf'
