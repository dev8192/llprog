; Define version structure variables (Major = 2, Minor = 0)
http_ver HTTPAPI_VERSION <2, 0> 

; 1. Initialize API
invoke HttpInitialize, [HTTP_INITIALIZE_SERVER], http_ver, NULL

; 2. Create a clean Server Session
invoke HttpCreateServerSession, http_ver, session_id, 0

; 3. Create a isolated URL Group under that session
invoke HttpCreateUrlGroup, [session_id], url_group_id, 0

; 4. Bind the string listening rule to the group
invoke HttpAddUrlToUrlGroup, [url_group_id], 'http://localhost:8080/', 0, 0

; 5. Create independent Request Queue and tie the group to it
invoke HttpCreateRequestQueue, http_ver, NULL, NULL, 0, queue_handle
invoke HttpSetUrlGroupProperty, [url_group_id], HttpServerBindingProperty, binding_info, binding_size
