format PE
entry start

include 'win32ax.inc'

macro DEFINE_HTTP_FEATURES [name, id] {
common
    feature_table:
forward
    dd name#_str, id
common
    FEATURE_COUNT = ($ - feature_table) / 8
forward
    name#_str db `name, 0
}

section '.data' data readable writeable
    DEFINE_HTTP_FEATURES\
        HttpFeatureUnknown,                                 0,\
        HttpFeatureResponseTrailers,                        1,\
        HttpFeatureApiTimings,                              2,\
        HttpFeatureDelegateEx,                              3,\
        HttpFeatureHttp3,                                   4,\
        HttpFeatureTlsSessionTickets,                       5,\
        HttpFeatureDisableTlsSessionId,                     6,\
        HttpFeatureTlsDualCerts,                            7,\
        HttpFeatureAutomaticChunkedEncoding,                8,\
        HttpFeatureDedicatedReqQueueDelegationType,         9,\
        HttpFeatureFastForwardResponse,                     10,\
        HttpFeatureCacheTlsClientHello,                     11,\
        HttpFeatureIdleConnectionTimeoutRequestProperty,    12,\
        HttpFeatureDisableAiaFlag,                          13,\
        HttpFeatureDscp,                                    14,\
        HttpFeatureQueryCipherInfo,                         15,\
        HttpFeatureQueryInitialPacketTtl,                   16,\
        HttpFeatureTlsHandshakePerformanceCounters,         17,\
        HttpFeatureLast,                                    18,\
        HttpFeaturemax,                                     0xFFFFFFFF
        
    fmt_msg             db '%-47s : %s', 10, 0
    msg_supported       db 'supported', 0
    msg_unsupported     db 'not supported', 0
    fmt_d               db '%d', 10, 0
    fmt_s               db '%s', 10, 0
    fmt_su              db '%s %u', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc HttpIsFeatureSupported_func, feature_name, FeatureId
    invoke HttpIsFeatureSupported, [FeatureId]
    test eax, eax
    jz .not_supported
    mov eax, msg_supported
    jmp .exit
.not_supported:
    mov eax, msg_unsupported
.exit:
    cinvoke printf, fmt_msg, [feature_name], eax
    ret
endp

proc main uses ebx
    cinvoke puts, '*** main1 ***'
    xor ebx, ebx
.loop:
    invoke HttpIsFeatureSupported, ebx
    cinvoke printf, fmt_d, eax
    inc ebx
    cmp ebx, 50
    jb .loop
    ret
endp

proc main2 uses ebx
    cinvoke puts, '*** main2 ***'
    xor ebx, ebx
.loop:
    lea eax, [feature_table + ebx * 8]
    stdcall HttpIsFeatureSupported_func, dword [eax], dword [eax + 4]
    inc ebx
    cmp ebx, FEATURE_COUNT
    jb .loop
    ret
endp

section '.idata' import data readable
    library kernel32,               'kernel32.dll',\
            msvcrt,                 'msvcrt.dll',\
            httpapi,                'httpapi.dll'
    import  kernel32,\
            ExitProcess,            'ExitProcess'
    import  msvcrt,\
            printf,                 'printf',\
            puts,                   'puts'
    import  httpapi,\
            HttpIsFeatureSupported, 'HttpIsFeatureSupported'
