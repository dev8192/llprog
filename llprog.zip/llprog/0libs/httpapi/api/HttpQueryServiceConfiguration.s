format PE
entry start

include 'win32ax.inc'

HTTPAPI_VER = 1
HTTP_INITIALIZE_SERVER = 1

; HTTP_SERVICE_CONFIG_ID 
HttpServiceConfigIPListenList           = 0
HttpServiceConfigSSLCertInfo            = 1
HttpServiceConfigUrlAclInfo             = 2
HttpServiceConfigTimeout                = 3
HttpServiceConfigCache                  = 4
HttpServiceConfigSslSniCertInfo         = 5
HttpServiceConfigSslCcsCertInfo         = 6
HttpServiceConfigSetting                = 7
HttpServiceConfigSslCertInfoEx          = 8
HttpServiceConfigSslSniCertInfoEx       = 9
HttpServiceConfigSslCcsCertInfoEx       = 10
HttpServiceConfigSslScopedCcsCertInfo   = 11
HttpServiceConfigSslScopedCcsCertInfoEx = 12
HttpServiceConfigMax                    = 13

ERROR_INSUFFICIENT_BUFFER = 122

section '.data' data readable writeable
    pReturnLength      dd 0
    pOutput            dd 0
    hHeap              dd 0
    
    fmtErrorInit       db 'HttpInitialize failed with error: %lu', 10, 0
    fmtErrorQuery      db 'HttpQueryServiceConfiguration failed with error: %lu', 10, 0
    fmtSuccess         db 'Successfully allocated %lu bytes and retrieved configuration!', 10, 0
    fmtIPCount         db 'Number of IP addresses found: %lu', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc HttpQueryServiceConfiguration_func, ServiceHandle, ConfigId, pInput, InputLength,\
                                        pOutput, OutputLength, pReturnLength, pOverlapped
    invoke HttpQueryServiceConfiguration, [ServiceHandle], [ConfigId], [pInput], [InputLength],\
                                        [pOutput], [OutputLength], [pReturnLength], [pOverlapped]
    ret
endp

proc main
    cinvoke puts, '*** main1 ***'
    invoke HttpInitialize, HTTPAPI_VER, HTTP_INITIALIZE_SERVER, 0
    test eax, eax
    jnz .error_init

    stdcall HttpQueryServiceConfiguration_func, 0, HttpServiceConfigIPListenList, 0, 0,\
            0, 0, pReturnLength, 0
    cmp eax, ERROR_INSUFFICIENT_BUFFER
    jne .error_query

    invoke GetProcessHeap
    mov [hHeap], eax
    invoke HeapAlloc, [hHeap], 8, [pReturnLength]
    test eax, eax
    jz .exit
    mov [pOutput], eax

    stdcall HttpQueryServiceConfiguration_func, 0, HttpServiceConfigIPListenList, 0, 0,\
            [pOutput], [pReturnLength], pReturnLength, 0
    test eax, eax
    jnz .error_query_buffered

    cinvoke printf, fmtSuccess, [pReturnLength]
    
    mov ecx, [pOutput]
    mov edx, [ecx]
    cinvoke printf, fmtIPCount, edx
    jmp .cleanup

.error_init:
    cinvoke printf, fmtErrorInit, eax
    jmp .exit

.error_query_buffered:
    push eax
    invoke HeapFree, [hHeap], 0, [pOutput]
    pop eax

.error_query:
    cinvoke printf, fmtErrorQuery, eax
    jmp .terminate

.cleanup:
    invoke HeapFree, [hHeap], 0, [pOutput]

.terminate:
    invoke HttpTerminate, 1, 0

.exit:
    ret
endp

section '.idata' import data readable
    library kernel32,                       'kernel32.dll',\
            httpapi,                        'httpapi.dll',\
            msvcrt,                         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,                    'ExitProcess',\
            GetProcessHeap,                 'GetProcessHeap',\
            HeapAlloc,                      'HeapAlloc',\
            HeapFree,                       'HeapFree'
    import  httpapi,\
            HttpInitialize,                 'HttpInitialize',\
            HttpQueryServiceConfiguration,  'HttpQueryServiceConfiguration',\
            HttpTerminate,                  'HttpTerminate'
    import  msvcrt,\
            printf,                         'printf',\
            puts,                           'puts'
