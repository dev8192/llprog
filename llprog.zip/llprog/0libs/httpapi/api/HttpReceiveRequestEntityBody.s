format PE console
entry start

include 'win32a.inc'

HTTPAPI_VERSION_2 equ 0x00000002
HTTP_INITIALIZE_SERVER equ 1
HttpServerBindingProperty equ 7
HttpHeaderContentType equ 12
HTTP_REQUEST_FLAG_MORE_ENTITY_BODY_EXISTS equ 1
ERROR_HANDLE_EOF equ 38
NO_ERROR equ 0
BUFFER_SIZE equ 4096

struct HTTP_RESPONSE_V1
    Flags               dd ?
    VersionMajor        dw ?
    VersionMinor        dw ?
    StatusCode          dw ?
    ReasonLength        dw ?
    pReason             dd ?
    UnknownHeaderCount  dw ?
    padding1            dw ?
    pUnknownHeaders     dd ?
    TrailingHeaderCount dw ?
    padding2            dw ?
    pTrailingHeaders    dd ?
    KnownHeaders        rb 30 * 8
    EntityChunkCount    dw ?
    padding3            dw ?
    pEntityChunks       dd ?
ends

struct HTTP_DATA_CHUNK
    DataChunkType       dd ?
    pBuffer             dd ?
    BufferLength        dd ?
ends

section '.data' data readable writeable

    sessionId           dq 0
    urlGroupId          dq 0
    requestQueue        dd 0
    bindingInfo         dd 1, 0

    bytesRead           dd 0
    bytesSent           dd 0

    url                 du 'http://localhost:8080/', 0

    msgListening        db 'Listening on http://localhost:8080/ (Send a POST with body)', 10, 0
    msgError            db 'Error: %08X', 10, 0
    msgBodyChunk        db 'Received body data: %s', 10, 0
    msgNoBody           db 'No body in request.', 10, 0

    reasonText          db 'OK', 0
    contentTypeHeader   db 'text/html', 0
    responseBody        db '<html><body><h1>Body Received!</h1></body></html>', 0
    responseBodyLen = $ - responseBody - 1

    response HTTP_RESPONSE_V1 \
        Flags: 0, \
        VersionMajor: 1, \
        VersionMinor: 1, \
        StatusCode: 200, \
        ReasonLength: 2, \
        pReason: reasonText, \
        UnknownHeaderCount: 0, \
        padding1: 0, \
        pUnknownHeaders: 0, \
        TrailingHeaderCount: 0, \
        padding2: 0, \
        pTrailingHeaders: 0, \
        EntityChunkCount: 1, \
        padding3: 0, \
        pEntityChunks: dataChunk

    dataChunk HTTP_DATA_CHUNK \
        DataChunkType: 0, \
        pBuffer: responseBody, \
        BufferLength: responseBodyLen

    requestBuffer       rb BUFFER_SIZE
    bodyBuffer          rb BUFFER_SIZE + 1

section '.text' code readable executable

proc start
    invoke HttpInitialize, HTTPAPI_VERSION_2, HTTP_INITIALIZE_SERVER, 0
    test eax, eax
    jnz .error

    invoke HttpCreateServerSession, HTTPAPI_VERSION_2, sessionId, 0
    test eax, eax
    jnz .error

    invoke HttpCreateUrlGroup, dword [sessionId], dword [sessionId+4], urlGroupId, 0
    test eax, eax
    jnz .error

    invoke HttpCreateRequestQueue, HTTPAPI_VERSION_2, 0, 0, 0, requestQueue
    test eax, eax
    jnz .error

    mov eax, dword [requestQueue]
    mov dword [bindingInfo + 4], eax

    invoke HttpSetUrlGroupProperty, dword [urlGroupId], dword [urlGroupId+4], \
                                    HttpServerBindingProperty, bindingInfo, 8
    test eax, eax
    jnz .error

    invoke HttpAddUrlToUrlGroup, dword [urlGroupId], dword [urlGroupId+4], url, 0, 0, 0
    test eax, eax
    jnz .error

    mov word [response.KnownHeaders + HttpHeaderContentType * 8], 9
    mov dword [response.KnownHeaders + HttpHeaderContentType * 8 + 4], contentTypeHeader

    cinvoke printf, msgListening

.loop:
    invoke HttpReceiveHttpRequest, dword [requestQueue], 0, 0, 0, \
                                   requestBuffer, BUFFER_SIZE, bytesRead, 0
    test eax, eax
    jnz .error

    test dword [requestBuffer], HTTP_REQUEST_FLAG_MORE_ENTITY_BODY_EXISTS
    jz .no_body

.read_loop:
    mov eax, dword [requestBuffer + 16]
    mov edx, dword [requestBuffer + 20]

    invoke HttpReceiveRequestEntityBody, dword [requestQueue], eax, edx, 0, \
                                         bodyBuffer, BUFFER_SIZE, bytesRead, 0
    cmp eax, NO_ERROR
    je .print_chunk
    cmp eax, ERROR_HANDLE_EOF
    je .print_chunk_eof
    jmp .error

.print_chunk:
    mov ecx, dword [bytesRead]
    mov byte [bodyBuffer + ecx], 0
    cinvoke printf, msgBodyChunk, bodyBuffer
    jmp .read_loop

.print_chunk_eof:
    mov ecx, dword [bytesRead]
    test ecx, ecx
    jz .send_response
    mov byte [bodyBuffer + ecx], 0
    cinvoke printf, msgBodyChunk, bodyBuffer
    jmp .send_response

.no_body:
    cinvoke printf, msgNoBody

.send_response:
    mov eax, dword [requestBuffer + 16]
    mov edx, dword [requestBuffer + 20]

    invoke HttpSendHttpResponse, dword [requestQueue], eax, edx, 0, \
                                 response, 0, bytesSent, 0, 0, 0, 0
    jmp .loop

.error:
    cinvoke printf, msgError, eax
    invoke ExitProcess, 1
endp

section '.idata' import data readable

    library kernel32, 'kernel32.dll', \
            httpapi, 'httpapi.dll', \
            msvcrt, 'msvcrt.dll'

    import kernel32, \
           ExitProcess, 'ExitProcess'

    import httpapi, \
           HttpInitialize, 'HttpInitialize', \
           HttpCreateServerSession, 'HttpCreateServerSession', \
           HttpCreateUrlGroup, 'HttpCreateUrlGroup', \
           HttpCreateRequestQueue, 'HttpCreateRequestQueue', \
           HttpSetUrlGroupProperty, 'HttpSetUrlGroupProperty', \
           HttpAddUrlToUrlGroup, 'HttpAddUrlToUrlGroup', \
           HttpReceiveHttpRequest, 'HttpReceiveHttpRequest', \
           HttpReceiveRequestEntityBody, 'HttpReceiveRequestEntityBody', \
           HttpSendHttpResponse, 'HttpSendHttpResponse'

    import msvcrt, \
           printf, 'printf'
