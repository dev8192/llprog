format PE GUI 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    ; Use the 4-byte offset layout (No padding)
    ; Flags(4) + ConnId(8) + ReqId(8) + Context(8) + Version(4) + Verb(4) + UnknownVerbLen(2) = 38
    OFFSET_RAW_URL_LEN_NO_PADDING = 38
    
    ; Use the 8-byte alignment layout (With padding)
    ; Flags(4) + Pad(4) + ConnId(8) + ReqId(8) + Context(8) + Version(4) + Verb(4) + UnknownVerbLen(2) = 42
    OFFSET_RAW_URL_LEN_WITH_PADDING = 42

    requestQueue  dd ?
    bytesRead     dd ?
    urlStr        db 'http://localhost:8080/', 0
    
    requestBuffer rb 4096

section '.text' code readable executable
start:
    invoke HttpInitialize, 1, 1, 0
    invoke HttpCreateHttpHandle, requestQueue, 0
    invoke HttpAddUrl, [requestQueue], urlStr, 0
    invoke HttpReceiveHttpRequest, [requestQueue], 0, 0, 0, requestBuffer, 4096, bytesRead, 0
    test eax, eax
    jnz .exit

    ; 3. CHECK THE DLL'S WORK: Read the RawUrlLength field from both candidate offsets
    movzx ecx, word [requestBuffer + OFFSET_RAW_URL_LEN_NO_PADDING]   ; If Offset 12 was true
    movzx edx, word [requestBuffer + OFFSET_RAW_URL_LEN_WITH_PADDING] ; If Offset 16 was true

    ; 4. Use break-points or output to verify which register holds the real URL length.
    ; If you go to http://localhost:8080/, the raw URL text is "/" (length = 1)
    cmp ecx, 1
    je .offset_12_is_correct
    
    cmp edx, 1
    je .offset_16_is_correct

.exit:
    invoke ExitProcess, 0

.offset_12_is_correct:
    invoke MessageBox, 0, 'httpapi.dll uses Offset 12! No Padding exists.', 'Proof Result', 0
    jmp .exit

.offset_16_is_correct:
    invoke MessageBox, 0, 'httpapi.dll uses Offset 16! Padding exists.', 'Proof Result', 0
    jmp .exit

section '.idata' import data readable
    library kernel32,               'kernel32.dll',\
            user32,                 'user32.dll',\
            httpapi,                'httpapi.dll'
    import  kernel32,\
            ExitProcess,            'ExitProcess'
    import  user32,\
            MessageBox,             'MessageBoxA'
    import  httpapi,\
            HttpInitialize,         'HttpInitialize',\
            HttpCreateHttpHandle,   'HttpCreateHttpHandle',\
            HttpAddUrl,             'HttpAddUrl',\
            HttpReceiveHttpRequest, 'HttpReceiveHttpRequest'
