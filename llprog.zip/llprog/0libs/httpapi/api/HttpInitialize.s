format PE
entry start

include 'win32ax.inc'

HTTPAPI_VER1 = 1
HTTP_INITIALIZE_SERVER = 1

struct HTTPAPI_VERSION
    HttpApiMajor    dw ?
    HttpApiMinor    dw ?
ends

section '.data' data readable writeable
    httpapi_ver2    dd 1
    httpapi_ver3    HTTPAPI_VERSION 1, 0
    httpapi_ver4    db 1, 0, 0, 0
    msg_success     db 'success', 10, 0
    fmt_err         db 'Initialization failed. Error code: %d', 10, 0
    fmt_x           db '%x', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc HttpInitialize_func, Version, Flags, pReserved
    invoke HttpInitialize, [Version], [Flags], [pReserved]
    push eax
    test eax, eax
    jnz .init_error
    cinvoke printf, msg_success
    jmp .exit
.init_error:
    cinvoke printf, fmt_err, eax
.exit:
    pop eax
    ret
endp

proc HttpInitialize_test, httpapi_ver
    stdcall HttpInitialize_func, [httpapi_ver], HTTP_INITIALIZE_SERVER, 0
    test eax, eax
    jnz .exit
    invoke HttpTerminate, HTTP_INITIALIZE_SERVER, 0
.exit:
    ret
endp

proc main1
    cinvoke puts, '*** main1 ***'
    cinvoke printf, fmt_x, HTTPAPI_VER1
    cinvoke printf, fmt_x, dword [httpapi_ver2]
    cinvoke printf, fmt_x, dword [httpapi_ver3]
    cinvoke printf, fmt_x, dword [httpapi_ver4]
    ret
endp

; ---------------------------------
; success
; ---------------------------------
proc main
    cinvoke puts, '*** main2 ***'
    stdcall HttpInitialize_test, HTTPAPI_VER1
    stdcall HttpInitialize_test, dword [httpapi_ver2]
    stdcall HttpInitialize_test, dword [httpapi_ver3]
    stdcall HttpInitialize_test, dword [httpapi_ver4]
    stdcall HttpInitialize_test, 1
    ret
endp

; ---------------------------------
; 1154 ERROR_BAD_DLL_ENTRYPOINT
; ---------------------------------
proc main4
    cinvoke puts, '*** main4 ***'
    stdcall HttpInitialize_func, 555, HTTP_INITIALIZE_SERVER, 0
    ret
endp

; ---------------------------------
; 87 ERROR_INVALID_PARAMETER
; ---------------------------------
proc main5
    cinvoke puts, '*** main5 ***'
    stdcall HttpInitialize_func, HTTPAPI_VER1, 555, 0
    stdcall HttpInitialize_func, HTTPAPI_VER1, HTTP_INITIALIZE_SERVER, 555
    ret
endp

section '.idata' import data readable
    library kernel32,                   'kernel32.dll',\
            msvcrt,                     'msvcrt.dll',\
            httpapi,                    'httpapi.dll'
    import  kernel32,\
            ExitProcess,                'ExitProcess',\
            RtlZeroMemory,              'RtlZeroMemory',\
            lstrcmp,                    'lstrcmpW'
    import  msvcrt,\
            printf,                     'printf',\
            puts,                       'puts'
    import  httpapi,\
            HttpInitialize,             'HttpInitialize',\
            HttpTerminate,              'HttpTerminate'
