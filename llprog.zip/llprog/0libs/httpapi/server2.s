format PE
entry start

include 'win32ax.inc'

HTTPAPI_VERSION_1 = 0x00000001
HTTP_RECEIVE_REQUEST_FLAG_COPY_BODY = 0x00000001
HTTP_INITIALIZE_SERVER = 1

struct HTTPAPI_VERSION
    HttpApiMajor    dw ?
    HttpApiMinor    dw ?
ends

section '.data' data readable writeable
    url_binding     du 'http://localhost:8443/', 0
    
    route_home      db '/', 0
    res_status_200  db '200 OK', 0
    res_content_txt db 'text/plain', 0
    body_home       db 'Welcome to my ultra-safe FASM Server!', 0

    fmt_err         db 'Initialization failed. Error code: %d', 10, 0
    fmt_listen      db 'FASM Server listening safely on http://localhost:8443/', 10, 0

    align 8
    req_buffer      db 4096 dup(0)
    bytes_returned  dd ?
    req_id          dq ?
    req_handle      dd ?
    msg_success     db 'success', 10, 0
    http_ver1       dd 0x00000002
    http_ver2       HTTPAPI_VERSION 1, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    cinvoke puts, '*** main1 ***'
    invoke HttpInitialize, HTTPAPI_VERSION_1, HTTP_INITIALIZE_SERVER, 0
   ;invoke HttpInitialize, dword [http_ver2], HTTP_INITIALIZE_SERVER, 0
    test eax, eax
    jnz .init_error
    cinvoke printf, msg_success
    invoke HttpTerminate, HTTP_INITIALIZE_SERVER, 0
    jmp .exit
.init_error:
    cinvoke printf, fmt_err, eax
.exit:
    ret
endp

; ---------------------------------
; 1154 ERROR_BAD_DLL_ENTRYPOINT
; ---------------------------------
proc main11
    cinvoke puts, '*** main11 ***'
    invoke HttpInitialize, 0, HTTP_INITIALIZE_SERVER, 0
    test eax, eax
    jnz .init_error
    cinvoke printf, msg_success
    invoke HttpTerminate, HTTP_INITIALIZE_SERVER, 0
    jmp .exit
.init_error:
    cinvoke printf, fmt_err, eax
.exit:
    ret
endp

proc main2 use esi edi
    cinvoke puts, '*** main2 ***'
    invoke HttpInitialize, HTTPAPI_VERSION_1, HTTP_INITIALIZE_SERVER, 0
    test eax, eax
    jnz .init_error

    invoke HttpCreateHttpQueueHandle, req_handle, 0
    test eax, eax
    jnz .cleanup

    invoke HttpAddUrl, [req_handle], url_binding, 0
    test eax, eax
    jnz .cleanup

    cinvoke printf, fmt_listen

.server_loop:
    invoke  HttpReceiveHttpRequest, [req_handle], 0,\
            HTTP_RECEIVE_REQUEST_FLAG_COPY_BODY, req_buffer, 4096, bytes_returned, 0
    test eax, eax
    jnz .server_loop

    mov esi, req_buffer
    mov edi, [esi + 12]     
    mov eax, [edi + 4]      

    invoke lstrcmp, eax, url_binding
    je .handle_home

    stdcall send_response, res_status_200, res_content_txt, body_home, 37
    jmp .server_loop

.handle_home:
    stdcall send_response, res_status_200, res_content_txt, body_home, 37
    jmp .server_loop

.cleanup:
    invoke HttpTerminate, HTTP_INITIALIZE_SERVER, 0
    jmp .exit

.init_error:
    cinvoke printf, fmt_err, eax
.exit:
    ret
endp

proc send_response, pStatus, pType, pBody, nBodyLen
    local response:HTTP_RESPONSE
    local chunk:HTTP_DATA_CHUNK

    lea eax, [response]
    invoke RtlZeroMemory, eax, sizeof.HTTP_RESPONSE
    lea eax, [chunk]
    invoke RtlZeroMemory, eax, sizeof.HTTP_DATA_CHUNK

    mov [response.StatusCode], 200
    mov eax, [pStatus]
    mov [response.pReason], eax
    mov [response.ReasonLength], 6

    mov [chunk.DataChunkType], HttpDataChunkFromMemory
    mov eax, [pBody]
    mov [chunk.pBuffer], eax
    mov eax, [nBodyLen]
    mov [chunk.BufferLength], eax

    lea eax, [chunk]
    mov [response.pEntityChunks], eax
    mov [response.EntityChunkCount], 1

    mov esi, req_buffer
    mov eax, [esi + 24]     
    mov edx, [esi + 28]
    mov dword [req_id], eax
    mov dword [req_id + 4], edx

    invoke HttpSendHttpResponse, [req_handle], [req_id], 0, response, 0, 0, 0, 0, 0, 0
    ret
endp

section '.idata' import data readable
    library kernel32,                   'kernel32.dll',\
            msvcrt,                     'msvcrt.dll',\
            httpapi,                    'httpapi.dll'
    import  kernel32,\
            ExitProcess,                'ExitProcess',\
            RtlZeroMemory,              'RtlZeroMemory',\
            lstrcmp,                    'lstrcmpW'
    import  msvcrt,\
            printf,                     'printf',\
            puts,                       'puts'
    import  httpapi,\
            HttpInitialize,             'HttpInitialize',\
            HttpCreateHttpQueueHandle,  'HttpCreateHttpQueueHandle',\
            HttpAddUrl,                 'HttpAddUrl',\
            HttpReceiveHttpRequest,     'HttpReceiveHttpRequest',\
            HttpSendHttpResponse,       'HttpSendHttpResponse',\
            HttpTerminate,              'HttpTerminate'
