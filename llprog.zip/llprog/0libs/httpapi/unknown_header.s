; ==============================================================================
; Searching Unknown Headers for "X-Auth-Token"
; ==============================================================================
; Assume: EBX = Base pointer to the main HTTP_REQUEST_V1 structure

; 1. Navigate to the Headers component block
lea edx, [ebx + 80]                    ; EDX = Pointer to Headers struct (+80)

; 2. Fetch the loop configuration counter and array pointer
movzx ecx, word [edx + 0]               ; ECX = UnknownHeaderCount (+0)
mov esi, [edx + 2]                     ; ESI = pUnknownHeaders array base pointer (+2)

test ecx, ecx                          ; Are there any unknown headers?
jz .header_not_found                   ; If 0, bypass search loop

.search_loop:
  push ecx                             ; Save the outer loop counter
  
  ; 3. Validate name string length first to optimize speed
  ; "X-Auth-Token" is exactly 12 characters long
  cmp [esi + 0], word 12                ; Check HTTP_UNKNOWN_HEADER.NameLength
  jne .next_header                     ; If size mismatches, skip string comparison
  
  ; 4. Compare the header name string in memory
  mov edi, [esi + 4]                   ; EDI = HTTP_UNKNOWN_HEADER.pName string pointer
  mov ecx, 12                          ; ECX = 12 bytes to compare
  push esi                             ; Save current array item pointer
  mov esi, target_header_name          ; ESI = Pointer to our local target string constant
  repe cmpsb                           ; Compare strings byte-by-byte
  pop esi                              ; Restore current array item pointer
  jne .next_header                     ; If text does not match, hop to next
  
  ; 5. MATCH FOUND! Extract the header value
  movzx eax, word [esi + 2]            ; EAX = HTTP_UNKNOWN_HEADER.RawValueLength
  mov edx, [esi + 8]                   ; EDX = HTTP_UNKNOWN_HEADER.pRawValue string pointer
  
  pop ecx                              ; Clear the saved loop count from stack
  jmp .process_token                   ; Proceed with your custom value logic

.next_header:
  pop ecx                              ; Restore loop counter
  add esi, 12                          ; Advance ESI to the next structure index (+12 bytes)
  loop .search_loop                    ; Decrement ECX and repeat loop if ECX > 0

.header_not_found:
  ; Custom header was not sent by the client
  xor edx, edx                         ; NULL out register
  xor eax, eax                         ; NULL out register

.process_token:
  ; If found, EDX now points to the token string, and EAX holds its length.
  ; Note: Strings are NOT null-terminated! Use EAX for string operations.


section '.data' data readable
  target_header_name db 'X-Auth-Token'
