format PE
entry start

include 'win32ax.inc'
include 'httpapi.inc'

section '.data' data readable writeable
    fmt_x       db '%x', 10, 0
    fmt_d       db '%d', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main1
    cinvoke puts, '*** main1 ***'
    cinvoke printf, fmt_d, sizeof.FromMemory
    cinvoke printf, fmt_d, sizeof.FromFileHandle
    cinvoke printf, fmt_d, sizeof.FromFragmentCache

    cinvoke printf, fmt_d, sizeof.HTTP_DATA_CHUNK_inner_struct
    cinvoke printf, fmt_d, sizeof.HTTP_DATA_CHUNK_outer_struct
    cinvoke printf, fmt_d, sizeof.HTTP_DATA_CHUNK_FromMemory
    cinvoke printf, fmt_d, sizeof.HTTP_DATA_CHUNK_FromFileHandle
    cinvoke printf, fmt_d, sizeof.HTTP_DATA_CHUNK_FromFragmentCache
    ret
endp

proc main
    cinvoke puts, '*** main2 ***'
    cinvoke printf, fmt_d, sizeof.HTTP_RESPONSE_V1
    cinvoke printf, fmt_d, sizeof.HTTP_RESPONSE_V2
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
