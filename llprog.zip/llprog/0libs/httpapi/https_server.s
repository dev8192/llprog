
; HttpSetServiceConfiguration
; HttpDeleteServiceConfiguration
; HttpUpdateServiceConfiguration
; HttpQueryServiceConfiguration
