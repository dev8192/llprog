format PE console
entry start

include 'win32a.inc'
include 'httpapi.inc'

section '.data' data readable writeable
    sessionId           dq 0
    urlGroupId          dq 0
    requestQueue        dd 0
    bindingInfo         dd 1, 0

    bytesRead           dd 0
    bytesSent           dd 0

    url                 du 'http://localhost:8080/', 0

    msgListening        db 'Listening on http://localhost:8080/', 10, 0
    msgError            db 'Error: %08X', 10, 0

    reasonText          db 'OK', 0
    contentTypeHeader   db 'text/html', 0
    responseBody        db '<html><body><h1>Hello from FASM HTTP Server!</h1></body></html>', 0
    responseBodyLen = $ - responseBody - 1

    response HTTP_RESPONSE_V1 \
        Flags: 0,\
        VersionMajor: 1,\
        VersionMinor: 1,\
        StatusCode: 200,\
        ReasonLength: 2,\
        pReason: reasonText,\
        UnknownHeaderCount: 0,\
        padding1: 0,\
        pUnknownHeaders: 0,\
        TrailingHeaderCount: 0,\
        padding2: 0,\
        pTrailingHeaders: 0,\
        EntityChunkCount: 1,\
        padding3: 0,\
        pEntityChunks: dataChunk

    dataChunk HTTP_DATA_CHUNK \
        DataChunkType: 0,\
        pBuffer: responseBody,\
        BufferLength: responseBodyLen

    requestBuffer       rb 4096

section '.text' code readable executable

proc start
    invoke HttpInitialize, HTTPAPI_VERSION_2, HTTP_INITIALIZE_SERVER, 0
    test eax, eax
    jnz .error

    invoke HttpCreateServerSession, HTTPAPI_VERSION_2, sessionId, 0
    test eax, eax
    jnz .error

    invoke HttpCreateUrlGroup, dword [sessionId], dword [sessionId+4], urlGroupId, 0
    test eax, eax
    jnz .error

    invoke HttpCreateRequestQueue, HTTPAPI_VERSION_2, 0, 0, 0, requestQueue
    test eax, eax
    jnz .error

    mov eax, dword [requestQueue]
    mov dword [bindingInfo + 4], eax

    invoke HttpSetUrlGroupProperty, dword [urlGroupId], dword [urlGroupId+4],\
                                    HttpServerBindingProperty, bindingInfo, 8
    test eax, eax
    jnz .error

    invoke HttpAddUrlToUrlGroup, dword [urlGroupId], dword [urlGroupId+4], url, 0, 0, 0
    test eax, eax
    jnz .error

    mov word [response.KnownHeaders + HttpHeaderContentType * 8], 9
    mov dword [response.KnownHeaders + HttpHeaderContentType * 8 + 4], contentTypeHeader

    invoke printf, msgListening

.loop:
    invoke HttpReceiveHttpRequest, dword [requestQueue], 0, 0, 0,\
                                   requestBuffer, 4096, bytesRead, 0
    test eax, eax
    jnz .error
    mov eax, dword [requestBuffer + 16]
    mov edx, dword [requestBuffer + 20]
    invoke HttpSendHttpResponse, dword [requestQueue], eax, edx, 0,\
                                 response, 0, bytesSent, 0, 0, 0, 0
    jmp .loop

.error:
    invoke printf, msgError, eax
    invoke ExitProcess, 1
endp

section '.idata' import data readable
    library kernel32,                   'kernel32.dll',\
            httpapi,                    'httpapi.dll',\
            msvcrt,                     'msvcrt.dll'
    import  kernel32,\
            ExitProcess,                'ExitProcess'
    import  httpapi,\
            HttpInitialize,             'HttpInitialize',\
            HttpCreateServerSession,    'HttpCreateServerSession',\
            HttpCreateUrlGroup,         'HttpCreateUrlGroup',\
            HttpCreateRequestQueue,     'HttpCreateRequestQueue',\
            HttpSetUrlGroupProperty,    'HttpSetUrlGroupProperty',\
            HttpAddUrlToUrlGroup,       'HttpAddUrlToUrlGroup',\
            HttpReceiveHttpRequest,     'HttpReceiveHttpRequest',\
            HttpSendHttpResponse,       'HttpSendHttpResponse'
    import  msvcrt,\
            printf,                     'printf'
