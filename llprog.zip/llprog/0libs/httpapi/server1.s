format PE
entry start

include 'win32ax.inc'

HTTP_INITIALIZE_SERVER equ 1
HttpDataChunkFromMemory equ 0
HttpHeaderContentType equ 12
REQ_BUF_SIZE equ 4096
HTTPAPI_VERSION_MAJOR equ 1
HTTPAPI_VERSION_MINOR equ 0
HTTPAPI_VERSION_1_0 equ (HTTPAPI_VERSION_MINOR shl 16) or HTTPAPI_VERSION_MAJOR
HTTP_STATUS_OK equ 200
HTTP_RES_VER_MAJOR equ 1
HTTP_RES_VER_MINOR equ 1

struct HTTP_VERSION
    MajorVersion dw ?
    MinorVersion dw ?
ends

struct HTTP_KNOWN_HEADER
    RawValueLength dw ?
    wPad dw ?
    pRawValue dd ?
ends

struct HTTP_RESPONSE_HEADERS
    UnknownHeaderCount dw ?
    wPad1 dw ?
    pUnknownHeaders dd ?
    TrailerCount dw ?
    wPad2 dw ?
    pTrailers dd ?
    KnownHeaders HTTP_KNOWN_HEADER 30 dup(?)
ends

struct HTTP_RESPONSE
    Flags dd ?
    Version HTTP_VERSION
    StatusCode dw ?
    ReasonLength dw ?
    pReason dd ?
    Headers HTTP_RESPONSE_HEADERS
    EntityChunkCount dw ?
    wPad1 dw ?
    pEntityChunks dd ?
ends

struct HTTP_DATA_CHUNK
    DataChunkType dd ?
    pBuffer dd ?
    BufferLength dd ?
    _pad dd 3 dup(?)
ends

struct HTTP_REQUEST
    Flags dd ?
    _pad dd ?
    ConnectionId dq ?
    RequestId dq ?
ends

section '.data' data readable writeable
    hReqQueue           dd ?
    bytesReturned       dd ?
    url                 du 'http://localhost:8080/', 0
    msg_listening       db 'Listening on http://localhost:8080/', 10, 0
    reason              db 'OK', 0
    REASON_LEN          = $ - reason - 1
    contentType         db 'text/plain', 0
    CONTENT_TYPE_LEN    = $ - contentType - 1
    body                db 'Hello from FASM HTTP Server!'
    BODY_LEN            = $ - body
    reqBuf              rb REQ_BUF_SIZE
    response            HTTP_RESPONSE
    dataChunk           HTTP_DATA_CHUNK

section '.text' code readable executable
start:
    invoke main
    invoke ExitProcess, 0

proc main
    invoke HttpInitialize, HTTPAPI_VERSION_1_0, HTTP_INITIALIZE_SERVER, 0
    invoke HttpCreateHttpHandle, hReqQueue, 0
    invoke HttpAddUrl, [hReqQueue], url, 0
    cinvoke printf, msg_listening
request_loop:
    cinvoke memset, reqBuf, 0, REQ_BUF_SIZE
    invoke HttpReceiveHttpRequest,\
           [hReqQueue], 0, 0, 0,\
           reqBuf, REQ_BUF_SIZE, bytesReturned, 0
    test eax, eax
    jnz request_loop
    invoke handle_request
    jmp request_loop
    ret
endp

proc handle_request
    cinvoke memset, response, 0, sizeof.HTTP_RESPONSE

    mov [response.StatusCode], HTTP_STATUS_OK
    mov [response.ReasonLength], REASON_LEN
    mov [response.pReason], reason
    mov [response.Version.MajorVersion], HTTP_RES_VER_MAJOR
    mov [response.Version.MinorVersion], HTTP_RES_VER_MINOR

    mov eax, HttpHeaderContentType
    imul eax, eax, sizeof.HTTP_KNOWN_HEADER
    add eax, response.Headers.KnownHeaders
    mov [eax + HTTP_KNOWN_HEADER.RawValueLength], CONTENT_TYPE_LEN
    mov dword [eax + HTTP_KNOWN_HEADER.pRawValue], contentType

    mov [dataChunk.DataChunkType], HttpDataChunkFromMemory
    mov [dataChunk.pBuffer], body
    mov [dataChunk.BufferLength], BODY_LEN

    mov [response.EntityChunkCount], 1
    mov [response.pEntityChunks], dataChunk

    mov eax, dword [reqBuf + HTTP_REQUEST.RequestId]
    mov edx, dword [reqBuf + HTTP_REQUEST.RequestId + 4]

    invoke HttpSendHttpResponse,\
           [hReqQueue], eax, edx, 0,\
           response, 0, bytesReturned, 0, 0, 0, 0
    ret
endp

section '.idata' import data readable
    library httpapi,                'httpapi.dll',\
            msvcrt,                 'msvcrt.dll',\
            kernel32,               'kernel32.dll'
    import  httpapi,\
            HttpInitialize,         'HttpInitialize',\
            HttpCreateHttpHandle,   'HttpCreateHttpHandle',\
            HttpAddUrl,             'HttpAddUrl',\
            HttpReceiveHttpRequest, 'HttpReceiveHttpRequest',\
            HttpSendHttpResponse,   'HttpSendHttpResponse'
    import  msvcrt,\
            printf,                 'printf',\
            memset,                 'memset'
    import  kernel32,\
            ExitProcess,            'ExitProcess'
