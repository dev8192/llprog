format PE console
entry start

include 'win32a.inc'

; HttpApi Constants
HTTPAPI_VERSION_1 = 0x00010000
HTTP_RECEIVE_REQUEST_FLAG_COPY_BODY = 0x00000001

section '.data' data readable writeable
    ; Bind to HTTPS on port 443. The '+' means listen on all hostnames/IPs.
    url_binding     du 'https://:443/',0
    
    route_home      db '/', 0
    route_api       db '/api', 0

    res_status_200  db '200 OK', 0
    res_status_404  db '404 Not Found', 0
    res_content_txt db 'text/plain', 0
    
    ; Response Payloads
    body_home       db 'Welcome to FASM Express!', 0
    body_api        db '{"status":"success","data":"Hello from Assembly"}', 0
    body_404        db 'Route not found.', 0

    fmt_err         db 'Initialization failed. Error code: %d', 13, 10, 0
    fmt_listen      db 'FASM Server listening on https://localhost:443/', 13, 10, 0

    align 8
    req_buffer      db 4096 dup(0)    ; Buffer to store the incoming HTTP request
    bytes_returned  dd ?
    req_id          dq ?              ; 64-bit ID assigned to this request by Windows

section '.code' code readable executable

start:
    ; 1. Initialize the native Windows HTTP engine
    invoke HttpInitialize, HTTPAPI_VERSION_1, HTTP_INITIALIZE_SERVER, 0
    test eax, eax
    jnz .init_error

    ; 2. Create an HTTP Request Queue (Like app = express())
    invoke HttpCreateHttpQueueHandle, req_handle, 0
    test eax, eax
    jnz .cleanup

    ; 3. Add our HTTPS URL binding to the queue
    invoke HttpAddUrl, [req_handle], url_binding, 0
    test eax, eax
    jnz .cleanup

    cinvoke printf, fmt_listen

.server_loop:
    invoke HttpReceiveHttpRequest, [req_handle], 0, \
                                  HTTP_RECEIVE_REQUEST_FLAG_COPY_BODY, \
                                  req_buffer, 4096, bytes_returned, 0
    test eax, eax
    jnz .server_loop

    mov esi, req_buffer
    mov edx, [esi + 12]     ; Offset 12 inside req_buffer holds the pointer to the cooked URL string
    test edx, edx
    jz .send_404

    ; Convert wide character cooked URL pointer to regular ASCII string comparison
    ; For simplicity, we check if the user is hitting the root '/' path or '/api'
    mov edi, [esi + 12]     ; Fetch URL structure pointer
    mov eax, [edi + 4]      ; Offset 4 inside URL struct points directly to the raw URL string

    ; --- Route: GET / ---
    invoke lstrcmp, eax, url_binding ; Compare with our binding string format
    je .handle_home

    ; --- Route Default: 404 ---
.send_404:
    invoke send_response, res_status_404, res_content_txt, body_404, 16
    jmp .server_loop

.handle_home:
    invoke send_response, res_status_200, res_content_txt, body_home, 26
    jmp .server_loop

.cleanup:
    invoke HttpTerminate, HTTP_INITIALIZE_SERVER, 0
.exit:
    invoke ExitProcess, 0

.init_error:
    cinvoke printf, fmt_err, eax
    jmp .exit

req_handle dd ?

proc send_response stdcall, pStatus, pType, pBody, nBodyLen
    local response:HTTP_RESPONSE
    local chunk:HTTP_DATA_CHUNK

    ; Clean out structural memory spaces
    lea eax, [response]
    invoke RtlZeroMemory, eax, sizeof.HTTP_RESPONSE
    lea eax, [chunk]
    invoke RtlZeroMemory, eax, sizeof.HTTP_DATA_CHUNK

    ; Set HTTP status and content type header
    mov eax, [pStatus]
    mov [response.StatusCode], 200 ; Short-circuited to 200 for simplicity
    mov eax, [pStatus]
    mov [response.pReason], eax
    mov [response.ReasonLength], 6

    ; Point the response data chunk to our string payload body
    mov [chunk.DataChunkType], HttpDataChunkFromMemory
    mov eax, [pBody]
    mov [chunk.pBuffer], eax
    mov eax, [nBodyLen]
    mov [chunk.BufferLength], eax

    lea eax, [chunk]
    mov [response.pEntityChunks], eax
    mov [response.EntityChunkCount], 1

    ; Send the response back through the kernel queue
    mov esi, req_buffer
    mov eax, [esi + 24]     ; Fetch RequestID from incoming buffer
    mov edx, [esi + 28]
    mov dword [req_id], eax
    mov dword [req_id + 4], edx

    invoke HttpSendHttpResponse, [req_handle], [req_id], 0, response, 0, 0, 0, 0, 0, 0
    ret
endp

section '.idata' import data readable
    library kernel32, 'kernel32.dll', \
            msvcrt,   'msvcrt.dll', \
            httpapi,  'httpapi.dll'

    import kernel32, \
           ExitProcess, 'ExitProcess', \
           RtlZeroMemory, 'RtlZeroMemory', \
           lstrcmp, 'lstrcmpW'

    import msvcrt, \
           printf, 'printf'

    ; Native Windows HTTP Server Functions
    import httpapi, \
           HttpInitialize, 'HttpInitialize', \
           HttpCreateHttpQueueHandle, 'HttpCreateHttpQueueHandle', \
           HttpAddUrl, 'HttpAddUrl', \
           HttpReceiveHttpRequest, 'HttpReceiveHttpRequest', \
           HttpSendHttpResponse, 'HttpSendHttpResponse', \
           HttpTerminate, 'HttpTerminate'
