format PE
entry start

include 'win32ax.inc'

BUF_SIZE = 10

section '.data' data readable writeable
    buf1        rb BUF_SIZE
    fmt_x       db '%x', 10, 0

include '../../util/print_bytes.text.inc'

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

include '../../util/print_bytes.data.inc'

proc main
    cinvoke puts, '*** main1 ***'
    stdcall print_bytes, buf1, BUF_SIZE
    cinvoke memset, buf1, 0x20, BUF_SIZE
    stdcall print_bytes, buf1, BUF_SIZE
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            ntdll,          'ntdll.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  ntdll,\
            memset,         'memset'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
