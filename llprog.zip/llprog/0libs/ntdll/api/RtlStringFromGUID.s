format PE
entry start

include 'win32w.inc'

struct UNICODE_STRING
    Length        dw ?
    MaximumLength dw ?
    Buffer        dd ?
ends

section '.data' data readable writeable
    guid_str1       du '{11223344-5566-7788-99aa-bbccddeeff00}', 0
    guid_str1_len   = $ - guid_str1
    
    sample_guid:
        dd 0x11223344       ; Data1 (unsigned long)
        dw 0x5566           ; Data2 (unsigned short)
        dw 0x7788           ; Data3 (unsigned short)
        db 0x99, 0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF, 0x00 ; Data4 (8 bytes)

    guid_string UNICODE_STRING 0
    fmt_Sn      db '%S', 10, 0
    fmt_dn      db '%d', 10, 0
    fmt_err     db 'error: %d', 10, 0

include '../../../util/print_bytes.data.inc'

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

include '../../../util/print_bytes.text.inc'

proc main
    invoke RtlStringFromGUID, sample_guid, guid_string
    test eax, eax
    js .error

    stdcall print_bytes, guid_str1, guid_str1_len
    cinvoke printf, fmt_Sn, guid_str1
    
    stdcall print_bytes, [guid_string.Buffer], 38 * 2 + 2
    cinvoke printf, fmt_Sn, [guid_string.Buffer]
    
    invoke RtlFreeUnicodeString, guid_string
    jmp .exit
.error:
    cinvoke printf, fmt_err, eax
.exit:
    ret
endp

section '.idata' import data readable
    library kernel32,               'kernel32.dll',\
            user32,                 'user32.dll',\
            ntdll,                  'ntdll.dll',\
            msvcrt,                 'msvcrt.dll'
    import  kernel32,\
            ExitProcess,            'ExitProcess'
    import  user32,\
            MessageBoxW,            'MessageBoxW'
    import  ntdll,\
            RtlStringFromGUID,      'RtlStringFromGUID',\
            RtlFreeUnicodeString,   'RtlFreeUnicodeString'
    import  msvcrt,\
            printf,                 'printf'
