format PE
entry start

include 'win32ax.inc'

struct OSVERSIONINFOEXW
    dwOSVersionInfoSize dd ?
    dwMajorVersion      dd ?
    dwMinorVersion      dd ?
    dwBuildNumber       dd ?
    dwPlatformId        dd ?
    szCSDVersion        rw 128
    wServicePackMajor   dw ?
    wServicePackMinor   dw ?
    wSuiteMask          dw ?
    wProductType        db ?
    wReserved           db ?
ends

section '.data' data readable writeable
    ntdll_name  db 'ntdll.dll', 0
    proc_name   db 'RtlGetVersion', 0
    os_info     OSVERSIONINFOEXW
    fmt         db 'Major: %d', 10
                db 'Minor: %d', 10
                db 'Build: %d', 10
                db 'OS: %s', 10, 0

    win11       db 'Windows 11', 0
    win10       db 'Windows 10', 0
    win_old     db 'Older/Other Windows', 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc print_os_info
    cmp [os_info.dwMajorVersion], 10
    je .check_build_num
    mov eax, win_old
    jmp .print_info
.check_build_num:
    cmp [os_info.dwBuildNumber], 22000
    jb .found_win10
    mov eax, win11
    jmp .print_info
.found_win10:
    mov eax, win10
.print_info:
    cinvoke printf, fmt,\
        [os_info.dwMajorVersion], [os_info.dwMinorVersion],\
        [os_info.dwBuildNumber], eax
    ret
endp

proc main1
    cinvoke puts, '*** main1 ***'
    mov [os_info.dwOSVersionInfoSize], sizeof.OSVERSIONINFOEXW
    invoke RtlGetVersion, os_info
    stdcall print_os_info
    ret
endp

proc main
    cinvoke puts, '*** main2 ***'
    invoke GetModuleHandle, ntdll_name
    invoke GetProcAddress, eax, proc_name
    test eax, eax
    jz .exit
    mov [os_info.dwOSVersionInfoSize], sizeof.OSVERSIONINFOEXW
    stdcall eax, os_info

    stdcall print_os_info
.exit:
    ret
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            msvcrt,             'msvcrt.dll',\
            ntdll,              'ntdll.dll'
    import  kernel32,\
            GetModuleHandle,    'GetModuleHandleA',\
            GetProcAddress,     'GetProcAddress',\
            ExitProcess,        'ExitProcess'
    import  msvcrt,\
            printf,             'printf',\
            puts,               'puts'
    import  ntdll,\
            RtlGetVersion,      'RtlGetVersion'
