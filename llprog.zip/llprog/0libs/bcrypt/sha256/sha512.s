format PE
entry start

include 'win32ax.inc'

SHA512_SIZE = 64

section '.data' data readable writeable
    alg_id      du 'SHA512', 0
    str1        db 'The quick brown fox jumps over the lazy dog', 0
    str1_len    = $ - str1 - 1
    expected_result     db '07e547d9586f6a73f73fbac0435ed769'
                        db '51218fb7d0c8d788a309d785436bbb64'
                        db '2e93a252a954f23912547d1e8a3b5ed6'
                        db 'e1bfd7097821233fa0538f3db854fee6', 0
    hAlg        dd 0
    hHash       dd 0
    hash        db SHA512_SIZE dup(0)
    fmt_x       db '%02x', 0
    fmt_s       db '%s', 10, 0
    newline     db 10, 0
    hex_byte    rb 4

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc print_hex1 uses ebx esi, buf, buf_size
    mov esi, [buf]
    mov ebx, [buf_size]
.loop:
    movzx eax, byte [esi]
    cinvoke printf, fmt_x, eax
    inc esi
    dec ebx
    jnz .loop
    cinvoke printf, newline
    ret
endp

proc print_hex2 uses ebx esi, buf, buf_size
    local hex_output[129]:BYTE
    local hex_byte[3]:BYTE
    mov esi, [buf]
    mov ebx, 0
    mov byte [hex_output], 0
.loop:
    movzx eax, byte [esi + ebx]
    cinvoke wsprintf, addr hex_byte, fmt_x, eax
    invoke lstrcat, addr hex_output, addr hex_byte
    inc ebx
    cmp ebx, [buf_size]
    jb .loop
    cinvoke printf, fmt_s, addr hex_output
    ret
endp

proc print_hex uses ebx esi edi, buf, buf_size
    local hex_output[257]:BYTE
    mov esi, [buf]
    mov ecx, [buf_size]
    lea edi, [hex_output]
    test ecx, ecx
    jz .done
.loop:
    movzx eax, byte [esi]
    inc esi
    
    ; --- HIGH NIBBLE ---
    mov edx, eax
    shr edx, 4               ; edx = high 4 bits
    
    cmp dl, 10
    sbb al, al               ; al = 0xFF if < 10, 0x00 if >= 10
    and al, 0xF9             ; al = 0xF9 (-7) if < 10, 0x00 if >= 10
    add al, 0x41             ; al = 0x3A if < 10, 0x041 if >= 10
    add al, dl               ; al = final ASCII char
    mov [edi], al
    inc edi

    ; --- LOW NIBBLE ---
    mov edx, eax
    and edx, 0x0F            ; edx = low 4 bits
    
    cmp dl, 10
    sbb al, al               ; Reset al based on new low nibble CF
    and al, 0xF9
    add al, 0x41
    add al, dl
    mov [edi], al
    inc edi
    
    loop .loop
.done:
    mov byte [edi], 0
    cinvoke printf, fmt_s, addr hex_output
    ret
endp

proc main
    cinvoke puts, '*** main1 ***'
    invoke BCryptOpenAlgorithmProvider, hAlg, alg_id, 0, 0
    invoke BCryptCreateHash, [hAlg], hHash, 0, 0, 0, 0, 0
    invoke BCryptHashData, [hHash], str1, str1_len, 0
    invoke BCryptFinishHash, [hHash], hash, SHA512_SIZE, 0
    stdcall print_hex, hash, SHA512_SIZE
    ret
endp

section '.idata' import data readable
    library kernel32,                       'kernel32.dll',\
            user32,                         'user32.dll',\
            msvcrt,                         'msvcrt.dll',\
            bcrypt,                         'bcrypt.dll'
    import  kernel32,\
            GetProcessHeap,                 'GetProcessHeap',\
            HeapAlloc,                      'HeapAlloc',\
            HeapFree,                       'HeapFree',\
            lstrcat,                        'lstrcatA',\
            ExitProcess,                    'ExitProcess'
    import  user32,\
            wsprintf,                       'wsprintfA'
    import  msvcrt,\
            printf,                         'printf',\
            puts,                           'puts'
    import  bcrypt,\
            BCryptOpenAlgorithmProvider,    'BCryptOpenAlgorithmProvider',\
            BCryptCreateHash,               'BCryptCreateHash',\
            BCryptHashData,                 'BCryptHashData',\
            BCryptFinishHash,               'BCryptFinishHash'
