format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    host1           db 'example.com', 0
    host2           db 'sqlite.org', 0
    host3           db 'abc', 0
    host4           db 0
    fmt_err         db 'Error: %d', 10, 0
    fmt_d           db '%d', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

include '../util/hostent.text.inc'

proc main
    cinvoke puts, '*** main1 ***'
    local hostent1:hostent
    cinvoke printf, fmt_x, sizeof.hostent
    ret
endp

proc main5
    cinvoke puts, '*** main5 ***'
    local wsa_data:WSADATA
    invoke WSAStartup, 0x0202, addr wsa_data
    invoke gethostbyname, host2
    test eax, eax
    jz .error
    stdcall print_ip_addrs, eax
    jmp .exit
.error:
    invoke WSAGetLastError
    cinvoke printf, fmt_err, eax
.exit:
    ret
endp

section '.idata' data import readable
    library kernel32,           'kernel32.dll',\
            ws2_32,             'ws2_32.dll',\
            msvcrt,             'msvcrt.dll'
    import  kernel32,\
            FormatMessage,      'FormatMessageA',\
            ExitProcess,        'ExitProcess'
    import  ws2_32,\
            WSAStartup,         'WSAStartup',\
            WSACleanup,         'WSACleanup',\
            WSAGetLastError,    'WSAGetLastError',\
            gethostbyname,      'gethostbyname',\
            inet_ntoa,          'inet_ntoa'
    import  msvcrt,\
            printf,             'printf',\
            puts,               'puts'
