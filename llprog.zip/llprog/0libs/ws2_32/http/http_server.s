format PE
entry start

include 'win32ax.inc'
include '../ws2_32.inc'

PORT = 8080
REQ_BUFFER_SIZE = 4096
FILE_BUFFER_SIZE = 1048576

section '.data' data readable writeable
    strIndex db '0files/index.html', 0

    strOkHeader db 'HTTP/1.1 200 OK', 13, 10,\
        'Content-Type: text/html', 13, 10,\
        'Connection: close', 13, 10, 13, 10, 0
    lenOkHeader = $ - strOkHeader - 1

    str404Header db 'HTTP/1.1 404 Not Found', 13, 10,\
        'Connection: close', 13, 10, 13, 10,\
        '<h1>404 Not Found</h1>', 0
    len404Header = $ - str404Header - 1

    strStart    db 'Listening on http://127.0.0.1:8080', 10, 0
    strReq      db 'Request received. Sending response...', 10, 0

section '.bss' readable writeable
    reqBuffer rb REQ_BUFFER_SIZE
    fileBuffer rb FILE_BUFFER_SIZE

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    cinvoke puts, '*** main1 ***'
    local wsa_data:WSADATA, srv_sock:DWORD, cli_sock:DWORD
    local srv_addr:sockaddr_in
    local hFile:DWORD, bytes_read:DWORD, file_size:DWORD
    invoke WSAStartup, 0x0202, addr wsa_data
    invoke socket, AF_INET, SOCK_STREAM, IPPROTO_TCP
    mov [srv_sock], eax
    mov [srv_addr.sin_family], AF_INET
    invoke htons, PORT
    mov [srv_addr.sin_port], ax
    mov [srv_addr.sin_addr], INADDR_LOOPBACK
    invoke bind, [srv_sock], addr srv_addr, sizeof.sockaddr_in
    invoke listen, [srv_sock], SOMAXCONN
    cinvoke printf, strStart
.accept_loop:
    invoke accept, [srv_sock], 0, 0
    cmp eax, INVALID_SOCKET
    je .accept_loop
    mov [cli_sock], eax
    cinvoke printf, strReq
    invoke recv, [cli_sock], reqBuffer, REQ_BUFFER_SIZE, 0
    invoke  CreateFile, strIndex, GENERIC_READ, FILE_SHARE_READ, 0,\
            OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0
    cmp eax, INVALID_HANDLE_VALUE
    je .send_404
    mov [hFile], eax
    invoke send, [cli_sock], strOkHeader, lenOkHeader, 0
    invoke GetFileSize, [hFile], 0
    mov [file_size], eax
    invoke ReadFile, [hFile], fileBuffer, [file_size], addr bytes_read, 0
    invoke send, [cli_sock], fileBuffer, [file_size], 0
    invoke CloseHandle, [hFile]
    jmp .close_client
.send_404:
    invoke send, [cli_sock], str404Header, len404Header, 0
.close_client:
    invoke closesocket, [cli_sock]
    jmp .accept_loop
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            ws2_32,         'ws2_32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            CreateFile,     'CreateFileA',\
            GetFileSize,    'GetFileSize',\
            ReadFile,       'ReadFile',\
            CloseHandle,    'CloseHandle',\
            ExitProcess,    'ExitProcess'
    import  ws2_32,\
            WSAStartup,     'WSAStartup',\
            accept,         'accept',\
            bind,           'bind',\
            closesocket,    'closesocket',\
            htons,          'htons',\
            listen,         'listen',\
            recv,           'recv',\
            send,           'send',\
            socket,         'socket'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
