format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    binary_ip   dd 0x0100007F     ; 127.0.0.1
    fmt_s       db '%s', 10, 0
    fmt_d       db '%d', 10, 0
    wsadata     WSADATA

section '.text' code readable executable
start:
    stdcall test10
    invoke ExitProcess, 0

proc test10
    cinvoke puts, 'test10'
    invoke inet_ntoa, [binary_ip]
    cinvoke printf, fmt_s, eax
    ret
endp

proc test15
    cinvoke puts, 'test15'
    invoke WSAStartup, 0x0202, wsadata
    test eax, eax
    jnz .done
    invoke inet_ntoa, [binary_ip]
    test eax, eax
    jz .cleanup_ws
    cinvoke printf, fmt_s, eax
.cleanup_ws:
    invoke WSACleanup
.done:
    ret
endp

section '.idata' import data readable
    library kernel32,       'KERNEL32.DLL',\
            msvcrt,         'MSVCRT.DLL',\
            ws2_32,         'WS2_32.DLL'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
    import  ws2_32,\
            WSAStartup,     'WSAStartup',\
            WSACleanup,     'WSACleanup',\
            inet_ntoa,      'inet_ntoa'
