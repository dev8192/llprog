; htonl (Host to Network Long)
format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_x       db '%x', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main1 uses ebx
    cinvoke puts, '*** main1 ***'
    mov ebx, 0x12345678
    cinvoke printf, fmt_x, ebx
    invoke htonl, ebx
    mov ebx, eax
    cinvoke printf, fmt_x, ebx
    invoke htonl, ebx
    mov ebx, eax
    cinvoke printf, fmt_x, ebx
    ret
endp

proc main uses ebx
    cinvoke puts, '*** main2 ***'
    invoke htonl, 0x12345678
    cinvoke printf, fmt_x, eax

    mov eax, 0x12345678
    bswap eax
    cinvoke printf, fmt_x, eax
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            ws2_32,         'ws2_32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  ws2_32,\
            WSAStartup,     'WSAStartup',\
            htonl,          'htonl'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
