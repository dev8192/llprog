format PE
entry start

include 'win32ax.inc'
include '../ws2_32.inc'

LANG_ENGLISH_US = 0x0409
ERR_BUF_SZ = 256

section '.data' data readable writeable
    fmt_success     db 'success: %d', 10, 0
    fmt_err         db "Error %u (0x%X): '%s'", 10, 0
    err_buf         rb ERR_BUF_SZ
    fmt_x           db '%x', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc recv_func, hSocket, buf, len, flags
    invoke WSASetLastError, 0
    invoke recv, [hSocket], [buf], [len], [flags]
    push eax
    cmp eax, SOCKET_ERROR
    je .error
    cinvoke printf, fmt_success, eax
    jmp .done
.error:
    invoke WSAGetLastError
    push eax
    invoke  FormatMessage, FORMAT_MESSAGE_FROM_SYSTEM +\
            FORMAT_MESSAGE_MAX_WIDTH_MASK + FORMAT_MESSAGE_IGNORE_INSERTS,\
            0, eax, LANG_ENGLISH_US, err_buf, ERR_BUF_SZ, 0
    pop eax
    cinvoke printf, fmt_err, eax, eax, err_buf
.done:
    pop eax
    ret
endp

; Error 10093 (0x276D): 'Either the application has not called WSAStartup, or WSAStartup failed. '
proc main1
    cinvoke puts, '*** main1 ***'
    stdcall recv_func, 0, 0, 0, 0
    ret
endp

; Error 10038 (0x2736): 'An operation was attempted on something that is not a socket. '
proc main2
    cinvoke puts, '*** main2 ***'
    local wsa_data:WSADATA
    invoke WSAStartup, 0x0202, addr wsa_data
    stdcall recv_func, 0, 0, 0, 0
    ret
endp

; Error 10057 (0x2749): 'A request to send or receive data was disallowed because the socket is not connected and (when sending on a datagram socket using a sendto call) no address was supplied. '
proc main
    cinvoke puts, '*** main3 ***'
    local wsa_data:WSADATA
    invoke WSAStartup, 0x0202, addr wsa_data
    invoke socket, AF_INET, SOCK_STREAM, IPPROTO_TCP
    stdcall recv_func, eax, 0, 0, 0
    ret
endp

; fff
proc main4
    cinvoke puts, '*** main4 ***'
    local wsa_data:WSADATA, h_sock:DWORD
    invoke WSAStartup, 0x0202, addr wsa_data
    invoke socket, AF_INET, SOCK_STREAM, IPPROTO_TCP
    mov [h_sock], eax
    stdcall recv_func, eax, 0, 0, 0
    ret
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            ws2_32,             'ws2_32.dll',\
            msvcrt,             'msvcrt.dll'
    import  kernel32,\
            FormatMessage,      'FormatMessageA',\
            ExitProcess,        'ExitProcess'
    import  ws2_32,\
            WSAStartup,         'WSAStartup',\
            WSACleanup,         'WSACleanup',\
            WSAGetLastError,    'WSAGetLastError',\
            WSASetLastError,    'WSASetLastError',\
            accept,             'accept',\
            bind,               'bind',\
            closesocket,        'closesocket',\
            htons,              'htons',\
            listen,             'listen',\
            recv,               'recv',\
            send,               'send',\
            socket,             'socket'
    import  msvcrt,\
            printf,             'printf',\
            puts,               'puts'
