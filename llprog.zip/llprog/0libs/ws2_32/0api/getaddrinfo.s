getaddrinfo

getnameinfo
