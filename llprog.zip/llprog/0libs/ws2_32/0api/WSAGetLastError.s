https://learn.microsoft.com/en-us/windows/win32/winsock/windows-sockets-error-codes-2
