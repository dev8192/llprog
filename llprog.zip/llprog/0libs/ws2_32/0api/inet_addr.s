format PE
entry start

include 'win32ax.inc'
include '../ws2_32.inc'

section '.data' data readable writeable

include 'ip_addr.data.inc'

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc inet_addr_func, address
    local buf1[32]:BYTE
    cinvoke sprintf, addr buf1, fmt_str, [address]
    invoke inet_addr, [address]
    cmp eax, INADDR_NONE
    je .invalid_ip
    cinvoke printf, fmt_addr, addr buf1, eax
    jmp .exit
.invalid_ip:
    cinvoke printf, fmt_invalid, addr buf1
.exit:
    ret
endp

proc main1
    cinvoke puts, '*** main1 ***'
    mov esi, ipv4_arr
.loop:
    cmp dword [esi], 0
    je .done
    invoke inet_addr, dword [esi]
    cinvoke printf, fmt_x, eax
    add esi, 4
    jmp .loop
.done:
    ret
endp

proc main uses esi
    cinvoke puts, '*** main2 ***'
    mov esi, ipv4_arr
.loop:
    cmp dword [esi], 0
    je .done
    stdcall inet_addr_func, dword [esi]
    add esi, 4
    jmp .loop
.done:
    ret
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            ws2_32,             'ws2_32.dll',\
            msvcrt,             'msvcrt.dll'
    import  kernel32,\
            ExitProcess,        'ExitProcess'
    import  ws2_32,\
            inet_addr,          'inet_addr'
    import  msvcrt,\
            sprintf,            'sprintf',\
            strcpy,             'strcpy',\
            printf,             'printf',\
            puts,               'puts'
