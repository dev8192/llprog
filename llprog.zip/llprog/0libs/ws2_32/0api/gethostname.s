format PE
entry start

include 'win32ax.inc'
include '../ws2_32.inc'

LANG_ENGLISH_US = 0x0409
ERR_BUF_SZ = 256

section '.data' data readable writeable
    fmt_success     db 'success: %d', 10, 0
    fmt_err         db "Error %u (0x%X): '%s'", 10, 0
    err_buf         rb ERR_BUF_SZ
    fmt_s           db '%s', 10, 0
    fmt_d           db '%d', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc gethostname_func, name, namelen
    invoke WSASetLastError, 0
    invoke gethostname, [name], [namelen]
    push eax
    cmp eax, SOCKET_ERROR
    je .error
    cinvoke printf, fmt_success, eax
    jmp .done
.error:
    invoke WSAGetLastError
    push eax
    invoke  FormatMessage, FORMAT_MESSAGE_FROM_SYSTEM +\
            FORMAT_MESSAGE_MAX_WIDTH_MASK + FORMAT_MESSAGE_IGNORE_INSERTS,\
            0, eax, LANG_ENGLISH_US, err_buf, ERR_BUF_SZ, 0
    pop eax
    cinvoke printf, fmt_err, eax, eax, err_buf
.done:
    pop eax
    ret
endp

; Error 10093 (0x276D): 'Either the application has not called WSAStartup, or WSAStartup failed. '
proc main1
    cinvoke puts, '*** main1 ***'
    stdcall gethostname_func, 0, 0
    ret
endp

; Error 10014 (0x271E): 'The system detected an invalid pointer address in attempting to use a pointer argument in a call. '
proc main2
    cinvoke puts, '*** main2 ***'
    local wsa_data:WSADATA
    invoke WSAStartup, 0x0202, addr wsa_data
    stdcall gethostname_func, 0, 0
    ret
endp

; Error 10014 (0x271E): 'The system detected an invalid pointer address in attempting to use a pointer argument in a call. '
proc main3
    cinvoke puts, '*** main3 ***'
    local wsa_data:WSADATA, buf1[64]:BYTE
    invoke WSAStartup, 0x0202, addr wsa_data
    stdcall gethostname_func, addr buf1, 1
    ret
endp

; success
proc main
    cinvoke puts, '*** main4 ***'
    local wsa_data:WSADATA, buf1[64]:BYTE
    invoke WSAStartup, 0x0202, addr wsa_data
    stdcall gethostname_func, addr buf1, 64
    cinvoke printf, fmt_s, addr buf1
    ret
endp

section '.idata' data import readable
    library kernel32,           'kernel32.dll',\
            ws2_32,             'ws2_32.dll',\
            msvcrt,             'msvcrt.dll'
    import  kernel32,\
            FormatMessage,      'FormatMessageA',\
            ExitProcess,        'ExitProcess'
    import  ws2_32,\
            WSAStartup,         'WSAStartup',\
            WSACleanup,         'WSACleanup',\
            WSAGetLastError,    'WSAGetLastError',\
            WSASetLastError,    'WSASetLastError',\
            gethostname,        'gethostname'
    import  msvcrt,\
            printf,             'printf',\
            puts,               'puts'
