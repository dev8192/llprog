format PE
entry start

include 'win32ax.inc'
include '../ws2_32.inc'

LANG_ENGLISH_US = 0x0409
ERR_BUF_SZ = 256

section '.data' data readable writeable
    fmt_success     db 'success: %d', 10, 0
    fmt_err         db "Error %u (0x%X): '%s'", 10, 0
    err_buf         rb ERR_BUF_SZ
    fmt_x           db '%x', 10, 0
    fmt_d           db '%d', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc bind_func, hSocket, name, namelen
    invoke WSASetLastError, 0
    invoke bind, [hSocket], [name], [namelen]
    push eax
   ;test eax, eax
   ;jnz .error
    cmp eax, SOCKET_ERROR
    je .error
    cinvoke printf, fmt_success, eax
    jmp .done
.error:
    invoke WSAGetLastError
    push eax
    invoke  FormatMessage, FORMAT_MESSAGE_FROM_SYSTEM +\
            FORMAT_MESSAGE_MAX_WIDTH_MASK + FORMAT_MESSAGE_IGNORE_INSERTS,\
            0, eax, LANG_ENGLISH_US, err_buf, ERR_BUF_SZ, 0
    pop eax
    cinvoke printf, fmt_err, eax, eax, err_buf
.done:
    pop eax
    ret
endp

proc bind_test, callback
    local wsadata:WSADATA, hSocket:DWORD, sin:sockaddr_in
    invoke WSAStartup, 0x0202, addr wsadata
    test eax, eax
    jnz .WSAStartup_err
   ;invoke socket, AF_INET, SOCK_DGRAM, IPPROTO_UDP
    invoke socket, AF_INET, SOCK_STREAM, IPPROTO_TCP
    cmp eax, INVALID_SOCKET
    je .socket_err
    mov [hSocket], eax
    stdcall [callback], [hSocket], addr sin
    cmp eax, SOCKET_ERROR
    je .call_closesocket
    cinvoke puts, 'do something useful'
    jmp .call_closesocket
.WSAStartup_err:
    cinvoke puts, 'WSAStartup_err'
    jmp .exit
.socket_err:
    cinvoke puts, 'socket_err'
    jmp .call_WSACleanup
.call_closesocket:
    invoke closesocket, [hSocket]
.call_WSACleanup:
    invoke WSACleanup
.exit:
    ret
endp

proc prepare_sin uses ebx, sin, family, port, address
    mov ebx, [sin]
    mov eax, [family]
    mov [ebx + sockaddr_in.sin_family], ax
    invoke htons, [port]
    mov [ebx + sockaddr_in.sin_port], ax
    mov eax, [address]
    mov [ebx + sockaddr_in.sin_addr], eax
    ret
endp

proc main1
    cinvoke puts, '*** main1 ***'
    cinvoke printf, fmt_d, sizeof.sockaddr
    cinvoke printf, fmt_d, sizeof.sockaddr_in
    ret
endp

; Error 10047 (0x273F): 'An address incompatible with the requested protocol was used. '
proc main2
    cinvoke puts, '*** main2 ***'
    stdcall bind_test, main2_callback
    ret
endp

proc main2_callback, hSocket, sin
    cinvoke memset, [sin], 0, sizeof.sockaddr_in
    stdcall bind_func, [hSocket], [sin], sizeof.sockaddr_in
    ret
endp

; success
proc main
    cinvoke puts, '*** main10 ***'
    stdcall bind_test, main10_callback
    ret
endp

proc main10_callback, hSocket, sin
    cinvoke memset, [sin], 0, sizeof.sockaddr_in
   ;stdcall prepare_sin, [sin], AF_INET, 8080, INADDR_ANY
   ;stdcall prepare_sin, [sin], AF_INET, 80, INADDR_ANY
   ;stdcall prepare_sin, [sin], AF_INET, 0, INADDR_ANY
    stdcall prepare_sin, [sin], AF_INET, 8080, INADDR_LOOPBACK
    stdcall bind_func, [hSocket], [sin], sizeof.sockaddr_in
    ret
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            ws2_32,             'ws2_32.dll',\
            msvcrt,             'msvcrt.dll'
    import  kernel32,\
            FormatMessage,      'FormatMessageA',\
            ExitProcess,        'ExitProcess'
    import  ws2_32,\
            WSAStartup,         'WSAStartup',\
            WSACleanup,         'WSACleanup',\
            WSAGetLastError,    'WSAGetLastError',\
            WSASetLastError,    'WSASetLastError',\
            socket,             'socket',\
            closesocket,        'closesocket',\
            bind,               'bind',\
            htons,              'htons'
    import  msvcrt,\
            memset,             'memset',\
            printf,             'printf',\
            puts,               'puts'
