format PE
entry start

include 'win32ax.inc'
include '../ws2_32.inc'

LANG_ENGLISH_US = 0x0409
ERR_BUF_SZ = 256

section '.data' data readable writeable
    fmt_success     db 'success: %d', 10, 0
    fmt_err         db "Error %u (0x%X): '%s'", 10, 0
    err_buf         rb ERR_BUF_SZ
    fmt_x           db '%x', 10, 0
    fmt_d           db '%d', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc socket_func, af, type, protocol
    invoke WSASetLastError, 0
    invoke socket, [af], [type], [protocol]
    push eax
    cmp eax, INVALID_SOCKET
    je .error
    cinvoke printf, fmt_success, eax
    jmp .done
.error:
    invoke WSAGetLastError
    push eax
    invoke  FormatMessage, FORMAT_MESSAGE_FROM_SYSTEM +\
            FORMAT_MESSAGE_MAX_WIDTH_MASK + FORMAT_MESSAGE_IGNORE_INSERTS,\
            0, eax, LANG_ENGLISH_US, err_buf, ERR_BUF_SZ, 0
    pop eax
    cinvoke printf, fmt_err, eax, eax, err_buf
.done:
    pop eax
    ret
endp

proc main1
    cinvoke puts, '*** main1 ***'
    local wsa_data:WSADATA
   ;invoke WSAStartup, 0x0202, addr wsa_data
    cinvoke printf, fmt_x, esp
    invoke socket, AF_INET, SOCK_STREAM, IPPROTO_TCP
    cinvoke printf, fmt_d, eax
    cinvoke printf, fmt_x, esp
    ret
endp

; Error 10022 (0x2726): 'An invalid argument was supplied. '
proc main2
    cinvoke puts, '*** main2 ***'
    local wsa_data:WSADATA
    invoke WSAStartup, 0x0202, addr wsa_data
   ;stdcall socket_func, AF_INET, SOCK_STREAM, IPPROTO_TCP
    stdcall socket_func, 0, 0, 0
    ret
endp

; Error 10093 (0x276D): 'Either the application has not called WSAStartup, or WSAStartup failed. '
proc main3
    cinvoke puts, '*** main3 ***'
    local wsa_data:WSADATA
   ;invoke WSAStartup, 0x0202, addr wsa_data
    stdcall socket_func, AF_INET, SOCK_STREAM, IPPROTO_TCP
    ret
endp

; Error 10043 (0x273B): 'The requested protocol has not been configured into the system, or no implementation for it exists. '
proc main
    cinvoke puts, '*** main4 ***'
    local wsa_data:WSADATA
    invoke WSAStartup, 0x0202, addr wsa_data
   ;stdcall socket_func, AF_INET, SOCK_STREAM, IPPROTO_TCP      ; ok
   ;stdcall socket_func, AF_INET, SOCK_DGRAM, IPPROTO_UDP       ; ok
   ;stdcall socket_func, AF_INET, SOCK_DGRAM, IPPROTO_TCP       ; error
   ;stdcall socket_func, AF_INET, SOCK_STREAM, IPPROTO_UDP      ; error
   ;stdcall socket_func, AF_INET6, SOCK_STREAM, IPPROTO_TCP     ; ok
   ;stdcall socket_func, AF_INET6, SOCK_DGRAM, IPPROTO_UDP      ; ok
   ;stdcall socket_func, AF_INET6, SOCK_DGRAM, IPPROTO_TCP      ; error
    stdcall socket_func, AF_INET6, SOCK_STREAM, IPPROTO_UDP     ; error
    ret
endp

; success
proc main10
    cinvoke puts, '*** main10 ***'
    local wsa_data:WSADATA
    invoke WSAStartup, 0x0202, addr wsa_data
   ;stdcall socket_func, AF_INET, SOCK_STREAM, IPPROTO_TCP
   ;stdcall socket_func, AF_INET6, SOCK_STREAM, IPPROTO_TCP
    stdcall socket_func, AF_INET, SOCK_DGRAM, IPPROTO_TCP
    ret
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            ws2_32,             'ws2_32.dll',\
            msvcrt,             'msvcrt.dll'
    import  kernel32,\
            FormatMessage,      'FormatMessageA',\
            ExitProcess,        'ExitProcess'
    import  ws2_32,\
            WSAStartup,         'WSAStartup',\
            WSACleanup,         'WSACleanup',\
            WSAGetLastError,    'WSAGetLastError',\
            WSASetLastError,    'WSASetLastError',\
            socket,             'socket'
    import  msvcrt,\
            printf,             'printf',\
            puts,               'puts'
