; WSA stands for Windows Sockets API
format PE
entry start

include 'win32ax.inc'
include '../ws2_32.inc'

LANG_ENGLISH_US = 0x0409
ERR_BUF_SZ = 256

section '.data' data readable writeable
    fmt_success     db 'success', 10, 0
    fmt_err         db "Error %u (0x%X): '%s'", 10, 0
    err_buf         rb ERR_BUF_SZ
    fmt_x           db '%x', 10, 0
    fmt_d           db '%d', 10, 0

include '../util/util.data.inc'
include '../../util/print_bytes.data.inc'

section '.bss' readable writeable
    wsa_data1       db sizeof.WSADATA dup(0xAA)

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

include '../util/util.text.inc'
include '../../util/print_bytes.text.inc'

proc WSAStartup_func, wVersionRequired, lpWSAData
    invoke WSAStartup, [wVersionRequired], [lpWSAData]
    push eax
    test eax, eax
    jnz .error
    cinvoke printf, fmt_success
    jmp .done
.error:
    push eax
    invoke  FormatMessage, FORMAT_MESSAGE_FROM_SYSTEM +\
            FORMAT_MESSAGE_MAX_WIDTH_MASK + FORMAT_MESSAGE_IGNORE_INSERTS,\
            0, eax, LANG_ENGLISH_US, err_buf, ERR_BUF_SZ, 0
    pop eax
    cinvoke printf, fmt_err, eax, eax, err_buf
.done:
    pop eax
    ret
endp

proc main1
    cinvoke puts, '*** main1 ***'
    cinvoke printf, fmt_d, sizeof.WSADATA
    sub esp, sizeof.WSADATA
    cinvoke printf, fmt_x, esp
   ;invoke WSAStartup, 0x0202, esp
    invoke WSAStartup, 0x0101, esp
    cinvoke printf, fmt_d, eax
    cinvoke printf, fmt_x, esp
    add esp, sizeof.WSADATA
    ret
endp

; Error 10092 (0x276C): 'The Windows Sockets version requested is not supported. '
proc main2
    cinvoke puts, '*** main2 ***'
   ;stdcall WSAStartup_func, 0x0001, wsa_data1 ; 1.0
   ;stdcall WSAStartup_func, 0x0101, wsa_data1 ; 1.1
   ;stdcall WSAStartup_func, 0x0002, wsa_data1 ; 2.0
   ;stdcall WSAStartup_func, 0x0102, wsa_data1 ; 2.1
   ;stdcall WSAStartup_func, 0x0202, wsa_data1 ; 2.2
   ;stdcall WSAStartup_func, 0x0302, wsa_data1
    stdcall WSAStartup_func, 0, wsa_data1
    test eax, eax
    jnz .exit
    invoke WSACleanup
.exit:
    ret
endp

; Error 10014 (0x271E): 'The system detected an invalid pointer address in attempting to use a pointer argument in a call. '
proc main3
    cinvoke puts, '*** main3 ***'
   ;stdcall WSAStartup_func, 0x0202, wsa_data1
    stdcall WSAStartup_func, 0x0202, 0
    test eax, eax
    jnz .exit
    invoke WSACleanup
.exit:
    ret
endp

proc main
    cinvoke puts, '*** main10 ***'
    local hHeap:DWORD, wsa_data2:DWORD
    invoke GetProcessHeap
    mov [hHeap], eax
    invoke HeapAlloc, [hHeap], HEAP_ZERO_MEMORY, sizeof.WSADATA
    mov [wsa_data2], eax
    invoke WSAStartup, 0x0202, [wsa_data2]
    stdcall print_wsadata, [wsa_data2]
    invoke socket, AF_INET, SOCK_STREAM, IPPROTO_TCP
    cinvoke printf, fmt_d, eax
    invoke WSACleanup
    invoke HeapFree, [hHeap], 0, [wsa_data2]
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            ws2_32,         'ws2_32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            FormatMessage,  'FormatMessageA',\
            GetProcessHeap, 'GetProcessHeap',\
            HeapAlloc,      'HeapAlloc',\
            HeapFree,       'HeapFree',\
            ExitProcess,    'ExitProcess'
    import  ws2_32,\
            WSAStartup,     'WSAStartup',\
            WSACleanup,     'WSACleanup',\
            socket,         'socket'
    import  msvcrt,\
            sprintf,        'sprintf',\
            printf,         'printf',\
            puts,           'puts'
