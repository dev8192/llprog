; htons (Host to Network Short)
; htonl (Host to Network Long)
; ntohs
format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_x       db '%x', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main1 uses ebx
    cinvoke puts, '*** main1 ***'
    mov ebx, 8080
    cinvoke printf, fmt_x, ebx
    invoke htons, ebx
    mov ebx, eax
    cinvoke printf, fmt_x, ebx
    invoke htons, ebx
    mov ebx, eax
    cinvoke printf, fmt_x, ebx
    ret
endp

proc main2 uses ebx
    cinvoke puts, '*** main2 ***'
    mov ebx, 8080
    cinvoke printf, fmt_x, ebx
    invoke htons, ebx
    mov bx, ax
    cinvoke printf, fmt_x, ebx
    invoke htons, ebx
    mov bx, ax
    cinvoke printf, fmt_x, ebx
    ret
endp

proc main uses ebx
    cinvoke puts, '*** main3 ***'
    invoke htons, 0x1234
    cinvoke printf, fmt_x, eax

    invoke htons, 0x1234
    movzx eax, ax
    cinvoke printf, fmt_x, eax

    invoke htons, 0x1234
    and eax, 0xFFFF
    cinvoke printf, fmt_x, eax

    mov eax, 0x1234
    xchg al, ah
    cinvoke printf, fmt_x, eax
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            ws2_32,         'ws2_32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  ws2_32,\
            WSAStartup,     'WSAStartup',\
            htons,          'htons'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
