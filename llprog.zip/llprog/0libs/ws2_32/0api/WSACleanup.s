format PE
entry start

include 'win32ax.inc'

LANG_ENGLISH_US = 0x0409
ERR_BUF_SZ = 256

section '.data' data readable writeable
    fmt_success     db 'success', 10, 0
    fmt_err         db "Error %u (0x%X): '%s'", 10, 0
    err_buf         rb ERR_BUF_SZ
    wsa_data1       WSADATA
    fmt_d           db '%d', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc WSACleanup_func
   ;invoke SetLastError, 0
    invoke WSASetLastError, 0
    invoke WSACleanup
    test eax, eax
    jnz .error
    cinvoke printf, fmt_success
    jmp .done
.error:
   ;invoke GetLastError
    invoke WSAGetLastError
    push eax
    invoke  FormatMessage, FORMAT_MESSAGE_FROM_SYSTEM +\
            FORMAT_MESSAGE_MAX_WIDTH_MASK + FORMAT_MESSAGE_IGNORE_INSERTS,\
            0, eax, LANG_ENGLISH_US, err_buf, ERR_BUF_SZ, 0
    pop eax
    cinvoke printf, fmt_err, eax, eax, err_buf
.done:
    ret
endp

; Error 10093 (0x276D): 'Either the application has not called WSAStartup, or WSAStartup failed. '
proc main
    cinvoke puts, '*** main1 ***'
   ;invoke WSAStartup, 0x0202, wsa_data1
    invoke WSAStartup, 0x0202, 0
    stdcall WSACleanup_func
    ret
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            ws2_32,             'ws2_32.dll',\
            msvcrt,             'msvcrt.dll'
    import  kernel32,\
            GetLastError,       'GetLastError',\
            SetLastError,       'SetLastError',\
            FormatMessage,      'FormatMessageA',\
            ExitProcess,        'ExitProcess'
    import  ws2_32,\
            WSAStartup,         'WSAStartup',\
            WSACleanup,         'WSACleanup',\
            WSAGetLastError,    'WSAGetLastError',\
            WSASetLastError,    'WSASetLastError'
    import  msvcrt,\
            printf,             'printf',\
            puts,               'puts'
