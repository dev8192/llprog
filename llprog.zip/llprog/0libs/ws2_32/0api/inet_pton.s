format PE
entry start

include 'win32ax.inc'
include '../ws2_32.inc'

LANG_ENGLISH_US = 0x0409
ERR_BUF_SZ = 256

section '.data' data readable writeable
    fmt_success     db 'success', 10, 0
    fmt_err         db "Error %u (0x%X): '%s'", 10, 0
    err_buf         rb ERR_BUF_SZ

include 'ip_addr.data.inc'
include '../../util/print_bytes.data.inc'

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

include '../../util/print_bytes.text.inc'

proc inet_pton_test, Family, pszAddrString, pAddrBuf
    local buf1[32]:BYTE
    cinvoke sprintf, addr buf1, fmt_str, [pszAddrString]
    invoke inet_pton, [Family], [pszAddrString], [pAddrBuf]
    test eax, eax
    je .invalid_ip
    cmp eax, -1
    jz .error
    mov eax, [pAddrBuf]
    cinvoke printf, fmt_addr, addr buf1, dword [eax]
    jmp .exit
.invalid_ip:
    cinvoke printf, fmt_invalid, addr buf1
    jmp .exit
.error:
    invoke WSAGetLastError
    push eax
    invoke  FormatMessage, FORMAT_MESSAGE_FROM_SYSTEM +\
            FORMAT_MESSAGE_MAX_WIDTH_MASK + FORMAT_MESSAGE_IGNORE_INSERTS,\
            0, eax, LANG_ENGLISH_US, err_buf, ERR_BUF_SZ, 0
    pop eax
    cinvoke printf, fmt_err, eax, eax, err_buf
.exit:
    ret
endp

proc main1
    cinvoke puts, '*** main1 ***'
    local buf1[4+4]:BYTE, buf2[16+4]:BYTE
    cinvoke memset, addr buf1, 0xAA, 4+4
    lea eax, [buf1 + 2]
    invoke inet_pton, AF_INET, ipv4_addr1, eax
    stdcall print_bytes, addr buf1, 4+4
    cinvoke memset, addr buf2, 0xAA, 16+4
    lea eax, [buf2 + 2]
    invoke inet_pton, AF_INET6, ipv6_addr1, eax
    stdcall print_bytes, addr buf2, 16+4
    ret
endp

proc main2 uses esi
    cinvoke puts, '*** main2 ***'
    local buf1[4]:BYTE
    mov esi, ipv4_arr
.loop:
    cmp dword [esi], 0
    je .done
    stdcall inet_pton_test, AF_INET, dword [esi], addr buf1
    add esi, 4
    jmp .loop
.done:
    ret
endp

proc main uses esi
    cinvoke puts, '*** main3 ***'
    local buf1[16]:BYTE
    mov esi, ipv6_arr
.loop:
    cmp dword [esi], 0
    je .done
    stdcall inet_pton_test, AF_INET6, dword [esi], addr buf1
    add esi, 4
    jmp .loop
.done:
    ret
endp

; Error 10047 (0x273F): 'An address incompatible with the requested protocol was used. '
proc main50 uses esi
    cinvoke puts, '*** main50 ***'
    local buf1[4]:BYTE
   ;stdcall inet_pton_test, AF_INET, addr1, addr buf1
   ;stdcall inet_pton_test, 0, addr1, addr buf1
    stdcall inet_pton_test, AF_INET, addr1, 0
    ret
endp

; Error 10014 (0x271E): 'The system detected an invalid pointer address in attempting to use a pointer argument in a call. '
proc main51 uses esi
    cinvoke puts, '*** main51 ***'
    local buf1[4]:BYTE
   ;stdcall inet_pton_test, AF_INET, addr1, addr buf1
   ;stdcall inet_pton_test, AF_INET, addr1, 0
    stdcall inet_pton_test, AF_INET, 0, addr buf1
    ret
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            ws2_32,             'ws2_32.dll',\
            msvcrt,             'msvcrt.dll'
    import  kernel32,\
            FormatMessage,      'FormatMessageA',\
            ExitProcess,        'ExitProcess'
    import  ws2_32,\
            inet_pton,          'inet_pton',\
            WSAGetLastError,    'WSAGetLastError',\
            WSASetLastError,    'WSASetLastError'
    import  msvcrt,\
            memset,             'memset',\
            sprintf,            'sprintf',\
            strcpy,             'strcpy',\
            printf,             'printf',\
            puts,               'puts'
