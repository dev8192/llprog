format PE
entry start

include 'win32ax.inc'

LANG_ENGLISH_US = 0x0409
ERR_BUF_SZ = 256

section '.data' data readable writeable
    fmt_success     db 'success: %d', 10, 0
    fmt_err         db "Error %u (0x%X): '%s'", 10, 0
    err_buf         rb ERR_BUF_SZ
    host1           db 'example.com', 0
    host2           db 'sqlite.org', 0
    host3           db 'abc', 0
    host4           db 0
    fmt_err2        db 'Error code: %d', 10, 0
    fmt_d           db '%d', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

include '../util/hostent.text.inc'

proc gethostbyname_func, name
    invoke WSASetLastError, 0
    invoke gethostbyname, [name]
    push eax
    test eax, eax
    jz .error
    cinvoke printf, fmt_success, eax
    jmp .done
.error:
    invoke WSAGetLastError
    push eax
    invoke  FormatMessage, FORMAT_MESSAGE_FROM_SYSTEM +\
            FORMAT_MESSAGE_MAX_WIDTH_MASK + FORMAT_MESSAGE_IGNORE_INSERTS,\
            0, eax, LANG_ENGLISH_US, err_buf, ERR_BUF_SZ, 0
    pop eax
    cinvoke printf, fmt_err, eax, eax, err_buf
.done:
    pop eax
    ret
endp

; Error 10093 (0x276D): 'Either the application has not called WSAStartup, or WSAStartup failed. '
proc main1
    cinvoke puts, '*** main1 ***'
    stdcall gethostbyname_func, host1
    ret
endp

; Error 11001 (0x2AF9): 'No such host is known. '
proc main2
    cinvoke puts, '*** main2 ***'
    local wsa_data:WSADATA
    invoke WSAStartup, 0x0202, addr wsa_data
    stdcall gethostbyname_func, host3
    ret
endp

; success
proc main3
    cinvoke puts, '*** main3 ***'
    local wsa_data:WSADATA
    invoke WSAStartup, 0x0202, addr wsa_data
    stdcall gethostbyname_func, host1
    stdcall print_ip_addrs, eax
    stdcall gethostbyname_func, host4
    stdcall print_ip_addrs, eax
    ret
endp

; success
proc main4
    cinvoke puts, '*** main4 ***'
    local wsa_data:WSADATA, buf1[64]:BYTE
    invoke WSAStartup, 0x0202, addr wsa_data
    stdcall gethostbyname_func, 0
    stdcall print_ip_addrs, eax

    invoke WSAStartup, 0x0202, addr wsa_data
    invoke gethostname, addr buf1, 64
    stdcall gethostbyname_func, addr buf1
    stdcall print_ip_addrs, eax
    ret
endp

proc main uses esi
    cinvoke puts, '*** main10 ***'
    local wsa_data:WSADATA
    invoke WSAStartup, 0x0202, addr wsa_data
    test eax, eax
    jnz .exit
    invoke gethostbyname, host1
    test eax, eax
    jz .wsa_error
    stdcall print_ip_addrs, eax
.cleanup:
    invoke WSACleanup
    jmp .exit
.wsa_error:
    invoke WSAGetLastError
    cinvoke printf, fmt_err2, eax
    jmp .cleanup
.exit:
    ret
endp

section '.idata' data import readable
    library kernel32,           'kernel32.dll',\
            ws2_32,             'ws2_32.dll',\
            msvcrt,             'msvcrt.dll'
    import  kernel32,\
            FormatMessage,      'FormatMessageA',\
            ExitProcess,        'ExitProcess'
    import  ws2_32,\
            WSAStartup,         'WSAStartup',\
            WSACleanup,         'WSACleanup',\
            WSAGetLastError,    'WSAGetLastError',\
            WSASetLastError,    'WSASetLastError',\
            gethostbyname,      'gethostbyname',\
            gethostname,        'gethostname',\
            inet_ntoa,          'inet_ntoa'
    import  msvcrt,\
            printf,             'printf',\
            puts,               'puts'
