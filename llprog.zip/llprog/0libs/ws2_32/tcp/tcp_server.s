format PE
entry start

include 'win32ax.inc'
include '../ws2_32.inc'

PORT = 8080

section '.data' data readable writeable
    counter         dd 1
    recv_buf        rb 64

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    cinvoke puts, '*** main1 ***'
    local wsa_data:WSADATA, srv_sock:DWORD, cli_sock:DWORD
    invoke WSAStartup, 0x0202, wsa_data
    invoke socket, AF_INET, SOCK_STREAM, IPPROTO_TCP
    mov [srv_sock], eax
    mov [srv_addr.sin_family], AF_INET
    invoke htons, PORT
    mov [srv_addr.sin_port], ax
    mov [srv_addr.sin_addr], INADDR_LOOPBACK
    invoke bind, [srv_sock], addr srv_addr, sizeof.sockaddr_in
    invoke listen, [srv_sock], SOMAXCONN
.loop:
    invoke accept, [srv_sock], 0, 0
    mov [cli_sock], eax
    invoke recv, [cli_sock], recv_buf, 64, 0
    invoke send, [cli_sock], counter, 4, 0
    inc dword [counter]
    invoke closesocket, [cli_sock]
    jmp .loop
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            ws2_32,         'ws2_32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  ws2_32,\
            WSAStartup,     'WSAStartup',\
            socket,         'socket',\
            htons,          'htons',\
            bind,           'bind',\
            listen,         'listen',\
            accept,         'accept',\
            recv,           'recv',\
            send,           'send',\
            closesocket,    'closesocket'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
