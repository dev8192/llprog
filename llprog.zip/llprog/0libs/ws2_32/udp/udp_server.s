format PE
entry start

include 'win32ax.inc'
include '../ws2_32.inc'

PORT = 8080

section '.data' data readable writeable
    fmt_startup  db 'UDP Server listening on port 8080...', 10, 0
    fmt_recv     db 'Received %d bytes from client: %s', 10, 0
    client_len   dd sizeof.sockaddr_in
    buffer       db 1024 dup(0)

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    cinvoke puts, '*** main1 ***'
    local wsa_data:WSADATA, srv_sock:DWORD
    local srv_addr:sockaddr_in, cli_addr:sockaddr_in
    invoke WSAStartup, 0x0202, addr wsa_data
    test eax, eax
    jnz .error_exit
    invoke socket, AF_INET, SOCK_DGRAM, IPPROTO_UDP
    cmp eax, INVALID_SOCKET
    je .cleanup_winsock
    mov [srv_sock], eax
    mov [srv_addr.sin_family], AF_INET
    invoke htons, PORT
    mov [srv_addr.sin_port], ax
    mov [srv_addr.sin_addr], INADDR_LOOPBACK
    invoke bind, [srv_sock], addr srv_addr, sizeof.sockaddr_in
    cmp eax, SOCKET_ERROR
    je .close_socket
    cinvoke printf, fmt_startup
.server_loop:
    invoke RtlZeroMemory, buffer, 1024
    invoke recvfrom, [srv_sock], buffer, 1023, 0, addr cli_addr, client_len
    cmp eax, SOCKET_ERROR
    je .close_socket
    mov ebx, eax 
    cinvoke printf, fmt_recv, ebx, buffer
    invoke sendto, [srv_sock], buffer, ebx, 0, addr cli_addr, [client_len]
    jmp .server_loop
.close_socket:
    invoke closesocket, [srv_sock]
.cleanup_winsock:
    invoke WSACleanup
.error_exit:
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            ws2_32,         'ws2_32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            RtlZeroMemory,  'RtlZeroMemory',\
            ExitProcess,    'ExitProcess'
    import  ws2_32,\
            WSAStartup,     'WSAStartup',\
            WSACleanup,     'WSACleanup',\
            socket,         'socket',\
            bind,           'bind',\
            recvfrom,       'recvfrom',\
            sendto,         'sendto',\
            htons,          'htons',\
            closesocket,    'closesocket'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
