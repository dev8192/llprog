format PE console
entry start

include 'win32a.inc'

AF_INET = 2
INET_ADDRSTRLEN = 16

section '.data' data readable writeable
    fmt_s db "'%s'", 10, 0
    raw_ip  dd 0x0100007F
    str_ip  rb INET_ADDRSTRLEN

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, NULL

proc main
    invoke inet_ntop, AF_INET, raw_ip, str_ip, INET_ADDRSTRLEN
    test eax, eax
    jz .error
    cinvoke printf, fmt_s, str_ip
.error:
    ret
endp

section '.idata' import data readable writeable
    library kernel32, 'kernel32.dll', \
            msvcrt, 'msvcrt.dll', \
            ws2_32, 'ws2_32.dll'
    import kernel32, \
           ExitProcess, 'ExitProcess'
    import msvcrt, \
           printf, 'printf'
    import ws2_32, \
           inet_ntop, 'inet_ntop'
