format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    host db 'example.com', 0
    fmt_host db 'Host: %s', 10, 0
    fmt_ip db 'IP: %s', 10, 0
    fmt_err db 'Error code: %d', 10, 0
    wsa WSADATA

section '.code' code readable executable
proc start
    invoke WSAStartup, 0x0202, wsa
    test eax, eax
    jnz .error

    invoke gethostbyname, host
    test eax, eax
    jz .wsa_error

    mov esi, eax
    cinvoke printf, fmt_host, host

    mov edx, [esi + hostent.h_addr_list]
    mov edx, [edx]
    test edx, edx
    jz .cleanup

.loop_ips:
    mov eax, [edx]
    invoke inet_ntoa, eax
    cinvoke printf, fmt_ip, eax

    add dword [esi + hostent.h_addr_list], 4
    mov edx, [esi + hostent.h_addr_list]
    mov edx, [edx]
    test edx, edx
    jnz .loop_ips

.cleanup:
    invoke WSACleanup
    invoke ExitProcess, 0

.wsa_error:
    invoke WSAGetLastError
    cinvoke printf, fmt_err, eax
    jmp .cleanup

.error:
    invoke ExitProcess, 1
endp

section '.idata' data import readable
    library kernel32, 'kernel32.dll', \
            wsock32, 'wsock32.dll', \
            msvcrt, 'msvcrt.dll'

    import kernel32, \
           ExitProcess, 'ExitProcess'

    import wsock32, \
           WSAStartup, 'WSAStartup', \
           WSACleanup, 'WSACleanup', \
           WSAGetLastError, 'WSAGetLastError', \
           gethostbyname, 'gethostbyname', \
           inet_ntoa, 'inet_ntoa'

    import msvcrt, \
           printf, 'printf'
