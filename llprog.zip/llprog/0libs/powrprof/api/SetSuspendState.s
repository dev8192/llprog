format PE
entry start

include 'win32ax.inc'

LANG_ENGLISH_US = 0x0409
ERR_BUF_SZ = 256

section '.data' data readable writeable
    fmt_success     db 'Success: %x', 10, 0
    fmt_err         db "Error %u (0x%X): '%s'", 10, 0
    err_buf         rb ERR_BUF_SZ

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc SetSuspendState_func bHibernate, bForce, bWakeupEventsDisabled
    invoke SetSuspendState, [bHibernate], [bForce], [bWakeupEventsDisabled]
    test    eax, eax
    jz      .error
    cinvoke printf, fmt_success, eax
    jmp     .done
.error:
    invoke  GetLastError
    push    eax
    invoke  FormatMessage,\
            FORMAT_MESSAGE_FROM_SYSTEM + FORMAT_MESSAGE_MAX_WIDTH_MASK,\
            0, eax, LANG_ENGLISH_US, err_buf, ERR_BUF_SZ, 0
    pop     eax
    cinvoke printf, fmt_err, eax, eax, err_buf
.done:
    ret
    ret
endp

proc main
    cinvoke puts, '*** main1 ***'
    stdcall SetSuspendState_func, 1, 0, 0
    ret
endp

section '.idata' import data readable
    library powrprof,           'powrprof.dll',\
            kernel32,           'kernel32.dll',\
            msvcrt,             'msvcrt.dll'
    import  powrprof,\
            SetSuspendState,    'SetSuspendState'
    import  kernel32,\
            FormatMessage,      'FormatMessageA',\
            GetLastError,       'GetLastError',\
            ExitProcess,        'ExitProcess'
    import  msvcrt,\
            printf,             'printf',\
            puts,               'puts'
