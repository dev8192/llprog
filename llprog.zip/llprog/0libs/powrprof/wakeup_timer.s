format PE
entry start

include 'win32ax.inc'

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    local hTimer:DWORD
    local dueTime:QWORD
    invoke CreateWaitableTimer, 0, 1, 0
    mov [hTimer], eax
    test eax, eax
    jz exit
    ; Windows time is in 100-nanosecond intervals. 
    ; Negative values represent relative time.
    ; 20 seconds = 20 * 10,000,000 = 200,000,000 intervals.
    ; 200,000,000 in hex is 0x0BEBC200. 
    ; To make it negative, its two's complement is 0xF4143E00.
    ; High DWORD = 0xFFFFFFFF, Low DWORD = 0xF4143E00.
    mov dword [dueTime], 0xF4143E00
    mov dword [dueTime+4], 0xFFFFFFFF
    invoke SetWaitableTimer, [hTimer], addr dueTime, 0, 0, 0, 1
    test eax, eax
    jz close_timer
    invoke SetSuspendState, 0, 0, 1
close_timer:
    invoke CloseHandle, [hTimer]
exit:
    ret
endp

section '.idata' import data readable
    library kernel32,               'kernel32.dll',\
            powrprof,               'powrprof.dll',\
            msvcrt,                 'msvcrt.dll'
    import  kernel32,\
            CreateWaitableTimer,    'CreateWaitableTimerW',\
            SetWaitableTimer,       'SetWaitableTimer',\
            CloseHandle,            'CloseHandle',\
            ExitProcess,            'ExitProcess'
    import  powrprof,\
            SetSuspendState,        'SetSuspendState'
    import  msvcrt,\
            printf,                 'printf',\
            puts,                   'puts'
