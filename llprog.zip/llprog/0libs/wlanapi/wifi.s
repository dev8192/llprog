format PE
entry start

include 'win32a.inc'

wlan_intf_opcode_radio_state = 1
wlan_connection_mode_profile = 0
dot11_BSS_type_infrastructure = 1
dot11_radio_state_on = 1
dot11_radio_state_off = 2
WLAN_API_VERSION_2_0 = 2
CP_ACP = 0
LB_ERR = -1
LANG_ENGLISH = 9
SUBLANG_DEFAULT = 1

IDD_MAIN = 1000
IDC_LIST = 101
IDC_BTN_ON = 102
IDC_BTN_OFF = 103
IDC_BTN_REFRESH = 104
IDC_BTN_CONNECT = 105
IDC_BTN_DISCONNECT = 106
IDC_EDIT_PASS = 107

struct WLAN_AVAILABLE_NETWORK
    strProfileName              rw 256
    uSSIDLength                 dd ?
    ucSSID                      rb 32
    dot11BssType                dd ?
    uNumberOfBssids             dd ?
    bNetworkConnectable         dd ?
    wlanNotConnectableReason    dd ?
    uNumberOfPhyTypes           dd ?
    dot11PhyTypes               dd 8 dup (?)
    bMorePhyTypes               dd ?
    wlanSignalQuality           dd ?
    bSecurityEnabled            dd ?
    dot11DefaultAuthAlgorithm   dd ?
    dot11DefaultCipherAlgorithm dd ?
    dwFlags                     dd ?
    dwReserved                  dd ?
ends

struct WLAN_CONNECTION_PARAMETERS
    wlanConnectionMode dd ?
    strProfile dd ?
    pDot11Ssid dd ?
    pDesiredBssidList dd ?
    dot11BssType dd ?
    dwFlags dd ?
ends

struct WLAN_PHY_RADIO_STATE
    dwPhyIndex dd ?
    dot11SoftwareRadioState dd ?
    dot11HardwareRadioState dd ?
ends

section '.data' data readable writeable
    dwNegotiatedVersion dd ?
    hClient dd ?
    pInterfaceList dd ?
    pNetworkList dd ?
    dwReason dd ?

    InterfaceGuid rb 16

    TempSsid rb 33
    TempPass rb 256

    WideSsid rw 256
    WidePass rw 256
    ProfileXml rw 2048

    connParams WLAN_CONNECTION_PARAMETERS
    radioState WLAN_PHY_RADIO_STATE

    XmlTemplate du '<?xml version="1.0"?>', 13, 10,\
        '<WLANProfile xmlns="http://www.microsoft.com/networking/WLAN/profile/v1">', 13, 10,\
        '<name>%s</name>', 13, 10,\
        '<SSIDConfig>', 13, 10,\
        '<SSID><name>%s</name></SSID>', 13, 10,\
        '</SSIDConfig>', 13, 10,\
        '<connectionType>ESS</connectionType>', 13, 10,\
        '<connectionMode>auto</connectionMode>', 13, 10,\
        '<MSM>', 13, 10,\
        '<security>', 13, 10,\
        '<authEncryption>', 13, 10,\
        '<authentication>WPA2PSK</authentication>', 13, 10,\
        '<encryption>AES</encryption>', 13, 10,\
        '<useOneX>false</useOneX>', 13, 10,\
        '</authEncryption>', 13, 10,\
        '<sharedKey>', 13, 10,\
        '<keyType>passPhrase</keyType>', 13, 10,\
        '<protected>false</protected>', 13, 10,\
        '<keyMaterial>%s</keyMaterial>', 13, 10,\
        '</sharedKey>', 13, 10,\
        '</security>', 13, 10,\
        '</MSM>', 13, 10,\
        '</WLANProfile>', 0

section '.text' code readable executable
start:
    invoke GetModuleHandle, 0
    invoke DialogBoxParam, eax, IDD_MAIN, 0, DialogProc, 0
    invoke ExitProcess, 0

proc DialogProc hwnd, msg, wparam, lparam
    cmp [msg], WM_INITDIALOG
    je .wm_initdialog
    cmp [msg], WM_COMMAND
    je .wm_command
    cmp [msg], WM_CLOSE
    je .wm_close
    xor eax, eax
    ret
.wm_initdialog:
    invoke WlanOpenHandle, WLAN_API_VERSION_2_0, 0, dwNegotiatedVersion, hClient
    invoke WlanEnumInterfaces, [hClient], 0, pInterfaceList
    test eax, eax
    jnz .handled
    mov esi, [pInterfaceList]
    cmp dword [esi], 0
    jz .free_list
    add esi, 8
    mov edi, InterfaceGuid
    mov ecx, 4
    rep movsd
.free_list:
    invoke WlanFreeMemory, [pInterfaceList]
    jmp .handled
.wm_command:
    mov eax, [wparam]
    and eax, 0FFFFh
    cmp eax, IDC_BTN_REFRESH
    je .refresh
    cmp eax, IDC_BTN_CONNECT
    je .connect
    cmp eax, IDC_BTN_DISCONNECT
    je .disconnect
    cmp eax, IDC_BTN_ON
    je .radio_on
    cmp eax, IDC_BTN_OFF
    je .radio_off
    xor eax, eax
    ret
.refresh:
    invoke SendDlgItemMessage, [hwnd], IDC_LIST, LB_RESETCONTENT, 0, 0
    invoke WlanGetAvailableNetworkList, [hClient], InterfaceGuid, 0, 0, pNetworkList
    test eax, eax
    jnz .handled
    mov ebx, [pNetworkList]
    mov edi, [ebx]
    mov esi, ebx
    add esi, 8
.refr_loop:
    test edi, edi
    jz .refr_done
    mov ecx, [esi + WLAN_AVAILABLE_NETWORK.uSSIDLength]
    cmp ecx, 32
    jbe .len_ok
    mov ecx, 32
.len_ok:
    push edi
    push esi
    lea eax, [esi + WLAN_AVAILABLE_NETWORK.ucSSID]
    mov esi, eax
    mov edi, TempSsid
    rep movsb
    mov byte [edi], 0
    pop esi
    invoke SendDlgItemMessage, [hwnd], IDC_LIST, LB_ADDSTRING, 0, TempSsid
    pop edi
    add esi, sizeof.WLAN_AVAILABLE_NETWORK
    dec edi
    jmp .refr_loop
.refr_done:
    invoke WlanFreeMemory, [pNetworkList]
    jmp .handled
.connect:
    invoke SendDlgItemMessage, [hwnd], IDC_LIST, LB_GETCURSEL, 0, 0
    cmp eax, LB_ERR
    je .handled
    invoke SendDlgItemMessage, [hwnd], IDC_LIST, LB_GETTEXT, eax, TempSsid
    invoke MultiByteToWideChar, CP_ACP, 0, TempSsid, -1, WideSsid, 256
    invoke GetDlgItemText, [hwnd], IDC_EDIT_PASS, TempPass, 256
    test eax, eax
    jz .connect_no_pass
    invoke MultiByteToWideChar, CP_ACP, 0, TempPass, -1, WidePass, 256
    cinvoke wsprintfW, ProfileXml, XmlTemplate, WideSsid, WideSsid, WidePass
    invoke WlanSetProfile, [hClient], InterfaceGuid, 0, ProfileXml, 0, 1, 0, dwReason
.connect_no_pass:
    mov [connParams.wlanConnectionMode], wlan_connection_mode_profile
    mov dword [connParams.strProfile], WideSsid
    mov dword [connParams.pDot11Ssid], 0
    mov dword [connParams.pDesiredBssidList], 0
    mov [connParams.dot11BssType], dot11_BSS_type_infrastructure
    mov [connParams.dwFlags], 0
    invoke WlanConnect, [hClient], InterfaceGuid, connParams, 0
    jmp .handled
.disconnect:
    invoke WlanDisconnect, [hClient], InterfaceGuid, 0
    jmp .handled
.radio_on:
    mov [radioState.dwPhyIndex], 0
    mov [radioState.dot11SoftwareRadioState], dot11_radio_state_on
    invoke WlanSetInterface, [hClient], InterfaceGuid, wlan_intf_opcode_radio_state,\
           sizeof.WLAN_PHY_RADIO_STATE, radioState, 0
    jmp .handled
.radio_off:
    mov [radioState.dwPhyIndex], 0
    mov [radioState.dot11SoftwareRadioState], dot11_radio_state_off
    invoke WlanSetInterface, [hClient], InterfaceGuid, wlan_intf_opcode_radio_state,\
           sizeof.WLAN_PHY_RADIO_STATE, radioState, 0
    jmp .handled
.wm_close:
    invoke WlanCloseHandle, [hClient], 0
    invoke EndDialog, [hwnd], 0
.handled:
    mov eax, 1
    ret
endp

section '.idata' import data readable writeable
library kernel32,                       'kernel32.dll',\
        user32,                         'user32.dll',\
        wlanapi,                        'wlanapi.dll'
import  kernel32,\
        ExitProcess,                    'ExitProcess',\
        GetModuleHandle,                'GetModuleHandleA',\
        MultiByteToWideChar,            'MultiByteToWideChar'
import  user32,\
        DialogBoxParam,                 'DialogBoxParamA',\
        EndDialog,                      'EndDialog',\
        SendDlgItemMessage,             'SendDlgItemMessageA',\
        GetDlgItemText,                 'GetDlgItemTextA',\
        wsprintfW,                      'wsprintfW'
import  wlanapi,\
        WlanOpenHandle,                 'WlanOpenHandle',\
        WlanCloseHandle,                'WlanCloseHandle',\
        WlanEnumInterfaces,             'WlanEnumInterfaces',\
        WlanGetAvailableNetworkList,    'WlanGetAvailableNetworkList',\
        WlanFreeMemory,                 'WlanFreeMemory',\
        WlanConnect,                    'WlanConnect',\
        WlanDisconnect,                 'WlanDisconnect',\
        WlanSetInterface,               'WlanSetInterface',\
        WlanSetProfile,                 'WlanSetProfile'

section '.rsrc' resource data readable
    directory RT_DIALOG, dialogs

    resource dialogs,\
             IDD_MAIN, LANG_ENGLISH + SUBLANG_DEFAULT, main_dialog

    dialog main_dialog, 'Wi-Fi Manager', 50, 50, 200, 180,\
           WS_CAPTION or WS_SYSMENU or WS_VISIBLE or DS_CENTER
        dialogitem 'LISTBOX', '', IDC_LIST, 10, 10, 180, 100,\
                   WS_VISIBLE or WS_BORDER or LBS_NOTIFY or WS_VSCROLL
        dialogitem 'BUTTON', 'Refresh', IDC_BTN_REFRESH, 10, 115, 50, 15,\
                   WS_VISIBLE or BS_PUSHBUTTON
        dialogitem 'BUTTON', 'On', IDC_BTN_ON, 70, 115, 30, 15,\
                   WS_VISIBLE or BS_PUSHBUTTON
        dialogitem 'BUTTON', 'Off', IDC_BTN_OFF, 110, 115, 30, 15,\
                   WS_VISIBLE or BS_PUSHBUTTON
        dialogitem 'EDIT', '', IDC_EDIT_PASS, 10, 135, 180, 12,\
                   WS_VISIBLE or WS_BORDER or ES_AUTOHSCROLL
        dialogitem 'BUTTON', 'Connect', IDC_BTN_CONNECT, 10, 155, 80, 15,\
                   WS_VISIBLE or BS_PUSHBUTTON
        dialogitem 'BUTTON', 'Disconnect', IDC_BTN_DISCONNECT, 100, 155, 80, 15,\
                   WS_VISIBLE or BS_PUSHBUTTON
    enddialog
