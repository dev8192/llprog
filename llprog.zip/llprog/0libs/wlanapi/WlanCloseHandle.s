format PE
entry start

include 'win32ax.inc'

WLAN_API_VERSION_2_0 = 2
ERROR_SUCCESS = 0 ; WinError.h
ERROR_INVALID_PARAMETER = 87 ; 0x57
ERROR_INVALID_HANDLE = 6
;RPC_STATUS
LANG_ENGLISH_US = 0x0409

section '.data' data readable writeable
    fmt_success         db 'Success', 10, 0
    fmt_err             db "Error %u (0x%X): '%s'", 10, 0
    buffer              rb 256
    dwNegotiatedVersion dd ?
    hClient             dd ?
    fmt_d               db '%d', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc wlan_close_handle uses ebx, hClientHandle, pReserved
    invoke  WlanCloseHandle, [hClientHandle], [pReserved]
    cmp     eax, ERROR_SUCCESS
    jne     .error
    cinvoke printf, fmt_success
    jmp     .done
.error:
    mov     ebx, eax
    invoke  FormatMessage,\
            FORMAT_MESSAGE_FROM_SYSTEM + FORMAT_MESSAGE_MAX_WIDTH_MASK,\
            0, eax, LANG_ENGLISH_US, buffer, 256, 0
    cinvoke printf, fmt_err, ebx, ebx, buffer
.done:
    ret
endp

; ------------------------------------------------
; No error
; ------------------------------------------------
proc main10
    invoke WlanOpenHandle, WLAN_API_VERSION_2_0, 0, dwNegotiatedVersion, hClient
    cinvoke printf, fmt_d, eax
    cinvoke printf, fmt_d, [hClient]
    stdcall wlan_close_handle, [hClient], 0
    ret
endp

; ------------------------------------------------
; Error 87 (0x57): 'The parameter is incorrect. '
; ------------------------------------------------
proc main20
    invoke WlanOpenHandle, WLAN_API_VERSION_2_0, 0, dwNegotiatedVersion, hClient
    cinvoke printf, fmt_d, eax
    cinvoke printf, fmt_d, [hClient]
    stdcall wlan_close_handle, [hClient], 123
    ret
endp

; ------------------------------------------------
; Error 87 (0x57): 'The parameter is incorrect. '
; ------------------------------------------------
proc main30
    stdcall wlan_close_handle, 0, 0
    ret
endp

; ------------------------------------------------
; Error 6 (0x6): 'The handle is invalid. '
; ------------------------------------------------
proc main
    stdcall wlan_close_handle, 1, 0
    stdcall wlan_close_handle, 2, 0
    stdcall wlan_close_handle, 3, 0
    stdcall wlan_close_handle, 4, 0
    stdcall wlan_close_handle, 5, 0
    ret
endp

section '.idata' import data readable
library kernel32,           'kernel32.dll',\
        wlanapi,            'wlanapi.dll',\
        msvcrt,             'msvcrt.dll'
import  kernel32,\
        ExitProcess,        'ExitProcess',\
        FormatMessage,      'FormatMessageA'
import  wlanapi,\
        WlanOpenHandle,     'WlanOpenHandle',\
        WlanCloseHandle,    'WlanCloseHandle'
import  msvcrt,\
        printf,             'printf'
