format PE
entry start

include 'win32aX.inc'

WLAN_API_VERSION_2_0 = 2

WLAN_INTERFACE_STATE_NOT_READY = 0
WLAN_INTERFACE_STATE_CONNECTED = 1
WLAN_INTERFACE_STATE_AD_HOC_NETWORK_FORMED = 2
WLAN_INTERFACE_STATE_DISCONNECTING = 3
WLAN_INTERFACE_STATE_DISCONNECTED = 4
WLAN_INTERFACE_STATE_ASSOCIATING = 5
WLAN_INTERFACE_STATE_DISCOVERING = 6
WLAN_INTERFACE_STATE_AUTHENTICATING = 7

struct WLAN_GUID
    Data1 dd ?
    Data2 dw ?
    Data3 dw ?
    Data4 rb 8
ends

struct WLAN_INTERFACE_INFO
    InterfaceGuid           WLAN_GUID
    strInterfaceDescription rw 256
    isState                 dd ?
ends

struct WLAN_INTERFACE_INFO_LIST
    dwNumberOfItems dd ?
    dwIndex         dd ?
    InterfaceInfo   WLAN_INTERFACE_INFO
ends

section '.data' data readable writeable
    fmt_d               db '%d', 10, 0
    dwNegotiatedVersion dd ?
    hClient             dd ?
    pInterfaceList      dd ?

    fstr_error      db 'WLAN API Error: %X', 10, 0
    fstr_header     db 'Number of interfaces: %u', 10, 10, 0
    fmt_iface_idx   db 'Interface Index: %u', 10, 0
    fmt_guid        db '  GUID: %08X-%04X-%04X-%02X%02X-%02X%02X%02X%02X%02X%02X', 10, 0
    fmt_desc        db '  Description: %ls', 10, 0
    fmt_state       db '  State: %u (%s)', 10, 0

    state_0 db 'Not ready', 0
    state_1 db 'Connected', 0
    state_2 db 'Ad hoc network formed', 0
    state_3 db 'Disconnecting', 0
    state_4 db 'Disconnected', 0
    state_5 db 'Associating', 0
    state_6 db 'Discovering', 0
    state_7 db 'Authenticating', 0
    state_unknown db 'Unknown state', 0

    state_ptrs dd state_0, state_1, state_2, state_3,\
                  state_4, state_5, state_6, state_7

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main10
    cinvoke printf, fmt_d, sizeof.WLAN_GUID                 ; 16
    cinvoke printf, fmt_d, sizeof.WLAN_INTERFACE_INFO       ; 532
    cinvoke printf, fmt_d, sizeof.WLAN_INTERFACE_INFO_LIST  ; 540
    ret
endp

; GUID: 24316660-8F6B-4D93-9485-364213196B9A
proc main
    local guid:WLAN_GUID
    mov [guid.Data1], 0x24316660
    mov word [guid.Data2], 0x8F6B
    mov word [guid.Data3], 0x4D93
    mov byte [guid.Data4 + 0], 0x94
    mov byte [guid.Data4 + 1], 0x85
    mov byte [guid.Data4 + 2], 0x36
    mov byte [guid.Data4 + 3], 0x42
    mov byte [guid.Data4 + 4], 0x13
    mov byte [guid.Data4 + 5], 0x19
    mov byte [guid.Data4 + 6], 0x6B
    mov byte [guid.Data4 + 7], 0x9A
    stdcall print_guid, addr guid
    ret
endp

proc main20 uses ebx esi edi
    invoke WlanOpenHandle, WLAN_API_VERSION_2_0, 0, dwNegotiatedVersion, hClient
    test eax, eax
    jnz .error_exit

    invoke WlanEnumInterfaces, [hClient], 0, pInterfaceList
    test eax, eax
    jnz .error_cleanup

    mov ebx, [pInterfaceList]
    mov edi, [ebx + WLAN_INTERFACE_INFO_LIST.dwNumberOfItems]

    cinvoke printf, fstr_header, edi

    xor esi, esi

.print_loop:
    cmp esi, edi
    jae .free_memory

    mov eax, sizeof.WLAN_INTERFACE_INFO
    mul esi
    lea edx, [ebx + WLAN_INTERFACE_INFO_LIST.InterfaceInfo + eax]

    virtual at edx
        .info WLAN_INTERFACE_INFO
    end virtual

    mov eax, [.info.isState]
    cmp eax, WLAN_INTERFACE_STATE_AUTHENTICATING
    ja .unknown_state
    mov ecx, dword [state_ptrs + eax * 4]
    jmp .push_args
.unknown_state:
    mov ecx, state_unknown

.push_args:
    cinvoke printf, fmt_iface_idx, esi

    stdcall print_guid, addr guid

    lea eax, [.info.strInterfaceDescription]
    cinvoke printf, fmt_desc, eax

    mov eax, [.info.isState]
    cinvoke printf, fmt_state, eax, ecx

    inc esi
    jmp .print_loop

.free_memory:
    invoke WlanFreeMemory, [pInterfaceList]

.error_cleanup:
    invoke WlanCloseHandle, [hClient], 0
    jmp .exit

.error_exit:
    cinvoke printf, fstr_error, eax

.exit:
    ret
endp

section '.idata' import data readable writeable
library kernel32,           'kernel32.dll',\
        wlanapi,            'wlanapi.dll',\
        msvcrt,             'msvcrt.dll'
import  kernel32,\
        ExitProcess,        'ExitProcess'
import  wlanapi,\
        WlanOpenHandle,     'WlanOpenHandle',\
        WlanEnumInterfaces, 'WlanEnumInterfaces',\
        WlanFreeMemory,     'WlanFreeMemory',\
        WlanCloseHandle,    'WlanCloseHandle'
import  msvcrt,\
        printf,             'printf'
