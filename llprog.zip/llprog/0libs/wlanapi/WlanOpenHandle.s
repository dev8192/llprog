format PE
entry start

include 'win32ax.inc'

WLAN_API_VERSION_2_0 = 2
ERROR_SUCCESS = 0 ; WinError.h
ERROR_INVALID_PARAMETER = 87 ; 0x57
ERROR_NOT_ENOUGH_MEMORY = 8
ERROR_REMOTE_SESSION_LIMIT_EXCEEDED = 1220 ; 0x4C4
;RPC_STATUS
LANG_ENGLISH_US = 0x0409

section '.data' data readable writeable
    fmt_success         db 'Success', 10, 0
    fmt_err             db "Error %u (0x%X): '%s'", 10, 0
    buffer              rb 256
    dwNegotiatedVersion dd ?
    hClient             dd ?
    fmt_version         db 'version: %d', 10, 0
    fmt_client          db 'client: %d', 10, 0
    fmt_close_handle    db 'close_handle: %d', 10, 0
    fmt_d               db '%d', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc wlan_open_handle uses ebx, dwClientVersion, pReserved, pdwNegotiatedVersion, phClientHandle
    invoke  WlanOpenHandle, [dwClientVersion], [pReserved], [pdwNegotiatedVersion], [phClientHandle]
    mov     ebx, eax
    cmp     eax, ERROR_SUCCESS
    jne     .error
    cinvoke printf, fmt_success
    jmp     .done
.error:
    invoke  FormatMessage,\
            FORMAT_MESSAGE_FROM_SYSTEM + FORMAT_MESSAGE_MAX_WIDTH_MASK,\
            0, eax, LANG_ENGLISH_US, buffer, 256, 0
    cinvoke printf, fmt_err, ebx, ebx, buffer
.done:
    mov eax, ebx
    ret
endp

; ------------------------------------------------
; No error
; ------------------------------------------------
proc main10
    stdcall wlan_open_handle, WLAN_API_VERSION_2_0, 0, dwNegotiatedVersion, hClient
    cinvoke printf, fmt_version, [dwNegotiatedVersion]
    cinvoke printf, fmt_client, [hClient]
    invoke WlanCloseHandle, [hClient], 0
    cinvoke printf, fmt_close_handle, eax
    ret
endp

; ------------------------------------------------
; Error 50 (0x32): 'The request is not supported. '
; ------------------------------------------------
proc main20
    stdcall wlan_open_handle, 0, 0, dwNegotiatedVersion, hClient
    stdcall wlan_open_handle, 3, 0, dwNegotiatedVersion, hClient
    stdcall wlan_open_handle, 4, 0, dwNegotiatedVersion, hClient
    stdcall wlan_open_handle, 5, 0, dwNegotiatedVersion, hClient
    ret
endp

; ------------------------------------------------
; Error 87 (0x57): 'The parameter is incorrect. '
; ------------------------------------------------
proc main30
    stdcall wlan_open_handle, WLAN_API_VERSION_2_0, 0, 0, hClient
    stdcall wlan_open_handle, WLAN_API_VERSION_2_0, 0, dwNegotiatedVersion, 0
    stdcall wlan_open_handle, WLAN_API_VERSION_2_0, 0, 0, 0
    stdcall wlan_open_handle, WLAN_API_VERSION_2_0, 123, dwNegotiatedVersion, hClient
    ret
endp

; ------------------------------------------------
; Error 1220 (0x4C4): 'An attempt was made to establish a session to a network server, but there are already too many sessions established to that server. '
; ------------------------------------------------
proc main uses ebx
    mov ebx, 0
.loop:
    inc ebx
    stdcall wlan_open_handle, WLAN_API_VERSION_2_0, 0, dwNegotiatedVersion, hClient
    test eax, eax
    jz .loop
    cinvoke printf, fmt_d, ebx
    ret
endp

section '.idata' import data readable
library kernel32,           'kernel32.dll',\
        wlanapi,            'wlanapi.dll',\
        msvcrt,             'msvcrt.dll'
import  kernel32,\
        ExitProcess,        'ExitProcess',\
        FormatMessage,      'FormatMessageA'
import  wlanapi,\
        WlanOpenHandle,     'WlanOpenHandle',\
        WlanCloseHandle,    'WlanCloseHandle'
import  msvcrt,\
        printf,             'printf'
