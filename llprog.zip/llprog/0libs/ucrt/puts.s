format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_d   db '%d', 10, 0
    fmt_x   db '%x', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    cinvoke ucrt_puts, '*** main ***'
    cinvoke printf, fmt_x, ucrt_puts
    cinvoke printf, fmt_x, msvcrt_puts
    cinvoke printf, fmt_x, [ucrt_puts]
    cinvoke printf, fmt_x, [msvcrt_puts]
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            ucrtbase,       'ucrtbase.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  ucrtbase,\
            ucrt_puts,      'puts'
    import  msvcrt,\
            printf,         'printf',\
            msvcrt_puts,    'puts'
