format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_d   db '%d', 10, 0
    fmt_x   db '%x', 10, 0
    str_a   db 'a', 0
    str_b   db 'b', 0
    str_c   db 'c', 0
    newline db 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main1
    cinvoke puts, '*** main1 ***'
    cinvoke _cputs, str_a
    cinvoke _cputs, str_b
    cinvoke _cputs, str_c
    cinvoke _cputs, newline
    cinvoke puts, str_a
    cinvoke puts, str_b
    cinvoke puts, str_c
    ret
endp

proc main
    cinvoke puts, '*** main2 ***'
    cinvoke printf, fmt_x, puts
    cinvoke printf, fmt_x, _cputs
    cinvoke printf, fmt_x, [puts]
    cinvoke printf, fmt_x, [_cputs]
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            ucrtbase,       'ucrtbase.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  ucrtbase,\
            _cputs,         '_cputs',\
            puts,           'puts'
    import  msvcrt,\
            printf,         'printf'
