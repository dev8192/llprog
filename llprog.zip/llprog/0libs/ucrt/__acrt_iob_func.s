format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    stdout_ptr      dd ?
    str1            db 'hello', 10, 0
    fmt_d           dd '%d', 10, 0
    val_to_print    dd 123

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    cinvoke puts, '*** main1 ***'
    cinvoke __acrt_iob_func, 1
    mov [stdout_ptr], eax
    cinvoke fputc, 97, [stdout_ptr]
    cinvoke printf, 0, 0, [stdout_ptr], fmt_d, 0, val_to_print
    ret
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            ucrtbase,           'ucrtbase.dll'
    import  kernel32,\
            ExitProcess,        'ExitProcess'
    import  ucrtbase,\
            __acrt_iob_func,    '__acrt_iob_func',\
            fputc,              'fputc',\
            printf,             '__stdio_common_vfprintf',\
            puts,               'puts'
