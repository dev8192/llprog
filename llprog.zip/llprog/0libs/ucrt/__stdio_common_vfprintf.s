format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    stdout_ptr      dd ?
    str1            db 'hello', 10, 0
    fmt_d           db '%d', 10, 0
    fmt_dd          db '%d %d', 10, 0
    fmt_ddd         db '%d %d %d', 10, 0
args:
    num1            dd 101
    num2            dd 102
    num3            dd 103

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main1
    cinvoke puts, '*** main1 ***'
    cinvoke __acrt_iob_func, 1
    mov [stdout_ptr], eax
    cinvoke printf, 0, 0, [stdout_ptr], fmt_d, 0, args
    cinvoke printf, 0, 0, [stdout_ptr], fmt_dd, 0, args
    cinvoke printf, 0, 0, [stdout_ptr], fmt_ddd, 0, args
    cinvoke printf, 0, 0, [stdout_ptr], str1, 0
    ret
endp

proc main
    locals
        num1            dd 102
        num2            dd 202
        num3            dd 302
    endl
    cinvoke puts, '*** main2 ***'
    cinvoke __acrt_iob_func, 1
    mov [stdout_ptr], eax
    cinvoke printf, 0, 0, [stdout_ptr], fmt_ddd, 0, addr num1
    cinvoke printf, 0, 0, [stdout_ptr], str1, 0
    ret
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            ucrtbase,           'ucrtbase.dll'
    import  kernel32,\
            ExitProcess,        'ExitProcess'
    import  ucrtbase,\
            __acrt_iob_func,    '__acrt_iob_func',\
            printf,             '__conio_common_vfprintf',\
            puts,               'puts'
