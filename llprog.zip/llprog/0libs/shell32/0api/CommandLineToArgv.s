format PE console
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    example1    du 'program.exe arg1 arg2', 0
    example2    du '"c:\path with spaces\prog.exe" "arg 1" -switch', 0
    example3    du 'app.exe /flag="value with spaces" trailing', 0

    examples    dd example1, example2, example3, 0

    fmt_header  db 'Parsing: %ls', 10, 0
    fmt_arg     db '    Arg %d: %ls', 10, 0
    fmt_newline db 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main uses ebx esi edi
    cinvoke puts, '*** main2 ***'
    local argc:DWORD, argv:DWORD
    ret
endp

proc main2 uses ebx esi edi
    cinvoke puts, '*** main2 ***'
    local argc:DWORD, argv:DWORD
    mov esi, examples
.process_loop:
    mov ebx, [esi]
    test ebx, ebx
    jz .done
    cinvoke printf, fmt_header, ebx
    invoke CommandLineToArgv, ebx, addr argc
    test eax, eax
    jz .next_example
    mov [argv], eax
    xor edi, edi
.print_args:
    cmp edi, [argc]
    jge .free_args
    mov eax, [argv]
    mov eax, [eax + edi * 4]
    cinvoke printf, fmt_arg, edi, eax
    inc edi
    jmp .print_args
.free_args:
    invoke LocalFree, [argv]
    cinvoke printf, fmt_newline
.next_example:
    add esi, 4
    jmp .process_loop
.done:
    ret
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            shell32,            'shell32.dll',\
            msvcrt,             'msvcrt.dll'
    import  kernel32,\
            ExitProcess,        'ExitProcess',\
            LocalFree,          'LocalFree'
    import  shell32,\
            CommandLineToArgv,  'CommandLineToArgvW'
    import  msvcrt,\
            printf,             'printf',\
            puts,               'puts'
