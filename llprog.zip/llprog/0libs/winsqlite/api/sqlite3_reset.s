format PE console
entry start

include 'win32a.inc'

SQLITE_OK   = 0
SQLITE_ROW  = 100
SQLITE_DONE = 101

section '.data' data readable writeable
    db_file     db ':memory:', 0
    sql_create  db 'CREATE TABLE users (id INTEGER PRIMARY KEY, name TEXT);', 0
    sql_insert  db 'INSERT INTO users (name) VALUES (?);', 0
    sql_select  db 'SELECT id, name FROM users;', 0
    name_one    db 'Alice', 0
    name_two    db 'Charlie', 0
    fmt_row     db 'ID: %d, Name: %s', 10, 0
    fmt_msg     db '%s', 10, 0
    msg_create  db 'Table created.', 0
    msg_insert1 db 'First user inserted.', 0
    msg_insert2 db 'Second user inserted via statement reuse.', 0
    db_handle   dd ?
    stmt_handle dd ?

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main uses ebx
    invoke sqlite3_open, db_file, db_handle
    test eax, eax
    jnz .exit

    invoke sqlite3_exec, [db_handle], sql_create, 0, 0, 0
    cinvoke printf, fmt_msg, msg_create

    invoke sqlite3_prepare_v2, [db_handle], sql_insert, -1, stmt_handle, 0
    test eax, eax
    jnz .close

    invoke sqlite3_bind_text, [stmt_handle], 1, name_one, -1, 0
    invoke sqlite3_step, [stmt_handle]
    cinvoke printf, fmt_msg, msg_insert1

    invoke sqlite3_reset, [stmt_handle]

    invoke sqlite3_bind_text, [stmt_handle], 1, name_two, -1, 0
    invoke sqlite3_step, [stmt_handle]
    cinvoke printf, fmt_msg, msg_insert2

    invoke sqlite3_finalize, [stmt_handle]

    invoke sqlite3_prepare_v2, [db_handle], sql_select, -1, stmt_handle, 0
    test eax, eax
    jnz .close

.read_loop:
    invoke sqlite3_step, [stmt_handle]
    cmp eax, SQLITE_ROW
    jne .finalize

    invoke sqlite3_column_int, [stmt_handle], 0
    mov ebx, eax
    invoke sqlite3_column_text, [stmt_handle], 1
    cinvoke printf, fmt_row, ebx, eax
    jmp .read_loop

.finalize:
    invoke sqlite3_finalize, [stmt_handle]

.close:
    invoke sqlite3_close, [db_handle]

.exit:
    ret
endp

section '.idata' import data readable
    library kernel32,               'kernel32.dll',\
            msvcrt,                 'msvcrt.dll',\
            winsqlite3,             'winsqlite3.dll'
    import  kernel32,\
            ExitProcess,            'ExitProcess'
    import  msvcrt,\
            printf,                 'printf'
    import  winsqlite3,\
            sqlite3_open,           'sqlite3_open',\
            sqlite3_exec,           'sqlite3_exec',\
            sqlite3_prepare_v2,     'sqlite3_prepare_v2',\
            sqlite3_bind_text,      'sqlite3_bind_text',\
            sqlite3_step,           'sqlite3_step',\
            sqlite3_reset,          'sqlite3_reset',\
            sqlite3_column_int,     'sqlite3_column_int',\
            sqlite3_column_text,    'sqlite3_column_text',\
            sqlite3_finalize,       'sqlite3_finalize',\
            sqlite3_close,          'sqlite3_close'
