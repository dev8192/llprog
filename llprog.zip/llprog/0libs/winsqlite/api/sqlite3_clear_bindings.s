format PE console
entry start

include 'win32a.inc'

SQLITE_OK   = 0
SQLITE_ROW  = 100
SQLITE_DONE = 101

section '.data' data readable writeable
    db_file     db ':memory:', 0
    sql_create  db 'CREATE TABLE products (id INTEGER PRIMARY KEY, name TEXT, category TEXT);', 0
    sql_insert  db 'INSERT INTO products (name, category) VALUES (?, ?);', 0
    sql_select  db 'SELECT id, name, category FROM products;', 0
    prod_name   db 'Laptop', 0
    prod_cat    db 'Electronics', 0
    fmt_row     db 'ID: %d, Name: %s, Category: %s', 13, 10, 0
    fmt_msg     db '%s', 13, 10, 0
    msg_create  db 'Table created.', 0
    msg_insert1 db 'First product inserted (Both parameters bound).', 0
    msg_insert2 db 'Second product inserted (Reset and bindings cleared).', 0
    db_handle   dd ?
    stmt_handle dd ?

section '.code' code readable executable

start:
    invoke db_ops
    invoke ExitProcess, 0

proc db_ops
    cinvoke sqlite3_open, db_file, db_handle
    test eax, eax
    jnz .exit

    cinvoke sqlite3_exec, [db_handle], sql_create, 0, 0, 0
    cinvoke printf, fmt_msg, msg_create

    cinvoke sqlite3_prepare_v2, [db_handle], sql_insert, -1, stmt_handle, 0
    test eax, eax
    jnz .close

    cinvoke sqlite3_bind_text, [stmt_handle], 1, prod_name, -1, 0
    cinvoke sqlite3_bind_text, [stmt_handle], 2, prod_cat, -1, 0
    cinvoke sqlite3_step, [stmt_handle]
    cinvoke printf, fmt_msg, msg_insert1

    cinvoke sqlite3_reset, [stmt_handle]
    cinvoke sqlite3_clear_bindings, [stmt_handle]

    cinvoke sqlite3_bind_text, [stmt_handle], 1, prod_name, -1, 0
    cinvoke sqlite3_step, [stmt_handle]
    cinvoke printf, fmt_msg, msg_insert2

    cinvoke sqlite3_finalize, [stmt_handle]

    cinvoke sqlite3_prepare_v2, [db_handle], sql_select, -1, stmt_handle, 0
    test eax, eax
    jnz .close

.read_loop:
    cinvoke sqlite3_step, [stmt_handle]
    cmp eax, SQLITE_ROW
    jne .finalize

    cinvoke sqlite3_column_int, [stmt_handle], 0
    mov ebx, eax
    cinvoke sqlite3_column_text, [stmt_handle], 1
    mov edi, eax
    cinvoke sqlite3_column_text, [stmt_handle], 2
    
    test eax, eax
    jnz .print
    mov eax, .null_str

.print:
    cinvoke printf, fmt_row, ebx, edi, eax
    jmp .read_loop

.finalize:
    cinvoke sqlite3_finalize, [stmt_handle]

.close:
    cinvoke sqlite3_close, [db_handle]

.exit:
    ret

.null_str db '[NULL]', 0
endp

section '.idata' import data readable
    library kernel32, 'kernel32.dll', \
            msvcrt, 'msvcrt.dll', \
            winsqlite3, 'winsqlite3.dll'

    import kernel32, \
           ExitProcess, 'ExitProcess'

    import msvcrt, \
           printf, 'printf'

    import winsqlite3, \
           sqlite3_open, 'sqlite3_open', \
           sqlite3_exec, 'sqlite3_exec', \
           sqlite3_prepare_v2, 'sqlite3_prepare_v2', \
           sqlite3_bind_text, 'sqlite3_bind_text', \
           sqlite3_step, 'sqlite3_step', \
           sqlite3_reset, 'sqlite3_reset', \
           sqlite3_clear_bindings, 'sqlite3_clear_bindings', \
           sqlite3_column_int, 'sqlite3_column_int', \
           sqlite3_column_text, 'sqlite3_column_text', \
           sqlite3_finalize, 'sqlite3_finalize', \
           sqlite3_close, 'sqlite3_close'
