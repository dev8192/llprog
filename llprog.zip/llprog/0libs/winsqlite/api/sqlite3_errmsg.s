format PE console
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    db_file1    db 'invalid_path/demo.db', 0
    db_file2    db ':memory:', 0
    fmt_err     db 'Database Error: %s', 10, 0
    fmt_msg     db '%s', 10, 0
    msg_ok      db 'msg_ok', 10, 0
    db_handle   dd ?
    bad_sql     db 'NOT A VALID SQL COMMAND;', 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc sqlite_func, db_file
    invoke sqlite3_open, [db_file], db_handle
    test eax, eax
    jnz .error
    invoke sqlite3_exec, [db_handle], bad_sql, 0, 0, 0
    test eax, eax
    jnz .error
    cinvoke printf, msg_ok
    jmp .close
.error:
    invoke sqlite3_errmsg, [db_handle]
    cinvoke printf, fmt_err, eax
.close:
    invoke sqlite3_close, [db_handle]
    ret
endp

proc main1
    cinvoke puts, '*** main1 ***'
    stdcall sqlite_func, db_file1
    stdcall sqlite_func, db_file2
    ret
endp

proc main
    cinvoke puts, '*** main2 ***'
    invoke sqlite3_errmsg, 0
    cinvoke printf, fmt_err, eax
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll',\
            winsqlite3,     'winsqlite3.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
    import  winsqlite3,\
            sqlite3_open,   'sqlite3_open',\
            sqlite3_exec,   'sqlite3_exec',\
            sqlite3_errmsg, 'sqlite3_errmsg',\
            sqlite3_close,  'sqlite3_close'
