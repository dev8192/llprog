format PE console
entry start

include 'win32a.inc'

SQLITE_OK = 0

section '.data' data readable writeable
    db_file     db ':memory:', 0
    sql_create  db 'CREATE TABLE users (id INTEGER PRIMARY KEY, name TEXT);', 0
    sql_insert  db "INSERT INTO users (name) VALUES ('Alice'), ('Bob'), ('Charlie');", 0
    sql_select  db 'SELECT id, name FROM users;', 0
    fmt_msg     db '%s', 13, 10, 0
    fmt_row     db '   %s = %s', 13, 10, 0
    msg_start   db '--- Query Results Start ---', 0
    msg_end     db '--- Query Results End ---', 0
    db_handle   dd ?

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    cinvoke sqlite3_open, db_file, db_handle
    test eax, eax
    jnz .exit

    cinvoke sqlite3_exec, [db_handle], sql_create, 0, 0, 0
    cinvoke sqlite3_exec, [db_handle], sql_insert, 0, 0, 0

    cinvoke printf, fmt_msg, msg_start
    cinvoke sqlite3_exec, [db_handle], sql_select, exec_callback, 0, 0
    cinvoke printf, fmt_msg, msg_end

    cinvoke sqlite3_close, [db_handle]

.exit:
    ret
endp

proc exec_callback cdecl, not_used, num_cols, col_values, col_names
    uses ebx, esi, edi

    mov esi, [col_names]
    mov edi, [col_values]
    mov ebx, [num_cols]
    xor ecx, ecx

.print_row:
    push ecx
    
    mov eax, [edi + ecx*4]
    test eax, eax
    jnz .has_val
    mov eax, .null_str

.has_val:
    push eax
    mov ecx, [esp + 4]
    mov eax, [esi + ecx*4]
    push eax
    push fmt_row
    ccall [printf]
    add esp, 12

    pop ecx
    inc ecx
    cmp ecx, ebx
    jl .print_row

    xor eax, eax
    ret

.null_str db '[NULL]', 0
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            msvcrt,             'msvcrt.dll',\
            winsqlite3,         'winsqlite3.dll'
    import  kernel32,\
            ExitProcess,        'ExitProcess'
    import  msvcrt,\
            printf,             'printf'
    import  winsqlite3,\
            sqlite3_open,       'sqlite3_open',\
            sqlite3_exec,       'sqlite3_exec',\
            sqlite3_close,      'sqlite3_close'
