format PE console
entry start

include 'win32ax.inc'

SQLITE_OK = 0

section '.data' data readable writeable
    db_file1    db 'invalid_path/demo.db', 0
    db_file2    db ':memory:', 0
    db_handle   dd ?
    fmt_d       db '%d', 10, 0
    fmt_x       db '%x', 10, 0
    fmt_err     db 'Database Error: %s', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc sqlite3_open_func, filename, ppDb
    invoke sqlite3_open, [filename], [ppDb]
    test eax, eax
    jz .exit
    push eax
    mov eax, [db_handle]
    invoke sqlite3_errmsg, dword [eax]
    cinvoke printf, fmt_err, eax
    pop eax
.exit:
    ret
endp

proc main1
    cinvoke puts, '*** main1 ***'
    stdcall sqlite3_open_func, db_file1, db_handle
    cinvoke printf, fmt_d, eax
    cinvoke printf, fmt_d, [db_handle]
    invoke sqlite3_close, [db_handle]
    ret
endp

proc main2 uses ebx
    invoke sqlite3_open, db_file1, db_handle
    mov ebx, [db_handle]
    cinvoke printf, fmt_x, ebx
    cinvoke printf, fmt_d, dword [ebx]
    ret
endp

; 'bad parameter or other API misuse' vs Access Violation
proc main uses ebx
   ;invoke sqlite3_errmsg, 1954000000
    invoke sqlite3_errmsg, 1953000000
    cinvoke printf, fmt_err, eax
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll',\
            winsqlite3,     'winsqlite3.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
    import  winsqlite3,\
            sqlite3_open,   'sqlite3_open',\
            sqlite3_exec,   'sqlite3_exec',\
            sqlite3_errmsg, 'sqlite3_errmsg',\
            sqlite3_close,  'sqlite3_close'
