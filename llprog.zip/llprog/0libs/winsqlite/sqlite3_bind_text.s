format PE console
entry start

include 'win32ax.inc'

SQLITE_OK   = 0
SQLITE_ROW  = 100
SQLITE_DONE = 101

SQLITE_STATIC = 0
SQLITE_TRANSIENT = -1

section '.data' data readable writeable
    db_file     db '0files/demo.db', 0
    sql_create  db 'CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, name TEXT);', 0
    sql_bind    db 'INSERT INTO users (name) VALUES (?);', 0
    sql_select  db 'SELECT id, name FROM users;', 0
    sql_update  db "UPDATE users SET name = 'Bob' WHERE id = 1;", 0
    sql_delete  db 'DELETE FROM users WHERE id = 1;', 0
    param_name  db 'Alice', 0
    fmt_row     db 'ID: %d, Name: %s', 10, 0
    fmt_msg     db '%s', 10, 0
    msg_create  db 'Table created/checked.', 0
    msg_bind    db 'Row bound and inserted.', 0
    msg_update  db 'Row updated.', 0
    msg_delete  db 'Row deleted.', 0
    db_handle   dd ?
    stmt_handle dd ?

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    invoke sqlite3_open, db_file, db_handle
    test eax, eax
    jnz .exit

    invoke sqlite3_exec, [db_handle], sql_create, 0, 0, 0
    cinvoke printf, fmt_msg, msg_create

    invoke sqlite3_prepare_v2, [db_handle], sql_bind, -1, stmt_handle, 0
    test eax, eax
    jnz .close

    invoke sqlite3_bind_text, [stmt_handle], 1, param_name, -1, SQLITE_STATIC
    invoke sqlite3_step, [stmt_handle]
    invoke sqlite3_finalize, [stmt_handle]
    cinvoke printf, fmt_msg, msg_bind

    invoke sqlite3_prepare_v2, [db_handle], sql_select, -1, stmt_handle, 0
    test eax, eax
    jnz .close

.read_loop:
    invoke sqlite3_step, [stmt_handle]
    cmp eax, SQLITE_ROW
    jne .finalize

    invoke sqlite3_column_int, [stmt_handle], 0
    mov ebx, eax
    invoke sqlite3_column_text, [stmt_handle], 1
    cinvoke printf, fmt_row, ebx, eax
    jmp .read_loop

.finalize:
    invoke sqlite3_finalize, [stmt_handle]

    invoke sqlite3_exec, [db_handle], sql_update, 0, 0, 0
    cinvoke printf, fmt_msg, msg_update

    invoke sqlite3_exec, [db_handle], sql_delete, 0, 0, 0
    cinvoke printf, fmt_msg, msg_delete

.close:
    invoke sqlite3_close, [db_handle]
.exit:
    ret
endp

section '.idata' import data readable
    library kernel32,               'kernel32.dll',\
            msvcrt,                 'msvcrt.dll',\
            winsqlite3,             'winsqlite3.dll'
    import  kernel32,\
            ExitProcess,            'ExitProcess'
    import  msvcrt,\
            printf,                 'printf'
    import  winsqlite3,\
            sqlite3_open,           'sqlite3_open',\
            sqlite3_exec,           'sqlite3_exec',\
            sqlite3_prepare_v2,     'sqlite3_prepare_v2',\
            sqlite3_bind_text,      'sqlite3_bind_text',\
            sqlite3_step,           'sqlite3_step',\
            sqlite3_column_int,     'sqlite3_column_int',\
            sqlite3_column_text,    'sqlite3_column_text',\
            sqlite3_finalize,       'sqlite3_finalize',\
            sqlite3_close,          'sqlite3_close'
