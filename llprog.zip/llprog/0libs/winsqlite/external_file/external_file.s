format PE console
entry start

include 'win32a.inc'

SQLITE_OK = 0

section '.data' data readable writeable
    db_file     db ':memory:', 0
    sql_file    db 'sqlite/external_file/script.sql', 0
    sql_select  db 'SELECT id, name FROM users;', 0
    fmt_msg     db '%s', 10, 0
    fmt_row     db 'ID: %s, Name: %s', 10, 0
    msg_ok      db 'Script file executed successfully.', 0
    msg_err_f   db 'Error: Could not open script.sql', 0
    db_handle   dd ?
    file_handle dd ?
    file_size   dd ?
    bytes_read  dd ?
    buf_handle  dd ?

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    invoke CreateFile, sql_file, GENERIC_READ, FILE_SHARE_READ, 0,\
                      OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0
    cmp eax, INVALID_HANDLE_VALUE
    je .err_file
    mov [file_handle], eax

    invoke GetFileSize, [file_handle], 0
    mov [file_size], eax

    mov ecx, eax
    inc ecx
    invoke VirtualAlloc, 0, ecx, MEM_COMMIT, PAGE_READWRITE
    mov [buf_handle], eax

    mov edx, [file_size]
    invoke ReadFile, [file_handle], [buf_handle], edx, bytes_read, 0
    invoke CloseHandle, [file_handle]

    mov eax, [buf_handle]
    add eax, [file_size]
    mov byte [eax], 0

    invoke sqlite3_open, db_file, db_handle
    test eax, eax
    jnz .exit

    invoke sqlite3_exec, [db_handle], [buf_handle], 0, 0, 0
    test eax, eax
    jnz .close_all
    cinvoke printf, fmt_msg, msg_ok

    invoke sqlite3_exec, [db_handle], sql_select, exec_callback, 0, 0

.close_all:
    invoke sqlite3_close, [db_handle]
    invoke VirtualFree, [buf_handle], 0, MEM_RELEASE
    ret

.err_file:
    cinvoke printf, fmt_msg, msg_err_f
.exit:
    ret
endp

proc exec_callback, not_used, num_cols, col_values, col_names
    mov eax, [col_values]
    mov ecx, [eax]
    mov edx, [eax + 4]
    cinvoke printf, fmt_row, ecx, edx
    xor eax, eax
    ret
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            msvcrt,             'msvcrt.dll',\
            winsqlite3,         'winsqlite3.dll'
    import  kernel32,\
            ExitProcess,        'ExitProcess',\
            CreateFile,         'CreateFileA',\
            GetFileSize,        'GetFileSize',\
            ReadFile,           'ReadFile',\
            CloseHandle,        'CloseHandle',\
            VirtualAlloc,       'VirtualAlloc',\
            VirtualFree,        'VirtualFree'
    import  msvcrt,\
            printf,             'printf'
    import  winsqlite3,\
            sqlite3_open,       'sqlite3_open',\
            sqlite3_exec,       'sqlite3_exec',\
            sqlite3_close,      'sqlite3_close'
