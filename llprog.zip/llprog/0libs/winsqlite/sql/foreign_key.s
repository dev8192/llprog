format PE console
entry start

include 'win32a.inc'

SQLITE_OK         = 0
SQLITE_CONSTRAINT = 19

section '.data' data readable writeable
    db_file         db ':memory:', 0
    sql_pragma      db 'PRAGMA foreign_keys = ON;', 0
    
    sql_create_grp  db 'CREATE TABLE groups ('
                    db '  id INTEGER PRIMARY KEY,'
                    db '  name TEXT'
                    db ');', 0
    sql_create_usr  db 'CREATE TABLE users ('
                    db '  id INTEGER PRIMARY KEY,'
                    db '  name TEXT,'
                    db '  group_id INTEGER,'
                    db '  FOREIGN KEY(group_id) REFERENCES groups(id)'
                    db ');', 0
    
    sql_insert_grp  db "INSERT INTO groups (id, name) VALUES (10, 'Admins');", 0
    sql_insert_ok   db "INSERT INTO users (name, group_id) VALUES ('Alice', 10);", 0
    sql_insert_bad  db "INSERT INTO users (name, group_id) VALUES ('Bob', 99);", 0
    
    fmt_msg         db '%s', 13, 10, 0
    fmt_err         db 'Constraint Violated: %s', 13, 10, 0
    
    msg_pragma      db 'Foreign keys enabled.', 0
    msg_tables      db 'Tables created successfully.', 0
    msg_group       db 'Valid group inserted (ID: 10).', 0
    msg_alice       db 'Alice inserted successfully (Group 10 exists).', 0
    db_handle       dd ?

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    invoke sqlite3_open, db_file, db_handle
    test eax, eax
    jnz .exit

    invoke sqlite3_exec, [db_handle], sql_pragma, 0, 0, 0
    cinvoke printf, fmt_msg, msg_pragma

    invoke sqlite3_exec, [db_handle], sql_create_grp, 0, 0, 0
    invoke sqlite3_exec, [db_handle], sql_create_usr, 0, 0, 0
    cinvoke printf, fmt_msg, msg_tables

    invoke sqlite3_exec, [db_handle], sql_insert_grp, 0, 0, 0
    cinvoke printf, fmt_msg, msg_group

    invoke sqlite3_exec, [db_handle], sql_insert_ok, 0, 0, 0
    cinvoke printf, fmt_msg, msg_alice

    invoke sqlite3_exec, [db_handle], sql_insert_bad, 0, 0, 0
    cmp eax, SQLITE_CONSTRAINT
    jne .close

    invoke sqlite3_errmsg, [db_handle]
    cinvoke printf, fmt_err, eax

.close:
    invoke sqlite3_close, [db_handle]

.exit:
    ret
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            msvcrt,             'msvcrt.dll',\
            winsqlite3,         'winsqlite3.dll'
    import  kernel32,\
            ExitProcess,        'ExitProcess'
    import  msvcrt,\
            printf,             'printf',\
            puts,               'puts'
    import  winsqlite3,\
            sqlite3_open,       'sqlite3_open',\
            sqlite3_exec,       'sqlite3_exec',\
            sqlite3_errmsg,     'sqlite3_errmsg',\
            sqlite3_close,      'sqlite3_close'
