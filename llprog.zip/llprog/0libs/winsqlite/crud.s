format PE console
entry start

include 'win32ax.inc'

SQLITE_OK   = 0
SQLITE_ROW  = 100
SQLITE_DONE = 101

section '.data' data readable writeable
    db_file1        db '0files/demo.db', 0
    db_file2        db ':memory:', 0

    sql_create      db 'CREATE TABLE users (id INTEGER PRIMARY KEY, name TEXT);', 0

    sql_insert      db "INSERT INTO users (name) VALUES ('Alice');", 0
    
    sql_select      db 'SELECT id, name FROM users;', 0
    
    sql_update1     db "UPDATE users SET name = 'Bob' WHERE id = 1;", 0
    sql_update2     db "UPDATE users SET name = 'John' WHERE id = 7;", 0
    sql_update3     db "UPDATE users SET name = 'Bob' WHERE id BETWEEN 3 AND 5;", 0
    sql_update4     db "UPDATE users SET name = 'Jane' WHERE id >= 3 AND id <= 4;", 0

    sql_delete1     db 'DELETE FROM users WHERE id = 3;', 0
    sql_delete2     db "DELETE FROM users WHERE name = 'Alice';", 0

    msg_success     db 'success', 10, 0
    db_handle       dd ?
    stmt_handle     dd ?
    fmt_row         db 'ID: %d, Name: %s', 10, 0
    fmt_msg         db '%s', 10, 0
    fmt_x           db '%x', 10, 0
    fmt_err         db 'Database Error: %s', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc exec_sql, sql_stmt
    invoke sqlite3_open, db_file1, db_handle
    test eax, eax
    jnz .error
    invoke sqlite3_exec, [db_handle], [sql_stmt], 0, 0, 0
    test eax, eax
    jnz .error
    cinvoke printf, msg_success
    jmp .close
.error:
    invoke sqlite3_errmsg, [db_handle]
    cinvoke printf, fmt_err, eax
.close:
    invoke sqlite3_close, [db_handle]
    ret
endp

proc select_and_print uses ebx
    invoke sqlite3_open, db_file1, db_handle
    test eax, eax
    jnz .close
    invoke sqlite3_prepare_v2, [db_handle], sql_select, -1, stmt_handle, 0
    test eax, eax
    jnz .close
.read_loop:
    invoke sqlite3_step, [stmt_handle]
    cmp eax, SQLITE_ROW
    jne .finalize
    invoke sqlite3_column_int, [stmt_handle], 0
    mov ebx, eax
    invoke sqlite3_column_text, [stmt_handle], 1
    cinvoke printf, fmt_row, ebx, eax
    jmp .read_loop
.finalize:
    invoke sqlite3_finalize, [stmt_handle]
.close:
    invoke sqlite3_close, [db_handle]
    ret
endp

proc main uses ebx
    cinvoke puts, '*** main1 ***'
   ;stdcall exec_sql, sql_create
   ;stdcall exec_sql, sql_insert
   ;stdcall exec_sql, sql_update4
    stdcall exec_sql, sql_delete1

    stdcall select_and_print
    ret
endp

section '.idata' import data readable
    library kernel32,               'kernel32.dll',\
            msvcrt,                 'msvcrt.dll',\
            winsqlite3,             'winsqlite3.dll'
    import  kernel32,\
            ExitProcess,            'ExitProcess'
    import  msvcrt,\
            printf,                 'printf',\
            puts,                   'puts'
    import  winsqlite3,\
            sqlite3_open,           'sqlite3_open',\
            sqlite3_exec,           'sqlite3_exec',\
            sqlite3_prepare_v2,     'sqlite3_prepare_v2',\
            sqlite3_step,           'sqlite3_step',\
            sqlite3_column_int,     'sqlite3_column_int',\
            sqlite3_column_text,    'sqlite3_column_text',\
            sqlite3_finalize,       'sqlite3_finalize',\
            sqlite3_errmsg,         'sqlite3_errmsg',\
            sqlite3_close,          'sqlite3_close'
