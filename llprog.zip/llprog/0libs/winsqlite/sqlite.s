format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    ; Path to the State Repository SQLite database
    db_path  db 'C:\ProgramData\Microsoft\Windows\AppRepository\StateRepository-Machine.srd', 0
    
    ; Example Query: List all registered package names and their publishers
    sql_query db 'SELECT PackageFullName, PublisherId FROM Package', 0
    
    db_handle dd ?
    stmt_handle dd ?

section '.code' code readable executable
start:
    ; 1. Open the database file
    cinvoke sqlite3_open, db_path, db_handle
    test eax, eax
    jnz .error

    ; 2. Compile the SQL query into byte-code
    cinvoke sqlite3_prepare_v2, [db_handle], sql_query, -1, stmt_handle, 0
    test eax, eax
    jnz .error

    ; 3. Loop through the rows using sqlite3_step here...
    
.error:
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll', \
            sqlite3,  'winsqlite3.dll'

    import kernel32, ExitProcess, 'ExitProcess'
    import sqlite3, \
           sqlite3_open, 'sqlite3_open', \
           sqlite3_prepare_v2, 'sqlite3_prepare_v2'
