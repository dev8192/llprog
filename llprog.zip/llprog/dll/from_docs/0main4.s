format PE console
entry start

include 'win32a.inc'

section '.text' code readable executable
start:
    invoke    SetLastError, 0
    invoke    ShowLastError, HWND_DESKTOP
    invoke    ExitProcess, 0

section '.idata' import data readable writeable
    library kernel32,       'KERNEL32.DLL',\
            errormsg,       'mydll.dll'
    import  kernel32,\
            SetLastError,   'SetLastError',\
            ExitProcess,    'ExitProcess'
    import  errormsg,\
            ShowLastError,  'ShowLastError33'
