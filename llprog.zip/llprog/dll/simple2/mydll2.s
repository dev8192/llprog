format PE console DLL
entry DllEntryPoint

include 'win32a.inc'

section '.code' code readable executable

proc DllEntryPoint hinstDLL, fdwReason, lpvReserved
    mov     eax, 1
    ret
endp

proc AddNumbers a, b
    mov     eax, [a]
    add     eax, [b]
    ret
endp

section '.edata' export data readable

    export 'mydll.dll',\
           AddNumbers, 'AddNumbers'

;section '.reloc' fixups data discardable
section '.reloc' fixups data readable discardable
