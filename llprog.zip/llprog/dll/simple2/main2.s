format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable

    szFmt db "Result from DLL: %d", 10, 0

section '.code' code readable executable

start:
    invoke  AddNumbers, 15, 27
    cinvoke printf, szFmt, eax

    invoke  ExitProcess, 0

section '.idata' import data readable

    library kernel32, 'kernel32.dll',\
            msvcrt, 'msvcrt.dll',\
            mydll, 'mydll.dll'

    import kernel32,\
           ExitProcess, 'ExitProcess'

    import msvcrt,\
           printf, 'printf'

    import mydll,\
           AddNumbers, 'AddNumbers'
