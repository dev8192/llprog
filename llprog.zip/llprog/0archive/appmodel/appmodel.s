format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    ; A package name from your StateRepository database to test
    package_name dw 'M','i','c','r','o','s','o','f','t','.','W','i','n','d','o','w','s','.','C','a','l','c','u','l','a','t','o','r','_',0
    
    buffer_size  dd 0
    info_buffer  dd ?
    package_info dd ?

section '.code' code readable executable
start:
    ; 1. Query the required buffer size from the system repository
    invoke OpenPackageInfoByFullName, package_name, 0, package_info
    test eax, eax
    jnz .error

    ; ... Process metadata from package_info here ...

.error:
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll', \
            appmodel, 'appmodel.dll'

    import kernel32, ExitProcess, 'ExitProcess'
    
    ; Built natively into Windows 10/11—no extra files required!
    import appmodel, \
           OpenPackageInfoByFullName, 'OpenPackageInfoByFullName'
