format PE GUI 4.0
entry start

include 'win32a.inc'

CELL_SIZE     equ 20
GRID_WIDTH    equ 20
GRID_HEIGHT   equ 20
IDT_TIMER     equ 100

section '.data' data readable writeable

    cls_name      db 'SnakeSafeClass',0
    win_title     db 'Snake Game: Safety Mode',0
    score_fmt     db 'Score: %d',0
    menu_msg      db 'SNAKE GAME - PRESS ENTER',0
    game_over_msg db 'GAME OVER',0
    try_again_msg db 'PRESS ENTER TO TRY AGAIN',0
    
    hWnd         dd 0
    gameState    dd 0
    score        dd 0
    direction    dd 3
    
    snakeX       dw 400 dup(0)
    snakeY       dw 400 dup(0)
    snakeLen     dd 3
    foodX        dw 0
    foodY        dw 0
    
    seed         dd ?
    wc           WNDCLASS
    msg          MSG
    ps           PAINTSTRUCT
    rect         RECT
    buf          db 64 dup(0)

section '.code' code readable executable

start:
    invoke GetModuleHandle, 0
    mov [wc.hInstance], eax
    mov [wc.lpfnWndProc], WindowProc
    mov [wc.hCursor], 0
    invoke LoadCursor, 0, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.hbrBackground], COLOR_WINDOW+1
    mov [wc.lpszClassName], cls_name
    invoke RegisterClass, wc
    
    invoke CreateWindowEx, 0, cls_name, win_title, \
           WS_VISIBLE or WS_OVERLAPPED or WS_CAPTION or WS_SYSMENU, \
           CW_USEDEFAULT, CW_USEDEFAULT, 425, 500, 0, 0, [wc.hInstance], 0
    mov [hWnd], eax
    
    invoke SetTimer, eax, IDT_TIMER, 150, 0

.msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    test eax, eax
    jz .exit
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp .msg_loop

.exit:
    invoke ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    push ebx esi edi
    mov eax, [wmsg]
    
    cmp eax, WM_PAINT
    je .paint
    cmp eax, WM_TIMER
    je .timer
    cmp eax, WM_KEYDOWN
    je .keydown
    cmp eax, WM_DESTROY
    je .destroy
    
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    jmp .finish

.timer:
    cmp [gameState], 1
    jne .finish
    call MoveLogic
    invoke InvalidateRect, [hwnd], 0, 1
    jmp .finish

.keydown:
    mov eax, [wparam]
    
    cmp [gameState], 1
    jne .check_enter

    cmp eax, VK_UP
    je .u
    cmp eax, VK_DOWN
    je .d
    cmp eax, VK_LEFT
    je .l
    cmp eax, VK_RIGHT
    je .r
    jmp .finish

.check_enter:
    cmp eax, VK_RETURN
    jne .finish
    call InitNewGame
    mov [gameState], 1
    jmp .finish

.u: 
    cmp [direction], 1 
    jne .su 
    jmp .finish
.su: 
    mov [direction], 0 
    jmp .finish
.d: 
    cmp [direction], 0 
    jne .sd 
    jmp .finish
.sd: 
    mov [direction], 1 
    jmp .finish
.l: 
    cmp [direction], 3 
    jne .sl 
    jmp .finish
.sl: 
    mov [direction], 2 
    jmp .finish
.r: 
    cmp [direction], 2 
    jne .sr 
    jmp .finish
.sr: 
    mov [direction], 3 
    jmp .finish

.paint:
    invoke BeginPaint, [hwnd], ps
    mov ebx, eax
    
    cmp [gameState], 0
    je .paint_menu
    
    cmp [gameState], 2
    je .paint_game_over
    
    invoke CreateSolidBrush, 0x0000FF
    push eax
    movzx ecx, [foodX]
    movzx edx, [foodY]
    call DrawRect
    pop eax
    invoke DeleteObject, eax
    
    invoke CreateSolidBrush, 0x00FF00
    push eax
    xor esi, esi
.slp:
    cmp esi, [snakeLen]
    jge .sdone
    movzx ecx, [snakeX + esi*2]
    movzx edx, [snakeY + esi*2]
    call DrawRect
    inc esi
    jmp .slp
.sdone:
    pop eax
    invoke DeleteObject, eax
    
    invoke wsprintf, buf, score_fmt, [score]
    invoke TextOut, ebx, 10, 420, buf, eax
    jmp .pe
    
.paint_menu:
    invoke TextOut, ebx, 100, 200, menu_msg, 24
    jmp .pe

.paint_game_over:
    invoke TextOut, ebx, 160, 170, game_over_msg, 9
    invoke TextOut, ebx, 100, 200, try_again_msg, 24
    
    invoke wsprintf, buf, score_fmt, [score]
    invoke TextOut, ebx, 170, 230, buf, eax
    jmp .pe
    
.pe:
    invoke EndPaint, [hwnd], ps
    jmp .finish

.destroy:
    invoke PostQuitMessage, 0

.finish:
    pop edi esi ebx
    ret
endp

InitNewGame:
    mov [snakeLen], 3
    mov [score], 0
    
    mov [snakeX], 10 
    mov [snakeY], 10
    
    mov [snakeX+2], 9 
    mov [snakeY+2], 10
    
    mov [snakeX+4], 8 
    mov [snakeY+4], 10
    
    mov [direction], 3
    call SpawnFood
    ret

SpawnFood:
    push eax
    push ecx
    push edx

    invoke GetTickCount
    mov [seed], eax
    and eax, 0xF
    mov [foodX], ax
    mov eax, [seed]
    shr eax, 4
    and eax, 0xF
    mov [foodY], ax

    pop edx
    pop ecx
    pop eax
    ret

MoveLogic:
    mov ecx, [snakeLen]
    dec ecx
.ml:
    test ecx, ecx
    jz .mh
    mov ax, [snakeX + ecx*2 - 2]
    mov [snakeX + ecx*2], ax
    mov ax, [snakeY + ecx*2 - 2]
    mov [snakeY + ecx*2], ax
    dec ecx
    jmp .ml
.mh:
    mov ax, [snakeX]
    mov dx, [snakeY]
    
    cmp [direction], 0 
    je .mu
    cmp [direction], 1 
    je .md
    cmp [direction], 2 
    je .ml_dir
    
    inc ax 
    jmp .mc
.mu: 
    dec dx 
    jmp .mc
.md: 
    inc dx 
    jmp .mc
.ml_dir: 
    dec ax
.mc:
    mov [snakeX], ax
    mov [snakeY], dx
    
    cmp ax, [foodX]
    jne .check_self_collision
    cmp dx, [foodY]
    jne .check_self_collision
    inc [score]
    inc [snakeLen]
    call SpawnFood

.check_self_collision:
    mov ecx, 1
.sc_loop:
    cmp ecx, [snakeLen]
    jge .check_bounds
    
    cmp ax, [snakeX + ecx*2]
    jne .sc_next
    cmp dx, [snakeY + ecx*2]
    je .die
    
.sc_next:
    inc ecx
    jmp .sc_loop

.check_bounds:
    cmp ax, 0 
    jl .die
    cmp ax, 20 
    jge .die
    cmp dx, 0 
    jl .die
    cmp dx, 20 
    jge .die
    ret

.die:
    mov [gameState], 2
    ret

DrawRect:
    imul ecx, CELL_SIZE
    imul edx, CELL_SIZE
    add ecx, 5 
    add edx, 5
    mov [rect.left], ecx
    mov [rect.top], edx
    add ecx, CELL_SIZE - 2
    add edx, CELL_SIZE - 2
    mov [rect.right], ecx
    mov [rect.bottom], edx
    invoke FillRect, ebx, rect, [esp+4]
    ret

section '.idata' import data readable writeable

library kernel32,'kernel32.dll',user32,'user32.dll',gdi32,'gdi32.dll'

import kernel32,GetModuleHandle,'GetModuleHandleA',ExitProcess,'ExitProcess',GetTickCount,'GetTickCount'

import user32,RegisterClass,'RegisterClassA',CreateWindowEx,'CreateWindowExA',DefWindowProc,'DefWindowProcA',\
              GetMessage,'GetMessageA',TranslateMessage,'TranslateMessage',DispatchMessage,'DispatchMessageA',\
              PostQuitMessage,'PostQuitMessage',LoadCursor,'LoadCursorA',SetTimer,'SetTimer',InvalidateRect,'InvalidateRect',\
              FillRect,'FillRect',BeginPaint,'BeginPaint',EndPaint,'EndPaint',wsprintf,'wsprintfA'

import gdi32,CreateSolidBrush,'CreateSolidBrush',DeleteObject,'DeleteObject',TextOut,'TextOutA'
