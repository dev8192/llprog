;format PE GUI
format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    _title db 'FASM Tetris - Score: 0',0
    _class db 'FASMTetris',0
    _msg_lost db 'GAME OVER! Start again?',0
    _score_fmt db 'FASM Tetris - Score: %d',0
    _title_buf db 64 dup(0)
    
    hInst dd ?
    hwnd  dd ?
    hBrushBlack dd ?
    hBrushGray  dd ?
    hBrushWhite dd ?

    gameArea db 200 dup(0)
    tickCount dd 0
    curX dd 3
    curY dd 0
    curType  dd 0
    curState dd 0
    gameRunning dd 1
    score dd 0
    
include 'figures.inc'

    wc WNDCLASS
    msg MSG
    ps  PAINTSTRUCT
    rect RECT

section '.text' code readable executable

start:
    invoke GetModuleHandle, 0
    mov [hInst], eax
    invoke CreateSolidBrush, 0x000000
    mov [hBrushBlack], eax
    invoke CreateSolidBrush, 0x808080
    mov [hBrushGray], eax
    invoke CreateSolidBrush, 0xFFFFFF
    mov [hBrushWhite], eax

    mov edi, wc
    mov ecx, sizeof.WNDCLASS
    xor al, al
    rep stosb

    mov [wc.lpfnWndProc], WindowProc
    mov eax, [hInst]
    mov [wc.hInstance], eax
    mov [wc.lpszClassName], _class
    invoke LoadCursor, 0, IDC_ARROW
    mov [wc.hCursor], eax
    
    invoke RegisterClass, wc
    invoke CreateWindowEx, 0, _class, _title,\
           WS_VISIBLE or WS_OVERLAPPED or WS_CAPTION or WS_SYSMENU,\
           CW_USEDEFAULT, CW_USEDEFAULT, 216, 439, 0, 0, [hInst], 0
    mov [hwnd], eax

    invoke SetTimer, [hwnd], 1, 16, 0
    call SpawnPiece

msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    cmp eax, 0
    jle exit_app
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp msg_loop

exit_app:
    invoke ExitProcess, [msg.wParam]

; --- PROCEDURES ---

; PROTECTED SCORE UPDATE: Saves everything before calling Windows
UpdateScoreTitle:
    pushad
    cinvoke wsprintf, _title_buf, _score_fmt, [score]
    invoke SetWindowText, [hwnd], _title_buf
    popad
    ret

SpawnPiece:
    invoke GetTickCount
    xor edx, edx
    mov ecx, 7
    div ecx
    mov [curType], edx
    mov [curState], 0
    mov [curX], 3
    mov [curY], 0
    push 0
    push 0
    call CheckCollision
    test eax, eax
    jnz .game_over
    ret
.game_over:
    mov [gameRunning], 0
    invoke MessageBox, [hwnd], _msg_lost, _title, MB_YESNO
    cmp eax, IDYES
    je .restart
    invoke PostQuitMessage, 0
    ret
.restart:
    mov edi, gameArea
    mov ecx, 200
    xor al, al
    rep stosb
    mov [score], 0
    call UpdateScoreTitle
    mov [gameRunning], 1
    call SpawnPiece
    ret

CheckCollision:
    push ebp
    mov ebp, esp
    push ebx ecx edx esi edi
    mov eax, [curType]
    shl eax, 6 
    mov ebx, [curState]
    shl ebx, 4
    add eax, ebx
    add eax, figures_data
    mov esi, eax
    xor ecx, ecx
.y: xor edx, edx
.x: mov eax, ecx
    shl eax, 2
    add eax, edx
    cmp byte [esi + eax], 0
    je .next
    mov eax, [curX]
    add eax, edx
    add eax, [ebp+12]
    cmp eax, 0
    jl .hit
    cmp eax, 10
    jge .hit
    mov ebx, [curY]
    add ebx, ecx
    add ebx, [ebp+8]
    cmp ebx, 0
    jl .next
    cmp ebx, 20
    jge .hit
    imul ebx, 10
    add ebx, eax
    cmp byte [gameArea + ebx], 0
    jne .hit
.next: inc edx
    cmp edx, 4
    jl .x
    inc ecx
    cmp ecx, 4
    jl .y
    xor eax, eax
    jmp .done
.hit: mov eax, 1
.done: pop edi esi edx ecx ebx
    pop ebp
    ret 8

LockPiece:
    mov eax, [curType]
    shl eax, 6
    mov ebx, [curState]
    shl ebx, 4
    add eax, ebx
    add eax, figures_data
    mov esi, eax
    xor ecx, ecx
.y: xor edx, edx
.x: mov eax, ecx
    shl eax, 2
    add eax, edx
    cmp byte [esi + eax], 0
    je .next
    mov eax, [curX]
    add eax, edx
    mov ebx, [curY]
    add ebx, ecx
    test ebx, ebx
    js .next
    imul ebx, 10
    add ebx, eax
    mov byte [gameArea + ebx], 1
.next: inc edx
    cmp edx, 4
    jl .x
    inc ecx
    cmp ecx, 4
    jl .y
    call ClearLines
    call SpawnPiece
    ret

; THE ATOMIC CLEARLINES: No Windows calls inside the loop
ClearLines:
    push ebp
    mov ebp, esp
    pushad
    
    mov ecx, 19
.row_loop:
    xor edx, edx
.col_loop:
    mov eax, ecx
    imul eax, 10
    add eax, edx
    cmp byte [gameArea + eax], 0
    je .next_row
    inc edx
    cmp edx, 10
    jl .col_loop

    add [score], 100
    mov ebx, ecx
.shift_loop:
    test ebx, ebx
    jz .clear_top
    mov edi, ebx
    imul edi, 10
    add edi, gameArea 
    mov esi, ebx
    dec esi
    imul esi, 10
    add esi, gameArea 
    xor eax, eax
.copy_row:
    mov dl, [esi + eax]
    mov [edi + eax], dl
    inc eax
    cmp eax, 10
    jl .copy_row
    dec ebx
    jmp .shift_loop
.clear_top:
    mov edi, gameArea
    mov eax, 10
.clear_loop:
    dec eax
    mov byte [edi + eax], 0
    jnz .clear_loop
    jmp .row_loop ; Re-check same index
.next_row:
    dec ecx
    jns .row_loop

    popad
    pop ebp
    ; Call UI update ONCE outside the heavy logic to prevent stack drift
    call UpdateScoreTitle
    ret

proc WindowProc uses ebx esi edi, hwnd, wmsg, wparam, lparam
    mov eax, [wmsg]
    cmp eax, WM_PAINT
    je .paint
    cmp eax, WM_TIMER
    je .timer
    cmp eax, WM_KEYDOWN
    je .keydown
    cmp eax, WM_DESTROY
    je .destroy
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret

.timer:
    cmp [gameRunning], 0
    je .finish
    inc [tickCount]
    mov eax, [curY]
    shr eax, 1
    mov ebx, 30
    sub ebx, eax
    cmp ebx, 5
    jge .check_tick
    mov ebx, 5
.check_tick:
    cmp [tickCount], ebx
    jl .finish
    mov [tickCount], 0
    push 0
    push 1
    call CheckCollision
    test eax, eax
    jnz .lock
    inc [curY]
    jmp .redraw
.lock:
    call LockPiece
.redraw:
    invoke InvalidateRect, [hwnd], 0, 0
.finish:
    xor eax, eax
    ret

.keydown:
    cmp [gameRunning], 0
    je .finish
    mov eax, [wparam]
    cmp eax, VK_LEFT
    je .left
    cmp eax, VK_RIGHT
    je .right
    cmp eax, VK_UP
    je .rotate
    cmp eax, VK_DOWN
    je .down
    jmp .finish
.left:
    push -1
    push 0
    call CheckCollision
    test eax, eax
    jnz .finish
    dec [curX]
    jmp .redraw
.right:
    push 1
    push 0
    call CheckCollision
    test eax, eax
    jnz .finish
    inc [curX]
    jmp .redraw
.down: push 0
    push 1
    call CheckCollision
    test eax, eax
    jnz .lock
    inc [curY]
    jmp .redraw
.rotate:
    mov ebx, [curState]
    inc [curState]
    and [curState], 3
    push 0
    push 0
    call CheckCollision
    test eax, eax
    jz .redraw
    mov [curState], ebx
    jmp .finish

.paint:
    invoke BeginPaint, [hwnd], ps
    mov edi, eax 
    invoke SetRect, rect, 0, 0, 200, 400
    invoke FillRect, edi, rect, [hBrushBlack]
    
    xor ecx, ecx
.py: xor edx, edx
.px: mov eax, ecx
    imul eax, 10
    add eax, edx
    cmp byte [gameArea + eax], 0
    je .pn
    mov eax, edx
    imul eax, 20
    mov [rect.left], eax
    add eax, 20
    mov [rect.right], eax
    mov eax, ecx
    imul eax, 20
    mov [rect.top], eax
    add eax, 20
    mov [rect.bottom], eax
    push ecx edx
    invoke FillRect, edi, rect, [hBrushGray]
    pop edx ecx
.pn: inc edx
    cmp edx, 10
    jl .px
    inc ecx
    cmp ecx, 20
    jl .py

    mov eax, [curType]
    shl eax, 6
    mov ebx, [curState]
    shl ebx, 4
    add eax, ebx
    add eax, figures_data
    mov esi, eax
    xor ecx, ecx
.fy: xor edx, edx
.fx: mov eax, ecx
    shl eax, 2
    add eax, edx
    cmp byte [esi + eax], 0
    je .fn
    mov eax, [curX]
    add eax, edx
    imul eax, 20
    mov [rect.left], eax
    add eax, 20
    mov [rect.right], eax
    mov eax, [curY]
    add eax, ecx
    imul eax, 20
    mov [rect.top], eax
    add eax, 20
    mov [rect.bottom], eax
    push ecx edx
    invoke FillRect, edi, rect, [hBrushWhite]
    pop edx ecx
.fn: inc edx
    cmp edx, 4
    jl .fx
    inc ecx
    cmp ecx, 4
    jl .fy

    invoke EndPaint, [hwnd], ps
    xor eax, eax
    ret

.destroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    ret
endp

section '.idata' import data readable
    library kernel32,           'KERNEL32.DLL',\
            user32,             'USER32.DLL',\
            gdi32,              'GDI32.DLL'
    import  kernel32,\
            ExitProcess,        'ExitProcess',\
            GetModuleHandle,    'GetModuleHandleA',\
            GetTickCount,       'GetTickCount'
    import  user32,\
            RegisterClass,      'RegisterClassA',\
            CreateWindowEx,     'CreateWindowExA',\
            MessageBox,         'MessageBoxA',\
            GetMessage,         'GetMessageA',\
            TranslateMessage,   'TranslateMessage',\
            DispatchMessage,    'DispatchMessageA',\
            DefWindowProc,      'DefWindowProcA',\
            PostQuitMessage,    'PostQuitMessage',\
            LoadCursor,         'LoadCursorA',\
            SetTimer,           'SetTimer',\
            InvalidateRect,     'InvalidateRect',\
            BeginPaint,         'BeginPaint',\
            EndPaint,           'EndPaint',\
            FillRect,           'FillRect',\
            SetRect,            'SetRect',\
            wsprintf,           'wsprintfA',\
            SetWindowText,      'SetWindowTextA'
    import  gdi32,\
            CreateSolidBrush,   'CreateSolidBrush'
