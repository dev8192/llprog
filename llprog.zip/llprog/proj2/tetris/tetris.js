function test() {
    // let [curType, curState] = [0, 1] // 0001_0000 16
    // let [curType, curState] = [0, 2] // 0010_0000 32
    // let [curType, curState] = [0, 3] // 0011_0000 48
    // let [curType, curState] = [1, 0] // 0100_0000 64
    curType <<= 6
    curState <<= 4
    const result = curType + curState
    console.log(result)
    console.log(result.toString(2))
}

test()
