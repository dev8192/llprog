format PE GUI 4.0
entry start

include 'win32a.inc'

CELL_SIZE equ 20     
FIELD_WIDTH equ 30   
FIELD_HEIGHT equ 16   
HEADER_HEIGHT equ 45
RAND_MULTIPLIER equ 214013
RAND_MULTIPLIER equ 2531011

section '.data' data readable writeable
    _class db 'Minesweeper',0
    _title db 'Minesweeper',0
    wc WNDCLASS
    msg MSG
    hwnd dd ?
    ps PAINTSTRUCT
    seed dd ?
    MINES_COUNT equ 99
    tmp_char db ?
    tmp_x dd ?
    tmp_y dd ?
    field rb FIELD_WIDTH * FIELD_HEIGHT
    EDGE_RAISED equ 5
    EDGE_SUNKEN equ 10
    BF_RECT     equ 15
    timer_id    dd ?
    TRANSPARENT equ 1
    WM_RBUTTONDOWN equ 0x0204
    game_status dd 0 ; 
    seconds     dd 0
    mines_left  dd MINES_COUNT
    is_timer_running db 0
    death_index dd -1    
    format_str db '%03d',0      
    buffer     rb 12            
    smiley_rect RECT
    rect RECT
    num_colors dd 0x000000, 0xFF0000, 0x008000, 0x0000FF, 0x800000, 0x000080, 0x808000, 0x000000, 0x808080
    _win_text db 'Congratulations! You have opened all the empty cells!', 0
    _win_title db 'Victory!', 0

section '.code' code readable executable
start:
    mov edi, wc
    mov ecx, sizeof.WNDCLASS
    xor eax, eax
    rep stosb
    invoke GetModuleHandle,0
    mov [wc.hInstance],eax
    mov [wc.style],CS_HREDRAW or CS_VREDRAW
    mov [wc.lpfnWndProc],WindowProc
    invoke LoadIcon,0,IDI_APPLICATION
    mov [wc.hIcon],eax
    invoke LoadCursor,0,IDC_ARROW
    mov [wc.hCursor],eax
    mov [wc.hbrBackground], 16
    mov [wc.lpszClassName],_class
    invoke RegisterClass,wc

    mov eax, CELL_SIZE
    imul eax, FIELD_WIDTH
    add eax, 16  
    
    mov ebx, CELL_SIZE
    imul ebx, FIELD_HEIGHT
    add ebx, 39 + HEADER_HEIGHT 

    invoke CreateWindowEx, 0, _class, _title,\
        WS_VISIBLE+WS_SYSMENU+WS_MINIMIZEBOX, 100, 100, eax, ebx, NULL, NULL, [wc.hInstance], NULL
    mov [hwnd],eax
    invoke SetTimer, [hwnd], 1, 1000, NULL
    mov [timer_id], eax
    invoke GetTickCount
    mov [seed], eax

    stdcall init_game


msg_loop:
    invoke GetMessage,msg,NULL,0,0
    cmp eax,1
    jb end_loop
    jne msg_loop
    invoke TranslateMessage,msg
    invoke DispatchMessage,msg
    jmp msg_loop

end_loop:
    invoke ExitProcess,[msg.wParam]

proc WindowProc uses ebx esi edi, hwnd, wmsg, wparam, lparam

    cmp [wmsg],WM_PAINT
    je .wm_paint
    cmp [wmsg],WM_LBUTTONDOWN
    je .wm_lbuttondown
    cmp [wmsg], WM_RBUTTONDOWN
    je .wm_rbutton
    cmp [wmsg],WM_DESTROY
    je .wm_destroy

    cmp [wmsg], WM_TIMER
    je .wm_timer

.defwndproc:
    invoke DefWindowProc,[hwnd],[wmsg],[wparam],[lparam]
    jmp .finish


.wm_paint:
    invoke BeginPaint,[hwnd],ps
    mov edi,eax 
    invoke SetBkMode, edi, TRANSPARENT

    mov [rect.left], 5
    mov [rect.top], 5
    mov eax, CELL_SIZE
    imul eax, FIELD_WIDTH
    add eax, 5
    mov [rect.right], eax
    mov [rect.bottom], HEADER_HEIGHT - 5
    invoke DrawEdge, edi, rect, EDGE_SUNKEN, BF_RECT

    invoke GetStockObject, LTGRAY_BRUSH
    invoke FillRect, edi, rect, eax

    mov eax, CELL_SIZE
    imul eax, FIELD_WIDTH
    shr eax, 1             
    sub eax, 13            
    mov [smiley_rect.left], eax
    add eax, 26
    mov [smiley_rect.right], eax
    mov [smiley_rect.top], 10
    mov [smiley_rect.bottom], 36
    invoke DrawEdge, edi, smiley_rect, EDGE_RAISED, BF_RECT

    invoke CreateSolidBrush, 0x00FFFF
    push eax
    mov eax, [smiley_rect.left]
    add eax, 2
    mov [rect.left], eax
    mov eax, [smiley_rect.top]
    add eax, 2
    mov [rect.top], eax
    mov eax, [smiley_rect.right]
    sub eax, 2
    mov [rect.right], eax
    mov eax, [smiley_rect.bottom]
    sub eax, 2
    mov [rect.bottom], eax
    pop eax

    invoke FillRect, edi, rect, eax
    invoke DeleteObject, eax
    invoke DrawEdge, edi, rect, EDGE_RAISED, BF_RECT
    invoke SetTextColor, edi, 0x0000FF
    invoke wsprintf, buffer, format_str, [mines_left]
    invoke TextOut, edi, 15, 15, buffer, 3
    invoke wsprintf, buffer, format_str, [seconds]
    mov eax, CELL_SIZE
    imul eax, FIELD_WIDTH
    sub eax, 45
    invoke TextOut, edi, eax, 15, buffer, 3
    xor ecx, ecx
    
.draw_cells:
    push ecx
    mov eax, ecx
    xor edx, edx
    mov ebx, FIELD_WIDTH
    div ebx 
    imul edx, CELL_SIZE
    imul eax, CELL_SIZE
    add eax, HEADER_HEIGHT 
    mov [rect.left], edx
    mov [rect.top], eax
    add edx, CELL_SIZE
    add eax, CELL_SIZE
    mov [rect.right], edx
    mov [rect.bottom], eax
    
    mov bl, [field + ecx]
    test bl, 32 
    jnz .is_open 
    invoke DrawEdge, edi, rect, EDGE_RAISED, BF_RECT
    test bl, 64
    jz .next_cell
    invoke SetTextColor, edi, 0x0000FF 
    mov [tmp_char], 'F'
    mov edx, [rect.left]
    add edx, 7
    mov eax, [rect.top]
    add eax, 2
    invoke TextOut, edi, edx, eax, tmp_char, 1
    jmp .next_cell
    
.is_open:
    invoke DrawEdge, edi, rect, EDGE_SUNKEN, BF_RECT 
    
    test bl, 16 
    jnz .draw_mine
    
    and ebx, 0Fh
    jz .next_cell 
    
    mov eax, [num_colors + ebx * 4]
    invoke SetTextColor, edi, eax
    add bl, '0'
    mov [tmp_char], bl

    mov edx, [rect.left]
    add edx, 7
    mov eax, [rect.top]
    add eax, 2
    invoke TextOut, edi, edx, eax, tmp_char, 1
    jmp .next_cell
    
.draw_mine:
    invoke DrawEdge, edi, rect, EDGE_SUNKEN, BF_RECT

    mov eax, [death_index]
    pop ecx
    push ecx
    cmp eax, ecx
    jne .just_mine
    
    invoke CreateSolidBrush, 0x0000FF
    invoke FillRect, edi, rect, eax
    invoke DeleteObject, eax

.just_mine:
    invoke SetTextColor, edi, 0 
    mov [tmp_char], '*'
    mov edx, [rect.left]
    add edx, 7
    mov eax, [rect.top]
    add eax, 2
    invoke TextOut, edi, edx, eax, tmp_char, 1
    jmp .next_cell
    
.next_cell:
    pop ecx
    inc ecx
    cmp ecx, FIELD_WIDTH * FIELD_HEIGHT
    jl .draw_cells

    invoke EndPaint,[hwnd],ps
    xor eax,eax
    jmp .finish

.wm_lbuttondown:
    mov eax, [lparam]
    movzx ebx, ax 
    shr eax, 16   
    cmp ebx, [smiley_rect.left]
    jl .check_field
    cmp ebx, [smiley_rect.right]
    jg .check_field
    cmp eax, [smiley_rect.top]
    jl .check_field
    cmp eax, [smiley_rect.bottom]
    jg .check_field
    stdcall restart_game 
    jmp .finish

.check_field:
    cmp [game_status], 0
    jne .finish
    mov eax, [lparam]
    movzx ebx, ax   
    shr eax, 16         
    sub eax, HEADER_HEIGHT 
    jl .finish             
    mov [is_timer_running], 1
    xor edx, edx
    mov ecx, CELL_SIZE
    div ecx
    imul eax, FIELD_WIDTH
    mov edi, eax          
    mov eax, ebx
    xor edx, edx
    div ecx               
    add edi, eax        
    
    test byte [field + edi], 64
    jnz .finish
    
    test byte [field + edi], 32
    jnz .finish

    test byte [field + edi], 16
    jnz .game_over
    stdcall open_cells, edi
    xor ecx, ecx
    xor edx, edx 

.win_scan_loop:
    test byte [field + ecx], 32 
    jnz .is_opened
    inc edx  

.is_opened:
    inc ecx
    cmp ecx, FIELD_WIDTH * FIELD_HEIGHT
    jl .win_scan_loop

    cmp edx, MINES_COUNT   
    jne .update_and_finish

    mov [game_status], 2
    mov [is_timer_running], 0
    invoke MessageBox, [hwnd], _win_text, _win_title, 0
    jmp .update_and_finish


.game_over:
    mov [game_status], 1
    mov [death_index], edi
    mov [is_timer_running], 0
    xor edx, edx
    
    
.reveal_loop:
    test byte [field + edx], 16
    jz .not_mine
    or byte [field + edx], 32
    
.not_mine:
    inc edx                   
    cmp edx, FIELD_WIDTH * FIELD_HEIGHT 
    jl .reveal_loop           
    invoke InvalidateRect, [hwnd], NULL, FALSE
    xor eax, eax
    jmp .finish

.update_and_finish:
    invoke InvalidateRect, [hwnd], NULL, FALSE
    xor eax, eax
    jmp .finish


.wm_rbutton:
    cmp [game_status], 0
    jne .finish
    mov eax, [lparam]
    and eax, 0FFFFh
    mov ecx, CELL_SIZE
    xor edx, edx
    div ecx
    mov ebx, eax     
    mov eax, [lparam]
    shr eax, 16
    sub eax, HEADER_HEIGHT 
    jl .finish           
    xor edx, edx
    div ecx          
    imul eax, FIELD_WIDTH
    add eax, ebx     
    test byte [field + eax], 32
    jnz .finish
    xor byte [field + eax], 64 
    test byte [field + eax], 64
    jnz .increment_mines
    inc [mines_left]           
    jmp .update_screen

.increment_mines:
    dec [mines_left]           

.update_screen:
    invoke InvalidateRect, [hwnd], 0, FALSE
    xor eax, eax
    jmp .finish

.wm_timer:
    cmp [game_status], 0 
    jne .finish
    cmp [is_timer_running], 1
    jne .finish
    inc [seconds]
    invoke InvalidateRect, [hwnd], NULL, FALSE
    jmp .finish
.wm_destroy:
    invoke PostQuitMessage,0
    xor eax,eax
.finish:
    ret
endp

proc init_game uses ebx esi edi
    local _base_x:DWORD, _base_y:DWORD
    mov ecx, FIELD_WIDTH * FIELD_HEIGHT
    mov al, 0
    mov edi, field
    rep stosb
    mov [mines_left], MINES_COUNT
    mov [seconds], 0
    mov ecx, MINES_COUNT

.place_mines:
    push ecx

.try_again:
    stdcall rand
    xor edx, edx
    mov ebx, FIELD_WIDTH * FIELD_HEIGHT
    div ebx
    test byte [field + edx], 16
    jnz .try_again
    or byte [field + edx], 16 
    mov eax, edx
    xor edx, edx
    mov ebx, FIELD_WIDTH
    div ebx
    mov [_base_y], eax
    mov [_base_x], edx
    mov edi, -1

.loop_y:
    mov ebx, -1

.loop_x:
    mov eax, [_base_y]
    add eax, edi 
    mov edx, [_base_x]
    add edx, ebx 
    cmp eax, 0
    jl .next_x
    cmp eax, FIELD_HEIGHT - 1
    jg .next_x
    cmp edx, 0
    jl .next_x
    cmp edx, FIELD_WIDTH - 1
    jg .next_x
    imul eax, FIELD_WIDTH
    add eax, edx
    test byte [field + eax], 16
    jnz .next_x
    inc byte [field + eax]

.next_x:
    inc ebx
    cmp ebx, 1
    jle .loop_x
    inc edi
    cmp edi, 1
    jle .loop_y
    pop ecx
    dec ecx
    jnz .place_mines
    ret
endp

proc restart_game
    mov [game_status], 0
    mov [death_index], -1
    mov [is_timer_running], 0
    stdcall init_game   
    invoke InvalidateRect, [hwnd], NULL, TRUE
    ret
endp

proc open_cells uses ebx esi edi, index
    local _cx:DWORD, _cy:DWORD
    mov esi, [index]
    test byte [field + esi], 32
    jnz .exit
    or byte [field + esi], 32
    mov al, [field + esi]
    and al, 0Fh
    jnz .exit 
    mov eax, esi
    xor edx, edx
    mov ebx, FIELD_WIDTH
    div ebx 
    mov [_cy], eax
    mov [_cx], edx
    mov edi, -1 

.loop_y:
    mov ebx, -1 
.loop_x:
    mov eax, [_cy]
    add eax, edi
    mov edx, [_cx]
    add edx, ebx
    cmp eax, 0
    jl .next_x
    cmp eax, FIELD_HEIGHT - 1
    jg .next_x
    cmp edx, 0
    jl .next_x
    cmp edx, FIELD_WIDTH - 1
    jg .next_x
    imul eax, FIELD_WIDTH
    add eax, edx
    stdcall open_cells, eax

.next_x:
    inc ebx
    cmp ebx, 1
    jle .loop_x
    inc edi
    cmp edi, 1
    jle .loop_y

.exit:
    ret
endp

proc rand
    mov eax, [seed]
    imul eax, RAND_MULTIPLIER
    add eax, RAND_MULTIPLIER
    mov [seed], eax
    shr eax, 16
    and eax, 7FFFh
    ret
endp

section '.idata' import data readable writeable
    library kernel,'KERNEL32.DLL',\
            user,'USER32.DLL',\
            gdi,'GDI32.DLL'

    import kernel,\
           GetModuleHandle,'GetModuleHandleA',\
           GetTickCount,'GetTickCount',\
           ExitProcess,'ExitProcess'

    import user,\
           RegisterClass,'RegisterClassA',\
           CreateWindowEx,'CreateWindowExA',\
           DefWindowProc,'DefWindowProcA',\
           GetMessage,'GetMessageA',\
           TranslateMessage,'TranslateMessage',\
           DispatchMessage,'DispatchMessageA',\
           LoadCursor,'LoadCursorA',\
           LoadIcon,'LoadIconA',\
           BeginPaint,'BeginPaint',\
           EndPaint,'EndPaint',\
           InvalidateRect,'InvalidateRect',\
           MessageBox,'MessageBoxA',\
           PostQuitMessage,'PostQuitMessage', \
           DrawEdge,'DrawEdge', \
           SetTimer,'SetTimer', \
           wsprintf,'wsprintfA', \
           FillRect,'FillRect'
  
    import gdi,\
           MoveToEx,'MoveToEx',\
           LineTo,'LineTo',\
           TextOut,'TextOutA', \
           SetTextColor,'SetTextColor', \
           SetBkMode,'SetBkMode', \
           CreateSolidBrush,'CreateSolidBrush', \
           DeleteObject,'DeleteObject', \
           GetStockObject,'GetStockObject'
