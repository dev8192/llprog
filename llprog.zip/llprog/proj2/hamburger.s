format PE console
entry start
 
include 'win32a.inc'
 
ID_HAMBURGER = 104
ID_MENU_ITEM1 = 105
ID_MENU_ITEM2 = 106
ID_MENU_ITEM3 = 107
 
section '.data' data readable writeable
    hwnd         dd ?
    hwndHamburger dd ?
    hwndMenu1    dd ?
    hwndMenu2    dd ?
    hwndMenu3    dd ?
    menuVisible  dd 0
    wc           WNDCLASS
    msg          MSG
    optionx  dd  70
    szClass      db 'HamburgerApp', 0
    szTitle      db 'Hamburger Button', 0
    szButton     db 'BUTTON', 0
    szHamburger  db '☰', 0
    szOption1    db 'Option 1', 0
    szOption2    db 'Option 2', 0
    szOption3    db 'Option 3', 0
    szResult     db 'You selected: ', 0
    szResultBuf  db 'You selected: Option 1', 0

    fmt_addr    db '%x', 10, 0
    msg1        db 'msg1', 10, 0
    rect_fmt     db "%x %x %x %x", 10, 0
 
section '.text' code readable executable
 
start:
    mov     [wc.style], CS_HREDRAW or CS_VREDRAW
    mov     [wc.lpfnWndProc], WindowProc
    invoke  GetModuleHandle, 0
    mov     [wc.hInstance], eax
    invoke  LoadIcon, 0, IDI_APPLICATION
    mov     [wc.hIcon], eax
    invoke  LoadCursor, 0, IDC_ARROW
    mov     [wc.hCursor], eax
    mov     [wc.hbrBackground], COLOR_WINDOW + 1
    mov     [wc.lpszClassName], szClass
    invoke  RegisterClass, wc
 
    invoke  CreateWindowEx, 0, szClass, szTitle, WS_VISIBLE or WS_OVERLAPPEDWINDOW, \
            CW_USEDEFAULT, CW_USEDEFAULT, 300, 250, 0, 0, [wc.hInstance], 0
    mov     [hwnd], eax
 
 
    invoke  CreateWindowEx, 0, szButton, szHamburger, \
            WS_VISIBLE or WS_CHILD or BS_PUSHBUTTON, \
            [optionx], 10, 50, 40, [hwnd], ID_HAMBURGER, [wc.hInstance], 0
    mov     [hwndHamburger], eax
 
 
    invoke  CreateWindowEx, 0, szButton, szOption1, \
            WS_CHILD or BS_PUSHBUTTON, \
            [optionx], 60, 120, 30, [hwnd], ID_MENU_ITEM1, [wc.hInstance], 0
    mov     [hwndMenu1], eax
 
    invoke  CreateWindowEx, 0, szButton, szOption2, \
            WS_CHILD or BS_PUSHBUTTON, \
            [optionx], 95, 120, 30, [hwnd], ID_MENU_ITEM2, [wc.hInstance], 0
    mov     [hwndMenu2], eax
 
    invoke  CreateWindowEx, 0, szButton, szOption3, \
            WS_CHILD or BS_PUSHBUTTON, \
            [optionx], 130, 120, 30, [hwnd], ID_MENU_ITEM3, [wc.hInstance], 0
    mov     [hwndMenu3], eax
 
msg_loop:
    invoke  GetMessage, msg, 0, 0, 0
    test    eax, eax
    jz      end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     msg_loop
 
end_loop:
    invoke  ExitProcess, [msg.wParam]
 
proc WindowProc hwnd, wmsg, wparam, lparam
    cmp     [wmsg], WM_COMMAND
    je      .wmcommand
    cmp     [wmsg], WM_DESTROY
    je      .wmdestroy
    cmp     [wmsg], WM_LBUTTONDOWN
    je      .wmlbuttondown
 
.defwndproc:
    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret
 
.wmcommand:
    mov     eax, [wparam]
    and     eax, 0FFFFh
    cmp     eax, ID_HAMBURGER
    je      .hamburger_click
    cmp     eax, ID_MENU_ITEM1
    je      .menu_item1
    cmp     eax, ID_MENU_ITEM2
    je      .menu_item2
    cmp     eax, ID_MENU_ITEM3
    je      .menu_item3
    jmp     .finish
 
.hamburger_click:
    cmp     [menuVisible], 0
    je      .show_menu
 
    invoke  ShowWindow, [hwndMenu1], SW_HIDE
    invoke  ShowWindow, [hwndMenu2], SW_HIDE
    invoke  ShowWindow, [hwndMenu3], SW_HIDE
    mov     [menuVisible], 0
    jmp     .finish
 
.show_menu:
 
    invoke  ShowWindow, [hwndMenu1], SW_SHOW
    invoke  ShowWindow, [hwndMenu2], SW_SHOW
    invoke  ShowWindow, [hwndMenu3], SW_SHOW
    mov     [menuVisible], 1
    jmp     .finish
 
.menu_item1:
 
    invoke  SetDlgItemText, [hwnd], ID_HAMBURGER, szOption1
    invoke  ShowWindow, [hwndMenu1], SW_HIDE
    invoke  ShowWindow, [hwndMenu2], SW_HIDE
    invoke  ShowWindow, [hwndMenu3], SW_HIDE
    mov     [menuVisible], 0
 
    invoke  SetWindowText, [hwnd], szOption1
    jmp     .finish
 
.menu_item2:
 
    invoke  SetDlgItemText, [hwnd], ID_HAMBURGER, szOption2
    invoke  ShowWindow, [hwndMenu1], SW_HIDE
    invoke  ShowWindow, [hwndMenu2], SW_HIDE
    invoke  ShowWindow, [hwndMenu3], SW_HIDE
    mov     [menuVisible], 0
 
    invoke  SetWindowText, [hwnd], szOption2
    jmp     .finish
 
.menu_item3:
 
    invoke  SetDlgItemText, [hwnd], ID_HAMBURGER, szOption3
    invoke  ShowWindow, [hwndMenu1], SW_HIDE
    invoke  ShowWindow, [hwndMenu2], SW_HIDE
    invoke  ShowWindow, [hwndMenu3], SW_HIDE
    mov     [menuVisible], 0
 
    invoke  SetWindowText, [hwnd], szOption3
    jmp     .finish
 
.wmlbuttondown:
    ;cinvoke printf, fmt_addr, .btnRect
    ;cinvoke printf, fmt_addr, .btnRect2
    ;mov dword [.btnRect2], 0xABCD
 
    cmp     [menuVisible], 1
    jne     .finish
    cinvoke printf, msg1
 
    mov     eax, [lparam]
    movzx   ecx, ax              ; x
    shr     eax, 16              ; y
    
    cinvoke printf, rect_fmt, [.btnRect.left], [.btnRect.top], [.btnRect.right], [.btnRect.bottom]
    invoke  GetWindowRect, [hwndHamburger], .btnRect
    cinvoke printf, rect_fmt, [.btnRect.left], [.btnRect.top], [.btnRect.right], [.btnRect.bottom]

    cmp     ecx, [.btnRect.left]
    jl      .hide_menu
    cmp     ecx, [.btnRect.right]
    jg      .hide_menu
    cmp     eax, [.btnRect.top]
    jl      .hide_menu
    cmp     eax, [.btnRect.bottom]
    jg      .hide_menu
    
    ;cinvoke printf, fmt_addr, .btnRect
    ;mov     dword [.btnRect], 0xabcd
    ;cinvoke printf, fmt_addr, .btnRect
    
    jmp     .finish
 
.hide_menu:
    invoke  ShowWindow, [hwndMenu1], SW_HIDE
    invoke  ShowWindow, [hwndMenu2], SW_HIDE
    invoke  ShowWindow, [hwndMenu3], SW_HIDE
    mov     [menuVisible], 0
    jmp     .finish
 
.wmdestroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
    ret
 
.finish:
    xor     eax, eax
    ret
 
.btnRect RECT
.btnRect2 RECT
endp
 
section '.idata' import data readable writeable
 
    library kernel32, 'KERNEL32.DLL',\
            user32, 'USER32.DLL',\
            msvcrt, 'MSVCRT.DLL'
 
    import kernel32,\
        ExitProcess, 'ExitProcess',\
        GetModuleHandle, 'GetModuleHandleA'
 
    import user32,\
        CreateWindowEx, 'CreateWindowExA',\
        DefWindowProc, 'DefWindowProcA',\
        DispatchMessage, 'DispatchMessageA',\
        GetMessage, 'GetMessageA',\
        GetWindowRect, 'GetWindowRect',\
        LoadCursor, 'LoadCursorA',\
        LoadIcon, 'LoadIconA',\
        PostQuitMessage, 'PostQuitMessage',\
        RegisterClass, 'RegisterClassA',\
        SetDlgItemText, 'SetDlgItemTextA',\
        SetWindowText, 'SetWindowTextA',\
        ShowWindow, 'ShowWindow',\
        TranslateMessage, 'TranslateMessage'

    import msvcrt,\
        printf, 'printf'
