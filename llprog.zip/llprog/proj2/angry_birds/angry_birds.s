format PE GUI 4.0
entry start

include "C:\fasm\INCLUDE\WIN32A.INC"

section '.data' data readable writeable
    _class TCHAR 'AB_Infinite_V17',0
    _title TCHAR 'FASM Angry Birds - True Tower Edition',0
    msg MSG
    wc WNDCLASS
    ps PAINTSTRUCT
    rect RECT
   
    hwnd_global dd ?
    rand_seed dd ?
    score dd 0
    birds_left dd 3
    level_count dd 1
   
    grid_w dd ?
    grid_h dd ?
    current_cell_x dd ?
   
    score_str rb 64
    birds_str rb 64
    lvl_str   rb 64
    win_title db 'Target Neutralized!',0
    win_msg   db 'Level %d cleared. The fortress grows...',0
    win_fmt   rb 128
   
    score_fmt db 'SCORE: %d',0
    birds_fmt db 'BIRDS: %d',0
    lvl_fmt   db 'LEVEL: %d',0

    sling_x dd 120
    sling_y dd 330
    drag_x  dd 120
    drag_y  dd 330
   
    max_active_birds = 15
    b_x  dd max_active_birds dup(0)
    b_y  dd max_active_birds dup(0)
    b_vx dd max_active_birds dup(0)
    b_vy dd max_active_birds dup(0)
    b_active dd max_active_birds dup(0)

    is_dragging dd 0
    max_radius dd 140.0  
    v_dx dd ?
    v_dy dd ?
    v_dist dd ?
   
    max_pigs = 5
    pig_x dd max_pigs dup(0)
    pig_y dd max_pigs dup(0)
    pig_alive db max_pigs dup(0)
    active_pigs_count dd 0
   
    struct_max = 300
    struct_x dd struct_max dup(0)
    struct_y dd struct_max dup(0)
    struct_w dd struct_max dup(0)
    struct_h dd struct_max dup(0)
    struct_active db struct_max dup(0)

    hBrushSky dd ?
    hBrushGround dd ?
    hBrushBird dd ?
    hBrushPig dd ?
    hBrushWood dd ?
    hBrushSling dd ?
   
    hdc_mem dd ?
    hbm_mem dd ?
    hbm_old dd ?

section '.text' code readable executable

proc rand_gen
    mov eax, [rand_seed]
    xor eax, 0x55555555
    imul eax, 214013
    add eax, 2531011
    mov [rand_seed], eax
    shr eax, 16
    and eax, 0x7FFF
    ret
endp

proc add_struct px, py, pw, ph, idx
    mov ebx, [idx]
    cmp ebx, struct_max
    jge .done
    shl ebx, 2
    mov eax, [px]
    mov [struct_x + ebx], eax
    mov eax, [py]
    mov [struct_y + ebx], eax
    mov eax, [pw]
    mov [struct_w + ebx], eax
    mov eax, [ph]
    mov [struct_h + ebx], eax
    mov ebx, [idx]
    mov [struct_active + ebx], 1
.done:
    ret
endp

proc reset_level
    mov ecx, struct_max
    mov edi, struct_active
    xor al, al
    rep stosb
   
    invoke GetTickCount
    add [rand_seed], eax
   
    mov [grid_w], 3

    mov eax, [level_count]
    cmp eax, 4
    jle .set_h
    mov eax, 4
.set_h:
    mov [grid_h], eax

    mov eax, [level_count]
    shr eax, 1
    add eax, 1
    cmp eax, max_pigs
    jle .set_p
    mov eax, max_pigs
.set_p:
    mov [active_pigs_count], eax

    mov ecx, max_pigs
    mov edi, pig_alive
    xor al, al
    rep stosb

    mov edi, 0
.pig_loop:
    cmp edi, [active_pigs_count]
    jge .pigs_done
   
    stdcall rand_gen
    xor edx, edx
    div [grid_w]
    mov ebx, edx
   
    stdcall rand_gen
    xor edx, edx
    div [grid_h]
    mov esi, edx
   
    mov eax, [grid_w]
    imul eax, 100
    mov ecx, 750
    sub ecx, eax
    mov eax, ebx
    imul eax, 100
    add eax, ecx
    add eax, 35
    mov [pig_x + edi*4], eax
   
    mov eax, esi
    imul eax, 90
    mov ecx, 450
    sub ecx, eax
    sub ecx, 30
    mov [pig_y + edi*4], ecx
   
    mov byte [pig_alive + edi], 1
    inc edi
    jmp .pig_loop
.pigs_done:

    mov esi, 0      
    mov edi, 0      
.col_loop:
    mov ebx, 0      
.row_loop:
    mov eax, [grid_w]
    imul eax, 100
    mov ecx, 750
    sub ecx, eax
    mov eax, edi
    imul eax, 100
    add eax, ecx
    mov [current_cell_x], eax
   
    mov eax, ebx
    imul eax, 90
    mov ecx, 450
    sub ecx, eax    
   
    mov edx, ecx
    sub edx, 80
    stdcall add_struct, [current_cell_x], edx, 10, 80, esi
    inc esi
   
    mov eax, [current_cell_x]
    add eax, 90
    stdcall add_struct, eax, edx, 10, 80, esi
    inc esi
   
    mov edx, ecx
    sub edx, 90
    stdcall add_struct, [current_cell_x], edx, 100, 10, esi
    inc esi
   
    inc ebx
    cmp ebx, [grid_h]
    jl .row_loop
    inc edi
    cmp edi, [grid_w]
    jl .col_loop

    mov eax, [level_count]
    xor edx, edx
    mov ecx, 3
    div ecx
    add eax, 3
    cmp eax, max_active_birds
    jle .apply_b
    mov eax, max_active_birds
.apply_b:
    mov [birds_left], eax

    mov ecx, max_active_birds
    xor eax, eax
    mov edi, b_active
    rep stosd
    mov [is_dragging], 0
    ret
endp

proc draw_rect hdc, rx, ry, rw, rh, rbrush
    mov eax, [rx]
    mov [rect.left], eax
    add eax, [rw]
    mov [rect.right], eax
    mov eax, [ry]
    mov [rect.top], eax
    add eax, [rh]
    mov [rect.bottom], eax
    invoke FillRect, [hdc], rect, [rbrush]
    ret
endp

start:
    invoke GetTickCount
    mov [rand_seed], eax
    invoke GetModuleHandle,0
    mov [wc.hInstance],eax
    mov [wc.lpfnWndProc],WindowProc
    mov [wc.hbrBackground],0
    mov [wc.lpszClassName],_class
    invoke LoadCursor,0,IDC_ARROW
    mov [wc.hCursor],eax
    invoke RegisterClass,wc
   
    invoke CreateWindowEx,0,_class,_title, \
           WS_OVERLAPPEDWINDOW or WS_VISIBLE, \
           100,100,800,600,0,0,[wc.hInstance],0
           
    invoke SetTimer, [hwnd_global], 1, 16, 0

msg_loop:
    invoke GetMessage,msg,0,0,0
    test eax, eax
    jz end_loop
    invoke TranslateMessage,msg
    invoke DispatchMessage,msg
    jmp msg_loop

end_loop:
    invoke ExitProcess,[msg.wParam]

proc WindowProc hwnd_p,wmsg,wparam,lparam
    cmp [wmsg],WM_CREATE
    je .wmcreate
    cmp [wmsg],WM_PAINT
    je .wmpaint
    cmp [wmsg],WM_ERASEBKGND
    je .wmerase
    cmp [wmsg],WM_TIMER
    je .wmtimer
    cmp [wmsg],WM_KEYDOWN
    je .wmkeydown
    cmp [wmsg],WM_LBUTTONDOWN
    je .wmlbuttondown
    cmp [wmsg],WM_MOUSEMOVE
    je .wmmousemove
    cmp [wmsg],WM_LBUTTONUP
    je .wmlbuttonup
    cmp [wmsg],WM_DESTROY
    je .wmdestroy
    invoke DefWindowProc,[hwnd_p],[wmsg],[wparam],[lparam]
    ret

.wmcreate:
    mov eax, [hwnd_p]
    mov [hwnd_global], eax
    invoke CreateSolidBrush, 0x00FFEECC
    mov [hBrushSky], eax
    invoke CreateSolidBrush, 0x0044AA44
    mov [hBrushGround], eax
    invoke CreateSolidBrush, 0x000000EE
    mov [hBrushBird], eax
    invoke CreateSolidBrush, 0x0000EE00
    mov [hBrushPig], eax
    invoke CreateSolidBrush, 0x00335577
    mov [hBrushWood], eax
    invoke CreateSolidBrush, 0x00112233
    mov [hBrushSling], eax
   
    invoke GetDC, [hwnd_p]
    mov ebx, eax
    invoke CreateCompatibleDC, ebx
    mov [hdc_mem], eax
    invoke CreateCompatibleBitmap, ebx, 800, 600
    mov [hbm_mem], eax
    invoke SelectObject, [hdc_mem], [hbm_mem]
    mov [hbm_old], eax
    invoke ReleaseDC, [hwnd_p], ebx
   
    stdcall reset_level
    xor eax,eax
    ret

.wmerase:
    mov eax, 1
    ret

.wmkeydown:
    cmp [wparam], 'R'
    jne .k_done
    stdcall reset_level
.k_done:
    ret

.wmpaint:
    invoke BeginPaint,[hwnd_p],ps
    mov edi, [hdc_mem]
   
    stdcall draw_rect, edi, 0, 0, 800, 450, [hBrushSky]
    stdcall draw_rect, edi, 0, 450, 800, 150, [hBrushGround]
   
    stdcall draw_rect, edi, 110, 350, 20, 100, [hBrushSling]
    stdcall draw_rect, edi, 95,  300, 15, 60, [hBrushSling]
    stdcall draw_rect, edi, 130, 300, 15, 60, [hBrushSling]
   
    mov ecx, 0
.draw_birds:
    push ecx
    cmp dword [b_active + ecx*4], 1
    jne .next_b_draw
    stdcall draw_rect, edi, [b_x + ecx*4], [b_y + ecx*4], \
            20, 20, [hBrushBird]
.next_b_draw:
    pop ecx
    inc ecx
    cmp ecx, max_active_birds
    jl .draw_birds

    cmp [is_dragging], 1
    je .draw_drag
    cmp [birds_left], 0
    jle .skip_sling_bird
    stdcall draw_rect, edi, [sling_x], [sling_y], 20, 20, [hBrushBird]
    jmp .skip_sling_bird
.draw_drag:
    stdcall draw_rect, edi, [drag_x], [drag_y], 20, 20, [hBrushBird]
.skip_sling_bird:

    mov ecx, 0
.draw_s:
    push ecx
    cmp byte [struct_active + ecx], 1
    jne .next_s
    mov ebx, ecx
    shl ebx, 2
    stdcall draw_rect, edi, [struct_x + ebx], [struct_y + ebx], \
            [struct_w + ebx], [struct_h + ebx], [hBrushWood]
.next_s:
    pop ecx
    inc ecx
    cmp ecx, struct_max
    jl .draw_s

    mov ecx, 0
.draw_pigs:
    push ecx
    cmp byte [pig_alive + ecx], 1
    jne .next_p
    mov ebx, ecx
    shl ebx, 2
    stdcall draw_rect, edi, [pig_x + ebx], [pig_y + ebx], \
            30, 30, [hBrushPig]
.next_p:
    pop ecx
    inc ecx
    cmp ecx, max_pigs
    jl .draw_pigs

    invoke SetBkMode, edi, 1
    cinvoke wsprintf, score_str, score_fmt, [score]
    invoke TextOut, edi, 25, 25, score_str, 11
    cinvoke wsprintf, birds_str, birds_fmt, [birds_left]
    invoke TextOut, edi, 25, 45, birds_str, 10
    cinvoke wsprintf, lvl_str, lvl_fmt, [level_count]
    invoke TextOut, edi, 25, 65, lvl_str, 10
   
    invoke BitBlt, [ps.hdc], 0, 0, 800, 600, [hdc_mem], 0, 0, SRCCOPY
    invoke EndPaint,[hwnd_p],ps
    xor eax,eax
    ret

.wmlbuttondown:
    cmp [birds_left], 0
    jle .sd
    mov [is_dragging], 1
.sd:
    ret

.wmmousemove:
    cmp [is_dragging], 1
    jne .sm
    mov eax, [lparam]
    movzx ecx, ax
    shr eax, 16
    movzx edx, ax
    sub ecx, [sling_x]
    mov [v_dx], ecx
    sub edx, [sling_y]
    mov [v_dy], edx
    fild dword [v_dx]
    fmul st0, st0
    fild dword [v_dy]
    fmul st0, st0
    faddp
    fsqrt
    fstp dword [v_dist]
    fld dword [v_dist]
    fcomp dword [max_radius]
    fstsw ax
    sahf
    jbe .no_clamp
    fild dword [v_dx]
    fmul dword [max_radius]
    fdiv dword [v_dist]
    fistp dword [v_dx]
    fild dword [v_dy]
    fmul dword [max_radius]
    fdiv dword [v_dist]
    fistp dword [v_dy]
.no_clamp:
    mov eax, [sling_x]
    add eax, [v_dx]
    mov [drag_x], eax
    mov eax, [sling_y]
    add eax, [v_dy]
    mov [drag_y], eax
.sm:
    ret

.wmlbuttonup:
    cmp [is_dragging], 1
    jne .su
    mov [is_dragging], 0
    mov ecx, 0
.find_slot:
    cmp dword [b_active + ecx*4], 0
    je .found_slot
    inc ecx
    cmp ecx, max_active_birds
    jl .find_slot
    jmp .su
.found_slot:
    mov dword [b_active + ecx*4], 1
    mov eax, [drag_x]
    mov [b_x + ecx*4], eax
    mov eax, [drag_y]
    mov [b_y + ecx*4], eax
    mov eax, [sling_x]
    sub eax, [drag_x]
    sar eax, 2
    mov [b_vx + ecx*4], eax
    mov eax, [sling_y]
    sub eax, [drag_y]
    sar eax, 2
    mov [b_vy + ecx*4], eax
    dec [birds_left]
.su:
    ret

.wmtimer:
    cmp [active_pigs_count], 0
    je .start_bird_update
    mov edi, 0
.pg_loop:
    cmp byte [pig_alive + edi], 0
    je .pg_next
   
    mov eax, [pig_y + edi*4]
    add eax, 4
    mov [pig_y + edi*4], eax
   
    cmp eax, 420
    jl .pg_check_structs
    mov dword [pig_y + edi*4], 420
    jmp .pg_next

.pg_check_structs:
    mov ecx, 0
.pg_s_loop:
    cmp byte [struct_active + ecx], 1
    jne .pg_s_next
    mov ebx, ecx
    shl ebx, 2
   
    mov eax, [pig_x + edi*4]
    add eax, 25
    cmp eax, [struct_x + ebx]
    jle .pg_s_next
    mov eax, [pig_x + edi*4]
    add eax, 5
    mov edx, [struct_x + ebx]
    add edx, [struct_w + ebx]
    cmp eax, edx
    jge .pg_s_next
   
    mov eax, [pig_y + edi*4]
    add eax, 30
    cmp eax, [struct_y + ebx]
    jl .pg_s_next
   
    mov edx, [struct_y + ebx]
    add edx, [struct_h + ebx]
    mov eax, [pig_y + edi*4]
    cmp eax, edx
    jge .pg_s_next
   
    mov eax, [struct_y + ebx]
    sub eax, 30
    mov [pig_y + edi*4], eax
    jmp .pg_next
   
.pg_s_next:
    inc ecx
    cmp ecx, struct_max
    jl .pg_s_loop
   
.pg_next:
    inc edi
    cmp edi, max_pigs
    jl .pg_loop

.start_bird_update:
    mov esi, 0
.update_loop:
    cmp dword [b_active + esi*4], 0
    je .next_update
   
    add dword [b_vy + esi*4], 1
    mov eax, [b_vx + esi*4]
    add [b_x + esi*4], eax
    mov eax, [b_vy + esi*4]
    add [b_y + esi*4], eax
   
    cmp dword [b_y + esi*4], 430
    jl .c_struct
    mov dword [b_y + esi*4], 430
    neg dword [b_vy + esi*4]
    sar dword [b_vy + esi*4], 1
    sar dword [b_vx + esi*4], 1
    cmp dword [b_vx + esi*4], 0
    jne .c_struct
    mov dword [b_active + esi*4], 0

.c_struct:
    mov ecx, 0
.s_loop:
    cmp byte [struct_active + ecx], 1
    jne .s_next
    mov ebx, ecx
    shl ebx, 2
    mov eax, [b_x + esi*4]
    add eax, 10
    cmp eax, [struct_x + ebx]
    jl .s_next
    sub eax, 20
    mov edx, [struct_x + ebx]
    add edx, [struct_w + ebx]
    cmp eax, edx
    jg .s_next
    mov eax, [b_y + esi*4]
    add eax, 10
    cmp eax, [struct_y + ebx]
    jl .s_next
    sub eax, 20
    mov edx, [struct_y + ebx]
    add edx, [struct_h + ebx]
    cmp eax, edx
    jg .s_next
   
    mov byte [struct_active + ecx], 0
    add [score], 50
    neg dword [b_vx + esi*4]
.s_next:
    inc ecx
    cmp ecx, struct_max
    jl .s_loop

    cmp [active_pigs_count], 0
    je .check_bounds

    mov ecx, 0
.p_loop:
    cmp byte [pig_alive + ecx], 0
    je .p_next

    mov ebx, ecx
    shl ebx, 2
   
    mov eax, [b_x + esi*4]
    sub eax, [pig_x + ebx]
    jns @F
    neg eax
@@: cmp eax, 25
    jg .p_next
   
    mov eax, [b_y + esi*4]
    sub eax, [pig_y + ebx]
    jns @F
    neg eax
@@: cmp eax, 25
    jg .p_next
   
    mov byte [pig_alive + ecx], 0
    dec [active_pigs_count]
    add [score], 1000
   
    cmp [active_pigs_count], 0
    jne .p_next
   
    cinvoke wsprintf, win_fmt, win_msg, [level_count]
    invoke MessageBox, [hwnd_global], win_fmt, win_title, MB_OK
    inc [level_count]
    stdcall reset_level
    jmp .timer_exit

.p_next:
    inc ecx
    cmp ecx, max_pigs
    jl .p_loop

.check_bounds:
    cmp dword [b_x + esi*4], 850
    jg .kill_b
    cmp dword [b_x + esi*4], -50
    jl .kill_b
    jmp .next_update
.kill_b:
    mov dword [b_active + esi*4], 0
.next_update:
    inc esi
    cmp esi, max_active_birds
    jl .update_loop
.timer_exit:
    invoke InvalidateRect, [hwnd_global], 0, 0
    ret

.wmdestroy:
    invoke DeleteObject, [hbm_mem]
    invoke DeleteDC, [hdc_mem]
    invoke PostQuitMessage,0
    xor eax,eax
    ret
endp

section '.idata' import data readable writeable
    library kernel32,'KERNEL32.DLL', \
            user32,'USER32.DLL', \
            gdi32,'GDI32.DLL'

    import kernel32, \
           GetModuleHandle,'GetModuleHandleA', \
           GetTickCount,'GetTickCount', \
           ExitProcess,'ExitProcess'

    import user32, \
           RegisterClass,'RegisterClassA', \
           CreateWindowEx,'CreateWindowExA', \
           DefWindowProc,'DefWindowProcA', \
           GetMessage,'GetMessageA', \
           TranslateMessage,'TranslateMessage', \
           DispatchMessage,'DispatchMessageA', \
           LoadCursor,'LoadCursorA', \
           PostQuitMessage,'PostQuitMessage', \
           SetTimer,'SetTimer', \
           wsprintf,'wsprintfA', \
           FillRect,'FillRect', \
           BeginPaint,'BeginPaint', \
           EndPaint,'EndPaint', \
           InvalidateRect,'InvalidateRect', \
           GetDC,'GetDC', \
           ReleaseDC,'ReleaseDC', \
           MessageBox,'MessageBoxA'

    import gdi32, \
           CreateSolidBrush,'CreateSolidBrush', \
           TextOut,'TextOutA', \
           SetBkMode,'SetBkMode', \
           CreateCompatibleDC,'CreateCompatibleDC', \
           CreateCompatibleBitmap,'CreateCompatibleBitmap', \
           SelectObject,'SelectObject', \
           BitBlt,'BitBlt', \
           DeleteObject,'DeleteObject', \
           DeleteDC,'DeleteDC'
