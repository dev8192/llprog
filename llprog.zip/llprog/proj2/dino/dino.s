format PE GUI 4.0
entry start
 
include "C:\fasm\INCLUDE\WIN32A.INC"
 
section '.data' data readable writeable
  wndTitle db 'Dino via FASM GDI', 0
  clsName  db 'FASMDinoClass', 0
 
  wc WNDCLASSEX
  msg MSG
  hwnd dd ?
  ps PAINTSTRUCT
  rect RECT
  dRect RECT
  oRect RECT
 
  hdc dd ?
  memDC dd ?
  hbmMem dd ?
  hbmOld dd ?
  hBrush dd ?
 
  dino_y     dd 160
  dino_vel   dd 0
  gravity    dd 1
  is_jumping dd 0
  obst_x     dd 600
  is_game_over dd 0 
 
  score      dd 0
  score_fmt  db 'Score: %d', 0
  score_buf  rb 32
 
  txt_game_over db 'GAME OVER', 0
  txt_restart   db 'Press SPACE to restart', 0
 
section '.text' code readable executable
 
start:
    invoke GetModuleHandle, 0
    mov [wc.hInstance], eax
 
    mov [wc.cbSize], sizeof.WNDCLASSEX
    mov [wc.style], CS_HREDRAW or CS_VREDRAW
    mov [wc.lpfnWndProc], WindowProc
    mov [wc.cbClsExtra], 0
    mov [wc.cbWndExtra], 0
    invoke LoadCursor, 0, IDC_ARROW
    mov [wc.hCursor], eax
    invoke CreateSolidBrush, 0x00FFFFFF
    mov [wc.hbrBackground], eax
    mov [wc.lpszMenuName], 0
    mov [wc.lpszClassName], clsName
    invoke RegisterClassEx, wc
 
    invoke CreateWindowEx, 0, clsName, wndTitle, \
            WS_VISIBLE or WS_OVERLAPPEDWINDOW xor WS_THICKFRAME xor WS_MAXIMIZEBOX, \
            CW_USEDEFAULT, CW_USEDEFAULT, 600, 300, 0, 0, [wc.hInstance], 0
    mov [hwnd], eax
 
msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    test eax, eax
    jz end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp msg_loop
 
end_loop:
    invoke ExitProcess, [msg.wParam]
 
proc WindowProc hwnd, uMsg, wParam, lParam
    cmp [uMsg], WM_CREATE
    je .wm_create
    cmp [uMsg], WM_TIMER
    je .wm_timer
    cmp [uMsg], WM_KEYDOWN
    je .wm_keydown
    cmp [uMsg], WM_PAINT
    je .wm_paint
    cmp [uMsg], WM_DESTROY
    je .wm_destroy
 
  .def_proc:
    invoke DefWindowProc, [hwnd], [uMsg], [wParam], [lParam]
    ret
 
  .wm_create:
    invoke SetTimer, [hwnd], 1, 16, 0
    xor eax, eax
    ret
 
  .wm_keydown:
    cmp [wParam], VK_SPACE
    jne .ret_zero
 
    cmp [is_game_over], 1
    je .restart_game
 
    cmp [is_jumping], 0
    jne .ret_zero           
    mov [dino_vel], -16
    mov [is_jumping], 1
    jmp .ret_zero
 
  .restart_game:
    mov [is_game_over], 0
    mov [dino_y], 160
    mov [is_jumping], 0
    mov [dino_vel], 0
    mov [obst_x], 600
    mov [score], 0
    jmp .ret_zero
 
  .wm_timer:
    cmp [is_game_over], 1
    je .redraw
 
    inc [score]
    mov eax, [dino_vel]
    add [dino_y], eax
    mov eax, [gravity]
    add [dino_vel], eax
 
    cmp [dino_y], 160
    jle .move_obstacle
    mov [dino_y], 160
    mov [is_jumping], 0
    mov [dino_vel], 0
 
  .move_obstacle:
    mov eax, [score]
    mov ebx, 100
    xor edx, edx
    div ebx
    add eax, 8
 
    cmp eax, 20
    jle .speed_ok
    mov eax, 20
 
  .speed_ok:
    sub [obst_x], eax
 
    cmp [obst_x], -30
    jg .check_collision
    mov [obst_x], 600
 
  .check_collision:
    cmp [obst_x], 90
    jge .redraw
    cmp [obst_x], 30
    jle .redraw
 
    cmp [dino_y], 120
    jle .redraw
 
    mov [is_game_over], 1
 
  .redraw:
    invoke InvalidateRect, [hwnd], 0, 0
  .ret_zero:
    xor eax, eax
    ret
 
  .wm_paint:
    invoke BeginPaint, [hwnd], ps
    mov [hdc], eax
    invoke GetClientRect, [hwnd], rect
 
    invoke CreateCompatibleDC, [hdc]
    mov [memDC], eax
    invoke CreateCompatibleBitmap, [hdc], [rect.right], [rect.bottom]
    mov [hbmMem], eax
    invoke SelectObject, [memDC], [hbmMem]
    mov [hbmOld], eax
 
    cmp [is_game_over], 1
    je .game_over_draw
 
    invoke CreateSolidBrush, 0x00FFFFFF
    mov [hBrush], eax
    invoke FillRect, [memDC], rect, [hBrush]
    invoke DeleteObject, [hBrush]
 
    mov eax, [dino_y]
    mov [dRect.top], eax
    add eax, 40
    mov [dRect.bottom], eax
    mov [dRect.left], 50
    mov [dRect.right], 90
 
    invoke CreateSolidBrush, 0x00555555
    mov [hBrush], eax
    invoke FillRect, [memDC], dRect, [hBrush]
    invoke DeleteObject, [hBrush]
 
    mov eax, [obst_x]
    mov [oRect.left], eax
    add eax, 20
    mov [oRect.right], eax
    mov [oRect.top], 160
    mov [oRect.bottom], 200
 
    invoke CreateSolidBrush, 0x000000FF
    mov [hBrush], eax
    invoke FillRect, [memDC], oRect, [hBrush]
    invoke DeleteObject, [hBrush]
 
    mov [oRect.left], 0
    mov [oRect.right], 600
    mov [oRect.top], 200
    mov [oRect.bottom], 202
    invoke CreateSolidBrush, 0x00000000
    mov [hBrush], eax
    invoke FillRect, [memDC], oRect, [hBrush]
    invoke DeleteObject, [hBrush]
 
    cinvoke wsprintf, score_buf, score_fmt, [score]
    mov ebx, eax
    invoke SetBkMode, [memDC], 1
    invoke SetTextColor, [memDC], 0x00000000
    invoke TextOut, [memDC], 10, 10, score_buf, ebx
 
    jmp .blit_screen
 
  .game_over_draw:
    invoke CreateSolidBrush, 0x00000000
    mov [hBrush], eax
    invoke FillRect, [memDC], rect, [hBrush]
    invoke DeleteObject, [hBrush]
 
    invoke SetBkMode, [memDC], 1
    invoke SetTextColor, [memDC], 0x00FFFFFF
 
    cinvoke wsprintf, score_buf, score_fmt, [score]
    mov ebx, eax
    invoke TextOut, [memDC], 10, 10, score_buf, ebx
 
    invoke TextOut, [memDC], 220, 100, txt_game_over, 9
    invoke TextOut, [memDC], 190, 140, txt_restart, 22
    jmp .blit_screen
 
  .blit_screen:
    invoke BitBlt, [hdc], 0, 0, [rect.right], [rect.bottom], [memDC], 0, 0, SRCCOPY
 
    invoke SelectObject, [memDC], [hbmOld]
    invoke DeleteObject, [hbmMem]
    invoke DeleteDC, [memDC]
    invoke EndPaint, [hwnd], ps
    xor eax, eax
    ret
 
  .wm_destroy:
    invoke KillTimer, [hwnd], 1
    invoke PostQuitMessage, 0
    xor eax, eax
    ret
endp
 
 
section '.idata' import data readable
  library kernel32, 'kernel32.dll', \
          user32, 'user32.dll', \
          gdi32, 'gdi32.dll'
 
  import kernel32, \
         GetModuleHandle, 'GetModuleHandleA', \
         ExitProcess, 'ExitProcess'
 
  import user32, \
         RegisterClassEx, 'RegisterClassExA', \
         CreateWindowEx, 'CreateWindowExA', \
         GetMessage, 'GetMessageA', \
         TranslateMessage, 'TranslateMessage', \
         DispatchMessage, 'DispatchMessageA', \
         DefWindowProc, 'DefWindowProcA', \
         SetTimer, 'SetTimer', \
         KillTimer, 'KillTimer', \
         GetClientRect, 'GetClientRect', \
         InvalidateRect, 'InvalidateRect', \
         BeginPaint, 'BeginPaint', \
         EndPaint, 'EndPaint', \
         LoadCursor, 'LoadCursorA', \
         FillRect, 'FillRect', \
         PostQuitMessage, 'PostQuitMessage', \
         wsprintf, 'wsprintfA'
 
  import gdi32, \
         CreateSolidBrush, 'CreateSolidBrush', \
         CreateCompatibleDC, 'CreateCompatibleDC', \
         CreateCompatibleBitmap, 'CreateCompatibleBitmap', \
         SelectObject, 'SelectObject', \
         DeleteObject, 'DeleteObject', \
         DeleteDC, 'DeleteDC', \
         BitBlt, 'BitBlt', \
         TextOut, 'TextOutA', \
         SetBkMode, 'SetBkMode', \
         SetTextColor, 'SetTextColor'
