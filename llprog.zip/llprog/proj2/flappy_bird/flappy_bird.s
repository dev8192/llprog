format PE console
entry start

include 'win32a.inc'

window_w equ 400
window_h equ 500
bird_x   equ 50
bird_size equ 20
pipe_w   equ 50
pipe_gap equ 130

section '.data' data readable writeable
    _class db 'FlappyFasm',0
    _title db 'FASM Flappy Bird!',0
    wc WNDCLASS
    msg MSG
    
    gravity  dd 2
    jump_v   dd -15
    pipe_speed dd 8

    bird_y      dd 200
    bird_vy     dd 0
    pipe_x      dd 400
    pipe_gap_y  dd 150
    score       dd 0
    high_score  dd 0
    game_over   dd 0

    ps PAINTSTRUCT
    rect RECT
    draw_rect RECT

    hbrBackground dd ? 
    hbrBird       dd ? 
    hbrPipe       dd ? 

    _score_fmt      db 'Score: %d',0
    _high_score_fmt db 'Best: %d',0
    _game_over_msg  db 'GAME OVER! Press SPACE to restart.',0
    score_buf rb 64
    fmt             db '%d', 10, 0

section '.text' code readable executable
start:
    ;mov     [wc.style], CS_HREDRAW or CS_VREDRAW
    mov     [wc.lpfnWndProc], WindowProc
    ;mov     [wc.cbClsExtra], 0
    ;mov     [wc.cbWndExtra], 0
    invoke  GetModuleHandle, 0
    mov     [wc.hInstance], eax
    ;invoke  LoadIcon,0,IDI_APPLICATION
    ;mov     [wc.hIcon],eax
    invoke  LoadCursor,0,IDC_ARROW
    mov     [wc.hCursor],eax
    ;mov     [wc.hbrBackground],COLOR_WINDOW+1
    ;mov     [wc.lpszMenuName],0
    mov     [wc.lpszClassName],_class
    invoke  RegisterClass,wc

    invoke  CreateWindowEx,0,_class,_title,WS_VISIBLE+WS_SYSMENU,\
        CW_USEDEFAULT, CW_USEDEFAULT,window_w,window_h,NULL,NULL,[wc.hInstance],NULL

msg_loop:
    invoke  GetMessage, msg, NULL, 0, 0
    test    eax, eax
    jle     end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     msg_loop

end_loop:
    invoke  ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp     [wmsg],WM_CREATE
    je      .wmcreate
    cmp     [wmsg],WM_TIMER
    je      .wmtimer
    cmp     [wmsg],WM_KEYDOWN
    je      .wmkeydown
    cmp     [wmsg],WM_PAINT
    je      .wmpaint
    cmp     [wmsg],WM_DESTROY
    je      .wmdestroy

    invoke  DefWindowProc,[hwnd],[wmsg],[wparam],[lparam]
    ret

.wmcreate:
    invoke  CreateSolidBrush,0x00EBCE87 
    mov     [hbrBackground],eax
    invoke  CreateSolidBrush,0x0000FFFF 
    mov     [hbrBird],eax
    invoke  CreateSolidBrush,0x0000CC00 
    mov     [hbrPipe],eax
    invoke  SetTimer,[hwnd],1,33,NULL 
    xor     eax,eax
    ret

.wmkeydown:
    cmp     [wparam],VK_SPACE
    jne     .end_keydown
    cmp     [game_over],1
    je      .restart_game
    mov     eax,[jump_v]
    mov     [bird_vy],eax
    jmp     .end_keydown

.restart_game:
    mov     [game_over],0
    mov     [bird_y],200
    mov     [bird_vy],0
    mov     [pipe_x],window_w
    mov     [score],0
    jmp     .end_keydown

.end_keydown:
    xor     eax,eax
    ret

.wmtimer:
    cmp     [game_over],1
    je      .update_screen

    mov     eax,[gravity]
    add     [bird_vy],eax
    mov     eax,[bird_vy]
    add     [bird_y],eax
    mov     eax,[pipe_speed]
    sub     [pipe_x],eax

    cmp     [pipe_x],-pipe_w
    jg      .check_collisions
    mov     [pipe_x],window_w
    add     [score],1
    invoke  GetTickCount
    xor     edx,edx
    mov     ecx, 200
    div     ecx
    add     edx, 50
    mov     [pipe_gap_y],edx

.check_collisions:
    cmp     [bird_y],0
    jl      .set_game_over
    mov     eax,window_h
    sub     eax,60 
    cmp     [bird_y],eax
    jg      .set_game_over

    mov     eax,bird_x
    add     eax,bird_size
    cmp     eax,[pipe_x]
    jl      .update_screen
    mov     eax,bird_x
    mov     ecx,[pipe_x]
    add     ecx,pipe_w
    cmp     eax,ecx
    jg      .update_screen

    mov     eax,[bird_y]
    cmp     eax,[pipe_gap_y]
    jl      .set_game_over
    add     eax,bird_size
    mov     ecx,[pipe_gap_y]
    add     ecx,pipe_gap
    cmp     eax,ecx
    jg      .set_game_over
    jmp     .update_screen

.set_game_over:
    mov     [game_over],1
    mov     eax,[score]
    cmp     eax,[high_score]
    jle     .update_screen
    mov     [high_score],eax

.update_screen:
    invoke  InvalidateRect,[hwnd],NULL,TRUE
    xor     eax,eax
    ret

.wmpaint:
    invoke  BeginPaint,[hwnd],ps
    invoke  GetClientRect,[hwnd],rect
    invoke  FillRect,[ps.hdc],rect,[hbrBackground]

    ; Top Pipe
    mov     eax,[pipe_x]
    mov     [draw_rect.left],eax
    add     eax,pipe_w
    mov     [draw_rect.right],eax
    mov     [draw_rect.top],0
    mov     eax,[pipe_gap_y]
    mov     [draw_rect.bottom],eax
    invoke  FillRect,[ps.hdc],draw_rect,[hbrPipe]

    ; Bottom Pipe
    mov     eax,[pipe_gap_y]
    add     eax,pipe_gap
    mov     [draw_rect.top],eax
    mov     [draw_rect.bottom],window_h
    invoke  FillRect,[ps.hdc],draw_rect,[hbrPipe]

    ; Bird
    mov     eax,bird_x
    mov     [draw_rect.left],eax
    add     eax,bird_size
    mov     [draw_rect.right],eax
    mov     eax,[bird_y]
    mov     [draw_rect.top],eax
    add     eax,bird_size
    mov     [draw_rect.bottom],eax
    invoke  FillRect,[ps.hdc],draw_rect,[hbrBird]

    ; Current Score output
    invoke  SetBkMode,[ps.hdc],1
    invoke  wsprintfA,score_buf,_score_fmt,[score]
    invoke  lstrlenA,score_buf
    invoke  TextOut,[ps.hdc],10,10,score_buf,eax

    ; High Score output
    invoke  wsprintfA,score_buf,_high_score_fmt,[high_score]
    invoke  lstrlenA,score_buf
    invoke  TextOut,[ps.hdc],10,30,score_buf,eax

    cmp     [game_over],1
    jne     .finish_paint
    invoke  lstrlenA,_game_over_msg
    invoke  TextOut,[ps.hdc],70,200,_game_over_msg,eax

.finish_paint:
    invoke  EndPaint,[hwnd],ps
    xor     eax,eax
    ret

.wmdestroy:
    invoke  KillTimer,[hwnd],1
    invoke  DeleteObject,[hbrBackground]
    invoke  DeleteObject,[hbrBird]
    invoke  DeleteObject,[hbrPipe]
    invoke  PostQuitMessage,0
    xor     eax,eax
    ret
endp

section '.idata' import data readable writeable
    library kernel,'KERNEL32.DLL',\
            user,'USER32.DLL',\
            gdi,'GDI32.DLL',\
            msvcrt,'MSVCRT.DLL'

    import kernel,\
            GetModuleHandle,'GetModuleHandleA',\
            GetTickCount,'GetTickCount',\
            lstrlenA,'lstrlenA',\
            ExitProcess,'ExitProcess'

    import  user,\
            RegisterClass,'RegisterClassA',\
            CreateWindowEx,'CreateWindowExA',\
            DefWindowProc,'DefWindowProcA',\
            GetMessage,'GetMessageA',\
            TranslateMessage,'TranslateMessage',\
            DispatchMessage,'DispatchMessageA',\
            LoadCursor,'LoadCursorA',\
            LoadIcon,'LoadIconA',\
            PostQuitMessage,'PostQuitMessage',\
            SetTimer,'SetTimer',\
            KillTimer,'KillTimer',\
            BeginPaint,'BeginPaint',\
            EndPaint,'EndPaint',\
            GetClientRect,'GetClientRect',\
            InvalidateRect,'InvalidateRect',\
            FillRect,'FillRect',\
            wsprintfA,'wsprintfA'

    import gdi,\
            CreateSolidBrush,'CreateSolidBrush',\
            DeleteObject,'DeleteObject',\
            TextOut,'TextOutA',\
            SetBkMode,'SetBkMode'

    import msvcrt,\
            printf, 'printf'
