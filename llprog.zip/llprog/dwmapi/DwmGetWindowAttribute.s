format PE console
entry start

include 'win32a.inc'
include 'dwmapi.inc'

section '.data' data readable writeable
    fmt     db "%d %d %d %d", 10, 0
    calc_title db 'Calculator', 0
    hwnd dd 0
    rect RECT

section '.code' code readable executable

start:
    invoke  Sleep, 5000
    invoke DwmGetWindowAttribute, [hwnd], DWMWA_EXTENDED_FRAME_BOUNDS, rect, 16
    cinvoke printf, fmt, [rect.left], [rect.top], [rect.right], [rect.bottom]
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32,               'kernel32.dll',\
            dwmapi,                 'dwmapi.dll',\
            msvcrt,                 'msvcrt.dll'
    import  kernel32,\
            ExitProcess,            'ExitProcess',\
            Sleep,                  'Sleep'
    import  dwmapi,\
            DwmGetWindowAttribute,  'DwmGetWindowAttribute'
    import  msvcrt,\
            printf,                 'printf'
