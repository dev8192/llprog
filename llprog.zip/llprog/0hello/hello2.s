format PE console on
entry start

STD_OUTPUT_HANDLE equ -11

section '.text' code readable executable

start:
    push STD_OUTPUT_HANDLE
    call [GetStdHandle]
    mov  ebx, eax

    lea  ecx, [msg]
    push 0
    push bytes_written
    push msg_len
    push ecx
    push ebx
    call [WriteFile]

    push 0
    call [ExitProcess]

section '.data' data readable writeable
    msg db 'Hello, world!',13,10
    msg_len = $ - msg
    bytes_written dd 0

section '.idata' import data readable writeable
    library kernel32,'KERNEL32.DLL'
    import kernel32,\
        GetStdHandle,'GetStdHandle',\
        WriteFile,'WriteFile',\
        ExitProcess,'ExitProcess'
