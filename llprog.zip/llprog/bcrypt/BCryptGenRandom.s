format PE
entry start

include 'win32ax.inc'

BCRYPT_RNG_USE_ENTROPY_IN_BUFFER    = 1
BCRYPT_USE_SYSTEM_PREFERRED_RNG     = 2
LANG_ENGLISH_US = 0x0409

section '.data' data readable writeable
    fmt_success     db 'Success: %x', 10, 0
    fmt_err         db "Error %d (0x%X): '%s'", 10, 0
    buffer          rb 256
    fmt_x           db '0x%08X', 10, 0
    rand_val        dd 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc BCryptGenRandom_func, hAlgorithm, pbBuffer, cbBuffer, dwFlags
    invoke BCryptGenRandom, [hAlgorithm], [pbBuffer], [cbBuffer], [dwFlags]
    push    eax
    test    eax, eax
    jnz     .error
    cinvoke printf, fmt_success, eax
    jmp     .done
.error:
    invoke  FormatMessage,\
            FORMAT_MESSAGE_FROM_SYSTEM + FORMAT_MESSAGE_MAX_WIDTH_MASK,\
            0, eax, LANG_ENGLISH_US, buffer, 256, 0
    pop     eax
    cinvoke printf, fmt_err, eax, eax, buffer
.done:
    ret
endp

; -----------------------
; Basic example
; -----------------------
proc main1
    cinvoke puts, '*** main1 ***'
    stdcall BCryptGenRandom_func, 0, rand_val, 4, BCRYPT_USE_SYSTEM_PREFERRED_RNG
    cinvoke printf, fmt_x, [rand_val]
    ret
endp

; -----------------------
; fff
; -----------------------
proc main
    cinvoke puts, '*** main2 ***'
    stdcall BCryptGenRandom_func, 0, rand_val, 4, 0
    cinvoke printf, fmt_x, [rand_val]
    ret
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            msvcrt,             'msvcrt.dll',\
            bcrypt,             'bcrypt.dll'
    import  kernel32,\
            FormatMessage,      'FormatMessageA',\
            ExitProcess,        'ExitProcess'
    import  msvcrt,\
            printf,             'printf',\
            puts,               'puts'
    import  bcrypt,\
            BCryptGenRandom,    'BCryptGenRandom'
