format PE CONSOLE 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt db 'Random value: 0x%08X', 10, 0
    rand_val dd 0

BCRYPT_USE_SYSTEM_PREFERRED_RNG = 2
section '.text' code readable executable
start:
    invoke BCryptGenRandom,\
    0,\                                 ; hAlgorithm
    rand_val,\                          ; pbBuffer
    4,\                                 ; cbBuffer
    BCRYPT_USE_SYSTEM_PREFERRED_RNG     ; dwFlags
    
    cinvoke printf, fmt, [rand_val]
    
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            msvcrt, 'msvcrt.dll',\
            bcrypt, 'bcrypt.dll'

    import kernel32,\
           ExitProcess, 'ExitProcess'

    import msvcrt,\
           printf, 'printf'

    import bcrypt,\
           BCryptGenRandom, 'BCryptGenRandom'
