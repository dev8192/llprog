format PE CONSOLE 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    alg_id du 'SHA512', 0
    msg db 'The quick brown fox jumps over the lazy dog', 0
    msg_len = $ - msg - 1
    
    align 4
    hAlg dd 0
    hHash dd 0
    hash db 64 dup(0)
    
    fmt db '%02x', 0
    newline db 10, 0

section '.text' code readable executable
start:
    invoke BCryptOpenAlgorithmProvider, hAlg, alg_id, 0, 0
    invoke BCryptCreateHash, [hAlg], hHash, 0, 0, 0, 0, 0
    invoke BCryptHashData, [hHash], msg, msg_len, 0
    invoke BCryptFinishHash, [hHash], hash, 64, 0

    mov esi, hash
    mov ebx, 64

print_loop:
    movzx eax, byte [esi]
    cinvoke printf, fmt, eax
    inc esi
    dec ebx
    jnz print_loop

    cinvoke printf, newline

    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            msvcrt, 'msvcrt.dll',\
            bcrypt, 'bcrypt.dll'

    import kernel32,\
           ExitProcess, 'ExitProcess'

    import msvcrt,\
           printf, 'printf'

    import bcrypt,\
           BCryptOpenAlgorithmProvider, 'BCryptOpenAlgorithmProvider',\
           BCryptCreateHash, 'BCryptCreateHash',\
           BCryptHashData, 'BCryptHashData',\
           BCryptFinishHash, 'BCryptFinishHash'
