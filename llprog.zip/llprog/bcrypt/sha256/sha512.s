format PE
entry start

include 'win32ax.inc'

SHA512_SIZE = 64

section '.data' data readable writeable
    alg_id      du 'SHA512', 0
    msg         db 'The quick brown fox jumps over the lazy dog', 0
    msg_len     = $ - msg - 1
    expected_result     db '07e547d9586f6a73f73fbac0435ed769'
                        db '51218fb7d0c8d788a309d785436bbb64'
                        db '2e93a252a954f23912547d1e8a3b5ed6'
                        db 'e1bfd7097821233fa0538f3db854fee6', 0
    hAlg        dd 0
    hHash       dd 0
    hash        db SHA512_SIZE dup(0)
    fmt         db '%02x', 0
    newline     db 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc print_hex1 uses ebx esi, buf, buf_size
    mov esi, [buf]
    mov ebx, [buf_size]
.loop:
    movzx eax, byte [esi]
    cinvoke printf, fmt, eax
    inc esi
    dec ebx
    jnz .loop
    cinvoke printf, newline
    ret
endp

proc print_hex uses ebx esi, buf, buf_size
    local hex_output[129]:BYTE
    mov esi, [buf]
    mov ecx, 0
.loop:
    push ecx
    movzx eax, byte [esi + ecx]
    cinvoke wsprintf, hex_byte, fmt, eax
    cinvoke lstrcat, addr hex_output, hex_byte
    pop ecx
    inc ecx
    cmp ecx, [buf_size]
    jb .loop
    cinvoke printf, fmt_s, addr hex_output
    ret
endp

proc main
    cinvoke puts, '*** main1 ***'
    invoke BCryptOpenAlgorithmProvider, hAlg, alg_id, 0, 0
    invoke BCryptCreateHash, [hAlg], hHash, 0, 0, 0, 0, 0
    invoke BCryptHashData, [hHash], msg, msg_len, 0
    invoke BCryptFinishHash, [hHash], hash, SHA512_SIZE, 0
    stdcall print_hex, hash, SHA512_SIZE
    ret
endp

section '.idata' import data readable
    library kernel32,                       'kernel32.dll',\
            msvcrt,                         'msvcrt.dll',\
            bcrypt,                         'bcrypt.dll'
    import  kernel32,\
            ExitProcess,                    'ExitProcess'
    import  msvcrt,\
            printf,                         'printf',\
            puts,                           'puts'
    import  bcrypt,\
            BCryptOpenAlgorithmProvider,    'BCryptOpenAlgorithmProvider',\
            BCryptCreateHash,               'BCryptCreateHash',\
            BCryptHashData,                 'BCryptHashData',\
            BCryptFinishHash,               'BCryptFinishHash'
