format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_x       db '%02x', 0
    fmt_s       db '%s', 10, 0

include '../../util/print_bytes.data.inc'

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

include '../../util/print_bytes.text.inc'

proc main1
    cinvoke puts, '*** main1 ***'
    local hex_byte[3]:BYTE
    mov [hex_byte + 0], -1
    mov [hex_byte + 1], -1
    mov [hex_byte + 2], -1
    stdcall print_bytes, addr hex_byte, 3
    mov eax, 0x12
    cinvoke wsprintf, addr hex_byte, fmt_x, eax
    stdcall print_bytes, addr hex_byte, 3
    ret
endp

proc main uses edi
    cinvoke puts, '*** main2 ***'
    local hex_byte[3]:BYTE
    local hex_output[129]:BYTE
    lea edi, [hex_output]
    mov eax, -1
    mov ecx, 129
    repne stosb
    mov [hex_output], 0
    stdcall print_bytes, addr hex_output, 129
    mov eax, 0x12
    cinvoke wsprintf, addr hex_byte, fmt_x, eax
    invoke lstrcat, addr hex_output, addr hex_byte
    stdcall print_bytes, addr hex_output, 129
    invoke lstrcat, addr hex_output, addr hex_byte
    stdcall print_bytes, addr hex_output, 129
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            user32,         'user32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            lstrcat,        'lstrcatA',\
            ExitProcess,    'ExitProcess'
    import  user32,\
            wsprintf,       'wsprintfA'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
