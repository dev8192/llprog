format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_x           db '%x', 10, 0
    fmt_x_space     db '%x ', 0
    newline         db 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc to_hex1, num
    xor eax, eax
    mov edx, [num]
    cmp dl, 10
    sbb al, al
    and al, 0xF9
    add al, 0x41
    add al, dl
    ret
endp

proc to_hex2, num
    mov edx, [num]       ; Input value (0-15) into edx
    xor eax, eax         ; Clear eax completely

    cmp dl, 10           ; CF=1 if dl < 10; CF=0 if dl >= 10
    sbb al, al           ; al = 0xFF if dl < 10; al = 0x00 if dl >= 10
    
    ; --- The Branchless Magic Formula ---
    and al, 0x07         ; al = 0x07 if dl < 10; al = 0x00 if dl >= 10
    add al, 0x3A         ; al = 0x41 ('A') if dl < 10; al = 0x3A if dl >= 10
    add al, dl           ; Add our input value
    sub al, al           ; Wait, simpler math below:
    ret
endp

proc to_hex3, num
    mov eax, [num]       ; Load number (0-15)
    cmp al, 10           ; CF=1 if 0-9; CF=0 if 10-15
    sbb al, 0x69         ; al = 0x96 (if 0-9) or 0x97 (if 10-15) via borrow
    das                  ; Decimal Adjust after Subtraction (magic CPU instruction)
    and eax, 0x0F        ; Isolates the converted hex nibble character gap
    
    ; Adjust to final ASCII values
    add al, 0x40         ; Transforms perfectly to 0x30-0x39 and 0x41-0x46
    ret
endp

proc to_hex4, num
    mov edx, [num]       ; edx = input (0-15)
    xor eax, eax
    
    cmp dl, 10           ; CF=1 if < 10
    sbb al, al           ; al = 0xFF (if < 10) or 0x00 (if >= 10)
    
    ; Math: '0' is 0x30, 'A' is 0x41. Gap is 7 characters.
    and al, 4            ; al = 4 if < 10, 0 if >= 10
    add al, 0x3D         ; al = 0x41 ('A') or 0x3D
    add al, dl           ; Add the base number
    sub al, al           ; Simple adjustments:
    
    ; Let's bypass the math error completely with this standard 3-instruction alternative:
    ; al = (num < 10) ? (num + '0') : (num - 10 + 'A')
    mov eax, [num]
    cmp eax, 10
    sbb ecx, ecx         ; ecx = -1 if < 10, 0 if >= 10
    and ecx, -7          ; ecx = -7 if < 10, 0 if >= 10
    add eax, 0x41        ; Base is 'A' (0x41)
    add eax, ecx         ; Apply offset modifier (-7 converts 'A' base to '0' base)
    ret
endp

proc to_hex5, num
    mov eax, [num]
    cmp al, 10
    jl .is_digit
    add al, 'a' - 10 - '0'
.is_digit:
    add al, '0'
    ret
endp


proc main1
    cinvoke puts, '*** main1 ***'
    stdcall to_hex1, 15
    cinvoke printf, fmt_x, eax
    ret
endp

proc main uses ebx
    cinvoke puts, '*** main2 ***'
    xor ebx, ebx
.loop:
    stdcall to_hex5, ebx
    cinvoke printf, fmt_x_space, eax
    inc ebx
    cmp ebx, 16
    jb .loop
    cinvoke printf, newline
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
