format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
; 84c52d8e220808a9f1d5c282118e4767e0be8156d4d22ce65ce109dcbe97238e
    msg      db 'Hello SHA-256', 0
    msg_len = $ - msg - 1
    alg_id   du 'SHA256', 0
    fmt      db '%02x', 0
    hAlg     dd ?
    hHash    dd ?
    hash     rb 32

section '.text' code readable executable
start:
    invoke BCryptOpenAlgorithmProvider, hAlg, alg_id, 0, 0
    invoke BCryptCreateHash, [hAlg], hHash, 0, 0, 0, 0, 0
    invoke BCryptHashData, [hHash], msg, msg_len, 0
    invoke BCryptFinishHash, [hHash], hash, 32, 0

    mov esi, hash
    mov ecx, 32
show_loop:
    push ecx
    movzx eax, byte [esi]
    cinvoke printf, fmt, eax
    inc esi
    pop ecx
    loop show_loop

    invoke BCryptDestroyHash, [hHash]
    invoke BCryptCloseAlgorithmProvider, [hAlg], 0
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            msvcrt,   'msvcrt.dll',\
            bcrypt,   'bcrypt.dll'

    import kernel32, ExitProcess, 'ExitProcess'
    import msvcrt,   printf, 'printf'
    import bcrypt,\
           BCryptOpenAlgorithmProvider, 'BCryptOpenAlgorithmProvider',\
           BCryptCreateHash, 'BCryptCreateHash',\
           BCryptHashData, 'BCryptHashData',\
           BCryptFinishHash, 'BCryptFinishHash',\
           BCryptDestroyHash, 'BCryptDestroyHash',\
           BCryptCloseAlgorithmProvider, 'BCryptCloseAlgorithmProvider'
