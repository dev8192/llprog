format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    BCRYPT_OBJECT_LENGTH_NAMED    db 'ObjectLength',0
    BCRYPT_HASH_LENGTH_NAMED      db 'HashLength',0
    alg_id         db 'SHA512',0

    hAlg            dd ?
    hHash           dd ?
    
    cbHashObject    dd ?
    cbHash          dd ?
    pbHashObject    dd ?
    
    input_data      db 'Hello SHA512', 0
    input_len       =  $-input_data - 1
    
    ; Output digest buffers (SHA512 produces 64 bytes)
    hash_digest     db 64 dup(0)
    hex_output      db 129 dup(0)
    
    ; Formatting
    fmt             db '%02x', 0
    hex_byte        db 4 dup(0)
    caption         db 'SHA512 Result', 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    invoke BCryptOpenAlgorithmProvider, hAlg, alg_id, 0, 0
    test eax, eax
    jnz .exit

    invoke BCryptGetProperty, [hAlg], BCRYPT_OBJECT_LENGTH_NAMED, addr cbHashObject, 4, addr cbHash, 0
    
    invoke GetProcessHeap
    invoke HeapAlloc, eax, HEAP_ZERO_MEMORY, [cbHashObject]
    mov [pbHashObject], eax

    invoke BCryptCreateHash, [hAlg], hHash, [pbHashObject], [cbHashObject], 0, 0, 0
    test eax, eax
    jnz .cleanup_alg

    invoke BCryptHashData, [hHash], input_data, input_len, 0
    test eax, eax
    jnz .cleanup_hash

    invoke BCryptFinishHash, [hHash], hash_digest, 64, 0

    mov ecx, 0
.hex_loop:
    push ecx
    movzx eax, byte [hash_digest + ecx]
    cinvoke wsprintf, hex_byte, fmt, eax
    invoke lstrcat, hex_output, hex_byte
    pop ecx
    inc ecx
    cmp ecx, 64
    jb .hex_loop

    cinvoke printf, fmt_s, hex_output

.cleanup_hash:
    invoke BCryptDestroyHash, [hHash]
.cleanup_alg:
    invoke GetProcessHeap
    invoke HeapFree, eax, 0, [pbHashObject]
    invoke BCryptCloseAlgorithmProvider, [hAlg], 0
.exit:
    ret
endp

section '.idata' import data readable
    library kernel32, 'kernel32.dll', \
            user32,   'user32.dll', \
            bcrypt,   'bcrypt.dll'

    import kernel32, \
           ExitProcess, 'ExitProcess', \
           GetProcessHeap, 'GetProcessHeap', \
           HeapAlloc, 'HeapAlloc', \
           HeapFree, 'HeapFree', \
           lstrcat, 'lstrcatA'

    import user32, \
           MessageBox, 'MessageBoxA', \
           wsprintf, 'wsprintfA'

    import bcrypt, \
           BCryptOpenAlgorithmProvider, 'BCryptOpenAlgorithmProvider', \
           BCryptGetProperty, 'BCryptGetProperty', \
           BCryptCreateHash, 'BCryptCreateHash', \
           BCryptHashData, 'BCryptHashData', \
           BCryptFinishHash, 'BCryptFinishHash', \
           BCryptDestroyHash, 'BCryptDestroyHash', \
           BCryptCloseAlgorithmProvider, 'BCryptCloseAlgorithmProvider'
