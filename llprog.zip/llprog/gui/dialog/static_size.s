; not working
format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    h_brush dd NULL
    color_red = 000000FFh
    msg_text db 'Hello World!', 0

section '.code' code readable executable
start:
    invoke CreateSolidBrush, color_red
    mov [h_brush], eax
    invoke GetModuleHandle, NULL
    invoke DialogBoxParam, eax, 1, HWND_DESKTOP, DialogProc, NULL
    invoke DeleteObject, [h_brush]
    invoke ExitProcess, 0

proc DialogProc hwnd, wmsg, wparam, lparam
    cmp [wmsg], WM_INITDIALOG
    je .init
    cmp [wmsg], WM_CTLCOLORSTATIC
    je .color_static
    cmp [wmsg], WM_CLOSE
    je .close
    xor eax, eax
    ret
.init:
    sub esp, 8 ; SIZE structure {cx, cy}
    mov ebx, esp
    invoke GetDlgItem, [hwnd], -1
    mov esi, eax
    invoke GetDC, esi
    mov edi, eax
    invoke SendMessage, esi, WM_GETFONT, 0, 0
    invoke SelectObject, edi, eax
    invoke lstrlen, msg_text
    invoke GetTextExtentPoint32, edi, msg_text, eax, ebx
    invoke SetWindowPos, esi, NULL, 0, 0, [ebx], [ebx+4], SWP_NOMOVE + SWP_NOZORDER
    invoke ReleaseDC, esi, edi
    add esp, 8
    mov eax, TRUE
    ret
.color_static:
    invoke SetBkColor, [wparam], color_red
    mov eax, [h_brush]
    ret
.close:
    invoke EndDialog, [hwnd], 0
    mov eax, TRUE
    ret
endp

section '.res' resource data readable
    directory RT_DIALOG, dialogs
    resource dialogs, 1, LANG_NEUTRAL, hello

    dialog hello, 'Hello', 0, 0, 100, 40,\
        WS_CAPTION + WS_SYSMENU + WS_VISIBLE + DS_CENTER
        dialogitem 'STATIC', 'Hello World', -1,\
            0, 0, 80, 20, WS_VISIBLE
    enddialog

section '.idata' import data readable
    library kernel32, 'kernel32.dll', user32, 'user32.dll', gdi32, 'gdi32.dll'
    import kernel32, GetModuleHandle, 'GetModuleHandleA', ExitProcess, 'ExitProcess', lstrlen, 'lstrlenA'
    import user32, DialogBoxParam, 'DialogBoxParamA', EndDialog, 'EndDialog', GetDlgItem, 'GetDlgItem', \
                   GetDC, 'GetDC', ReleaseDC, 'ReleaseDC', SendMessage, 'SendMessageA', SetWindowPos, 'SetWindowPos'
    import gdi32, CreateSolidBrush, 'CreateSolidBrush', DeleteObject, 'DeleteObject', SetBkColor, 'SetBkColor', \
                  SelectObject, 'SelectObject', GetTextExtentPoint32, 'GetTextExtentPoint32A'
