format PE
entry start

include 'win32ax.inc'

IDD_MAIN equ 37

section '.text' code readable executable
start:
    cinvoke puts, 'start'
    invoke GetModuleHandle, NULL
    invoke DialogBoxParam, eax, IDD_MAIN, HWND_DESKTOP, DialogProc, NULL
    cinvoke puts, 'end'
    invoke ExitProcess, 0

proc DialogProc hwnd, wmsg, wparam, lparam
    cmp [wmsg], WM_CLOSE
    je .wm_close
    xor eax, eax
    ret
.wm_close:
    invoke EndDialog, [hwnd], 0
    mov eax, TRUE
    ret
endp

section '.res' resource data readable
    directory RT_DIALOG, dialogs
    resource dialogs, IDD_MAIN, LANG_NEUTRAL, hello

    dialog hello, 'Hello', 0, 0, 100, 40,\
        WS_CAPTION + WS_SYSMENU + WS_VISIBLE + DS_CENTER
        dialogitem 'STATIC', 'Hello World!', -1,\
            0, 0, 100, 40,\
            SS_CENTER + SS_CENTERIMAGE + WS_VISIBLE
    enddialog

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            user32,             'user32.dll',\
            msvcrt,             'msvcrt.dll'
    import  kernel32,\
            GetModuleHandle,    'GetModuleHandleA',\
            ExitProcess,        'ExitProcess'
    import  user32,\
            DialogBoxParam,     'DialogBoxParamA',\
            EndDialog,          'EndDialog'
    import  msvcrt,\
            puts,               'puts'
