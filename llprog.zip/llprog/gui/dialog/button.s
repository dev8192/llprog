format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    caption db 'Hello', 0
    text db 'Hello World!', 0

section '.text' code readable executable
start:
    invoke GetModuleHandle, NULL
    invoke DialogBoxParam, eax, 1, HWND_DESKTOP, DialogProc, NULL
    invoke ExitProcess, 0

proc DialogProc hwnd, wmsg, wparam, lparam
    cmp [wmsg], WM_INITDIALOG
    je .init
    cmp [wmsg], WM_COMMAND
    je .command
    cmp [wmsg], WM_CLOSE
    je .close
    xor eax, eax
    jmp .finish
.init:
    invoke SetWindowText, [hwnd], caption
    mov eax, TRUE
    jmp .finish
.command:
    cmp [wparam], IDCANCEL
    je .close
    xor eax, eax
    jmp .finish
.close:
    invoke EndDialog, [hwnd], 0
    mov eax, TRUE
.finish:
    ret
endp

section '.res' resource data readable
    directory RT_DIALOG, dialogs
    resource dialogs,\
        1, LANG_ENGLISH + SUBLANG_DEFAULT, hello_dialog
    dialog hello_dialog, 'Hello World', 0, 0, 150, 50, \
        WS_CAPTION + WS_POPUP + WS_SYSMENU + DS_MODALFRAME + DS_CENTER
        dialogitem 'STATIC', 'Hello World!', -1,\
            10, 10, 130, 10, SS_CENTER + WS_VISIBLE
        dialogitem 'BUTTON', 'Close', IDCANCEL,\
            50, 30, 50, 14, WS_VISIBLE + BS_PUSHBUTTON
    enddialog

section '.idata' import data readable
    library kernel32, 'kernel32.dll', \
            user32, 'user32.dll'
    import kernel32, \
           GetModuleHandle, 'GetModuleHandleA', \
           ExitProcess, 'ExitProcess'
    import user32, \
           DialogBoxParam, 'DialogBoxParamA', \
           EndDialog, 'EndDialog', \
           SetWindowText, 'SetWindowTextA'
