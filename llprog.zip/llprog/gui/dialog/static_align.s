format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    h_brush dd NULL
    color_red = 000000FFh
    color_green = 0000FF00h
    color_blue = 00FF0000h

section '.text' code readable executable
start:
    invoke CreateSolidBrush, color_blue
    mov [h_brush], eax
    invoke GetModuleHandle, NULL
    invoke DialogBoxParam, eax, 1, HWND_DESKTOP, DialogProc, NULL
    invoke DeleteObject, [h_brush]
    invoke ExitProcess, 0

proc DialogProc hwnd, wmsg, wparam, lparam
    cmp [wmsg], WM_CTLCOLORSTATIC
    je .color_static
    cmp [wmsg], WM_CLOSE
    je .close
    xor eax, eax
    ret
.color_static:
    invoke SetTextColor, [wparam], color_red
    invoke SetBkColor, [wparam], color_green
    mov eax, [h_brush]
    ret
.close:
    invoke EndDialog, [hwnd], 0
    mov eax, TRUE
    ret
endp

section '.res' resource data readable
    directory RT_DIALOG, dialogs
    resource dialogs, 1, LANG_NEUTRAL, hello

    dialog hello, 'Hello', 0, 0, 200, 400,\
        WS_CAPTION + WS_SYSMENU + WS_VISIBLE + DS_CENTER

; TODO: What about a loop?
        STATIC_H = 20
        STATIC_GAP = 10
        STATIC_STEP = STATIC_GAP + STATIC_H
        STATIC_Y = STATIC_GAP
        dialogitem 'STATIC', 'default', -1,\
            10, STATIC_Y, 150, STATIC_H,\
            WS_VISIBLE
        STATIC_Y = STATIC_Y + STATIC_STEP
        dialogitem 'STATIC', 'SS_LEFT', -1,\
            10, STATIC_Y, 150, STATIC_H,\
            WS_VISIBLE + SS_LEFT
        STATIC_Y = STATIC_Y + STATIC_STEP
        dialogitem 'STATIC', 'SS_CENTER', -1,\
            10, STATIC_Y, 150, STATIC_H,\
            WS_VISIBLE + SS_CENTER
        STATIC_Y = STATIC_Y + STATIC_STEP
        dialogitem 'STATIC', 'SS_RIGHT', -1,\
            10, STATIC_Y, 150, STATIC_H,\
            WS_VISIBLE + SS_RIGHT
        STATIC_Y = STATIC_Y + STATIC_STEP
        dialogitem 'STATIC', 'SS_LEFT + SS_CENTERIMAGE', -1,\
            10, STATIC_Y, 150, STATIC_H,\
            WS_VISIBLE + SS_LEFT + SS_CENTERIMAGE
        STATIC_Y = STATIC_Y + STATIC_STEP
        dialogitem 'STATIC', 'SS_CENTER + SS_CENTERIMAGE', -1,\
            10, STATIC_Y, 150, STATIC_H,\
            WS_VISIBLE + SS_CENTER + SS_CENTERIMAGE
        STATIC_Y = STATIC_Y + STATIC_STEP
        dialogitem 'STATIC', 'SS_RIGHT + SS_CENTERIMAGE', -1,\
            10, STATIC_Y, 150, STATIC_H,\
            WS_VISIBLE + SS_RIGHT + SS_CENTERIMAGE
    enddialog

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            user32,             'user32.dll',\
            gdi32,              'gdi32.dll'
    import  kernel32,\
            GetModuleHandle,    'GetModuleHandleA',\
            ExitProcess,        'ExitProcess'
    import  user32,\
            DialogBoxParam,     'DialogBoxParamA',\
            EndDialog,          'EndDialog'
    import  gdi32,\
            CreateSolidBrush,   'CreateSolidBrush',\
            DeleteObject,       'DeleteObject',\
            SetTextColor,       'SetTextColor',\
            SetBkColor,         'SetBkColor'
