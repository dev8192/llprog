format PE
entry start

include 'win32ax.inc'

IDD_MAIN equ 37

section '.data' data readable writeable
    _class      db 'VerifyClass', 0
    _title      db 'HDC Verification', 0
    fmt         db 'eax: %p', 13, 10
                db 'ps.hdc: %p', 0
    buffer      rb 128
    ps          PAINTSTRUCT
    rect        RECT

section '.text' code readable executable
start:
    invoke GetModuleHandle, 0
    invoke DialogBoxParam, eax, IDD_MAIN, 0, DlgProc, 0
    invoke ExitProcess, 0

proc DlgProc uses ebx esi edi, hwnd, msg, wparam, lparam
    cmp  [msg], WM_PAINT
    je   .wmpaint
    cmp  [msg], WM_CLOSE
    je   .wmclose
    xor  eax, eax
    jmp  .finish

.wmpaint:
    invoke BeginPaint, [hwnd], ps
    mov    ebx, eax
    cinvoke wsprintf, buffer, fmt, ebx, [ps.hdc]
    invoke GetClientRect, [hwnd], rect
    invoke DrawText, [ps.hdc], buffer, -1, rect,\
        DT_CENTER or DT_VCENTER or DT_SINGLELINE
    invoke EndPaint, [hwnd], ps
    mov    eax, 1
    jmp    .finish

.wmclose:
    invoke EndDialog, [hwnd], 0
    mov    eax, 1

.finish:
    ret
endp

section '.idata' import data readable
    library kernel32,           'KERNEL32.DLL',\
            user32,             'USER32.DLL',\
            msvcrt,             'MSVCRT.DLL'
    import  kernel32,\
            GetModuleHandle,    'GetModuleHandleA',\
            ExitProcess,        'ExitProcess'
    import  user32,\
            BeginPaint,         'BeginPaint',\
            EndPaint,           'EndPaint',\
            DialogBoxParam,     'DialogBoxParamA',\
            EndDialog,          'EndDialog',\
            GetDlgItem,         'GetDlgItem',\
            GetDlgItemInt,      'GetDlgItemInt',\
            GetDlgItemText,     'GetDlgItemTextA',\
            GetClientRect,      'GetClientRect',\
            wsprintf,           'wsprintfA',\
            DrawText,           'DrawTextA'
    import  msvcrt,\
            printf,             'printf'

section '.res' resource data readable
    directory RT_DIALOG, dialogs
    resource dialogs,\
        IDD_MAIN, LANG_ENGLISH + SUBLANG_DEFAULT, main_dlg
    dialog main_dlg, 'Example Dialog', 100, 100, 200, 100,\
        WS_CAPTION+WS_SYSMENU+WS_VISIBLE
    enddialog
