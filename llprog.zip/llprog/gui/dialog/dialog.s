format PE
entry start

include 'win32a.inc'

IDC_TEXT_EDIT equ 101
IDC_INT_EDIT equ 102
IDC_READ_BUTTON equ 103
IDD_MAIN equ 37

section '.data' data readable writeable
    success_flag    dd 0
    text_buffer     rb 256
    fmt_hwnd        db "GetDlgItem HWND: %p", 10, 0
    fmt_s           db "'%s'", 10, 0
    fmt_int         db "%d (Success: %d)", 10, 0

section '.text' code readable executable
start:
    invoke GetModuleHandle, 0
    invoke DialogBoxParam, eax, IDD_MAIN, 0, DialogProc, 0
    invoke ExitProcess, 0

proc DialogProc hwnddlg, msg, wparam, lparam
    cmp [msg], WM_COMMAND
    je .wm_command
    cmp [msg], WM_CLOSE
    je .wm_close
    xor eax, eax
    ret

.wm_command:
    mov eax, [wparam]
    cmp ax, IDC_READ_BUTTON
    je .read_data
    cmp ax, IDCANCEL
    je .wm_close
    xor eax, eax
    ret

.read_data:
    invoke GetDlgItem, [hwnddlg], IDC_TEXT_EDIT
    cinvoke printf, fmt_hwnd, eax

    invoke GetDlgItemText, [hwnddlg], IDC_TEXT_EDIT,\
        text_buffer, 256
    cinvoke printf, fmt_s, text_buffer

    invoke GetDlgItemInt, [hwnddlg], IDC_INT_EDIT,\
        success_flag, FALSE
    cinvoke printf, fmt_int, eax, [success_flag]
    
    mov eax, TRUE
    ret

.wm_close:
    invoke EndDialog, [hwnddlg], 0
    mov eax, TRUE
    ret
endp

section '.idata' import data readable
    library kernel32,           'KERNEL32.DLL',\
            user32,             'USER32.DLL',\
            msvcrt,             'MSVCRT.DLL'
    import  kernel32,\
            GetModuleHandle,    'GetModuleHandleA',\
            ExitProcess,        'ExitProcess'
    import  user32,\
            DialogBoxParam,     'DialogBoxParamA',\
            EndDialog,          'EndDialog',\
            GetDlgItem,         'GetDlgItem',\
            GetDlgItemInt,      'GetDlgItemInt',\
            GetDlgItemText,     'GetDlgItemTextA'
    import  msvcrt,\
            printf,             'printf'

section '.rsrc' resource data readable
    directory RT_DIALOG, dialogs
    resource dialogs,\
        IDD_MAIN, LANG_ENGLISH + SUBLANG_DEFAULT, main_dialog
    dialog main_dialog, "Test Dialog", 50, 50, 200, 100,\
        WS_CAPTION + WS_POPUP + WS_SYSMENU + DS_MODALFRAME
        dialogitem 'STATIC', "Enter Text:", -1,\
            10, 10, 50, 10, WS_VISIBLE
        dialogitem 'EDIT', "", IDC_TEXT_EDIT,\
            70, 8, 100, 12, WS_VISIBLE + WS_BORDER + ES_AUTOHSCROLL
        dialogitem 'STATIC', "Enter Int:", -1,\
            10, 30, 50, 10, WS_VISIBLE
        dialogitem 'EDIT', "", IDC_INT_EDIT,\
            70, 28, 100, 12, WS_VISIBLE + WS_BORDER + ES_AUTOHSCROLL + ES_NUMBER
        dialogitem 'BUTTON', "Read Values", IDC_READ_BUTTON,\
            60, 60, 80, 15, WS_VISIBLE + BS_DEFPUSHBUTTON
    enddialog
