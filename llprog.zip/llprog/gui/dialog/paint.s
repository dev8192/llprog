format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    msg_text db 'Hello World!', 0
    color_red = 000000FFh
    color_green = 0000FF00h

section '.code' code readable executable
start:
    invoke GetModuleHandle, NULL
    invoke DialogBoxParam, eax, 1, HWND_DESKTOP, DialogProc, NULL
    invoke ExitProcess, 0

proc DialogProc hwnd, wmsg, wparam, lparam
    local ps:PAINTSTRUCT, rect:RECT
    cmp [wmsg], WM_PAINT
    je .wm_paint
    cmp [wmsg], WM_CLOSE
    je .wm_close
    xor eax, eax
    ret
.wm_paint:
    invoke BeginPaint, [hwnd], addr ps
    invoke SetTextColor, [ps.hdc], color_green
    invoke SetBkColor, [ps.hdc], color_red
    invoke GetClientRect, [hwnd], addr rect
    invoke DrawText, [ps.hdc], msg_text, -1, addr rect,\
        DT_SINGLELINE + DT_CENTER + DT_VCENTER
    invoke EndPaint, [hwnd], addr ps
    mov eax, TRUE
    ret
.wm_close:
    invoke EndDialog, [hwnd], 0
    mov eax, TRUE
    ret
endp

section '.res' resource data readable
    directory RT_DIALOG, dialogs
    resource dialogs, 1, LANG_NEUTRAL, hello

    dialog hello, 'Hello', 0, 0, 100, 40,\
        WS_CAPTION + WS_SYSMENU + WS_VISIBLE + DS_CENTER
    enddialog

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            user32,             'user32.dll',\
            gdi32,              'gdi32.dll'
    import  kernel32,\
            GetModuleHandle,    'GetModuleHandleA',\
            ExitProcess,        'ExitProcess'
    import  user32,\
            DialogBoxParam,     'DialogBoxParamA',\
            EndDialog,          'EndDialog',\
            BeginPaint,         'BeginPaint',\
            EndPaint,           'EndPaint',\
            GetClientRect,      'GetClientRect',\
            DrawText,           'DrawTextA'
    import  gdi32,\
            SetTextColor,       'SetTextColor',\
            SetBkColor,         'SetBkColor'
