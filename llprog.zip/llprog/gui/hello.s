; does not compile

format PE GUI 4.0

entry start

; -----------------------------------------------------------------------------
; Constants
; -----------------------------------------------------------------------------
WM_CREATE       equ 0x0001
WM_COMMAND      equ 0x0111
WM_DESTROY      equ 0x0002
WS_VISIBLE      equ 0x10000000
WS_CHILD        equ 0x40000000
WS_BORDER       equ 0x00800000
WS_CAPTION      equ 0x00C00000
WS_SYSMENU      equ 0x00080000
BS_PUSHBUTTON   equ 0x00000000
ES_NUMBER       equ 0x00002000
IDC_BUTTON      equ 1001
IDC_COUNTER     equ 1002

; -----------------------------------------------------------------------------
; Data Section (All data including uninitialized)
; -----------------------------------------------------------------------------
section '.data' data readable writable

    counter         dd 0
    hInstance       dd 0
    msg             dd 0, 0, 0, 0
    buffer          db 16 dup 0
    
    className       db 'CounterClass', 0
    windowTitle     db 'Counter Window', 0
    buttonText      db 'Increment', 0

; -----------------------------------------------------------------------------
; Code Section
; -----------------------------------------------------------------------------
section '.code' code readable executable

start:
    ; Get module handle
    push    0
    call    [GetModuleHandleA]
    mov     [hInstance], eax
    
    ; Register window class (WNDCLASSEXA = 48 bytes)
    push    0                   ; hIconSm
    push    0                   ; hInstance (will be set below)
    push    0                   ; hCursor
    push    0                   ; hbrBackground
    push    0                   ; lpszMenuName
    push    className           ; lpszClassName
    push    0                   ; hIcon
    push    [hInstance]         ; hInstance
    push    WndProc             ; lpfnWndProc
    push    0                   ; cbClsExtra
    push    0                   ; cbWndExtra
    push    0                   ; style
    push    48                  ; cbSize
    call    [RegisterClassExA]
    
    ; Create window
    push    0                   ; lpParam
    push    [hInstance]         ; hInstance
    push    0                   ; hMenu
    push    0                   ; hWndParent
    push    200                 ; nHeight
    push    300                 ; nWidth
    push    100                 ; y
    push    100                 ; x
    push    WS_VISIBLE or WS_CAPTION or WS_SYSMENU or WS_BORDER
    push    windowTitle         ; lpWindowName
    push    className           ; lpClassName
    push    0                   ; dwExStyle
    call    [CreateWindowExA]
    
    ; Message loop
message_loop:
    push    0
    push    0
    push    0
    push    msg
    call    [GetMessageA]
    test    eax, eax
    jz      end_loop
    
    push    msg
    call    [TranslateMessage]
    push    msg
    call    [DispatchMessageA]
    jmp     message_loop

end_loop:
    push    0
    call    [ExitProcess]

; -----------------------------------------------------------------------------
; Window Procedure
; -----------------------------------------------------------------------------
align 16
WndProc:
    push    ebp
    mov     ebp, esp
    push    ebx
    push    esi
    push    edi
    
    mov     eax, [ebp+12]       ; uMsg
    mov     edi, [ebp+8]        ; hWnd
    mov     esi, [ebp+16]       ; wParam
    mov     ebx, [ebp+20]       ; lParam
    
    cmp     eax, WM_CREATE
    je      .wm_create
    
    cmp     eax, WM_COMMAND
    je      .wm_command
    
    cmp     eax, WM_DESTROY
    je      .wm_destroy
    
    ; Default processing
    push    ebx
    push    esi
    push    eax
    push    edi
    call    [DefWindowProcA]
    jmp     .done

.wm_create:
    ; Create counter display (edit control)
    push    [hInstance]
    push    0
    push    IDC_COUNTER
    push    ES_NUMBER or WS_CHILD or WS_VISIBLE or WS_BORDER
    push    50                  ; y
    push    100                 ; x
    push    30                  ; height
    push    80                  ; width
    push    edi                 ; hWnd parent
    push    0                   ; lpClassName (NULL = edit control)
    push    0                   ; dwExStyle
    call    [CreateWindowExA]
    
    ; Create button
    push    [hInstance]
    push    0
    push    IDC_BUTTON
    push    BS_PUSHBUTTON or WS_CHILD or WS_VISIBLE
    push    100                 ; y
    push    100                 ; x
    push    30                  ; height
    push    80                  ; width
    push    edi                 ; hWnd parent
    push    buttonText          ; lpClassName
    push    0                   ; dwExStyle
    call    [CreateWindowExA]
    
    xor     eax, eax
    jmp     .done

.wm_command:
    mov     ax, si              ; Low word of wParam = control ID
    cmp     ax, IDC_BUTTON
    jne     .default
    
    ; Increment counter
    inc     [counter]
    
    ; Update counter display
    push    0
    push    10                  ; buffer size
    push    buffer
    push    [counter]
    call    [wsprintfA]
    
    ; Get counter control handle
    push    IDC_COUNTER
    push    edi
    call    [GetDlgItem]
    mov     edi, eax
    
    ; Set text
    push    buffer
    push    edi
    call    [SetWindowTextA]
    
    xor     eax, eax
    jmp     .done

.wm_destroy:
    push    0
    call    [PostQuitMessage]
    xor     eax, eax
    jmp     .done

.default:
    push    ebx
    push    esi
    push    eax
    push    edi
    call    [DefWindowProcA]

.done:
    pop     edi
    pop     esi
    pop     ebx
    pop     ebp
    ret     16

; -----------------------------------------------------------------------------
; Import Section
; -----------------------------------------------------------------------------
section '.idata' import data readable

    ; kernel32.dll imports
    dd rva kernel32_table, 0, 0, rva kernel32_name, rva kernel32_table
    dd rva _GetModuleHandleA
    dd rva _ExitProcess
    dd 0

    ; user32.dll imports
    dd rva user32_table, 0, 0, rva user32_name, rva user32_table
    dd rva _RegisterClassExA
    dd rva _CreateWindowExA
    dd rva _GetMessageA
    dd rva _TranslateMessage
    dd rva _DispatchMessageA
    dd rva _DefWindowProcA
    dd rva _PostQuitMessage
    dd rva _GetDlgItem
    dd rva _SetWindowTextA
    dd 0

    ; gdi32.dll imports
    dd rva gdi32_table, 0, 0, rva gdi32_name, rva gdi32_table
    dd rva _wsprintfA
    dd 0

    ; End of imports
    dd 0, 0, 0, 0, 0

kernel32_table:
    dd rva _GetModuleHandleA
    dd rva _ExitProcess
    dd 0

user32_table:
    dd rva _RegisterClassExA
    dd rva _CreateWindowExA
    dd rva _GetMessageA
    dd rva _TranslateMessage
    dd rva _DispatchMessageA
    dd rva _DefWindowProcA
    dd rva _PostQuitMessage
    dd rva _GetDlgItem
    dd rva _SetWindowTextA
    dd 0

gdi32_table:
    dd rva _wsprintfA
    dd 0

kernel32_name db 'kernel32.dll', 0
user32_name   db 'user32.dll', 0
gdi32_name    db 'gdi32.dll', 0

_GetModuleHandleA   db 'GetModuleHandleA', 0
_ExitProcess        db 'ExitProcess', 0
_RegisterClassExA   db 'RegisterClassExA', 0
_CreateWindowExA    db 'CreateWindowExA', 0
_GetMessageA        db 'GetMessageA', 0
_TranslateMessage   db 'TranslateMessage', 0
_DispatchMessageA   db 'DispatchMessageA', 0
_DefWindowProcA     db 'DefWindowProcA', 0
_PostQuitMessage    db 'PostQuitMessage', 0
_GetDlgItem         db 'GetDlgItem', 0
_SetWindowTextA     db 'SetWindowTextA', 0
_wsprintfA          db 'wsprintfA', 0
