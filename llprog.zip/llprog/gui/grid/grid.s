format PE GUI 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    wc WNDCLASSEX sizeof.WNDCLASSEX, 0, WndProc, 0, 0, 0, 0, 0, COLOR_WINDOW+1, 0, clsName, 0
    msg MSG
    ps PAINTSTRUCT
    rc RECT

    clsName db 'PosWin', 0
    txtNW   db 'nw', 0
    txtN    db 'n', 0
    txtNE   db 'ne', 0
    txtW    db 'w', 0
    txtC    db 'c', 0
    txtE    db 'e', 0
    txtSW   db 'sw', 0
    txtS    db 's', 0
    txtSE   db 'se', 0

section '.text' code readable executable
start:
    invoke  GetModuleHandle, 0
    mov     [wc.hInstance], eax
    invoke  LoadCursor, 0, IDC_ARROW
    mov     [wc.hCursor], eax
    invoke  RegisterClassEx, wc
    invoke  CreateWindowEx, 0, clsName, clsName, WS_OVERLAPPEDWINDOW+WS_VISIBLE,\
        CW_USEDEFAULT, CW_USEDEFAULT, 400, 300, 0, 0, [wc.hInstance], 0

msg_loop:
    invoke  GetMessage, msg, 0, 0, 0
    test    eax, eax
    jz      end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     msg_loop

end_loop:
    invoke  ExitProcess, [msg.wParam]

proc WndProc hwnd, wmsg, wparam, lparam
    cmp     [wmsg], WM_PAINT
    je      .on_paint
    cmp     [wmsg], WM_DESTROY
    je      .on_destroy
.def:
    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret

.on_paint:
    invoke  BeginPaint, [hwnd], ps
    invoke  GetClientRect, [hwnd], rc
    invoke  InflateRect, rc, -50, -10

    invoke  DrawText, [ps.hdc], txtNW, -1, rc, DT_TOP or DT_LEFT or DT_SINGLELINE
    invoke  DrawText, [ps.hdc], txtN, -1, rc, DT_TOP or DT_CENTER or DT_SINGLELINE
    invoke  DrawText, [ps.hdc], txtNE, -1, rc, DT_TOP or DT_RIGHT or DT_SINGLELINE
    invoke  DrawText, [ps.hdc], txtW, -1, rc, DT_VCENTER or DT_LEFT or DT_SINGLELINE
    invoke  DrawText, [ps.hdc], txtC, -1, rc, DT_VCENTER or DT_CENTER or DT_SINGLELINE
    invoke  DrawText, [ps.hdc], txtE, -1, rc, DT_VCENTER or DT_RIGHT or DT_SINGLELINE
    invoke  DrawText, [ps.hdc], txtSW, -1, rc, DT_BOTTOM or DT_LEFT or DT_SINGLELINE
    invoke  DrawText, [ps.hdc], txtS, -1, rc, DT_BOTTOM or DT_CENTER or DT_SINGLELINE
    invoke  DrawText, [ps.hdc], txtSE, -1, rc, DT_BOTTOM or DT_RIGHT or DT_SINGLELINE

    invoke  EndPaint, [hwnd], ps
    xor     eax, eax
    ret

.on_destroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
    ret
endp

section '.idata' import data readable writeable
    library kernel32, 'KERNEL32.DLL',\
            user32, 'USER32.DLL'

    import kernel32,\
        ExitProcess, 'ExitProcess',\
        GetModuleHandle, 'GetModuleHandleA'

    import user32,\
        BeginPaint, 'BeginPaint',\
        CreateWindowEx, 'CreateWindowExA',\
        DefWindowProc, 'DefWindowProcA',\
        DispatchMessage, 'DispatchMessageA',\
        DrawText, 'DrawTextA',\
        EndPaint, 'EndPaint',\
        GetClientRect, 'GetClientRect',\
        GetMessage, 'GetMessageA',\
        InflateRect, 'InflateRect',\
        LoadCursor, 'LoadCursorA',\
        PostQuitMessage, 'PostQuitMessage',\
        RegisterClassEx, 'RegisterClassExA',\
        TranslateMessage, 'TranslateMessage'
