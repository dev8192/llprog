format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    _class              db 'ExampleWindow', 0
    _title              db 'Example Window', 0
    _edit               db 'EDIT', 0
    msg                 MSG
    wc                  WNDCLASS

section '.text' code readable executable
start:
    mov     [wc.lpfnWndProc], WindowProc
    invoke  GetModuleHandle, 0
    mov     [wc.hInstance], eax
    mov     [wc.lpszClassName], _class
    mov     [wc.hbrBackground], COLOR_WINDOW+1
    invoke  LoadCursor, 0, IDC_ARROW
    mov     [wc.hCursor], eax
    invoke  RegisterClass, wc

    invoke  CreateWindowEx, 0, _class, _title,\
            WS_VISIBLE or WS_OVERLAPPEDWINDOW,\
            100, 100, 300, 200, 0, 0, [wc.hInstance], 0

msg_loop:
    invoke  GetMessage, msg, NULL, 0, 0
    test    eax, eax
    jz      end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     msg_loop

end_loop:
    invoke  ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp     [wmsg], WM_CREATE
    je      .wm_create
    cmp     [wmsg], WM_DESTROY
    je      .wm_destroy
.defproc:
    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret

.wm_create:
    invoke  CreateWindowEx, WS_EX_CLIENTEDGE, _edit, 0,\
            WS_VISIBLE or WS_CHILD or ES_AUTOHSCROLL,\
            10, 10, 200, 25, [hwnd], 0, [wc.hInstance], 0
    invoke  SetFocus, eax
    xor     eax, eax
    ret

.wm_destroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
    ret
endp

section '.idata' import data readable
library kernel32,           'kernel32.dll',\
        user32,             'user32.dll'
import  kernel32,\
        GetModuleHandle,    'GetModuleHandleA',\
        ExitProcess,        'ExitProcess'
import  user32,\
        CreateWindowEx,     'CreateWindowExA',\
        DefWindowProc,      'DefWindowProcA',\
        DispatchMessage,    'DispatchMessageA',\
        GetMessage,         'GetMessageA',\
        LoadCursor,         'LoadCursorA',\
        PostQuitMessage,    'PostQuitMessage',\
        RegisterClass,      'RegisterClassA',\
        SetFocus,           'SetFocus',\
        TranslateMessage,   'TranslateMessage'
