format PE console
;format PE GUI

include 'win32a.inc'

entry start

section '.data' data readable writeable

    _class  TCHAR 'FasmWin32', 0
    _title  TCHAR 'Simple Window', 0
    wc      WNDCLASS
    msg     MSG

section '.text' code readable executable

start:
    invoke  GetModuleHandle, 0
    mov     [wc.hInstance], eax
    mov     [wc.style], CS_HREDRAW or CS_VREDRAW
    mov     [wc.lpfnWndProc], WindowProc
    invoke  LoadIcon, 0, IDI_APPLICATION
    mov     [wc.hIcon], eax
    invoke  LoadCursor, 0, IDC_ARROW
    mov     [wc.hCursor], eax
    mov     [wc.hbrBackground], COLOR_BTNFACE + 1
    mov     [wc.lpszClassName], _class
    invoke  RegisterClass, wc

    invoke  CreateWindowEx, 0, _class, _title, WS_VISIBLE or WS_OVERLAPPEDWINDOW, 128, 128, 400, 300, 0, 0, [wc.hInstance], 0

msg_loop:
    invoke  GetMessage, msg, 0, 0, 0
    cmp     eax, 1
    jb      end_loop
    jne     msg_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     msg_loop

end_loop:
    invoke  ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp     [wmsg], WM_DESTROY
    je      .wmdestroy
.defwndproc:
    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    jmp     .finish
.wmdestroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
.finish:
    ret
endp

section '.idata' import data readable writeable

    library kernel32, 'KERNEL32.DLL',\
            user32, 'USER32.DLL'

    import  kernel32,\
            GetModuleHandle, 'GetModuleHandleA',\
            ExitProcess, 'ExitProcess'

    import  user32,\
            RegisterClass, 'RegisterClassA',\
            CreateWindowEx, 'CreateWindowExA',\
            DefWindowProc, 'DefWindowProcA',\
            GetMessage, 'GetMessageA',\
            TranslateMessage, 'TranslateMessage',\
            DispatchMessage, 'DispatchMessageA',\
            LoadCursor, 'LoadCursorA',\
            LoadIcon, 'LoadIconA',\
            PostQuitMessage, 'PostQuitMessage'
