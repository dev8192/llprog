format PE console
entry start

include 'c:\fasm\include\win32a.inc' 

section '.data' data readable writeable
    _class      db 'NotePadClass',0
    _title      db 'My Notes',0
    _btn_save   db 'Save',0
    _btn_load   db 'Load',0
    _btn_clear  db 'Clear',0
    _edit_class db 'EDIT',0
    _btn_class  db 'BUTTON',0
    _filename   db 'notes.txt',0
    _msg_ok     db 'File saved!',0
    _msg_cap    db 'Info',0

    hEdit       dd 0
    hFile       dd 0
    bytesRW     dd 0
    _buffer     rb 4096 

    wc          WNDCLASS 0,WindowProc,0,0,0,0,0,COLOR_WINDOW+1,0,_class
    msg         MSG

section '.text' code readable executable
start:
    invoke GetModuleHandle, 0
    mov [wc.hInstance], eax
    invoke LoadIcon, 0, IDI_APPLICATION
    mov [wc.hIcon], eax
    invoke LoadCursor, 0, IDC_ARROW
    mov [wc.hCursor], eax
    invoke RegisterClass, wc
    
    invoke CreateWindowEx, 0, _class, _title, WS_VISIBLE+WS_OVERLAPPEDWINDOW,\
        CW_USEDEFAULT, CW_USEDEFAULT, 400, 320, 0, 0, [wc.hInstance], 0
    test eax, eax
    jz exit_fail 

msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    cmp eax, 0 
    je exit
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp msg_loop

exit_fail:
    invoke ExitProcess, 1
exit:
    invoke ExitProcess, 0

proc WindowProc hwnd, umsg, wparam, lparam
    cmp [umsg], WM_CREATE
    je .create
    cmp [umsg], WM_COMMAND
    je .command
    cmp [umsg], WM_DESTROY
    je .destroy
    invoke DefWindowProc, [hwnd], [umsg], [wparam], [lparam]
    ret

.create:
    invoke CreateWindowEx, WS_EX_CLIENTEDGE, _edit_class, 0,\
        WS_VISIBLE+WS_CHILD+ES_MULTILINE+WS_VSCROLL+ES_AUTOVSCROLL,\
        10, 10, 360, 200, [hwnd], 101, [wc.hInstance], 0
    mov [hEdit], eax

    invoke CreateWindowEx, 0, _btn_class, _btn_save, WS_VISIBLE+WS_CHILD,\
        10, 220, 80, 30, [hwnd], 102, [wc.hInstance], 0
    invoke CreateWindowEx, 0, _btn_class, _btn_load, WS_VISIBLE+WS_CHILD,\
        100, 220, 80, 30, [hwnd], 103, [wc.hInstance], 0
    invoke CreateWindowEx, 0, _btn_class, _btn_clear, WS_VISIBLE+WS_CHILD,\
        190, 220, 80, 30, [hwnd], 104, [wc.hInstance], 0
    ret

.command:
    mov eax, [wparam]
    and eax, 0xFFFF 
    cmp eax, 102
    je .save
    cmp eax, 103
    je .load
    cmp eax, 104
    je .clear
    ret

.save:
    invoke CreateFile, _filename, GENERIC_WRITE, 0, 0, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0
    mov [hFile], eax
    invoke GetWindowText, [hEdit], _buffer, 4096
    invoke WriteFile, [hFile], _buffer, eax, bytesRW, 0
    invoke CloseHandle, [hFile]
    invoke MessageBox, [hwnd], _msg_ok, _msg_cap, MB_OK
    ret

.load:
    invoke CreateFile, _filename, GENERIC_READ, 0, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0
    cmp eax, -1
    je .done
    mov [hFile], eax
    invoke ReadFile, [hFile], _buffer, 4096, bytesRW, 0
    invoke CloseHandle, [hFile]
    invoke SetWindowText, [hEdit], _buffer
.done:
    ret

.clear:
    invoke SetWindowText, [hEdit], 0
    ret

.destroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    ret
endp

section '.idata' import data readable
    library kernel32,           'KERNEL32.DLL',\
            user32,             'USER32.DLL'
    import  kernel32,\
            GetModuleHandle,    'GetModuleHandleA',\
            ExitProcess,        'ExitProcess',\
            CreateFile,         'CreateFileA',\
            WriteFile,          'WriteFile',\
            ReadFile,           'ReadFile',\
            CloseHandle,        'CloseHandle'
    import  user32,\
            RegisterClass,      'RegisterClassA',\
            CreateWindowEx,     'CreateWindowExA',\
            DefWindowProc,      'DefWindowProcA',\
            GetMessage,         'GetMessageA',\
            DispatchMessage,    'DispatchMessageA',\
            TranslateMessage,   'TranslateMessage',\
            GetWindowText,      'GetWindowTextA',\
            SetWindowText,      'SetWindowTextA',\
            LoadIcon,           'LoadIconA',\
            LoadCursor,         'LoadCursorA',\
            PostQuitMessage,    'PostQuitMessage',\
            MessageBox,         'MessageBoxA'
