; --------------------------------------------------
; Starting point
; --------------------------------------------------
format PE console
entry start

include 'win32a.inc'

section '.text' code readable executable
start:
    invoke ExitProcess, 0

section '.idata' import data readable writeable
    library kernel32,           'KERNEL32.DLL'
    import  kernel32,\
            ExitProcess,        'ExitProcess'
