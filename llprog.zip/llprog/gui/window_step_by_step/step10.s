; --------------------------------------------------
; Starting point
; --------------------------------------------------
format PE

include 'win32a.inc'

section '.text' code readable executable
    invoke ExitProcess, 0

section '.idata' import data readable writeable
    library kernel32,           'kernel32.dll'
    import  kernel32,\
            ExitProcess,        'ExitProcess'
