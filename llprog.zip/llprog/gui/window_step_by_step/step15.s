; --------------------------------------------------
; Add printf()
; --------------------------------------------------
format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    msg1 db 'msg1!', 10, 0

section '.text' code readable executable
start:
    cinvoke printf, msg1
    invoke ExitProcess, 0

section '.idata' import data readable writeable
    library kernel32,           'kernel32.dll',\
            msvcrt,             'msvcrt.dll'
    import  kernel32,\
            ExitProcess,        'ExitProcess'
    import  msvcrt,\
            printf,             'printf'
