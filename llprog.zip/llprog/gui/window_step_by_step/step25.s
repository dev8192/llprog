; --------------------------------------------------
; Add class_name
; --------------------------------------------------
format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    class_name db 'ExampleWindow', 0
    fmt db '%d', 10, 0
    wc WNDCLASS

section '.text' code readable executable
start:
    mov [wc.lpszClassName], class_name
    invoke RegisterClass, wc
    cinvoke printf, fmt, eax
    invoke ExitProcess, 0

section '.idata' import data readable writeable
    library kernel32,           'kernel32.dll',\
            user32,             'user32.dll',\
            msvcrt,             'msvcrt.dll'
    import  kernel32,\
            GetModuleHandle,    'GetModuleHandleA',\
            ExitProcess,        'ExitProcess'
    import  user32,\
            RegisterClass,      'RegisterClassA',\
            DefWindowProc,      'DefWindowProcA'
    import  msvcrt,\
            printf,             'printf'
