; --------------------------------------------------
; Add CreateWindowEx()
; --------------------------------------------------
format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    class_name db 'ExampleWindow', 0
    fmt db '%d', 10, 0
    wc WNDCLASS

section '.text' code readable executable
start:
    mov eax, [DefWindowProc]
    mov [wc.lpfnWndProc], eax
    mov [wc.lpszClassName], class_name
    invoke RegisterClass, wc
    cinvoke printf, fmt, eax

    invoke CreateWindowEx, 0, class_name, class_name,\
        WS_VISIBLE + WS_OVERLAPPEDWINDOW,\
        CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,\
        0, 0, [wc.hInstance], 0
    cinvoke printf, fmt, eax

    invoke  Sleep, 10000
    invoke ExitProcess, 0

section '.idata' import data readable writeable
    library kernel32,           'kernel32.dll',\
            user32,             'user32.dll',\
            msvcrt,             'msvcrt.dll'
    import  kernel32,\
            Sleep,              'Sleep',\
            ExitProcess,        'ExitProcess'
    import  user32,\
            RegisterClass,      'RegisterClassA',\
            CreateWindowEx,     'CreateWindowExA',\
            DefWindowProc,      'DefWindowProcA'
    import  msvcrt,\
            printf,             'printf'
