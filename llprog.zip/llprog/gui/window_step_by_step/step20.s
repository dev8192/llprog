; --------------------------------------------------
; Add RegisterClass()
; --------------------------------------------------
format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt db '%d', 10, 0
    wc WNDCLASS

section '.text' code readable executable
start:
    invoke RegisterClass, wc
    cinvoke printf, fmt, eax
    invoke ExitProcess, 0

section '.idata' import data readable writeable
    library kernel32,           'kernel32.dll',\
            user32,             'user32.dll',\
            msvcrt,             'msvcrt.dll'
    import  kernel32,\
            ExitProcess,        'ExitProcess'
    import  user32,\
            RegisterClass,      'RegisterClassA'
    import  msvcrt,\
            printf,             'printf'
