; --------------------------------------------------
; Add WindowProc
; --------------------------------------------------
format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    class_name db 'ExampleWindow', 0
    wc WNDCLASS
    msg MSG

section '.text' code readable executable
start:
    mov [wc.lpfnWndProc], WindowProc
    mov [wc.lpszClassName], class_name
    invoke RegisterClass, wc

    invoke CreateWindowEx, 0, class_name, class_name,\
        WS_VISIBLE + WS_OVERLAPPEDWINDOW,\
        CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,\
        0, 0, [wc.hInstance], 0

.msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    test eax, eax
    jle .end_loop
    invoke DispatchMessage, msg
    jmp .msg_loop

.end_loop:
    invoke ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp [wmsg], WM_DESTROY
    je .wmdestroy
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret
.wmdestroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    ret
endp

section '.idata' import data readable writeable
    library kernel32,           'kernel32.dll',\
            user32,             'user32.dll',\
            msvcrt,             'msvcrt.dll'
    import  kernel32,\
            ExitProcess,        'ExitProcess'
    import  user32,\
            RegisterClass,      'RegisterClassA',\
            CreateWindowEx,     'CreateWindowExA',\
            DefWindowProc,      'DefWindowProcA',\
            GetMessage,         'GetMessageA',\
            DispatchMessage,    'DispatchMessageA',\
            PostQuitMessage,    'PostQuitMessage'
    import  msvcrt,\
            printf,             'printf'
