format PE GUI 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    className db 'HoverWin', 0
    wc WNDCLASS
    msg MSG
    rct RECT
    ps PAINTSTRUCT
    hovered dd 0

section '.text' code readable executable
start:
    invoke GetModuleHandle, 0
    mov [wc.hInstance], eax
    mov [wc.lpfnWndProc], WndProc
    mov [wc.hbrBackground], COLOR_WINDOW+1
    mov [wc.lpszClassName], className
    
    invoke LoadCursor, 0, IDC_ARROW
    mov [wc.hCursor], eax
    
    invoke RegisterClass, wc
    invoke CreateWindowEx, 0, className, className, WS_OVERLAPPEDWINDOW+WS_VISIBLE,\
        CW_USEDEFAULT, CW_USEDEFAULT, 640, 480, 0, 0, [wc.hInstance], 0

msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    cmp eax, 0
    jle end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp msg_loop

end_loop:
    invoke ExitProcess, [msg.wParam]

proc WndProc hwnd, wmsg, wparam, lparam
    cmp [wmsg], WM_DESTROY
    je .wmdestroy
    cmp [wmsg], WM_MOUSEMOVE
    je .wmmousemove
    cmp [wmsg], WM_PAINT
    je .wmpaint

    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret

.wmmousemove:
    invoke GetClientRect, [hwnd], rct
    mov eax, [rct.right]
    sub eax, 200
    sar eax, 1
    mov [rct.left], eax
    add eax, 200
    mov [rct.right], eax

    mov eax, [rct.bottom]
    sub eax, 200
    sar eax, 1
    mov [rct.top], eax
    add eax, 200
    mov [rct.bottom], eax

    mov eax, [lparam]
    movsx ecx, ax
    shr eax, 16
    movsx edx, ax

    cmp ecx, [rct.left]
    jl .not_hover
    cmp ecx, [rct.right]
    jg .not_hover
    cmp edx, [rct.top]
    jl .not_hover
    cmp edx, [rct.bottom]
    jg .not_hover

    cmp [hovered], 1
    je .done
    mov [hovered], 1
    invoke InvalidateRect, [hwnd], rct, 1
    jmp .done

.not_hover:
    cmp [hovered], 0
    je .done
    mov [hovered], 0
    invoke InvalidateRect, [hwnd], rct, 1

.done:
    xor eax, eax
    ret

.wmpaint:
    invoke BeginPaint, [hwnd], ps

    invoke GetClientRect, [hwnd], rct
    mov eax, [rct.right]
    sub eax, 200
    sar eax, 1
    mov [rct.left], eax
    add eax, 200
    mov [rct.right], eax

    mov eax, [rct.bottom]
    sub eax, 200
    sar eax, 1
    mov [rct.top], eax
    add eax, 200
    mov [rct.bottom], eax

    cmp [hovered], 1
    je .hover_color
    invoke CreateSolidBrush, 0x000000FF ; red
    jmp .do_fill

.hover_color:
    invoke CreateSolidBrush, 0x00FF0000 ; blue

.do_fill:
    push eax
    invoke FillRect, [ps.hdc], rct, eax
    pop eax
    invoke DeleteObject, eax

    invoke EndPaint, [hwnd], ps
    xor eax, eax
    ret

.wmdestroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    ret
endp

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            user32, 'user32.dll',\
            gdi32, 'gdi32.dll'

    import kernel32,\
           GetModuleHandle, 'GetModuleHandleA',\
           ExitProcess, 'ExitProcess'

    import user32,\
           RegisterClass, 'RegisterClassA',\
           CreateWindowEx, 'CreateWindowExA',\
           GetMessage, 'GetMessageA',\
           TranslateMessage, 'TranslateMessage',\
           DispatchMessage, 'DispatchMessageA',\
           DefWindowProc, 'DefWindowProcA',\
           PostQuitMessage, 'PostQuitMessage',\
           LoadCursor, 'LoadCursorA',\
           BeginPaint, 'BeginPaint',\
           EndPaint, 'EndPaint',\
           GetClientRect, 'GetClientRect',\
           InvalidateRect, 'InvalidateRect',\
           FillRect, 'FillRect'

    import gdi32,\
           CreateSolidBrush, 'CreateSolidBrush',\
           DeleteObject, 'DeleteObject'
