format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    clsName db 'MouseTracker', 0
    fmt     db 'X: %d, Y: %d', 10, 0
    wc      WNDCLASS
    msg     MSG

section '.text' code readable executable
start:
    invoke GetModuleHandle, 0
    mov [wc.hInstance], eax
    mov [wc.lpfnWndProc], WindowProc
    mov [wc.lpszClassName], clsName
    invoke LoadCursor, 0, IDC_ARROW
    mov [wc.hCursor], eax
    invoke RegisterClass, wc

    invoke CreateWindowEx, 0, clsName, clsName, WS_VISIBLE or WS_OVERLAPPEDWINDOW, \
        CW_USEDEFAULT, CW_USEDEFAULT, 400, 300, 0, 0, [wc.hInstance], 0

msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    test eax, eax
    jz end_loop
    invoke DispatchMessage, msg
    jmp msg_loop

end_loop:
    invoke ExitProcess, [msg.wParam]

WindowProc:
    mov eax, [esp+8]
    cmp eax, WM_MOUSEMOVE
    je .wmmousemove
    cmp eax, WM_DESTROY
    je .wmdestroy
    jmp [DefWindowProc]

.wmmousemove:
    mov edx, [esp+16]
    movsx ecx, dx
    sar edx, 16
    cinvoke printf, fmt, ecx, edx
    xor eax, eax
    ret 16

.wmdestroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    ret 16

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
        user32, 'user32.dll',\
        msvcrt, 'msvcrt.dll'

    import kernel32,\
        GetModuleHandle, 'GetModuleHandleA',\
        ExitProcess, 'ExitProcess'

    import user32,\
        LoadCursor, 'LoadCursorA',\
        RegisterClass, 'RegisterClassA',\
        CreateWindowEx, 'CreateWindowExA',\
        GetMessage, 'GetMessageA',\
        DispatchMessage, 'DispatchMessageA',\
        DefWindowProc, 'DefWindowProcA',\
        PostQuitMessage, 'PostQuitMessage'

    import msvcrt,\
        printf, 'printf'
