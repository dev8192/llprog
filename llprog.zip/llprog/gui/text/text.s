; ---------------------------------------------
; Prints 'one, two, three' in a monospace font.
; After 1 second 'one' becomes red.
; After 2 seconds 'two' becomes green and
; after 3 seconds 'three' becomes blue.
; ---------------------------------------------
format PE GUI 4.0
entry start

include 'win32a.inc'

ID_TIMER      = 1
TIMER_DELAY   = 1000
COLOR_BLACK   = 0x00000000
COLOR_RED     = 0x000000FF
COLOR_GREEN   = 0x0000FF00
COLOR_BLUE    = 0x00FF0000
WINDOW_WIDTH  = 400
WINDOW_HEIGHT = 200
TEXT_START_X  = 20
TEXT_START_Y  = 20
STATE_RED     = 1
STATE_GREEN   = 2
STATE_BLUE    = 3

section '.data' data readable writeable
    className   db 'MonoColorClass', 0
    windowTitle db 'Colored Text', 0
    
    strOne      db 'one, ', 0
    lenOne      = $ - strOne - 1
    strTwo      db 'two, ', 0
    lenTwo      = $ - strTwo - 1
    strThree    db 'three', 0
    lenThree    = $ - strThree - 1

    wc          WNDCLASS
    msg         MSG
    ps          PAINTSTRUCT
    state       dd 0
    hdc         dd ?

section '.text' code readable executable
proc start
    invoke GetModuleHandle, NULL
    mov [wc.hInstance], eax
    mov [wc.style], CS_HREDRAW or CS_VREDRAW
    mov [wc.lpfnWndProc], WindowProc
    invoke LoadIcon, NULL, IDI_APPLICATION
    mov [wc.hIcon], eax
    invoke LoadCursor, NULL, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.hbrBackground], COLOR_WINDOW + 1
    mov [wc.lpszClassName], className
    
    invoke RegisterClass, wc

    invoke CreateWindowEx, 0, className, windowTitle, \
           WS_OVERLAPPEDWINDOW or WS_VISIBLE, \
           CW_USEDEFAULT, CW_USEDEFAULT, \
           WINDOW_WIDTH, WINDOW_HEIGHT, \
           NULL, NULL, [wc.hInstance], NULL

.msg_loop:
    invoke GetMessage, msg, NULL, 0, 0
    cmp eax, 0
    je .end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp .msg_loop
    
.end_loop:
    invoke ExitProcess, [msg.wParam]
endp

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp [wmsg], WM_CREATE
    je .wm_create
    cmp [wmsg], WM_TIMER
    je .wm_timer
    cmp [wmsg], WM_PAINT
    je .wm_paint
    cmp [wmsg], WM_DESTROY
    je .wm_destroy

.def_proc:
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret

.wm_create:
    invoke SetTimer, [hwnd], ID_TIMER, TIMER_DELAY, NULL
    xor eax, eax
    ret

.wm_timer:
    inc [state]
    invoke InvalidateRect, [hwnd], NULL, TRUE
    cmp [state], STATE_BLUE
    jl .timer_ret
    invoke KillTimer, [hwnd], ID_TIMER
.timer_ret:
    xor eax, eax
    ret

.wm_paint:
    invoke BeginPaint, [hwnd], ps
    mov [hdc], eax

    invoke GetStockObject, ANSI_FIXED_FONT
    invoke SelectObject, [hdc], eax

    invoke SetBkMode, [hdc], TRANSPARENT
    invoke SetTextAlign, [hdc], TA_UPDATECP

    invoke MoveToEx, [hdc], TEXT_START_X, TEXT_START_Y, NULL

    mov ecx, COLOR_BLACK
    cmp [state], STATE_RED
    jl .draw_one
    mov ecx, COLOR_RED
.draw_one:
    invoke SetTextColor, [hdc], ecx
    invoke TextOut, [hdc], 0, 0, strOne, lenOne

    mov ecx, COLOR_BLACK
    cmp [state], STATE_GREEN
    jl .draw_two
    mov ecx, COLOR_GREEN
.draw_two:
    invoke SetTextColor, [hdc], ecx
    invoke TextOut, [hdc], 0, 0, strTwo, lenTwo

    mov ecx, COLOR_BLACK
    cmp [state], STATE_BLUE
    jl .draw_three
    mov ecx, COLOR_BLUE
.draw_three:
    invoke SetTextColor, [hdc], ecx
    invoke TextOut, [hdc], 0, 0, strThree, lenThree

    invoke EndPaint, [hwnd], ps
    xor eax, eax
    ret

.wm_destroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    ret
endp

section '.idata' import data readable
    library kernel32, 'kernel32.dll', \
            user32, 'user32.dll', \
            gdi32, 'gdi32.dll'

    import kernel32, \
           ExitProcess, 'ExitProcess', \
           GetModuleHandle, 'GetModuleHandleA'

    import user32, \
           BeginPaint, 'BeginPaint', \
           CreateWindowEx, 'CreateWindowExA', \
           DefWindowProc, 'DefWindowProcA', \
           DispatchMessage, 'DispatchMessageA', \
           EndPaint, 'EndPaint', \
           GetMessage, 'GetMessageA', \
           InvalidateRect, 'InvalidateRect', \
           KillTimer, 'KillTimer', \
           LoadCursor, 'LoadCursorA', \
           LoadIcon, 'LoadIconA', \
           PostQuitMessage, 'PostQuitMessage', \
           RegisterClass, 'RegisterClassA', \
           SetTimer, 'SetTimer', \
           TranslateMessage, 'TranslateMessage'

    import gdi32, \
           GetStockObject, 'GetStockObject', \
           MoveToEx, 'MoveToEx', \
           SelectObject, 'SelectObject', \
           SetBkMode, 'SetBkMode', \
           SetTextAlign, 'SetTextAlign', \
           SetTextColor, 'SetTextColor', \
           TextOut, 'TextOutA'
