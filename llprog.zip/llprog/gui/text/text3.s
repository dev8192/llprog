; -----------------------------------------------------------
; Prints 'one, three' in a monospace font.
; After 3 seconds 'two' is inserted between 'one' and 'three'
; so that the result is 'one, two, three'.
; RichEdit Control.
; -----------------------------------------------------------

format PE GUI 4.0
entry start

include 'win32a.inc'

EM_SETCHARFORMAT    = WM_USER + 68
SCF_SELECTION       = 0x0001
CFM_COLOR           = 0x40000000
CFM_FACE            = 0x20000000

COLOR_RED           = 0x000000FF
COLOR_GREEN         = 0x0000FF00
COLOR_BLUE          = 0x00FF0000
COLOR_BLACK         = 0x00000000

TIMER_INSERT_ID     = 1
TIMER_DELAY         = 3000

POS_START           = 0
POS_ONE_END         = 3
POS_THREE_START     = 5
POS_TWO_END         = 8

section '.text' code readable executable

start:
    invoke  GetModuleHandle, 0
    mov     [wc.hInstance], eax
    invoke  LoadLibrary, richedit_dll
    invoke  LoadCursor, 0, IDC_ARROW
    mov     [wc.hCursor], eax
    invoke  RegisterClass, wc
    invoke  CreateWindowEx, 0, class_name, window_title, \
            WS_OVERLAPPEDWINDOW or WS_VISIBLE, CW_USEDEFAULT, \
            CW_USEDEFAULT, 400, 300, 0, 0, [wc.hInstance], 0
    mov     [hwnd_main], eax

msg_loop:
    invoke  GetMessage, msg, 0, 0, 0
    test    eax, eax
    jz      end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     msg_loop

end_loop:
    invoke  ExitProcess, [msg.wParam]

proc WindowProc hwnd, msg, wparam, lparam
    cmp     [msg], WM_CREATE
    je      .on_create
    cmp     [msg], WM_SIZE
    je      .on_size
    cmp     [msg], WM_TIMER
    je      .on_timer
    cmp     [msg], WM_DESTROY
    je      .on_destroy
    invoke  DefWindowProc, [hwnd], [msg], [wparam], [lparam]
    ret

.on_create:
    invoke  CreateWindowEx, 0, richedit_class, 0, \
            WS_CHILD or WS_VISIBLE or ES_MULTILINE, \
            0, 0, 0, 0, [hwnd], 0, [wc.hInstance], 0
    mov     [hwnd_edit], eax
    stdcall InsertText, POS_START, COLOR_RED, str_one
    stdcall InsertText, POS_ONE_END, COLOR_BLACK, str_comma
    stdcall InsertText, POS_THREE_START, COLOR_BLUE, str_three
    invoke  SetTimer, [hwnd], TIMER_INSERT_ID, TIMER_DELAY, 0
    xor     eax, eax
    ret

.on_size:
    mov     eax, [lparam]
    movzx   edx, ax
    shr     eax, 16
    invoke  MoveWindow, [hwnd_edit], 0, 0, edx, eax, 1
    xor     eax, eax
    ret

.on_timer:
    invoke  KillTimer, [hwnd], TIMER_INSERT_ID
    stdcall InsertText, POS_THREE_START, COLOR_GREEN, str_two
    stdcall InsertText, POS_TWO_END, COLOR_BLACK, str_comma
    xor     eax, eax
    ret

.on_destroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
    ret
endp

proc InsertText pos, color, text
    invoke  SendMessage, [hwnd_edit], EM_SETSEL, [pos], [pos]
    mov     eax, [color]
    mov     [char_format.crTextColor], eax
    invoke  SendMessage, [hwnd_edit], EM_SETCHARFORMAT, \
            SCF_SELECTION, char_format
    invoke  SendMessage, [hwnd_edit], EM_REPLACESEL, 0, [text]
    ret
endp

section '.data' data readable writeable

wc:
    .style          dd CS_HREDRAW or CS_VREDRAW
    .lpfnWndProc    dd WindowProc
    .cbClsExtra     dd 0
    .cbWndExtra     dd 0
    .hInstance      dd 0
    .hIcon          dd 0
    .hCursor        dd 0
    .hbrBackground  dd COLOR_WINDOW + 1
    .lpszMenuName   dd 0
    .lpszClassName  dd class_name

msg:
    .hwnd           dd 0
    .message        dd 0
    .wParam         dd 0
    .lParam         dd 0
    .time           dd 0
    .pt.x           dd 0
    .pt.y           dd 0

align 4
char_format:
    .cbSize          dd 60
    .dwMask          dd CFM_COLOR or CFM_FACE
    .dwEffects       dd 0
    .yHeight         dd 200
    .yOffset         dd 0
    .crTextColor     dd 0
    .bCharSet        db 0
    .bPitchAndFamily db 0
    .szFaceName      db 'Consolas', 0
                     rb 23
                     dw 0

hwnd_main       dd 0
hwnd_edit       dd 0

class_name      db 'MainWndClass', 0
window_title    db 'RichEdit Insertion Demo', 0
richedit_class  db 'RichEdit20A', 0
richedit_dll    db 'riched20.dll', 0

str_one         db 'one', 0
str_two         db 'two', 0
str_three       db 'three', 0
str_comma       db ', ', 0

section '.idata' import data readable writeable

library kernel32, 'KERNEL32.DLL',\
        user32, 'USER32.DLL'

import kernel32,\
       GetModuleHandle, 'GetModuleHandleA',\
       LoadLibrary, 'LoadLibraryA',\
       ExitProcess, 'ExitProcess'

import user32,\
       RegisterClass, 'RegisterClassA',\
       CreateWindowEx, 'CreateWindowExA',\
       DefWindowProc, 'DefWindowProcA',\
       GetMessage, 'GetMessageA',\
       TranslateMessage, 'TranslateMessage',\
       DispatchMessage, 'DispatchMessageA',\
       SendMessage, 'SendMessageA',\
       LoadCursor, 'LoadCursorA',\
       MoveWindow, 'MoveWindow',\
       SetTimer, 'SetTimer',\
       KillTimer, 'KillTimer',\
       PostQuitMessage, 'PostQuitMessage'
