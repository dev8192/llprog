; ---------------------------------------------
; Prints 'one, two, three' in a monospace font.
; After 1 second 'one' becomes red.
; After 2 seconds 'two' becomes green and
; after 3 seconds 'three' becomes blue.
; Rich edit
; ---------------------------------------------
format PE console
entry start

include 'win32a.inc'

TIMER_ID          = 1
TIMER_INTERVAL    = 1000

EM_EXSETSEL       = WM_USER + 55
EM_SETCHARFORMAT  = WM_USER + 68
SCF_SELECTION     = 1
CFM_COLOR         = 0x40000000

RED_COLOR         = 0x000000FF
GREEN_COLOR       = 0x0000FF00
BLUE_COLOR        = 0x00FF0000

MAIN_WND_WIDTH    = 300
MAIN_WND_HEIGHT   = 200
RICHEDIT_X        = 10
RICHEDIT_Y        = 10
RICHEDIT_WIDTH    = 250
RICHEDIT_HEIGHT   = 100

ONE_START         = 0
ONE_END           = 3
TWO_START         = 5
TWO_END           = 8
THREE_START       = 10
THREE_END         = 15

DESELECT_POS      = -1

struct CHARRANGE
    cpMin dd ?
    cpMax dd ?
ends

struct CHARFORMAT
    cbSize          dd ?
    dwMask          dd ?
    dwEffects       dd ?
    yHeight         dd ?
    yOffset         dd ?
    crTextColor     dd ?
    bCharSet        db ?
    bPitchAndFamily db ?
    szFaceName      rb 32
    padding         dw ?
ends

section '.data' data readable writeable

    main_class        db 'MAINCLASS', 0
    richedit_lib      db 'RICHED20.DLL', 0
    richedit_class    db 'RichEdit20A', 0
    initial_text      db 'one, two, three', 0

    hRichEdit         dd ?
    timer_count       dd 0

    cf  CHARFORMAT
    cr  CHARRANGE
    msg MSG
    wc  WNDCLASS

section '.text' code readable executable

start:
    invoke LoadLibrary, richedit_lib
    invoke GetModuleHandle, 0
    mov [wc.hInstance], eax
    mov [wc.lpfnWndProc], WindowProc
    mov [wc.lpszClassName], main_class
    mov [wc.hbrBackground], COLOR_WINDOW
    invoke RegisterClass, wc
    invoke CreateWindowEx, 0, main_class, 0, \
        WS_VISIBLE or WS_OVERLAPPEDWINDOW, \
        CW_USEDEFAULT, CW_USEDEFAULT, \
        MAIN_WND_WIDTH, MAIN_WND_HEIGHT, \
        0, 0, [wc.hInstance], 0

msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    cmp eax, 0
    jle end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp msg_loop

end_loop:
    invoke ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp [wmsg], WM_CREATE
    je .wm_create
    cmp [wmsg], WM_TIMER
    je .wm_timer
    cmp [wmsg], WM_DESTROY
    je .wm_destroy

.defwndproc:
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret

.wm_create:
    invoke CreateWindowEx, 0, richedit_class, 0, \
        WS_CHILD or WS_VISIBLE or ES_READONLY, \
        RICHEDIT_X, RICHEDIT_Y, RICHEDIT_WIDTH, RICHEDIT_HEIGHT, \
        [hwnd], 0, [wc.hInstance], 0
    mov [hRichEdit], eax
    invoke GetStockObject, ANSI_FIXED_FONT
    invoke SendMessage, [hRichEdit], WM_SETFONT, eax, FALSE
    invoke SendMessage, [hRichEdit], WM_SETTEXT, 0, initial_text
    invoke SetTimer, [hwnd], TIMER_ID, TIMER_INTERVAL, 0
    xor eax, eax
    ret

.wm_timer:
    inc [timer_count]
    cmp [timer_count], 1
    je .step_one
    cmp [timer_count], 2
    je .step_two
    cmp [timer_count], 3
    je .step_three
    xor eax, eax
    ret

.step_one:
    invoke ColorizeText, ONE_START, ONE_END, RED_COLOR
    xor eax, eax
    ret

.step_two:
    invoke ColorizeText, TWO_START, TWO_END, GREEN_COLOR
    xor eax, eax
    ret

.step_three:
    invoke ColorizeText, THREE_START, THREE_END, BLUE_COLOR
    invoke KillTimer, [hwnd], TIMER_ID
    xor eax, eax
    ret

.wm_destroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    ret
endp

proc ColorizeText start_pos, end_pos, text_color
    mov eax, [start_pos]
    mov [cr.cpMin], eax
    mov eax, [end_pos]
    mov [cr.cpMax], eax
    invoke SendMessage, [hRichEdit], EM_EXSETSEL, 0, cr
    
    mov [cf.cbSize], sizeof.CHARFORMAT
    mov [cf.dwMask], CFM_COLOR
    mov eax, [text_color]
    mov [cf.crTextColor], eax
    invoke SendMessage, [hRichEdit], EM_SETCHARFORMAT, SCF_SELECTION, cf
    
    mov [cr.cpMin], DESELECT_POS
    mov [cr.cpMax], DESELECT_POS
    invoke SendMessage, [hRichEdit], EM_EXSETSEL, 0, cr
    ret
endp

section '.idata' import data readable

    library kernel32, 'KERNEL32.DLL', \
        user32, 'USER32.DLL', \
        gdi32, 'GDI32.DLL'

    import kernel32, \
        ExitProcess, 'ExitProcess', \
        GetModuleHandle, 'GetModuleHandleA', \
        LoadLibrary, 'LoadLibraryA'

    import user32, \
        CreateWindowEx, 'CreateWindowExA', \
        DefWindowProc, 'DefWindowProcA', \
        DispatchMessage, 'DispatchMessageA', \
        GetMessage, 'GetMessageA', \
        KillTimer, 'KillTimer', \
        PostQuitMessage, 'PostQuitMessage', \
        RegisterClass, 'RegisterClassA', \
        SendMessage, 'SendMessageA', \
        SetTimer, 'SetTimer', \
        TranslateMessage, 'TranslateMessage'

    import gdi32, \
        GetStockObject, 'GetStockObject'
