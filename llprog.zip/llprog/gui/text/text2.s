format PE GUI 4.0
entry start

include 'win32a.inc'

COLOR_RED = 0x0000FF
COLOR_GREEN = 0x00FF00
COLOR_BLUE = 0xFF0000

TIMER_ID = 1
TIMER_DELAY = 3000
STR_LEN = 5

WINDOW_WIDTH = 400
WINDOW_HEIGHT = 200

section '.data' data readable writeable

class_name db 'MyClass', 0
window_name db 'Insertion Demo', 0

str_one db 'one, '
str_two db 'two, '
str_three db 'three'

wc:
    .style dd 0
    .lpfnWndProc dd WindowProc
    .cbClsExtra dd 0
    .cbWndExtra dd 0
    .hInstance dd 0
    .hIcon dd 0
    .hCursor dd 0
    .hbrBackground dd COLOR_WINDOW + 1
    .lpszMenuName dd 0
    .lpszClassName dd class_name

msg MSG
ps PAINTSTRUCT

sz_cx dd 0
sz_cy dd 0

hwnd dd 0
hdc dd 0
step dd 0

pos_x1 dd 0
width2 dd 0
width3 dd 0
text_h dd 0

section '.text' code readable executable

start:
    invoke GetModuleHandle, NULL
    mov [wc.hInstance], eax
    invoke LoadIcon, NULL, IDI_APPLICATION
    mov [wc.hIcon], eax
    invoke LoadCursor, NULL, IDC_ARROW
    mov [wc.hCursor], eax
    invoke RegisterClass, wc
    invoke CreateWindowEx, 0, class_name, window_name, WS_OVERLAPPEDWINDOW \
        or WS_VISIBLE, CW_USEDEFAULT, CW_USEDEFAULT, WINDOW_WIDTH, \
        WINDOW_HEIGHT, NULL, NULL, [wc.hInstance], NULL
    mov [hwnd], eax
    invoke SetTimer, [hwnd], TIMER_ID, TIMER_DELAY, NULL

msg_loop:
    invoke GetMessage, msg, NULL, 0, 0
    cmp eax, 0
    je end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp msg_loop

end_loop:
    invoke ExitProcess, [msg.wParam]

proc WindowProc, wnd, wmsg, wparam, lparam
    cmp [wmsg], WM_DESTROY
    je .wmdestroy
    cmp [wmsg], WM_PAINT
    je .wmpaint
    cmp [wmsg], WM_TIMER
    je .wmtimer
    invoke DefWindowProc, [wnd], [wmsg], [wparam], [lparam]
    ret
.wmpaint:
    invoke BeginPaint, [wnd], ps
    mov [hdc], eax
    invoke GetStockObject, SYSTEM_FIXED_FONT
    invoke SelectObject, [hdc], eax
    invoke GetSysColor, COLOR_WINDOW
    invoke SetBkColor, [hdc], eax
    invoke SetTextColor, [hdc], COLOR_RED
    invoke TextOut, [hdc], 0, 0, str_one, STR_LEN
    invoke GetTextExtentPoint32, [hdc], str_one, STR_LEN, sz_cx
    cmp [step], 0
    je .draw_three
    invoke SetTextColor, [hdc], COLOR_GREEN
    invoke TextOut, [hdc], [sz_cx], 0, str_two, STR_LEN
    mov ebx, [sz_cx]
    invoke GetTextExtentPoint32, [hdc], str_two, STR_LEN, sz_cx
    add [sz_cx], ebx
.draw_three:
    invoke SetTextColor, [hdc], COLOR_BLUE
    invoke TextOut, [hdc], [sz_cx], 0, str_three, STR_LEN
    invoke EndPaint, [wnd], ps
    xor eax, eax
    ret
.wmtimer:
    invoke KillTimer, [wnd], TIMER_ID
    mov [step], 1
    invoke GetDC, [wnd]
    mov [hdc], eax
    invoke GetStockObject, SYSTEM_FIXED_FONT
    invoke SelectObject, [hdc], eax
    invoke GetSysColor, COLOR_WINDOW
    invoke SetBkColor, [hdc], eax
    invoke GetTextExtentPoint32, [hdc], str_one, STR_LEN, sz_cx
    mov ebx, [sz_cx]
    mov [pos_x1], ebx
    invoke GetTextExtentPoint32, [hdc], str_two, STR_LEN, sz_cx
    mov ebx, [sz_cx]
    mov [width2], ebx
    invoke GetTextExtentPoint32, [hdc], str_three, STR_LEN, sz_cx
    mov ebx, [sz_cx]
    mov [width3], ebx
    mov ebx, [sz_cy]
    mov [text_h], ebx
    mov eax, [pos_x1]
    add eax, [width2]
    invoke BitBlt, [hdc], eax, 0, [width3], [text_h], \
        [hdc], [pos_x1], 0, SRCCOPY
    invoke SetTextColor, [hdc], COLOR_GREEN
    invoke TextOut, [hdc], [pos_x1], 0, str_two, STR_LEN
    invoke ReleaseDC, [wnd], [hdc]
    xor eax, eax
    ret
.wmdestroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    ret
endp

section '.idata' import data readable

library kernel32, 'KERNEL32.DLL', \
    user32, 'USER32.DLL', \
    gdi32, 'GDI32.DLL'

import kernel32, \
    ExitProcess, 'ExitProcess', \
    GetModuleHandle, 'GetModuleHandleA'

import user32, \
    BeginPaint, 'BeginPaint', \
    CreateWindowEx, 'CreateWindowExA', \
    DefWindowProc, 'DefWindowProcA', \
    DispatchMessage, 'DispatchMessageA', \
    EndPaint, 'EndPaint', \
    GetDC, 'GetDC', \
    GetMessage, 'GetMessageA', \
    GetSysColor, 'GetSysColor', \
    KillTimer, 'KillTimer', \
    LoadCursor, 'LoadCursorA', \
    LoadIcon, 'LoadIconA', \
    PostQuitMessage, 'PostQuitMessage', \
    RegisterClass, 'RegisterClassA', \
    ReleaseDC, 'ReleaseDC', \
    SetTimer, 'SetTimer', \
    TranslateMessage, 'TranslateMessage'

import gdi32, \
    BitBlt, 'BitBlt', \
    GetStockObject, 'GetStockObject', \
    GetTextExtentPoint32, 'GetTextExtentPoint32A', \
    SelectObject, 'SelectObject', \
    SetBkColor, 'SetBkColor', \
    SetTextColor, 'SetTextColor', \
    TextOut, 'TextOutA'
