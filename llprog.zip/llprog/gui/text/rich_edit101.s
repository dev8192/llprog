format PE console
entry start

include 'win32a.inc'

WINDOW_WIDTH = 600
WINDOW_HEIGHT = 400

section '.data' data readable writeable

class_name db 'RichEditApp', 0
window_name db 'RichEdit Control Example', 0
richedit_dll db 'RICHED20.DLL', 0
richedit_class db 'RichEdit20A', 0

sample_text db 'Welcome to the RichEdit control!', 13, 10, \
    'This control is loaded dynamically from RICHED20.DLL.', 13, 10, \
    'You can type, select, and scroll here.', 0

wc:
    .style dd 0
    .lpfnWndProc dd WindowProc
    .cbClsExtra dd 0
    .cbWndExtra dd 0
    .hInstance dd 0
    .hIcon dd 0
    .hCursor dd 0
    .hbrBackground dd COLOR_WINDOW + 1
    .lpszMenuName dd 0
    .lpszClassName dd class_name

msg:
    .hwnd dd 0
    .message dd 0
    .wParam dd 0
    .lParam dd 0
    .time dd 0
    .pt.x dd 0
    .pt.y dd 0

rc:
    .left dd 0
    .top dd 0
    .right dd 0
    .bottom dd 0

hwnd dd 0
hRichEdit dd 0

section '.text' code readable executable

start:
    invoke GetModuleHandle, 0
    mov [wc.hInstance], eax
    invoke LoadIcon, 0, IDI_APPLICATION
    mov [wc.hIcon], eax
    invoke LoadCursor, 0, IDC_ARROW
    mov [wc.hCursor], eax
    invoke RegisterClass, wc
    invoke CreateWindowEx, 0, class_name, window_name, WS_OVERLAPPEDWINDOW \
        or WS_VISIBLE, CW_USEDEFAULT, CW_USEDEFAULT, WINDOW_WIDTH, \
        WINDOW_HEIGHT, 0, 0, [wc.hInstance], 0
    mov [hwnd], eax
    invoke LoadLibrary, richedit_dll
    invoke CreateWindowEx, WS_EX_CLIENTEDGE, richedit_class, 0, \
        WS_CHILD or WS_VISIBLE or ES_MULTILINE or WS_VSCROLL or WS_HSCROLL, \
        0, 0, 0, 0, [hwnd], 0, [wc.hInstance], 0
    mov [hRichEdit], eax
    invoke SendMessage, [hRichEdit], WM_SETTEXT, 0, sample_text

msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    cmp eax, 0
    je end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp msg_loop

end_loop:
    invoke ExitProcess, [msg.wParam]

proc WindowProc, wnd, wmsg, wparam, lparam
    cmp [wmsg], WM_SIZE
    je .wmsize
    cmp [wmsg], WM_DESTROY
    je .wmdestroy
    invoke DefWindowProc, [wnd], [wmsg], [wparam], [lparam]
    ret
.wmsize:
    invoke GetClientRect, [wnd], rc
    invoke MoveWindow, [hRichEdit], 0, 0, [rc.right], [rc.bottom], 1
    xor eax, eax
    ret
.wmdestroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    ret
endp

section '.idata' import data readable

library kernel32, 'KERNEL32.DLL', \
    user32, 'USER32.DLL'

import kernel32, \
    ExitProcess, 'ExitProcess', \
    GetModuleHandle, 'GetModuleHandleA', \
    LoadLibrary, 'LoadLibraryA'

import user32, \
    CreateWindowEx, 'CreateWindowExA', \
    DefWindowProc, 'DefWindowProcA', \
    DispatchMessage, 'DispatchMessageA', \
    GetClientRect, 'GetClientRect', \
    GetMessage, 'GetMessageA', \
    LoadCursor, 'LoadCursorA', \
    LoadIcon, 'LoadIconA', \
    MoveWindow, 'MoveWindow', \
    PostQuitMessage, 'PostQuitMessage', \
    RegisterClass, 'RegisterClassA', \
    SendMessage, 'SendMessageA', \
    TranslateMessage, 'TranslateMessage'
