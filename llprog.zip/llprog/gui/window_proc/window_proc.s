format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt_dwp         db 'dwp: %d %d %d %d', 10, 0
    fmt_pqm         db 'pqm: %d', 10, 0
    DefWindowProc   dd _DefWindowProc
    PostQuitMessage dd _PostQuitMessage

section '.text' code readable executable
start:
    stdcall WindowProc, -1, WM_DESTROY, -1, -1
    stdcall WindowProc, -1, WM_PAINT, -1, -1
    cinvoke exit, 0

proc _DefWindowProc hWnd, wMsg, wParam, lParam
    cinvoke printf, fmt_dwp, [hWnd], [wMsg], [wParam], [lParam]
    ret
endp

proc _PostQuitMessage nExitCode
    cinvoke printf, fmt_pqm, [nExitCode]
    ret
endp

proc WindowProc hWnd, wMsg, wParam, lParam
    cmp [wMsg], WM_DESTROY
    je .wm_destroy
    invoke DefWindowProc, [hWnd], [wMsg], [wParam], [lParam]
    ret
.wm_destroy:
    invoke PostQuitMessage, 123
    xor eax, eax
    ret
endp

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
