format PE GUI 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    wc WNDCLASS
    msg MSG
    class_name db 'F11Toggle', 0
    is_fullscreen dd 0
    wp WINDOWPLACEMENT

section '.text' code readable executable
start:
    invoke GetModuleHandle, 0
    mov [wc.hInstance], eax
    mov [wc.lpfnWndProc], WindowProc
    invoke LoadCursor, 0, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.lpszClassName], class_name
    mov [wc.hbrBackground], COLOR_WINDOW+1
    invoke RegisterClass, wc
    invoke CreateWindowEx, 0, class_name, class_name,\
        WS_OVERLAPPEDWINDOW + WS_VISIBLE,\
        CW_USEDEFAULT, CW_USEDEFAULT, 800, 600, 0, 0, [wc.hInstance], 0
msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    test eax, eax
    jz end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp msg_loop
end_loop:
    invoke ExitProcess, [msg.wParam]

proc WindowProc uses ebx, hwnd, wmsg, wparam, lparam
    cmp [wmsg], WM_DESTROY
    je .wmdestroy
    cmp [wmsg], WM_KEYDOWN
    je .wmkeydown
.defwndproc:
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret
.wmkeydown:
    cmp [wparam], VK_F11
    jne .defwndproc
    cmp [is_fullscreen], 0
    jne .restore
    mov [wp.length], sizeof.WINDOWPLACEMENT
    invoke GetWindowPlacement, [hwnd], wp
    invoke GetWindowLong, [hwnd], GWL_STYLE
    and eax, not WS_OVERLAPPEDWINDOW
    invoke SetWindowLong, [hwnd], GWL_STYLE, eax
    invoke GetSystemMetrics, SM_CXSCREEN
    mov ebx, eax
    invoke GetSystemMetrics, SM_CYSCREEN
    invoke SetWindowPos, [hwnd], 0, 0, 0, ebx, eax,\
        SWP_FRAMECHANGED or SWP_NOZORDER
    mov [is_fullscreen], 1
    ret
.restore:
    invoke GetWindowLong, [hwnd], GWL_STYLE
    or eax, WS_OVERLAPPEDWINDOW
    invoke SetWindowLong, [hwnd], GWL_STYLE, eax
    invoke SetWindowPlacement, [hwnd], wp
    invoke SetWindowPos, [hwnd], 0, 0, 0, 0, 0,\
        SWP_NOMOVE or SWP_NOSIZE or SWP_NOZORDER or SWP_FRAMECHANGED
    mov [is_fullscreen], 0
    ret
.wmdestroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    ret
endp

section '.idata' import data readable
    library kernel32,               'KERNEL32.DLL',\
            user32,                 'USER32.DLL'
    import  kernel32,\
            GetModuleHandle,        'GetModuleHandleA',\
            ExitProcess,            'ExitProcess'
    import  user32,\
            LoadCursor,             'LoadCursorA',\
            RegisterClass,          'RegisterClassA',\
            CreateWindowEx,         'CreateWindowExA',\
            GetMessage,             'GetMessageA',\
            TranslateMessage,       'TranslateMessage',\
            DispatchMessage,        'DispatchMessageA',\
            DefWindowProc,          'DefWindowProcA',\
            GetWindowPlacement,     'GetWindowPlacement',\
            GetWindowLong,          'GetWindowLongA',\
            SetWindowLong,          'SetWindowLongA',\
            GetSystemMetrics,       'GetSystemMetrics',\
            SetWindowPos,           'SetWindowPos',\
            SetWindowPlacement,     'SetWindowPlacement',\
            PostQuitMessage,        'PostQuitMessage'
