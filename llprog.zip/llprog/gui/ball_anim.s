format PE console
entry start

include 'win32a.inc'

uIDEvent = 1

section '.data' data readable writeable
    wc WNDCLASSEX sizeof.WNDCLASSEX, 0, WindowProc,\
        0, 0, NULL, NULL, NULL, COLOR_WINDOW+1, NULL, class_name, NULL
    msg_struct MSG
    rect RECT
    ps PAINTSTRUCT
    class_name db 'AnimClass', 0
    window_name db '1 Second Animation', 0

section '.text' code readable executable

start:
    invoke GetModuleHandle, 0
    mov [wc.hInstance], eax
    invoke LoadCursor, 0, IDC_ARROW
    mov [wc.hCursor], eax

    invoke RegisterClassEx, wc

    invoke CreateWindowEx, 0, class_name, window_name, WS_VISIBLE+WS_OVERLAPPEDWINDOW, \
           CW_USEDEFAULT, CW_USEDEFAULT, 600, 400, NULL, NULL, [wc.hInstance], NULL

msg_loop:
    invoke GetMessage, msg_struct, NULL, 0, 0
    test eax, eax
    jz end_loop
    invoke TranslateMessage, msg_struct
    invoke DispatchMessage, msg_struct
    jmp msg_loop

end_loop:
    invoke ExitProcess, [msg_struct.wParam]

proc WindowProc uses ebx, hwnd, uMsg, wParam, lParam
    cmp [uMsg], WM_PAINT
    je .wm_paint
    cmp [uMsg], WM_TIMER
    je .wm_timer
    cmp [uMsg], WM_CREATE
    je .wm_create
    cmp [uMsg], WM_DESTROY
    je .wm_destroy

.def_proc:
    invoke DefWindowProc, [hwnd], [uMsg], [wParam], [lParam]
    ret

.wm_create:
    invoke SetTimer, [hwnd], uIDEvent, 16, NULL
    xor eax, eax
    ret

.wm_timer:
    invoke InvalidateRect, [hwnd], NULL, TRUE
    xor eax, eax
    ret

.wm_paint:
    invoke BeginPaint, [hwnd], ps
    invoke GetClientRect, [hwnd], rect

    mov ebx, [rect.right]
    sub ebx, 50
    cmp ebx, 0
    jge .calc_time
    xor ebx, ebx

.calc_time:
    invoke GetTickCount
    xor edx, edx
    mov ecx, 2000
    div ecx

    cmp edx, 1000
    jl .moving_right
    mov eax, 2000
    sub eax, edx
    jmp .calc_pos
.moving_right:
    mov eax, edx

.calc_pos:
    imul eax, ebx
    xor edx, edx
    mov ecx, 1000
    div ecx
    push eax

    mov ecx, [rect.bottom]
    sub ecx, 50
    shr ecx, 1

    invoke GetStockObject, BLACK_BRUSH
    invoke SelectObject, [ps.hdc], eax

    pop eax
    mov ebx, eax
    add ebx, 50
    mov edx, ecx
    add edx, 50

    invoke Ellipse, [ps.hdc], eax, ecx, ebx, edx

    invoke EndPaint, [hwnd], ps
    xor eax, eax
    ret

.wm_destroy:
    invoke KillTimer, [hwnd], uIDEvent
    invoke PostQuitMessage, 0
    xor eax, eax
    ret
endp

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            user32, 'user32.dll',\
            gdi32, 'gdi32.dll'

    import kernel32,\
           GetModuleHandle, 'GetModuleHandleA',\
           GetTickCount, 'GetTickCount',\
           ExitProcess, 'ExitProcess'

    import user32,\
           LoadCursor, 'LoadCursorA',\
           RegisterClassEx, 'RegisterClassExA',\
           CreateWindowEx, 'CreateWindowExA',\
           GetMessage, 'GetMessageA',\
           TranslateMessage, 'TranslateMessage',\
           DispatchMessage, 'DispatchMessageA',\
           DefWindowProc, 'DefWindowProcA',\
           PostQuitMessage, 'PostQuitMessage',\
           SetTimer, 'SetTimer',\
           KillTimer, 'KillTimer',\
           BeginPaint, 'BeginPaint',\
           EndPaint, 'EndPaint',\
           GetClientRect, 'GetClientRect',\
           InvalidateRect, 'InvalidateRect'

    import gdi32,\
           GetStockObject, 'GetStockObject',\
           SelectObject, 'SelectObject',\
           Ellipse, 'Ellipse'
