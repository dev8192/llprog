format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    class_name     db 'EventWindowClass', 0
    title          db 'Event Logger Window', 0
    fmt_known      db "%02d:%02d:%02d.%03d | %-16s | w: 0x%08X | l: 0x%08X", 10, 0
    fmt_unknown    db "%02d:%02d:%02d.%03d | MSG: 0x%04X      | w: 0x%08X | l: 0x%08X", 10, 0
    wc             WNDCLASSEX
    msg            MSG

    s_create       db 'WM_CREATE', 0
    s_destroy      db 'WM_DESTROY', 0
    s_move         db 'WM_MOVE', 0
    s_size         db 'WM_SIZE', 0
    s_activate     db 'WM_ACTIVATE', 0
    s_setfocus     db 'WM_SETFOCUS', 0
    s_killfocus    db 'WM_KILLFOCUS', 0
    s_paint        db 'WM_PAINT', 0
    s_close        db 'WM_CLOSE', 0
    s_erasebkgnd   db 'WM_ERASEBKGND', 0
    s_showwindow   db 'WM_SHOWWINDOW', 0
    s_nchittest    db 'WM_NCHITTEST', 0
    s_ncmousemove  db 'WM_NCMOUSEMOVE', 0
    s_keydown      db 'WM_KEYDOWN', 0
    s_keyup        db 'WM_KEYUP', 0
    s_char         db 'WM_CHAR', 0
    s_mousemove    db 'WM_MOUSEMOVE', 0
    s_lbuttondown  db 'WM_LBUTTONDOWN', 0
    s_lbuttonup    db 'WM_LBUTTONUP', 0
    s_rbuttondown  db 'WM_RBUTTONDOWN', 0
    s_rbuttonup    db 'WM_RBUTTONUP', 0
    s_mousewheel   db 'WM_MOUSEWHEEL', 0

    align 4
    msg_table:
        dd 0x0001, s_create
        dd 0x0002, s_destroy
        dd 0x0003, s_move
        dd 0x0005, s_size
        dd 0x0006, s_activate
        dd 0x0007, s_setfocus
        dd 0x0008, s_killfocus
        dd 0x000F, s_paint
        dd 0x0010, s_close
        dd 0x0014, s_erasebkgnd
        dd 0x0018, s_showwindow
        dd 0x0084, s_nchittest
        dd 0x00A0, s_ncmousemove
        dd 0x0100, s_keydown
        dd 0x0101, s_keyup
        dd 0x0102, s_char
        dd 0x0200, s_mousemove
        dd 0x0201, s_lbuttondown
        dd 0x0202, s_lbuttonup
        dd 0x0204, s_rbuttondown
        dd 0x0205, s_rbuttonup
        dd 0x020A, s_mousewheel
        dd 0, 0

section '.code' code readable executable
start:
    mov     [wc.cbSize], sizeof.WNDCLASSEX
    mov     [wc.lpfnWndProc], WindowProc
    mov     [wc.style], CS_HREDRAW + CS_VREDRAW
    mov     [wc.hbrBackground], COLOR_WINDOW + 1
    mov     [wc.lpszClassName], class_name

    invoke  GetModuleHandle, 0
    mov     [wc.hInstance], eax

    invoke  LoadCursor, 0, IDC_ARROW
    mov     [wc.hCursor], eax

    invoke  RegisterClassEx, wc

    invoke  CreateWindowEx, 0, class_name, title, WS_VISIBLE + WS_OVERLAPPEDWINDOW, 128, 128, 400, 300, 0, 0, [wc.hInstance], 0

    .msg_loop:
    invoke  GetMessage, msg, 0, 0, 0
    test    eax, eax
    je      .end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     .msg_loop

    .end_loop:
    invoke  ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    local   loc_time SYSTEMTIME
    push    esi
    push    ebx

    lea     eax, [loc_time]
    invoke  GetLocalTime, eax

    mov     ebx, [wmsg]
    mov     esi, msg_table
    .find_msg:
    mov     edx, [esi]
    test    edx, edx
    jz      .not_found
    cmp     ebx, edx
    je      .found
    add     esi, 8
    jmp     .find_msg

    .found:
    push    [lparam]
    push    [wparam]
    push    dword [esi+4]
    movzx   eax, [loc_time.wMilliseconds]
    push    eax
    movzx   eax, [loc_time.wSecond]
    push    eax
    movzx   eax, [loc_time.wMinute]
    push    eax
    movzx   eax, [loc_time.wHour]
    push    eax
    push    fmt_known
    call    [printf]
    add     esp, 32
    jmp     .process_msg

    .not_found:
    push    [lparam]
    push    [wparam]
    push    [wmsg]
    movzx   eax, [loc_time.wMilliseconds]
    push    eax
    movzx   eax, [loc_time.wSecond]
    push    eax
    movzx   eax, [loc_time.wMinute]
    push    eax
    movzx   eax, [loc_time.wHour]
    push    eax
    push    fmt_unknown
    call    [printf]
    add     esp, 32

    .process_msg:
    cmp     [wmsg], WM_DESTROY
    je      .wm_destroy

    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    jmp     .done

    .wm_destroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax

    .done:
    pop     ebx
    pop     esi
    ret
endp

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL',\
            user32, 'USER32.DLL',\
            msvcrt, 'MSVCRT.DLL'

    import  kernel32,\
            GetModuleHandle, 'GetModuleHandleA',\
            GetLocalTime, 'GetLocalTime',\
            ExitProcess, 'ExitProcess'

    import  user32,\
            RegisterClassEx, 'RegisterClassExA',\
            CreateWindowEx, 'CreateWindowExA',\
            DefWindowProc, 'DefWindowProcA',\
            GetMessage, 'GetMessageA',\
            TranslateMessage, 'TranslateMessage',\
            DispatchMessage, 'DispatchMessageA',\
            LoadCursor, 'LoadCursorA',\
            PostQuitMessage, 'PostQuitMessage'

    import  msvcrt,\
            printf, 'printf'
