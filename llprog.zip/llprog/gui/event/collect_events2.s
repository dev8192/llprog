format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    class_name  db 'EventCounterClass', 0
    title       db 'Event Counter Window', 0
    wc          WNDCLASSEX
    msg         MSG

    fmt_start   db "{", 10, 0
    fmt_item    db "    0x%04X: %d,", 10, 0
    fmt_end     db "} // keys: %d, total: %d", 10, 0

    keys_count  dd 0
    total_count dd 0
    events      rd 2048

section '.code' code readable executable
start:
    mov     [wc.cbSize], sizeof.WNDCLASSEX
    mov     [wc.lpfnWndProc], WindowProc
    mov     [wc.style], CS_HREDRAW + CS_VREDRAW
    mov     [wc.hbrBackground], COLOR_WINDOW + 1
    mov     [wc.lpszClassName], class_name

    invoke  GetModuleHandle, 0
    mov     [wc.hInstance], eax

    invoke  LoadCursor, 0, IDC_ARROW
    mov     [wc.hCursor], eax

    invoke  RegisterClassEx, wc

    invoke  CreateWindowEx, 0, class_name, title, WS_VISIBLE + WS_OVERLAPPEDWINDOW, 128, 128, 400, 300, 0, 0, [wc.hInstance], 0

  .msg_loop:
    invoke  GetMessage, msg, 0, 0, 0
    test    eax, eax
    je      .end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     .msg_loop

  .end_loop:
    invoke  ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    push    ebx
    push    esi
    push    edi

    mov     ebx, [wmsg]

    inc     dword [total_count]

    mov     ecx, [keys_count]
    mov     esi, events
  .check_loop:
    test    ecx, ecx
    jz      .not_seen
    mov     eax, [esi]
    cmp     eax, ebx
    je      .found_seen
    add     esi, 8
    dec     ecx
    jmp     .check_loop

  .not_seen:
    mov     eax, [keys_count]
    cmp     eax, 1000
    jge     .print_obj
    shl     eax, 3
    mov     dword [events + eax], ebx
    mov     dword [events + eax + 4], 1
    inc     dword [keys_count]
    jmp     .print_obj

  .found_seen:
    inc     dword [esi + 4]

  .print_obj:
    push    fmt_start
    call    [printf]
    add     esp, 4

    mov     ecx, [keys_count]
    mov     esi, events
    test    ecx, ecx
    jz      .print_end

  .print_loop:
    push    ecx
    push    dword [esi + 4]
    push    dword [esi]
    push    fmt_item
    call    [printf]
    add     esp, 12
    pop     ecx

    add     esi, 8
    dec     ecx
    jnz     .print_loop

  .print_end:
    push    [total_count]
    push    [keys_count]
    push    fmt_end
    call    [printf]
    add     esp, 12

    cmp     [wmsg], WM_DESTROY
    je      .wm_destroy

    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    jmp     .done

  .wm_destroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax

  .done:
    pop     edi
    pop     esi
    pop     ebx
    ret
endp

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL',\
            user32, 'USER32.DLL',\
            msvcrt, 'MSVCRT.DLL'

    import  kernel32,\
            GetModuleHandle, 'GetModuleHandleA',\
            ExitProcess, 'ExitProcess'

    import  user32,\
            RegisterClassEx, 'RegisterClassExA',\
            CreateWindowEx, 'CreateWindowExA',\
            DefWindowProc, 'DefWindowProcA',\
            GetMessage, 'GetMessageA',\
            TranslateMessage, 'TranslateMessage',\
            DispatchMessage, 'DispatchMessageA',\
            LoadCursor, 'LoadCursorA',\
            PostQuitMessage, 'PostQuitMessage'

    import  msvcrt,\
            printf, 'printf'
