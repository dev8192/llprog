format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    class_name    db 'EventCounterClass', 0
    title         db 'Event Counter Window', 0
    wc            WNDCLASSEX
    msg           MSG

    fmt_obj_start db "{", 10, 0
    fmt_known     db "    %s: %d,", 10, 0
    fmt_unknown   db "    MSG_0x%04X: %d,", 10, 0
    fmt_obj_end   db "}", 10, 0

    s_null        db 'WM_NULL', 0
    s_create      db 'WM_CREATE', 0
    s_destroy     db 'WM_DESTROY', 0
    s_move        db 'WM_MOVE', 0
    s_size        db 'WM_SIZE', 0
    s_activate    db 'WM_ACTIVATE', 0
    s_setfocus    db 'WM_SETFOCUS', 0
    s_killfocus   db 'WM_KILLFOCUS', 0
    s_paint       db 'WM_PAINT', 0
    s_close       db 'WM_CLOSE', 0
    s_erasebkgnd  db 'WM_ERASEBKGND', 0
    s_showwindow  db 'WM_SHOWWINDOW', 0
    s_nchittest   db 'WM_NCHITTEST', 0
    s_ncmousemove db 'WM_NCMOUSEMOVE', 0
    s_keydown     db 'WM_KEYDOWN', 0
    s_keyup       db 'WM_KEYUP', 0
    s_char        db 'WM_CHAR', 0
    s_mousemove   db 'WM_MOUSEMOVE', 0
    s_lbuttondown db 'WM_LBUTTONDOWN', 0
    s_lbuttonup   db 'WM_LBUTTONUP', 0
    s_rbuttondown db 'WM_RBUTTONDOWN', 0
    s_rbuttonup   db 'WM_RBUTTONUP', 0
    s_mousewheel  db 'WM_MOUSEWHEEL', 0

    align 4
    known_msgs:
        dd 0x0000, s_null
        dd 0x0001, s_create
        dd 0x0002, s_destroy
        dd 0x0003, s_move
        dd 0x0005, s_size
        dd 0x0006, s_activate
        dd 0x0007, s_setfocus
        dd 0x0008, s_killfocus
        dd 0x000F, s_paint
        dd 0x0010, s_close
        dd 0x0014, s_erasebkgnd
        dd 0x0018, s_showwindow
        dd 0x0084, s_nchittest
        dd 0x00A0, s_ncmousemove
        dd 0x0100, s_keydown
        dd 0x0101, s_keyup
        dd 0x0102, s_char
        dd 0x0200, s_mousemove
        dd 0x0201, s_lbuttondown
        dd 0x0202, s_lbuttonup
        dd 0x0204, s_rbuttondown
        dd 0x0205, s_rbuttonup
        dd 0x020A, s_mousewheel
        dd 0xFFFFFFFF, 0

    seen_count    dd 0
    seen_msgs     rd 2048

section '.code' code readable executable
start:
    mov     [wc.cbSize], sizeof.WNDCLASSEX
    mov     [wc.lpfnWndProc], WindowProc
    mov     [wc.style], CS_HREDRAW + CS_VREDRAW
    mov     [wc.hbrBackground], COLOR_WINDOW + 1
    mov     [wc.lpszClassName], class_name

    invoke  GetModuleHandle, 0
    mov     [wc.hInstance], eax

    invoke  LoadCursor, 0, IDC_ARROW
    mov     [wc.hCursor], eax

    invoke  RegisterClassEx, wc

    invoke  CreateWindowEx, 0, class_name, title, WS_VISIBLE + WS_OVERLAPPEDWINDOW, 128, 128, 400, 300, 0, 0, [wc.hInstance], 0

  .msg_loop:
    invoke  GetMessage, msg, 0, 0, 0
    test    eax, eax
    je      .end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     .msg_loop

  .end_loop:
    invoke  ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    push    ebx
    push    esi
    push    edi

    mov     ebx, [wmsg]

    mov     ecx, [seen_count]
    mov     esi, seen_msgs
  .check_loop:
    test    ecx, ecx
    jz      .not_seen
    mov     eax, [esi]
    cmp     eax, ebx
    je      .found_seen
    add     esi, 8
    dec     ecx
    jmp     .check_loop

  .not_seen:
    mov     eax, [seen_count]
    cmp     eax, 1000
    jge     .print_obj
    shl     eax, 3
    mov     dword [seen_msgs + eax], ebx
    mov     dword [seen_msgs + eax + 4], 1
    inc     dword [seen_count]
    jmp     .print_obj

  .found_seen:
    inc     dword [esi + 4]

  .print_obj:
    push    fmt_obj_start
    call    [printf]
    add     esp, 4

    mov     ecx, [seen_count]
    mov     esi, seen_msgs
  .print_loop:
    push    ecx
    mov     ebx, [esi]
    mov     edi, [esi + 4]

    mov     edx, known_msgs
  .find_name:
    mov     eax, [edx]
    cmp     eax, 0xFFFFFFFF
    je      .name_unknown
    cmp     eax, ebx
    je      .name_known
    add     edx, 8
    jmp     .find_name

  .name_unknown:
    push    edi
    push    ebx
    push    fmt_unknown
    call    [printf]
    add     esp, 12
    jmp     .print_next

  .name_known:
    push    edi
    push    dword [edx + 4]
    push    fmt_known
    call    [printf]
    add     esp, 12

  .print_next:
    pop     ecx
    add     esi, 8
    dec     ecx
    jnz     .print_loop

    push    fmt_obj_end
    call    [printf]
    add     esp, 4

    cmp     [wmsg], WM_DESTROY
    je      .wm_destroy

    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    jmp     .done

  .wm_destroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax

  .done:
    pop     edi
    pop     esi
    pop     ebx
    ret
endp

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL',\
            user32, 'USER32.DLL',\
            msvcrt, 'MSVCRT.DLL'

    import  kernel32,\
            GetModuleHandle, 'GetModuleHandleA',\
            ExitProcess, 'ExitProcess'

    import  user32,\
            RegisterClassEx, 'RegisterClassExA',\
            CreateWindowEx, 'CreateWindowExA',\
            DefWindowProc, 'DefWindowProcA',\
            GetMessage, 'GetMessageA',\
            TranslateMessage, 'TranslateMessage',\
            DispatchMessage, 'DispatchMessageA',\
            LoadCursor, 'LoadCursorA',\
            PostQuitMessage, 'PostQuitMessage'

    import  msvcrt,\
            printf, 'printf'
