format PE console
;format PE GUI
entry start

include 'win32a.inc'

section '.data' data readable writeable
    wc          WNDCLASSEX
    msg         MSG
    hwnd        dd ?
    hFont       dd ?
    hOldFont    dd ?
    ps          PAINTSTRUCT
    rect        RECT
    buffer      rb 64
    fmt         db '%d x %d', 0
    fmt2        db '%d x %d', 10, 0
    className   db 'SizeWindow', 0
    titleName   db 'Window Dimensions', 0

section '.text' code readable executable
start:
    mov     [wc.cbSize], sizeof.WNDCLASSEX
    mov     [wc.style], CS_HREDRAW or CS_VREDRAW
    mov     [wc.lpfnWndProc], WindowProc
    mov     [wc.cbClsExtra], 0
    mov     [wc.cbWndExtra], 0
    invoke  GetModuleHandle, 0
    mov     [wc.hInstance], eax
    invoke  LoadIcon, 0, IDI_APPLICATION
    mov     [wc.hIcon], eax
    mov     [wc.hIconSm], eax
    invoke  LoadCursor, 0, IDC_ARROW
    mov     [wc.hCursor], eax
    mov     [wc.hbrBackground], COLOR_WINDOW+1
    mov     [wc.lpszMenuName], 0
    mov     [wc.lpszClassName], className
    invoke  RegisterClassEx, wc

    invoke  CreateWindowEx, 0, className, titleName, WS_OVERLAPPEDWINDOW or WS_VISIBLE,\
        CW_USEDEFAULT, CW_USEDEFAULT, 400, 400, 0, 0, [wc.hInstance], 0
    mov     [hwnd], eax

msg_loop:
    invoke  GetMessage, msg, 0, 0, 0
    test    eax, eax
    jz      end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     msg_loop

end_loop:
    invoke  ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp     [wmsg], WM_CREATE
    je      .wmcreate
    cmp     [wmsg], WM_SIZE
    je      .wmsize
    cmp     [wmsg], WM_PAINT
    je      .wmpaint
    cmp     [wmsg], WM_DESTROY
    je      .wmdestroy

.defwndproc:
    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret

.wmcreate:
    invoke CreateFont, \
        30, \                    ; int nHeight
        20, \                    ; int nWidth
        0, \                     ; int nEscapement
        0, \                     ; int nOrientation
        FW_BOLD, \               ; int fnWeight
        0, \                     ; DWORD fdwItalic
        0, \                     ; DWORD fdwUnderline
        0, \                     ; DWORD fdwStrikeOut
        DEFAULT_CHARSET, \       ; DWORD fdwCharSet
        OUT_DEFAULT_PRECIS, \    ; DWORD fdwOutputPrecision
        CLIP_DEFAULT_PRECIS, \   ; DWORD fdwClipPrecision
        DEFAULT_QUALITY, \       ; DWORD fdwQuality
        DEFAULT_PITCH or\ 
        FF_DONTCARE, \           ; DWORD fdwPitchAndFamily
        0                        ; LPCTSTR lpszFace

    mov     [hFont], eax
    xor     eax, eax
    ret

.wmsize:
    invoke  InvalidateRect, [hwnd], 0, TRUE
    xor     eax, eax
    ret

.wmpaint:
    invoke  BeginPaint, [hwnd], ps
    invoke  GetClientRect, [hwnd], rect
    cinvoke printf, fmt2, [rect.right], [rect.bottom]
    cinvoke wsprintf, buffer, fmt, [rect.right], [rect.bottom]
    invoke  SelectObject, [ps.hdc], [hFont]
    mov     [hOldFont], eax
    ;invoke  SetBkMode, [ps.hdc], TRANSPARENT
    invoke  DrawText, [ps.hdc], buffer, -1, rect,\
        DT_CENTER or DT_VCENTER or DT_SINGLELINE
    invoke  SelectObject, [ps.hdc], [hOldFont]
    invoke  EndPaint, [hwnd], ps
    xor     eax, eax
    ret

.wmdestroy:
    invoke  DeleteObject, [hFont]
    invoke  PostQuitMessage, 0
    xor     eax, eax
    ret
endp

section '.idata' import data readable
    library kernel32,   'KERNEL32.DLL',\
        user32,         'USER32.DLL',\
        gdi32,          'GDI32.DLL',\
        msvcrt,         'MSVCRT.DLL'

    import kernel32,\
        ExitProcess, 'ExitProcess',\
        GetModuleHandle, 'GetModuleHandleA'

    import user32,\
        BeginPaint, 'BeginPaint',\
        CreateWindowEx, 'CreateWindowExA',\
        DefWindowProc, 'DefWindowProcA',\
        DispatchMessage, 'DispatchMessageA',\
        DrawText, 'DrawTextA',\
        EndPaint, 'EndPaint',\
        GetClientRect, 'GetClientRect',\
        GetMessage, 'GetMessageA',\
        InvalidateRect, 'InvalidateRect',\
        LoadCursor, 'LoadCursorA',\
        LoadIcon, 'LoadIconA',\
        PostQuitMessage, 'PostQuitMessage',\
        RegisterClassEx, 'RegisterClassExA',\
        TranslateMessage, 'TranslateMessage',\
        wsprintf, 'wsprintfA'

    import gdi32,\
        CreateFont, 'CreateFontA',\
        DeleteObject, 'DeleteObject',\
        SelectObject, 'SelectObject',\
        SetBkMode, 'SetBkMode'

    import msvcrt,\
        printf, 'printf'
