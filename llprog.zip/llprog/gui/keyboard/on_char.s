format PE GUI 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    _class      db 'FASMKeyboardGUI', 0
    _title      db 'Key Press Listener', 0
    _font_name  db 'Arial', 0
    
    hwnd        dd ?
    msg         MSG
    wc          WNDCLASS
    rect        RECT
    
    hFont       dd ?
    pressed_key db ' ', 0

section '.code' code readable executable
start:
    invoke GetModuleHandle, 0
    mov [wc.hInstance], eax
    mov [wc.lpfnWndProc], WindowProc
    mov [wc.lpszClassName], _class
    mov [wc.hbrBackground], COLOR_WINDOW + 1
    
    invoke LoadIcon, 0, IDI_APPLICATION
    mov [wc.hIcon], eax
    invoke LoadCursor, 0, IDC_ARROW
    mov [wc.hCursor], eax
    
    invoke RegisterClass, wc
    
    invoke CreateWindowEx, 0, _class, _title, WS_OVERLAPPEDWINDOW + WS_VISIBLE, \
            CW_USEDEFAULT, CW_USEDEFAULT, 400, 300, 0, 0, [wc.hInstance], 0
    mov [hwnd], eax

msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    cmp eax, 0
    je end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp msg_loop

end_loop:
    invoke ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    push ebx esi edi
    
    cmp [wmsg], WM_CHAR
    je .on_char
    cmp [wmsg], WM_PAINT
    je .on_paint
    cmp [wmsg], WM_DESTROY
    je .on_destroy
    
.default:
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    jmp .finish

.on_char:
    mov eax, [wparam]
    mov [pressed_key], al
    invoke InvalidateRect, [hwnd], 0, TRUE
    xor eax, eax
    jmp .finish

.on_paint:
    invoke BeginPaint, [hwnd], msg ; TODO: I think msg is wrong type
    mov ebx, eax
    
    invoke CreateFont, 72, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE, \
            ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, \
            DEFAULT_QUALITY, DEFAULT_PITCH, _font_name
    mov [hFont], eax
    
    invoke SelectObject, ebx, [hFont]
    push eax 
    
    invoke GetClientRect, [hwnd], rect
    invoke DrawText, ebx, pressed_key, 1, rect, DT_CENTER or DT_VCENTER or DT_SINGLELINE
    
    pop eax
    invoke SelectObject, ebx, eax
    invoke DeleteObject, [hFont]
    
    invoke EndPaint, [hwnd], msg
    xor eax, eax
    jmp .finish

.on_destroy:
    invoke PostQuitMessage, 0
    xor eax, eax

.finish:
    pop edi esi ebx
    ret
endp

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL', \
            user32,   'USER32.DLL', \
            gdi32,    'GDI32.DLL'

    import kernel32, \
           GetModuleHandle, 'GetModuleHandleA', \
           ExitProcess,     'ExitProcess'

    import user32, \
           RegisterClass,    'RegisterClassA', \
           CreateWindowEx,   'CreateWindowExA', \
           GetMessage,       'GetMessageA', \
           TranslateMessage, 'TranslateMessage', \
           DispatchMessage,  'DispatchMessageA', \
           PostQuitMessage,  'PostQuitMessage', \
           DefWindowProc,    'DefWindowProcA', \
           BeginPaint,       'BeginPaint', \
           EndPaint,         'EndPaint', \
           InvalidateRect,   'InvalidateRect', \
           GetClientRect,    'GetClientRect', \
           DrawText,         'DrawTextA', \
           LoadIcon,         'LoadIconA', \
           LoadCursor,       'LoadCursorA'

    import gdi32, \
           CreateFont,   'CreateFontA', \
           SelectObject, 'SelectObject', \
           DeleteObject, 'DeleteObject'
