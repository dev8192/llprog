format PE GUI 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    className  db 'KeyMonitor', 0
    fontName   db 'Arial', 0
    ctrlStr    db 'Ctrl + ', 0
    shiftStr   db 'Shift + ', 0
    altStr     db 'Alt + ', 0
    initial    db 'Press any key', 0
    
    wc         WNDCLASS
    msg        MSG
    ps         PAINTSTRUCT
    rect       RECT
    
    hFont      dd ?
    
    keyText    rb 256
    keyNameBuf rb 64

section '.text' code readable executable
start:
    invoke GetModuleHandle, 0
    mov [wc.hInstance], eax
    mov [wc.lpfnWndProc], WindowProc
    mov [wc.lpszClassName], className
    mov [wc.hbrBackground], COLOR_WINDOW+1
    
    invoke LoadCursor, 0, IDC_ARROW
    mov [wc.hCursor], eax

    invoke RegisterClass, wc

    invoke CreateFont, 72, 0, 0, 0, FW_BOLD, 0, 0, 0, DEFAULT_CHARSET, \
        OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, \
        DEFAULT_PITCH, fontName
    mov [hFont], eax

    invoke lstrcpy, keyText, initial

    invoke CreateWindowEx, 0, className, className, WS_VISIBLE or WS_OVERLAPPEDWINDOW, \
        CW_USEDEFAULT, CW_USEDEFAULT, 800, 600, 0, 0, [wc.hInstance], 0

msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    test eax, eax
    jz end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp msg_loop

end_loop:
    invoke DeleteObject, [hFont]
    invoke ExitProcess, [msg.wParam]

WindowProc:
    mov eax, [esp+8]
    cmp eax, WM_PAINT
    je .wmpaint
    cmp eax, WM_KEYDOWN
    je .on_key
    cmp eax, WM_SYSKEYDOWN
    je .on_syskey
    cmp eax, WM_DESTROY
    je .wmdestroy
    jmp [DefWindowProc]

.on_key:
    mov ebx, [esp+4]
    mov esi, [esp+12]
    mov edi, [esp+16]
    call ..UpdateText
    xor eax, eax
    ret 16

.on_syskey:
    mov ebx, [esp+4]
    mov esi, [esp+12]
    mov edi, [esp+16]
    call ..UpdateText
    jmp [DefWindowProc]

..UpdateText:
    mov byte [keyText], 0
    
    cmp esi, VK_CONTROL
    je .get_name
    cmp esi, VK_SHIFT
    je .get_name
    cmp esi, VK_MENU
    je .get_name

    invoke GetKeyState, VK_CONTROL
    test ax, 0x8000
    jz .check_shift
    invoke lstrcat, keyText, ctrlStr

.check_shift:
    invoke GetKeyState, VK_SHIFT
    test ax, 0x8000
    jz .check_alt
    invoke lstrcat, keyText, shiftStr

.check_alt:
    invoke GetKeyState, VK_MENU
    test ax, 0x8000
    jz .get_name
    invoke lstrcat, keyText, altStr

.get_name:
    invoke GetKeyNameText, edi, keyNameBuf, 64
    invoke lstrcat, keyText, keyNameBuf

    invoke InvalidateRect, ebx, 0, 1
    ret

.wmpaint:
    mov edi, [esp+4]
    invoke BeginPaint, edi, ps
    mov esi, eax
    
    invoke SelectObject, esi, [hFont]
    mov ebx, eax
    
    invoke GetClientRect, edi, rect
    invoke SetBkMode, esi, TRANSPARENT
    
    invoke lstrlen, keyText
    invoke DrawText, esi, keyText, eax, rect, DT_CENTER or DT_VCENTER or DT_SINGLELINE
    
    invoke SelectObject, esi, ebx
    invoke EndPaint, edi, ps
    xor eax, eax
    ret 16

.wmdestroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    ret 16

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
        user32, 'user32.dll',\
        gdi32, 'gdi32.dll'

    import kernel32,\
        GetModuleHandle, 'GetModuleHandleA',\
        ExitProcess, 'ExitProcess',\
        lstrcpy, 'lstrcpyA',\
        lstrcat, 'lstrcatA',\
        lstrlen, 'lstrlenA'

    import user32,\
        LoadCursor, 'LoadCursorA',\
        RegisterClass, 'RegisterClassA',\
        CreateWindowEx, 'CreateWindowExA',\
        GetMessage, 'GetMessageA',\
        TranslateMessage, 'TranslateMessage',\
        DispatchMessage, 'DispatchMessageA',\
        DefWindowProc, 'DefWindowProcA',\
        PostQuitMessage, 'PostQuitMessage',\
        BeginPaint, 'BeginPaint',\
        EndPaint, 'EndPaint',\
        GetClientRect, 'GetClientRect',\
        DrawText, 'DrawTextA',\
        InvalidateRect, 'InvalidateRect',\
        GetKeyState, 'GetKeyState',\
        GetKeyNameText, 'GetKeyNameTextA'

    import gdi32,\
        CreateFont, 'CreateFontA',\
        SelectObject, 'SelectObject',\
        SetBkMode, 'SetBkMode',\
        DeleteObject, 'DeleteObject'
