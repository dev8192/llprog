include 'win32ax.inc'

.code
    start:
        invoke MessageBox, \
            HWND_DESKTOP, \              ; Owner window (Desktop)
            "May I ask you something?", \ ; The Message text
            invoke GetCommandLine, \     ; The Title bar (program path)
            MB_YESNO                     ; Button style (Yes and No)
        .if eax = IDYES
            invoke MessageBox,HWND_DESKTOP,"Hi! I'm the example program!","Hello!",MB_OK
        .endif
        invoke ExitProcess,0
.end start
