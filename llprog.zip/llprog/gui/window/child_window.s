format PE GUI 4.0
entry start

include 'win32a.inc'

ID_BTN_200 = 1
ID_BTN_400 = 2
ID_BTN_600 = 3

BTN_WIDTH = 100
BTN_HEIGHT = 30
BTN_X = 50

BTN_Y_200 = 20
BTN_Y_400 = 60
BTN_Y_600 = 100

SIZE_MULTIPLIER = 200
MAIN_WIDTH = 220
MAIN_HEIGHT = 200

section '.data' data readable writeable
    mainClass db 'MainWndClass', 0
    subClass db 'SubWndClass', 0
    btnClass db 'BUTTON', 0
    mainTitle db 'Window Generator', 0
    txt200 db '200x200', 0
    txt400 db '400x400', 0
    txt600 db '600x600', 0

    wc WNDCLASSEX
    msg MSG
    hInst dd ?

section '.text' code readable executable
start:
    invoke GetModuleHandle, NULL
    mov [hInst], eax

    mov [wc.cbSize], sizeof.WNDCLASSEX
    mov [wc.style], CS_HREDRAW or CS_VREDRAW
    mov [wc.lpfnWndProc], MainWndProc
    mov eax, [hInst]
    mov [wc.hInstance], eax
    invoke LoadCursor, NULL, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.hbrBackground], COLOR_WINDOW + 1
    mov [wc.lpszClassName], mainClass
    invoke RegisterClassEx, wc

    mov eax, [DefWindowProc]
    mov [wc.lpfnWndProc], eax
    mov [wc.lpszClassName], subClass
    invoke RegisterClassEx, wc

    invoke CreateWindowEx, 0, mainClass, mainTitle, \
        WS_VISIBLE or WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, \
        CW_USEDEFAULT, MAIN_WIDTH, MAIN_HEIGHT, NULL, NULL, [hInst], NULL

.msg_loop:
    invoke GetMessage, msg, NULL, 0, 0
    test eax, eax
    jz .end_loop
    invoke DispatchMessage, msg
    jmp .msg_loop

.end_loop:
    invoke ExitProcess, [msg.wParam]

proc MainWndProc uses ebx esi edi, hwnd, wmsg, wparam, lparam
    cmp [wmsg], WM_CREATE
    je .on_create
    cmp [wmsg], WM_COMMAND
    je .on_command
    cmp [wmsg], WM_DESTROY
    je .on_destroy
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    jmp .finish

.on_create:
    invoke CreateWindowEx, 0, btnClass, txt200, \
        WS_VISIBLE or WS_CHILD, BTN_X, BTN_Y_200, \
        BTN_WIDTH, BTN_HEIGHT, [hwnd], ID_BTN_200, [hInst], NULL
    invoke CreateWindowEx, 0, btnClass, txt400, \
        WS_VISIBLE or WS_CHILD, BTN_X, BTN_Y_400, \
        BTN_WIDTH, BTN_HEIGHT, [hwnd], ID_BTN_400, [hInst], NULL
    invoke CreateWindowEx, 0, btnClass, txt600, \
        WS_VISIBLE or WS_CHILD, BTN_X, BTN_Y_600, \
        BTN_WIDTH, BTN_HEIGHT, [hwnd], ID_BTN_600, [hInst], NULL
    xor eax, eax
    jmp .finish

.on_command:
    mov eax, [wparam]
    and eax, 0FFFFh
    cmp eax, ID_BTN_200
    jl .def_proc
    cmp eax, ID_BTN_600
    jg .def_proc
    imul ebx, eax, SIZE_MULTIPLIER
    invoke CreateWindowEx, 0, subClass, mainTitle, \
        WS_VISIBLE or WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, \
        CW_USEDEFAULT, ebx, ebx, NULL, NULL, [hInst], NULL
    xor eax, eax
    jmp .finish

.on_destroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    jmp .finish

.def_proc:
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]

.finish:
    ret
endp

section '.idata' import data readable
    library kernel32, 'kernel32.dll', \
            user32, 'user32.dll'

    import kernel32, \
           GetModuleHandle, 'GetModuleHandleA', \
           ExitProcess, 'ExitProcess'

    import user32, \
           RegisterClassEx, 'RegisterClassExA', \
           CreateWindowEx, 'CreateWindowExA', \
           DefWindowProc, 'DefWindowProcA', \
           GetMessage, 'GetMessageA', \
           DispatchMessage, 'DispatchMessageA', \
           PostQuitMessage, 'PostQuitMessage', \
           LoadCursor, 'LoadCursorA'
