format PE
entry start

include 'win32a.inc'

IDC_BUTTON equ 101
MAIN_WND_W equ 300
MAIN_WND_H equ 200

SUB_WND_W equ 250
SUB_WND_H equ 150

section '.data' data readable writeable
    hButton dd ?
    hSubWindow dd ?
    msg MSG
    wc WNDCLASS

    classNameMain db 'MainWndClass', 0
    windowTitleMain db 'Main Window', 0

    classNameSub db 'SubWndClass', 0
    windowTitleSub db 'Secondary Window', 0
    
    btnClass db 'BUTTON', 0
    btnTextOpen db 'Open window', 0
    btnTextClose db 'Close window', 0

section '.text' code readable executable
start:
    mov [wc.style], CS_HREDRAW or CS_VREDRAW
    mov [wc.lpfnWndProc], MainWndProc
    invoke GetModuleHandle, 0
    mov [wc.hInstance], eax
    invoke LoadIcon, 0, IDI_APPLICATION
    mov [wc.hIcon], eax
    invoke LoadCursor, 0, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.hbrBackground], COLOR_BTNFACE + 1
    mov [wc.lpszMenuName], 0
    mov [wc.lpszClassName], classNameMain
    invoke RegisterClass, wc

    mov [wc.lpfnWndProc], SubWndProc
    mov [wc.lpszClassName], classNameSub
    invoke RegisterClass, wc

    invoke CreateWindowEx, 0, classNameMain, windowTitleMain,\
        WS_VISIBLE or WS_OVERLAPPEDWINDOW,\
        CW_USEDEFAULT, CW_USEDEFAULT, MAIN_WND_W, MAIN_WND_H,\
        0, 0, [wc.hInstance], 0

msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    test eax, eax
    jz end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp msg_loop

end_loop:
    invoke ExitProcess, [msg.wParam]

proc MainWndProc hwnd, wmsg, wparam, lparam
    cmp [wmsg], WM_CREATE
    je .wm_create
    cmp [wmsg], WM_COMMAND
    je .wm_command
    cmp [wmsg], WM_DESTROY
    je .wm_destroy
.defproc:
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret

.wm_create:
    BTN_X equ 50
    BTN_Y equ 50
    BTN_W equ 150
    BTN_H equ 40
    invoke CreateWindowEx, 0, btnClass, btnTextOpen,\
        WS_CHILD or WS_VISIBLE or BS_PUSHBUTTON,\
        BTN_X, BTN_Y, BTN_W, BTN_H,\
        [hwnd], IDC_BUTTON, [wc.hInstance], 0
    mov [hButton], eax
    xor eax, eax
    ret

.wm_command:
    cmp [wparam], IDC_BUTTON
    jne .defproc
    cmp [hSubWindow], 0
    jne .close_sub
    invoke CreateWindowEx, 0, classNameSub, windowTitleSub,\
        WS_VISIBLE or WS_OVERLAPPEDWINDOW,\
        CW_USEDEFAULT, CW_USEDEFAULT, SUB_WND_W, SUB_WND_H,\
        0, 0, [wc.hInstance], 0
    mov [hSubWindow], eax
    invoke SetWindowText, [hButton], btnTextClose
    xor eax, eax
    ret

.close_sub:
    invoke DestroyWindow, [hSubWindow]
    xor eax, eax
    ret

.wm_destroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    ret
endp

proc SubWndProc hwnd, wmsg, wparam, lparam
    cmp [wmsg], WM_DESTROY
    je .wm_destroy
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret

.wm_destroy:
    mov [hSubWindow], 0
    invoke SetWindowText, [hButton], btnTextOpen
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret
endp

section '.idata' import data readable writeable
    library kernel32,           'kernel32.dll',\
            user32,             'user32.dll'
    import  kernel32,\
            GetModuleHandle,    'GetModuleHandleA',\
            ExitProcess,        'ExitProcess'
    import  user32,\
            RegisterClass,      'RegisterClassA',\
            CreateWindowEx,     'CreateWindowExA',\
            DestroyWindow,      'DestroyWindow',\
            DefWindowProc,      'DefWindowProcA',\
            GetMessage,         'GetMessageA',\
            TranslateMessage,   'TranslateMessage',\
            DispatchMessage,    'DispatchMessageA',\
            LoadCursor,         'LoadCursorA',\
            LoadIcon,           'LoadIconA',\
            SetWindowText,      'SetWindowTextA',\
            PostQuitMessage,    'PostQuitMessage'
