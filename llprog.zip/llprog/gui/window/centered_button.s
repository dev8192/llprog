format PE
entry start

include 'win32a.inc'

BTN_WIDTH equ 120
BTN_HEIGHT equ 30
BTN_ID equ 1001

section '.data' data readable writeable
    class_name db 'ExampleWindow', 0
    window_name db 'Example Window', 0
    btn_class db 'BUTTON', 0
    btn_text db 'Close window', 0

    wc WNDCLASS
    msg MSG
    hwnd_btn dd ?

section '.text' code readable executable
start:    
    mov [wc.style], CS_HREDRAW or CS_VREDRAW
    mov [wc.lpfnWndProc], WindowProc
    invoke GetModuleHandle, 0
    mov [wc.hInstance], eax
    invoke LoadCursor, 0, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.hbrBackground], COLOR_BTNFACE + 1
    mov [wc.lpszClassName], class_name
    
    invoke RegisterClass, wc
    
    invoke CreateWindowEx, 0, class_name, window_name,\
        WS_VISIBLE or WS_OVERLAPPEDWINDOW or WS_MAXIMIZE,\
        CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,\
        0, 0, [wc.hInstance], 0
        
msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    cmp eax, 0
    je end_loop
    invoke DispatchMessage, msg
    jmp msg_loop
    
end_loop:
    invoke ExitProcess, [msg.wParam]
    
proc WindowProc hwnd, wmsg, wparam, lparam
    cmp [wmsg], WM_CREATE
    je .wm_create
    cmp [wmsg], WM_SIZE
    je .wm_size
    cmp [wmsg], WM_COMMAND
    je .wm_command
    cmp [wmsg], WM_DESTROY
    je .wm_destroy
    
.def_wnd_proc:
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret
    
.wm_create:
    invoke CreateWindowEx, 0, btn_class, btn_text,\
        WS_CHILD or WS_VISIBLE,\
        0, 0, BTN_WIDTH, BTN_HEIGHT,\
        [hwnd], BTN_ID, [wc.hInstance], 0
    mov [hwnd_btn], eax
    xor eax, eax
    ret
    
.wm_size:
    mov eax, [lparam]
    movzx ecx, ax 
    shr eax, 16   
    
    sub ecx, BTN_WIDTH
    sar ecx, 1
    
    sub eax, BTN_HEIGHT
    sar eax, 1
    
    invoke MoveWindow, [hwnd_btn], ecx, eax, BTN_WIDTH, BTN_HEIGHT, TRUE
    xor eax, eax
    ret

.wm_command:
    mov eax, [wparam]
    and eax, 0FFFFh
    cmp eax, BTN_ID
    jne .def_wnd_proc
    invoke SendMessage, [hwnd], WM_CLOSE, 0, 0
    xor eax, eax
    ret
    
.wm_destroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    ret
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            user32,             'user32.dll'
    import  kernel32,\
            GetModuleHandle,    'GetModuleHandleA',\
            ExitProcess,        'ExitProcess'
    import  user32,\
            RegisterClass,      'RegisterClassA',\
            CreateWindowEx,     'CreateWindowExA',\
            DefWindowProc,      'DefWindowProcA',\
            GetMessage,         'GetMessageA',\
            TranslateMessage,   'TranslateMessage',\
            DispatchMessage,    'DispatchMessageA',\
            SendMessage,        'SendMessageA',\
            MoveWindow,         'MoveWindow',\
            LoadIcon,           'LoadIconA',\
            LoadCursor,         'LoadCursorA',\
            PostQuitMessage,    'PostQuitMessage'
