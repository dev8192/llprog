format PE GUI 4.0
entry start

include 'win32a.inc'

ID_RED   = 101
ID_GREEN = 102
ID_BLUE  = 103

section '.data' data readable writeable
    hwnd         dd ?
    wc           WNDCLASS
    msg          MSG
    ps           PAINTSTRUCT

    currentColor dd 0
    boxRect      dd 20, 20, 120, 120

    szClass      db 'ColorBoxApp', 0
    szTitle      db 'RGB Color Box', 0
    szButton     db 'BUTTON', 0
    szRed        db 'Red', 0
    szGreen      db 'Green', 0
    szBlue       db 'Blue', 0

section '.text' code readable executable

start:
    mov     [wc.style], CS_HREDRAW or CS_VREDRAW
    mov     [wc.lpfnWndProc], WindowProc
    invoke  GetModuleHandle, 0
    mov     [wc.hInstance], eax
    invoke  LoadIcon, 0, IDI_APPLICATION
    mov     [wc.hIcon], eax
    invoke  LoadCursor, 0, IDC_ARROW
    mov     [wc.hCursor], eax
    mov     [wc.hbrBackground], COLOR_WINDOW + 1
    mov     [wc.lpszClassName], szClass
    invoke  RegisterClass, wc

    invoke  CreateWindowEx, 0, szClass, szTitle, WS_VISIBLE or WS_OVERLAPPEDWINDOW, \
            CW_USEDEFAULT, CW_USEDEFAULT, 260, 200, 0, 0, [wc.hInstance], 0
    mov     [hwnd], eax

    invoke  CreateWindowEx, 0, szButton, szRed,\
            WS_VISIBLE or WS_CHILD or BS_AUTOCHECKBOX, \
            140, 20, 80, 20, [hwnd], ID_RED, [wc.hInstance], 0
    invoke  CreateWindowEx, 0, szButton, szGreen,\
            WS_VISIBLE or WS_CHILD or BS_AUTOCHECKBOX, \
            140, 50, 80, 20, [hwnd], ID_GREEN, [wc.hInstance], 0
    invoke  CreateWindowEx, 0, szButton, szBlue,\
            WS_VISIBLE or WS_CHILD or BS_AUTOCHECKBOX, \
            140, 80, 80, 20, [hwnd], ID_BLUE, [wc.hInstance], 0

msg_loop:
    invoke  GetMessage, msg, 0, 0, 0
    test    eax, eax
    jz      end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     msg_loop

end_loop:
    invoke  ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp     [wmsg], WM_COMMAND
    je      .wmcommand
    cmp     [wmsg], WM_PAINT
    je      .wmpaint
    cmp     [wmsg], WM_DESTROY
    je      .wmdestroy

.defwndproc:
    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret

.wmcommand:
    mov     eax, [wparam]
    and     eax, 0FFFFh
    cmp     eax, ID_RED
    je      .update_color
    cmp     eax, ID_GREEN
    je      .update_color
    cmp     eax, ID_BLUE
    je      .update_color
    jmp     .finish

.update_color:
    push    ebx

    invoke  IsDlgButtonChecked, [hwnd], ID_RED
    neg     eax
    and     eax, 000000FFh
    mov     ebx, eax

    invoke  IsDlgButtonChecked, [hwnd], ID_GREEN
    neg     eax
    and     eax, 0000FF00h
    or      ebx, eax

    invoke  IsDlgButtonChecked, [hwnd], ID_BLUE
    neg     eax
    and     eax, 00FF0000h
    or      ebx, eax

    mov     [currentColor], ebx
    pop     ebx

    ;invoke  InvalidateRect, [hwnd], boxRect, TRUE
    invoke  InvalidateRect, [hwnd], boxRect, FALSE
    jmp     .finish

.wmpaint:
    invoke  BeginPaint, [hwnd], ps
    invoke  CreateSolidBrush, [currentColor]
    push    eax
    invoke  FillRect, [ps.hdc], boxRect, eax
    pop     eax
    invoke  DeleteObject, eax
    invoke  EndPaint, [hwnd], ps
    jmp     .finish

.wmdestroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
    ret

.finish:
    xor     eax, eax
    ret
endp

section '.idata' import data readable writeable

    library kernel32, 'KERNEL32.DLL',\
            user32, 'USER32.DLL',\
            gdi32, 'GDI32.DLL'

    import kernel32,\
        ExitProcess, 'ExitProcess',\
        GetModuleHandle, 'GetModuleHandleA'

    import user32,\
        BeginPaint, 'BeginPaint',\
        CreateWindowEx, 'CreateWindowExA',\
        DefWindowProc, 'DefWindowProcA',\
        DispatchMessage, 'DispatchMessageA',\
        EndPaint, 'EndPaint',\
        FillRect, 'FillRect',\
        GetMessage, 'GetMessageA',\
        InvalidateRect, 'InvalidateRect',\
        IsDlgButtonChecked, 'IsDlgButtonChecked',\
        LoadCursor, 'LoadCursorA',\
        LoadIcon, 'LoadIconA',\
        PostQuitMessage, 'PostQuitMessage',\
        RegisterClass, 'RegisterClassA',\
        TranslateMessage, 'TranslateMessage'

    import gdi32,\
        CreateSolidBrush, 'CreateSolidBrush',\
        DeleteObject, 'DeleteObject'
