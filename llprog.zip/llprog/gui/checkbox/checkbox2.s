format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    _class      db 'FasmCheckClass', 0
    _title      db 'Checkbox Test', 0
    _button     db 'BUTTON', 0
    _box_text   db 'Check me', 0
    _fmt_on     db 'Checkbox is checked', 10, 0
    _fmt_off    db 'Checkbox is unchecked', 10, 0
    
    hwnd_main   dd 0
    hwnd_check  dd 0
    wc          WNDCLASS
    msg         MSG

section '.text' code readable executable
start:
    invoke  GetModuleHandle, 0
    mov     [wc.hInstance], eax
    mov     [wc.lpfnWndProc], WindowProc
    mov     [wc.lpszClassName], _class
    mov     [wc.hbrBackground], COLOR_BTNFACE + 1
    invoke  RegisterClass, wc

    invoke  CreateWindowEx, 0, _class, _title,\
            WS_VISIBLE or WS_OVERLAPPEDWINDOW,\
            100, 100, 300, 150,\
            0, 0, [wc.hInstance], 0
    mov     [hwnd_main], eax

    invoke  AllocConsole

.msg_loop:
    invoke  GetMessage, msg, NULL, 0, 0
    test    eax, eax
    jz      .end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     .msg_loop
.end_loop:
    invoke  ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp     [wmsg], WM_CREATE
    je      .on_create
    cmp     [wmsg], WM_COMMAND
    je      .on_command
    cmp     [wmsg], WM_DESTROY
    je      .on_destroy
    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret

.on_create:
    invoke  GetModuleHandle, 0
    invoke  CreateWindowEx, 0, _button, _box_text,\
            WS_VISIBLE or WS_CHILD or BS_AUTOCHECKBOX,\
            20, 20, 150, 25, [hwnd], 101, eax, 0
    mov     [hwnd_check], eax
    xor     eax, eax
    ret

.on_command:
    mov     eax, [wparam]
    cmp     ax, 101
    jne     .finish
    
    invoke  SendMessage, [hwnd_check], BM_GETCHECK, 0, 0
    cmp     eax, BST_CHECKED
    je      .checked
    
    cinvoke printf, _fmt_off
    jmp     .finish

.checked:
    cinvoke printf, _fmt_on

.finish:
    xor     eax, eax
    ret

.on_destroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
    ret
endp

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            user32,   'user32.dll',\
            msvcrt,   'msvcrt.dll'

    import kernel32, GetModuleHandle, 'GetModuleHandleA',\
                     AllocConsole, 'AllocConsole',\
                     ExitProcess, 'ExitProcess'

    import user32,   RegisterClass, 'RegisterClassA',\
                     CreateWindowEx, 'CreateWindowExA',\
                     DefWindowProc, 'DefWindowProcA',\
                     GetMessage, 'GetMessageA',\
                     TranslateMessage, 'TranslateMessage',\
                     DispatchMessage, 'DispatchMessageA',\
                     SendMessage, 'SendMessageA',\
                     PostQuitMessage, 'PostQuitMessage'

    import msvcrt,   printf, 'printf'
