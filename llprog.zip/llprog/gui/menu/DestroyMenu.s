format PE console
entry start
include 'win32a.inc'

section '.data' data readable writeable
    class_name      db 'DestroyMenuClass', 0
    window_title    db 'DestroyMenu Demo', 0
    str_destroy     db 'Destroy This Menu', 0

    wc          WNDCLASS
    msg         MSG
    hwnd        dd ?
    hMainMenu   dd ?

section '.text' code readable executable
start:
    invoke  GetModuleHandle, 0
    mov     [wc.hInstance], eax

    invoke  LoadCursor, 0, IDC_ARROW
    mov     [wc.hCursor], eax

    mov     [wc.style], 0
    mov     [wc.lpfnWndProc], WindowProc
    mov     [wc.lpszClassName], class_name
    mov     [wc.hbrBackground], COLOR_WINDOW+1

    invoke  RegisterClass, wc

    invoke  CreateWindowEx, 0, class_name, window_title,\
        WS_VISIBLE or WS_OVERLAPPEDWINDOW,\
        100, 100, 300, 200, 0, 0, [wc.hInstance], 0
    mov     [hwnd], eax

    invoke  CreateMenu
    mov     [hMainMenu], eax

    invoke  AppendMenu, [hMainMenu], MF_STRING, 101, str_destroy

    invoke  SetMenu, [hwnd], [hMainMenu]

msg_loop:
    invoke  GetMessage, msg, 0, 0, 0
    test    eax, eax
    jz      end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     msg_loop

end_loop:
    invoke  ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp     [wmsg], WM_COMMAND
    je      .wmcommand
    cmp     [wmsg], WM_DESTROY
    je      .wmdestroy
.defwndproc:
    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret
.wmcommand:
    cmp     [wparam], 101
    jne     .defwndproc
    
    invoke  GetMenu, [hwnd]
    test    eax, eax
    jz      .done
    
    push    eax
    invoke  SetMenu, [hwnd], 0
    pop     eax
    
    invoke  DestroyMenu, eax
    
.done:
    xor     eax, eax
    ret
.wmdestroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
    ret
endp

section '.idata' import data readable writeable

    library kernel32, 'KERNEL32.DLL',\
            user32, 'USER32.DLL'

    import kernel32,\
           GetModuleHandle, 'GetModuleHandleA',\
           ExitProcess, 'ExitProcess'

    import user32,\
           RegisterClass, 'RegisterClassA',\
           CreateWindowEx, 'CreateWindowExA',\
           DefWindowProc, 'DefWindowProcA',\
           GetMessage, 'GetMessageA',\
           TranslateMessage, 'TranslateMessage',\
           DispatchMessage, 'DispatchMessageA',\
           PostQuitMessage, 'PostQuitMessage',\
           LoadCursor, 'LoadCursorA',\
           CreateMenu, 'CreateMenu',\
           AppendMenu, 'AppendMenuA',\
           SetMenu, 'SetMenu',\
           GetMenu, 'GetMenu',\
           DestroyMenu, 'DestroyMenu'
