format PE GUI 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable

    class_name        db 'MenuTypesClass', 0
    window_title      db 'Menu Types Demo', 0

    str_menubar_node  db 'Menu Bar Item', 0
    str_dropdown_item db 'Drop-down Item', 0
    str_submenu_node  db 'Submenu Node', 0
    str_submenu_item  db 'Submenu Item', 0
    str_shortcut_item db 'Shortcut (Context) Item', 0

    wc            WNDCLASS
    msg           MSG
    hwnd          dd ?
    hMenuBar      dd ?
    hDropDown     dd ?
    hSubMenu      dd ?
    hShortcutMenu dd ?

section '.text' code readable executable
start:
    invoke  GetModuleHandle, 0
    mov     [wc.hInstance], eax

    invoke  LoadCursor, 0, IDC_ARROW
    mov     [wc.hCursor], eax

    mov     [wc.style], 0
    mov     [wc.lpfnWndProc], WindowProc
    mov     [wc.lpszClassName], class_name
    mov     [wc.hbrBackground], COLOR_WINDOW+1

    invoke  RegisterClass, wc

    invoke  CreateWindowEx, 0, class_name, window_title,\
        WS_VISIBLE or WS_OVERLAPPEDWINDOW,\
        100, 100, 400, 300, 0, 0, [wc.hInstance], 0
    mov     [hwnd], eax

    invoke  CreateMenu
    mov     [hMenuBar], eax

    invoke  CreatePopupMenu
    mov     [hDropDown], eax

    invoke  CreatePopupMenu
    mov     [hSubMenu], eax

    invoke  CreatePopupMenu
    mov     [hShortcutMenu], eax

    invoke  AppendMenu, [hSubMenu], MF_STRING, 101, str_submenu_item

    invoke  AppendMenu, [hDropDown], MF_STRING, 102, str_dropdown_item
    invoke  AppendMenu, [hDropDown], MF_POPUP, [hSubMenu], str_submenu_node

    invoke  AppendMenu, [hMenuBar], MF_POPUP, [hDropDown], str_menubar_node

    invoke  AppendMenu, [hShortcutMenu], MF_STRING, 103, str_shortcut_item

    invoke  SetMenu, [hwnd], [hMenuBar]

msg_loop:
    invoke  GetMessage, msg, 0, 0, 0
    test    eax, eax
    jz      end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     msg_loop

end_loop:
    invoke  ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp     [wmsg], WM_CONTEXTMENU
    je      .wmcontextmenu
    cmp     [wmsg], WM_DESTROY
    je      .wmdestroy
    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret
.wmcontextmenu:
    mov     eax, [lparam]
    movsx   ecx, ax
    sar     eax, 16
    invoke  TrackPopupMenu, [hShortcutMenu], TPM_RIGHTBUTTON, ecx, eax, 0, [hwnd], 0
    xor     eax, eax
    ret
.wmdestroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
    ret
endp

section '.idata' import data readable writeable
    library kernel32,           'KERNEL32.DLL',\
            user32,             'USER32.DLL'
    import  kernel32,\
            GetModuleHandle,    'GetModuleHandleA',\
            ExitProcess,        'ExitProcess'
    import  user32,\
            RegisterClass,      'RegisterClassA',\
            CreateWindowEx,     'CreateWindowExA',\
            DefWindowProc,      'DefWindowProcA',\
            GetMessage,         'GetMessageA',\
            TranslateMessage,   'TranslateMessage',\
            DispatchMessage,    'DispatchMessageA',\
            PostQuitMessage,    'PostQuitMessage',\
            LoadCursor,         'LoadCursorA',\
            CreateMenu,         'CreateMenu',\
            CreatePopupMenu,    'CreatePopupMenu',\
            AppendMenu,         'AppendMenuA',\
            SetMenu,            'SetMenu',\
            TrackPopupMenu,     'TrackPopupMenu'
