format PE GUI 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    class_name      db 'EditMenuClass', 0
    window_title    db 'Edit Menu Example', 0

    str_edit        db '&Edit', 0
    str_undo        db '&Undo', 9, 'Ctrl+Z', 0
    str_redo        db '&Redo', 9, 'Ctrl+Y', 0
    str_cut         db 'Cu&t', 9, 'Ctrl+X', 0
    str_copy        db '&Copy', 9, 'Ctrl+C', 0
    str_paste       db '&Paste', 9, 'Ctrl+V', 0

    msg_undo        db 'Undo action selected', 0
    msg_redo        db 'Redo action selected', 0
    msg_cut         db 'Cut action selected', 0
    msg_copy        db 'Copy action selected', 0
    msg_paste       db 'Paste action selected', 0

    wc              WNDCLASS
    msg             MSG
    hwnd            dd ?
    hMenuBar        dd ?
    hEditMenu       dd ?
    
    ps              PAINTSTRUCT
    rect            RECT
    current_text    dd 0

section '.text' code readable executable

start:
    invoke  GetModuleHandle, 0
    mov     [wc.hInstance], eax

    invoke  LoadCursor, 0, IDC_ARROW
    mov     [wc.hCursor], eax

    mov     [wc.style], 0
    mov     [wc.lpfnWndProc], WindowProc
    mov     [wc.lpszClassName], class_name
    mov     [wc.hbrBackground], COLOR_WINDOW+1

    invoke  RegisterClass, wc

    invoke  CreateWindowEx, 0, class_name, window_title,\
        WS_VISIBLE or WS_OVERLAPPEDWINDOW,\
        100, 100, 400, 300, 0, 0, [wc.hInstance], 0
    mov     [hwnd], eax

    invoke  CreateMenu
    mov     [hMenuBar], eax

    invoke  CreatePopupMenu
    mov     [hEditMenu], eax

    invoke  AppendMenu, [hEditMenu], MF_STRING, 101, str_undo
    invoke  AppendMenu, [hEditMenu], MF_STRING, 102, str_redo
    invoke  AppendMenu, [hEditMenu], MF_SEPARATOR, 0, 0
    invoke  AppendMenu, [hEditMenu], MF_STRING, 103, str_cut
    invoke  AppendMenu, [hEditMenu], MF_STRING, 104, str_copy
    invoke  AppendMenu, [hEditMenu], MF_STRING, 105, str_paste

    invoke  AppendMenu, [hMenuBar], MF_POPUP, [hEditMenu], str_edit
    invoke  SetMenu, [hwnd], [hMenuBar]

msg_loop:
    invoke  GetMessage, msg, 0, 0, 0
    test    eax, eax
    jz      end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     msg_loop

end_loop:
    invoke  ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp     [wmsg], WM_COMMAND
    je      .wmcommand
    cmp     [wmsg], WM_TIMER
    je      .wmtimer
    cmp     [wmsg], WM_PAINT
    je      .wmpaint
    cmp     [wmsg], WM_DESTROY
    je      .wmdestroy
.defwndproc:
    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret

.wmcommand:
    mov     eax, [wparam]
    and     eax, 0FFFFh
    
    cmp     eax, 101
    je      .on_undo
    cmp     eax, 102
    je      .on_redo
    cmp     eax, 103
    je      .on_cut
    cmp     eax, 104
    je      .on_copy
    cmp     eax, 105
    je      .on_paste
    jmp     .defwndproc

.on_undo:
    mov     [current_text], msg_undo
    jmp     .show_message
.on_redo:
    mov     [current_text], msg_redo
    jmp     .show_message
.on_cut:
    mov     [current_text], msg_cut
    jmp     .show_message
.on_copy:
    mov     [current_text], msg_copy
    jmp     .show_message
.on_paste:
    mov     [current_text], msg_paste

.show_message:
    invoke  SetTimer, [hwnd], 1, 3000, 0
    invoke  InvalidateRect, [hwnd], 0, TRUE
    xor     eax, eax
    ret

.wmtimer:
    invoke  KillTimer, [hwnd], 1
    mov     [current_text], 0
    invoke  InvalidateRect, [hwnd], 0, TRUE
    xor     eax, eax
    ret

.wmpaint:
    invoke  BeginPaint, [hwnd], ps
    cmp     [current_text], 0
    je      .endpaint
    
    invoke  GetClientRect, [hwnd], rect
    invoke  DrawText, [ps.hdc], [current_text], -1, rect,\
        DT_CENTER or DT_VCENTER or DT_SINGLELINE

.endpaint:
    invoke  EndPaint, [hwnd], ps
    xor     eax, eax
    ret

.wmdestroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
    ret
endp

section '.idata' import data readable writeable

    library kernel32, 'KERNEL32.DLL',\
            user32, 'USER32.DLL'

    import kernel32,\
           GetModuleHandle, 'GetModuleHandleA',\
           ExitProcess, 'ExitProcess'

    import user32,\
           RegisterClass, 'RegisterClassA',\
           CreateWindowEx, 'CreateWindowExA',\
           DefWindowProc, 'DefWindowProcA',\
           GetMessage, 'GetMessageA',\
           TranslateMessage, 'TranslateMessage',\
           DispatchMessage, 'DispatchMessageA',\
           PostQuitMessage, 'PostQuitMessage',\
           LoadCursor, 'LoadCursorA',\
           CreateMenu, 'CreateMenu',\
           CreatePopupMenu, 'CreatePopupMenu',\
           AppendMenu, 'AppendMenuA',\
           SetMenu, 'SetMenu',\
           SetTimer, 'SetTimer',\
           KillTimer, 'KillTimer',\
           InvalidateRect, 'InvalidateRect',\
           BeginPaint, 'BeginPaint',\
           EndPaint, 'EndPaint',\
           GetClientRect, 'GetClientRect',\
           DrawText, 'DrawTextA'
