include 'win32ax.inc'

.code

  start:
    ; First MessageBox: Ask the user a question
    invoke MessageBox, \
           HWND_DESKTOP, \           ; hWnd: Owner window (Desktop)
           "may I introduce myself?", \ ; lpText: The message body
           \ ;invoke GetCommandLine, \  ; lpCaption: The title (program path)
           "no invoke", \  ; lpCaption: The title (program path)
           MB_YESNO                  ; uType: Buttons (Yes and No)

    .if eax = IDYES
        ; Second MessageBox: Introduce the program
        invoke MessageBox, \
               HWND_DESKTOP, \               ; hWnd
               "Hi! I'm the example program!", \ ; lpText
               "Hello!", \                   ; lpCaption
               MB_OK                         ; uType
    .endif

    ; Exit the program
    invoke ExitProcess, \
           0                         ; uExitCode: Success

.end start
