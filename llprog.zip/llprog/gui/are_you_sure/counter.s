format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable

    className   db 'CounterApp', 0
    windowTitle db 'Continuous Counter', 0
    msgText     db 'Are you sure?', 0
    msgTitle    db 'Confirm Close', 0
    fmtString   db 'Counter: %d', 0
    fmt         db '%d, %d', 10, 0
    before_MessageBox   db 'before_MessageBox', 10, 0
    after_MessageBox    db 'after_MessageBox', 10, 0

    counter     dd 0
    buffer      rb 64

    wc          WNDCLASS
    msg         MSG
    ps          PAINTSTRUCT
    rect        RECT

section '.text' code readable executable

start:
    invoke  GetModuleHandle, 0
    mov     [wc.hInstance], eax
    mov     [wc.style], CS_HREDRAW or CS_VREDRAW
    mov     [wc.lpfnWndProc], WindowProc
    invoke  LoadCursor, 0, IDC_ARROW
    mov     [wc.hCursor], eax
    mov     [wc.hbrBackground], COLOR_WINDOW + 1
    mov     [wc.lpszClassName], className
    invoke  RegisterClass, wc

    invoke  CreateWindowEx, 0, className, windowTitle, \
            WS_VISIBLE or WS_OVERLAPPEDWINDOW, \
            CW_USEDEFAULT, CW_USEDEFAULT, 300, 200, \
            0, 0, [wc.hInstance], 0

msg_loop:
    invoke  GetMessage, msg, 0, 0, 0
    test    eax, eax
    jz      end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     msg_loop

end_loop:
    invoke  ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    cinvoke printf, fmt, esp, [hwnd]
    cmp     [wmsg], WM_CREATE
    je      .wm_create
    cmp     [wmsg], WM_TIMER
    je      .wm_timer
    cmp     [wmsg], WM_PAINT
    je      .wm_paint
    cmp     [wmsg], WM_CLOSE
    je      .wm_close
    cmp     [wmsg], WM_DESTROY
    je      .wm_destroy

.def_wnd_proc:
    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret

.wm_create:
    invoke  SetTimer, [hwnd], 1, 1000, 0
    xor     eax, eax
    ret

.wm_timer:
    inc     [counter]
    invoke  InvalidateRect, [hwnd], 0, TRUE
    xor     eax, eax
    ret

.wm_paint:
    cinvoke wsprintf, buffer, fmtString, [counter]
    invoke  BeginPaint, [hwnd], ps
    invoke  GetClientRect, [hwnd], rect
    invoke  DrawText, [ps.hdc], buffer, -1, rect, DT_SINGLELINE or DT_CENTER or DT_VCENTER
    invoke  EndPaint, [hwnd], ps
    xor     eax, eax
    ret

.wm_close:
    cinvoke printf, before_MessageBox
    invoke  MessageBox, [hwnd], msgText, msgTitle, MB_YESNO or MB_ICONQUESTION
    push eax
    cinvoke printf, after_MessageBox
    pop eax
    cmp     eax, IDYES
    jne     .keep_open
    invoke  DestroyWindow, [hwnd]
.keep_open:
    xor     eax, eax
    ret

.wm_destroy:
    invoke  KillTimer, [hwnd], 1
    invoke  PostQuitMessage, 0
    xor     eax, eax
    ret
endp

section '.idata' import data readable
    library kernel32,           'KERNEL32.DLL',\
            user32,             'USER32.DLL',\
            msvcrt,             'MSVCRT.DLL'
    import  kernel32,\
            GetCurrentThreadId, 'GetCurrentThreadId',\
            GetModuleHandle,    'GetModuleHandleA',\
            ExitProcess,        'ExitProcess'
    import  user32,\
            BeginPaint,         'BeginPaint',\
            CreateWindowEx,     'CreateWindowExA',\
            DefWindowProc,      'DefWindowProcA',\
            DestroyWindow,      'DestroyWindow',\
            DispatchMessage,    'DispatchMessageA',\
            DrawText,           'DrawTextA',\
            EndPaint,           'EndPaint',\
            GetClientRect,      'GetClientRect',\
            GetMessage,         'GetMessageA',\
            InvalidateRect,     'InvalidateRect',\
            KillTimer,          'KillTimer',\
            LoadCursor,         'LoadCursorA',\
            MessageBox,         'MessageBoxA',\
            PostQuitMessage,    'PostQuitMessage',\
            RegisterClass,      'RegisterClassA',\
            SetTimer,           'SetTimer',\
            TranslateMessage,   'TranslateMessage',\
            wsprintf,           'wsprintfA'
    import  msvcrt,\
            printf,             'printf'
