format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    wc WNDCLASS
    msg MSG
    ps PAINTSTRUCT

    _class db 'MyWindowClass', 0
    _title  db 'Beginner GUI Window', 0
    _text  db 'Try to close this window!', 0
    _text_len  = $ - _text - 1

    mb_text    db 'Are you sure?', 0
    mb_cap     db 'Confirm Exit', 0

section '.text' code readable executable
start:
    invoke  GetModuleHandle, 0
    mov     [wc.hInstance], eax
    invoke  LoadCursor, 0, IDC_ARROW
    mov     [wc.hCursor], eax
    mov     [wc.lpfnWndProc], WindowProc
    mov     [wc.hbrBackground], COLOR_WINDOW + 1
    mov     [wc.lpszClassName], _class
    invoke  RegisterClass, wc

    invoke  CreateWindowEx, 0, _class, _title,\
            WS_VISIBLE or WS_OVERLAPPEDWINDOW,\
            CW_USEDEFAULT, CW_USEDEFAULT, 400, 200,\
            0, 0, [wc.hInstance], 0

.msg_loop:
    invoke  GetMessage, msg, 0, 0, 0
    cmp     eax, 0
    je      .end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     .msg_loop

.end_loop:
    invoke  ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp     [wmsg], WM_PAINT
    je      .on_paint
    cmp     [wmsg], WM_CLOSE
    je      .on_close
    cmp     [wmsg], WM_DESTROY
    je      .on_destroy

    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret

.on_paint:
    invoke  BeginPaint, [hwnd], ps
    invoke  TextOut, eax, 20, 20, _text, _text_len
    invoke  EndPaint, [hwnd], ps
    xor     eax, eax
    ret

.on_close:
    invoke  MessageBox, [hwnd], mb_text, mb_cap, MB_YESNO + MB_ICONQUESTION
    cmp     eax, IDNO
    je     .cancel_close

    ;cmp eax, IDYES
    ;jne .cancel_close
    
    invoke  DestroyWindow, [hwnd]

.cancel_close:
    xor     eax, eax
    ret

.on_destroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
    ret
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            user32,             'user32.dll',\
            gdi32,              'gdi32.dll'
    import  kernel32,\
            ExitProcess,        'ExitProcess'
            GetModuleHandle,    'GetModuleHandleA',\
    import  user32,\
            BeginPaint,         'BeginPaint',\
            CreateWindowEx,     'CreateWindowExA',\
            DefWindowProc,      'DefWindowProcA',\
            DestroyWindow,      'DestroyWindow',\
            DispatchMessage,    'DispatchMessageA',\
            EndPaint,           'EndPaint',\
            GetMessage,         'GetMessageA',\
            LoadCursor,         'LoadCursorA',\
            MessageBox,         'MessageBoxA',\
            PostQuitMessage,    'PostQuitMessage'
            RegisterClass,      'RegisterClassA',\
            TranslateMessage,   'TranslateMessage',\
    import  gdi32,\
            TextOut,            'TextOutA'
