format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    wc WNDCLASS
    msg MSG
    ps PAINTSTRUCT

    class_name db 'MyWindowClass', 0
    win_title  db 'Beginner GUI Window', 0
    hello_txt  db 'Try to close this window!', 0
    hello_len  = $ - hello_txt - 1

    mb_text    db 'Are you sure?', 0
    mb_cap     db 'Confirm Exit', 0

section '.text' code readable executable
start:
    invoke GetModuleHandle, 0
    mov [wc.hInstance], eax
    mov [wc.lpfnWndProc], WindowProc
    invoke LoadCursor, 0, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.hbrBackground], COLOR_WINDOW + 1
    mov [wc.lpszClassName], class_name
    invoke RegisterClass, wc

    invoke  CreateWindowEx, 0, class_name, win_title,\
            WS_VISIBLE + WS_OVERLAPPEDWINDOW,\
            CW_USEDEFAULT, CW_USEDEFAULT, 350, 200, 0, 0, [wc.hInstance], 0

msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    cmp eax, 0
    je end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp msg_loop

end_loop:
    invoke ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp [wmsg], WM_PAINT
    je .on_paint
    cmp [wmsg], WM_CLOSE
    je .on_close
    cmp [wmsg], WM_DESTROY
    je .on_destroy

.def_proc:
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret

.on_paint:
    invoke BeginPaint, [hwnd], ps
    invoke TextOut, eax, 20, 20, hello_txt, hello_len
    invoke EndPaint, [hwnd], ps
    xor eax, eax
    ret

.on_close:
    invoke MessageBox, [hwnd], mb_text, mb_cap, MB_YESNO + MB_ICONQUESTION
    cmp eax, IDYES
    jne .keep_open
    invoke DestroyWindow, [hwnd]
.keep_open:
    xor eax, eax
    ret

.on_destroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    ret
endp

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
        user32, 'user32.dll',\
        gdi32, 'gdi32.dll'

    import kernel32,\
        GetModuleHandle, 'GetModuleHandleA',\
        ExitProcess, 'ExitProcess'

    import user32,\
        LoadCursor, 'LoadCursorA',\
        RegisterClass, 'RegisterClassA',\
        CreateWindowEx, 'CreateWindowExA',\
        GetMessage, 'GetMessageA',\
        TranslateMessage, 'TranslateMessage',\
        DispatchMessage, 'DispatchMessageA',\
        DefWindowProc, 'DefWindowProcA',\
        BeginPaint, 'BeginPaint',\
        EndPaint, 'EndPaint',\
        MessageBox, 'MessageBoxA',\
        DestroyWindow, 'DestroyWindow',\
        PostQuitMessage, 'PostQuitMessage'

    import gdi32,\
        TextOut, 'TextOutA'
