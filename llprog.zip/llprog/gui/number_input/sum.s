format PE console
entry start

include 'win32a.inc'

ID_EDIT_START = 100
ID_EDIT_END = 103
DEFAULT_VAL = 10

WINDOW_WIDTH = 300
WINDOW_HEIGHT = 220
EDIT_X = 90
EDIT_Y_START = 20
EDIT_WIDTH = 100
EDIT_HEIGHT = 24
EDIT_SPACING = 34

section '.data' data readable writeable
    wc WNDCLASS
    msg MSG
    hInstance dd ?
    hwnd dd ?
    OriginalEditProc dd 0

    className db 'FasmSumWindow', 0
    editClass db 'EDIT', 0
    titleFormat db 'Sum: %d', 0
    titleBuffer rb 64
    fmt db '%d', 0

section '.text' code readable executable
start:
    invoke GetModuleHandle, NULL
    mov [hInstance], eax
    mov [wc.lpfnWndProc], WindowProc
    mov eax, [hInstance]
    mov [wc.hInstance], eax
    invoke LoadCursor, NULL, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.hbrBackground], COLOR_WINDOW + 1
    mov [wc.lpszClassName], className
    invoke RegisterClass, wc

    ;dwStyle = WS_VISIBLE or WS_SYSMENU or WS_MINIMIZEBOX
    dwStyle = WS_VISIBLE or WS_OVERLAPPEDWINDOW

    invoke CreateWindowEx, 0, className, NULL,\
        dwStyle,\
        CW_USEDEFAULT, CW_USEDEFAULT, WINDOW_WIDTH, WINDOW_HEIGHT,\
        NULL, NULL, [hInstance], NULL
    mov [hwnd], eax

msg_loop:
    invoke GetMessage, msg, NULL, 0, 0
    test eax, eax
    jz end_loop
    invoke IsDialogMessage, [hwnd], msg
    push eax
   ;cinvoke printf, fmt, eax
    pop eax
    test eax, eax
    jnz msg_loop
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp msg_loop

end_loop:
    invoke ExitProcess, [msg.wParam]

proc WindowProc uses ebx edi, hwndWnd, wmsg, wparam, lparam
    cmp [wmsg], WM_CREATE
    je .wmcreate
    cmp [wmsg], WM_COMMAND
    je .wmcommand
    cmp [wmsg], WM_DESTROY
    je .wmdestroy
.defwndproc:
    invoke DefWindowProc, [hwndWnd], [wmsg], [wparam], [lparam]
    ret

.wmcreate:
    mov edi, ID_EDIT_START
    mov ebx, EDIT_Y_START
    
.create_loop:
    invoke CreateWindowEx, WS_EX_CLIENTEDGE, editClass, NULL,\
        WS_CHILD or WS_VISIBLE or WS_TABSTOP or ES_NUMBER,\
        EDIT_X, ebx, EDIT_WIDTH, EDIT_HEIGHT, [hwndWnd], edi, [hInstance], NULL
        
    push eax
    invoke SetDlgItemInt, [hwndWnd], edi, DEFAULT_VAL, TRUE
    pop eax
    
    invoke SetWindowLong, eax, GWL_WNDPROC, EditSubclassProc
    
    cmp [OriginalEditProc], 0
    jne .next_edit
    mov [OriginalEditProc], eax
    
.next_edit:
    add ebx, EDIT_SPACING
    inc edi
    cmp edi, ID_EDIT_END
    jle .create_loop

    invoke GetDlgItem, [hwndWnd], ID_EDIT_START
    mov ebx, eax
    invoke SetFocus, eax
    invoke SendMessage, ebx, EM_SETSEL, 0, -1

    stdcall UpdateSum, [hwndWnd]
    xor eax, eax
    ret

.wmcommand:
    mov eax, [wparam]
    shr eax, 16
    cmp ax, EN_CHANGE
    jne .defwndproc
    stdcall UpdateSum, [hwndWnd]
    xor eax, eax
    ret

.wmdestroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    ret
endp

proc EditSubclassProc uses ebx esi edi, hwndCtrl, wmsg, wparam, lparam
    cmp [wmsg], WM_GETDLGCODE
    je .getdlgcode
    cmp [wmsg], WM_KEYDOWN
    jne .default

    mov eax, [wparam]
    cmp eax, VK_UP
    je .move_up
    cmp eax, VK_DOWN
    je .move_down
    jmp .default

.getdlgcode:
    invoke CallWindowProc, [OriginalEditProc], [hwndCtrl], [wmsg], [wparam], [lparam]
    or eax, DLGC_WANTARROWS
    ret

.move_up:
    mov ebx, 1
    jmp .update_val
    
.move_down:
    mov ebx, -1

.update_val:
    invoke GetParent, [hwndCtrl]
    mov esi, eax
    invoke GetDlgCtrlID, [hwndCtrl]
    mov edi, eax
    invoke GetDlgItemInt, esi, edi, NULL, TRUE
    add eax, ebx
    invoke SetDlgItemInt, esi, edi, eax, TRUE
    xor eax, eax
    ret

.default:
    invoke CallWindowProc, [OriginalEditProc], [hwndCtrl], [wmsg], [wparam], [lparam]
    ret
endp

proc UpdateSum uses ebx edi, hwndWnd
    xor ebx, ebx
    mov edi, ID_EDIT_START
    
.sum_loop:
    invoke GetDlgItemInt, [hwndWnd], edi, NULL, TRUE
    add ebx, eax
    inc edi
    cmp edi, ID_EDIT_END
    jle .sum_loop

    cinvoke sprintf, titleBuffer, titleFormat, ebx
    invoke SetWindowText, [hwndWnd], titleBuffer
    ret
endp

section '.idata' import data readable writeable
library kernel32,           'KERNEL32.DLL',\
        user32,             'USER32.DLL',\
        msvcrt,             'MSVCRT.DLL'
import  kernel32,\
        ExitProcess,        'ExitProcess',\
        GetModuleHandle,    'GetModuleHandleA'
import  user32,\
        CallWindowProc,     'CallWindowProcA',\
        CreateWindowEx,     'CreateWindowExA',\
        DefWindowProc,      'DefWindowProcA',\
        DispatchMessage,    'DispatchMessageA',\
        GetDlgCtrlID,       'GetDlgCtrlID',\
        GetDlgItem,         'GetDlgItem',\
        GetDlgItemInt,      'GetDlgItemInt',\
        SetFocus,           'SetFocus',\
        GetMessage,         'GetMessageA',\
        GetParent,          'GetParent',\
        IsDialogMessage,    'IsDialogMessageA',\
        LoadCursor,         'LoadCursorA',\
        PostQuitMessage,    'PostQuitMessage',\
        RegisterClass,      'RegisterClassA',\
        SetDlgItemInt,      'SetDlgItemInt',\
        SetWindowLong,      'SetWindowLongA',\
        SendMessage,        'SendMessageA',\
        SetWindowText,      'SetWindowTextA',\
        TranslateMessage,   'TranslateMessage'
import  msvcrt,\
        sprintf,            'sprintf',\
        printf,             'printf'
