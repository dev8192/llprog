format PE
entry start

include 'win32a.inc'

CTL_ID = 1001
BUF_SIZE = 16
RADIX = 10
WIN_W = 300
WIN_H = 200
EDT_X = 10
EDT_Y = 10
EDT_W = 100
EDT_H = 25

section '.data' data readable writeable
    hInstance       dd ?
    hwndMain        dd ?
    hwndEdit        dd ?
    OldEditProc     dd ?
    delta           dd ?
    wc              WNDCLASS
    msg             MSG
    _class          db 'NumWin', 0
    _title          db 'Number Input', 0
    _edit           db 'EDIT', 0
    _fmt            db '%d', 10, 0
    buffer          rb BUF_SIZE

section '.text' code readable executable
start:
    invoke  GetModuleHandle, NULL
    mov     [hInstance], eax
    mov     [wc.style], CS_HREDRAW or CS_VREDRAW
    mov     [wc.lpfnWndProc], WindowProc
    mov     eax, [hInstance]
    mov     [wc.hInstance], eax
    invoke  LoadCursor, NULL, IDC_ARROW
    mov     [wc.hCursor], eax
    mov     [wc.hbrBackground], COLOR_WINDOW + 1
    mov     [wc.lpszMenuName], NULL
    mov     [wc.lpszClassName], _class
    invoke  RegisterClass, wc
    invoke  CreateWindowEx, 0, _class, _title,\
            WS_OVERLAPPEDWINDOW or WS_VISIBLE,\
            CW_USEDEFAULT, CW_USEDEFAULT, WIN_W, WIN_H,\
            NULL, NULL, [hInstance], NULL
    mov     [hwndMain], eax
.msg_loop:
    invoke  GetMessage, msg, NULL, 0, 0
    or      eax, eax
    jz      .end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     .msg_loop
.end_loop:
    invoke  ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp     [wmsg], WM_CREATE
    je      .wm_create
    cmp     [wmsg], WM_DESTROY
    je      .wm_destroy
    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret
.wm_create:
    invoke  CreateWindowEx, WS_EX_CLIENTEDGE, _edit, NULL,\
            WS_CHILD or WS_VISIBLE or ES_NUMBER,\
            EDT_X, EDT_Y, EDT_W, EDT_H,\
            [hwnd], CTL_ID, [hInstance], NULL
    mov     [hwndEdit], eax
    invoke  SetFocus, eax
    invoke  SetWindowLong, eax, GWL_WNDPROC, EditProc
    mov     [OldEditProc], eax
    xor     eax, eax
    ret
.wm_destroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
    ret
endp

proc EditProc hwnd, wmsg, wparam, lparam
    cmp     [wmsg], WM_KEYDOWN
    je      .wm_keydown
.defproc:
    invoke  CallWindowProc, [OldEditProc], [hwnd], [wmsg], [wparam], [lparam]
    ret

.wm_keydown:
    cmp     [wparam], VK_UP
    je      .do_inc
    cmp     [wparam], VK_DOWN
    je      .do_dec
    jmp     .defproc
.do_inc:
    mov     [delta], 1
    jmp     .do_math
.do_dec:
    mov     [delta], -1
.do_math:
    invoke  GetWindowText, [hwnd], buffer, BUF_SIZE
    cinvoke atoi, buffer
    add     eax, [delta]
    cinvoke _itoa, eax, buffer, RADIX
    invoke  SetWindowText, [hwnd], buffer
    cinvoke printf, _fmt, eax
    xor     eax, eax
    ret
endp

section '.idata' import data readable writeable
library kernel32,           'kernel32.dll',\
        user32,             'user32.dll',\
        msvcrt,             'msvcrt.dll'
import  kernel32,\
        GetModuleHandle,    'GetModuleHandleA',\
        ExitProcess,        'ExitProcessA'
import  user32,\
        LoadCursor,         'LoadCursorA',\
        RegisterClass,      'RegisterClassA',\
        CreateWindowEx,     'CreateWindowExA',\
        SetFocus,           'SetFocus',\
        SetWindowLong,      'SetWindowLongA',\
        GetMessage,         'GetMessageA',\
        TranslateMessage,   'TranslateMessage',\
        DispatchMessage,    'DispatchMessageA',\
        DefWindowProc,      'DefWindowProcA',\
        PostQuitMessage,    'PostQuitMessage',\
        CallWindowProc,     'CallWindowProcA',\
        GetWindowText,      'GetWindowTextA',\
        SetWindowText,      'SetWindowTextA'
import  msvcrt,\
        printf,             'printf',\
        atoi,               'atoi',\
        _itoa,              '_itoa'
