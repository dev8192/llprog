format PE
entry start

include 'win32a.inc'

RECT_W = 200
RECT_H = 200

COL1_X = 50
COL2_X = 300
ROW1_Y = 50
ROW2_Y = 300

section '.data' data readable writeable
    class_name db 'ExampleWindow', 0
    window_name db 'Example Window', 0
    staticClass db 'STATIC', 0

    txtHand db 'IDC_HAND', 0
    txtIBeam db 'IDC_IBEAM', 0
    txtWait db 'IDC_WAIT', 0
    txtCross db 'IDC_CROSS', 0

    wc WNDCLASS
    msg MSG
    hInst dd ?

    hwndHand dd ?
    hwndIBeam dd ?
    hwndWait dd ?
    hwndCross dd ?

    hCurHand dd ?
    hCurIBeam dd ?
    hCurWait dd ?
    hCurCross dd ?

section '.text' code readable executable
start:
    invoke GetModuleHandle, 0
    mov [hInst], eax

    mov [wc.style], CS_HREDRAW or CS_VREDRAW
    mov [wc.lpfnWndProc], WindowProc
    mov eax, [hInst]
    mov [wc.hInstance], eax
    invoke LoadCursor, 0, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.hbrBackground], COLOR_WINDOW + 1
    mov [wc.lpszClassName], class_name
    invoke RegisterClass, wc

    invoke CreateWindowEx, 0, class_name, window_name,\
        WS_VISIBLE or WS_OVERLAPPEDWINDOW or WS_MAXIMIZE,\
        CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,\
        0, 0, [hInst], 0

.msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    test eax, eax
    jz .end_loop
    invoke DispatchMessage, msg
    jmp .msg_loop

.end_loop:
    invoke ExitProcess, [msg.wParam]

proc WindowProc uses ebx esi edi, hwnd, wmsg, wparam, lparam
    cmp [wmsg], WM_CREATE
    je .wm_create
    cmp [wmsg], WM_SETCURSOR
    je .wm_setcursor
    cmp [wmsg], WM_CTLCOLORSTATIC
    je .wm_ctlcolor
    cmp [wmsg], WM_DESTROY
    je .wm_destroy
.defproc:
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret

.wm_create:
    invoke LoadCursor, 0, IDC_HAND
    mov [hCurHand], eax
    invoke LoadCursor, 0, IDC_IBEAM
    mov [hCurIBeam], eax
    invoke LoadCursor, 0, IDC_WAIT
    mov [hCurWait], eax
    invoke LoadCursor, 0, IDC_CROSS
    mov [hCurCross], eax

    invoke CreateWindowEx, 0, staticClass, txtHand,\
        WS_CHILD or WS_VISIBLE or SS_CENTER or SS_CENTERIMAGE or SS_NOTIFY,\
        COL1_X, ROW1_Y, RECT_W, RECT_H, [hwnd], 0, [hInst], 0
    mov [hwndHand], eax

    invoke CreateWindowEx, 0, staticClass, txtIBeam,\
        WS_CHILD or WS_VISIBLE or SS_CENTER or SS_CENTERIMAGE or SS_NOTIFY,\
        COL2_X, ROW1_Y, RECT_W, RECT_H, [hwnd], 0, [hInst], 0
    mov [hwndIBeam], eax

    invoke CreateWindowEx, 0, staticClass, txtWait,\
        WS_CHILD or WS_VISIBLE or SS_CENTER or SS_CENTERIMAGE or SS_NOTIFY,\
        COL1_X, ROW2_Y, RECT_W, RECT_H, [hwnd], 0, [hInst], 0
    mov [hwndWait], eax

    invoke CreateWindowEx, 0, staticClass, txtCross,\
        WS_CHILD or WS_VISIBLE or SS_CENTER or SS_CENTERIMAGE or SS_NOTIFY,\
        COL2_X, ROW2_Y, RECT_W, RECT_H, [hwnd], 0, [hInst], 0
    mov [hwndCross], eax

    xor eax, eax
    ret

.wm_setcursor:
    mov eax, [wparam]
    cmp eax, [hwndHand]
    je .set_hand
    cmp eax, [hwndIBeam]
    je .set_ibeam
    cmp eax, [hwndWait]
    je .set_wait
    cmp eax, [hwndCross]
    je .set_cross
    jmp .defproc

.set_hand:
    invoke SetCursor, [hCurHand]
    mov eax, 1
    ret

.set_ibeam:
    invoke SetCursor, [hCurIBeam]
    mov eax, 1
    ret

.set_wait:
    invoke SetCursor, [hCurWait]
    mov eax, 1
    ret

.set_cross:
    invoke SetCursor, [hCurCross]
    mov eax, 1
    ret

.wm_ctlcolor:
    invoke SetBkMode, [wparam], TRANSPARENT
    invoke GetStockObject, LTGRAY_BRUSH
    ret

.wm_destroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    ret
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            user32,             'user32.dll',\
            gdi32,              'gdi32.dll'
    import  kernel32,\
            GetModuleHandle,    'GetModuleHandleA',\
            ExitProcess,        'ExitProcess'
    import  user32,\
            RegisterClass,      'RegisterClassA',\
            CreateWindowEx,     'CreateWindowExA',\
            DefWindowProc,      'DefWindowProcA',\
            GetMessage,         'GetMessageA',\
            DispatchMessage,    'DispatchMessageA',\
            PostQuitMessage,    'PostQuitMessage',\
            LoadCursor,         'LoadCursorA',\
            SetCursor,          'SetCursor'
    import  gdi32,\
            GetStockObject,     'GetStockObject',\
            SetBkMode,          'SetBkMode'
