format PE GUI 4.0
entry start

include 'win32a.inc'

HIT_MARGIN = 8

DRAG_LEFT   = 1
DRAG_RIGHT  = 2
DRAG_TOP    = 4
DRAG_BOTTOM = 8

WND_W = 600
WND_H = 400

LOWORD_MASK = 0FFFFh
HTCLIENT = 1

section '.data' data readable writeable
    mainClass db 'MainWndClass', 0
    mainTitle db 'Cursor Hover Zones', 0
    
    wc WNDCLASSEX
    msg MSG
    ps PAINTSTRUCT
    rect RECT 200, 125, 400, 275
    
    hoverState dd 0
    
    hCurArrow dd ?
    hCurWE dd ?
    hCurNS dd ?
    hCurNWSE dd ?
    hCurNESW dd ?
    hActiveCursor dd ?

section '.text' code readable executable
start:
    invoke GetModuleHandle, NULL
    mov [wc.hInstance], eax
    mov [wc.cbSize], sizeof.WNDCLASSEX
    mov [wc.style], CS_HREDRAW or CS_VREDRAW
    mov [wc.lpfnWndProc], WindowProc
    invoke LoadCursor, NULL, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.hbrBackground], COLOR_WINDOW + 1
    mov [wc.lpszClassName], mainClass
    invoke RegisterClassEx, wc

    invoke CreateWindowEx, 0, mainClass, mainTitle, \
        WS_VISIBLE or WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, \
        CW_USEDEFAULT, WND_W, WND_H, NULL, NULL, [wc.hInstance], NULL

.msg_loop:
    invoke GetMessage, msg, NULL, 0, 0
    test eax, eax
    jz .end_loop
    invoke DispatchMessage, msg
    jmp .msg_loop

.end_loop:
    invoke ExitProcess, [msg.wParam]

proc WindowProc uses ebx esi edi, hwnd, wmsg, wparam, lparam
    cmp [wmsg], WM_CREATE
    je .on_create
    cmp [wmsg], WM_PAINT
    je .on_paint
    cmp [wmsg], WM_MOUSEMOVE
    je .on_mousemove
    cmp [wmsg], WM_SETCURSOR
    je .on_setcursor
    cmp [wmsg], WM_DESTROY
    je .on_destroy
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    jmp .finish_ret

.on_create:
    invoke LoadCursor, NULL, IDC_ARROW
    mov [hCurArrow], eax
    mov [hActiveCursor], eax
    invoke LoadCursor, NULL, IDC_SIZEWE
    mov [hCurWE], eax
    invoke LoadCursor, NULL, IDC_SIZENS
    mov [hCurNS], eax
    invoke LoadCursor, NULL, IDC_SIZENWSE
    mov [hCurNWSE], eax
    invoke LoadCursor, NULL, IDC_SIZENESW
    mov [hCurNESW], eax
    xor eax, eax
    jmp .finish_ret

.on_paint:
    invoke BeginPaint, [hwnd], ps
    invoke GetStockObject, BLACK_PEN
    invoke SelectObject, [ps.hdc], eax
    invoke GetStockObject, NULL_BRUSH
    invoke SelectObject, [ps.hdc], eax
    invoke Rectangle, [ps.hdc], [rect.left], [rect.top], \
        [rect.right], [rect.bottom]
    invoke EndPaint, [hwnd], ps
    xor eax, eax
    jmp .finish_ret

.on_mousemove:
    movsx esi, word [lparam]
    mov eax, [lparam]
    shr eax, 16
    movsx edi, ax
    stdcall GetHitState, esi, edi
    mov [hoverState], eax
    stdcall UpdateCursor, eax
    jmp .finish_ret

.on_setcursor:
    mov eax, [lparam]
    and eax, LOWORD_MASK
    cmp eax, HTCLIENT
    jne .finish_def
    cmp [hoverState], 0
    je .finish_def
    invoke SetCursor, [hActiveCursor]
    mov eax, TRUE
    jmp .finish_ret

.on_destroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    jmp .finish_ret

.finish_def:
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
.finish_ret:
    ret
endp

proc GetHitState uses ebx esi edi, x, y
    mov esi, [x]
    mov edi, [y]
    xor ebx, ebx

    mov eax, [rect.left]
    sub eax, HIT_MARGIN
    cmp esi, eax
    jl .done
    mov eax, [rect.right]
    add eax, HIT_MARGIN
    cmp esi, eax
    jg .done
    mov eax, [rect.top]
    sub eax, HIT_MARGIN
    cmp edi, eax
    jl .done
    mov eax, [rect.bottom]
    add eax, HIT_MARGIN
    cmp edi, eax
    jg .done

    mov eax, esi
    sub eax, [rect.left]
    cdq
    xor eax, edx
    sub eax, edx
    cmp eax, HIT_MARGIN
    jg .chk_right
    or ebx, DRAG_LEFT
.chk_right:
    mov eax, esi
    sub eax, [rect.right]
    cdq
    xor eax, edx
    sub eax, edx
    cmp eax, HIT_MARGIN
    jg .chk_top
    or ebx, DRAG_RIGHT
.chk_top:
    mov eax, edi
    sub eax, [rect.top]
    cdq
    xor eax, edx
    sub eax, edx
    cmp eax, HIT_MARGIN
    jg .chk_bottom
    or ebx, DRAG_TOP
.chk_bottom:
    mov eax, edi
    sub eax, [rect.bottom]
    cdq
    xor eax, edx
    sub eax, edx
    cmp eax, HIT_MARGIN
    jg .done
    or ebx, DRAG_BOTTOM
.done:
    mov eax, ebx
    ret
endp

proc UpdateCursor uses ebx, state
    mov eax, [state]
    test eax, eax
    jz .arrow
    cmp eax, DRAG_LEFT
    je .we
    cmp eax, DRAG_RIGHT
    je .we
    cmp eax, DRAG_TOP
    je .ns
    cmp eax, DRAG_BOTTOM
    je .ns
    cmp eax, DRAG_LEFT or DRAG_TOP
    je .nwse
    cmp eax, DRAG_RIGHT or DRAG_BOTTOM
    je .nwse
    cmp eax, DRAG_RIGHT or DRAG_TOP
    je .nesw
    cmp eax, DRAG_LEFT or DRAG_BOTTOM
    je .nesw
.arrow:
    mov eax, [hCurArrow]
    jmp .done
.we:
    mov eax, [hCurWE]
    jmp .done
.ns:
    mov eax, [hCurNS]
    jmp .done
.nwse:
    mov eax, [hCurNWSE]
    jmp .done
.nesw:
    mov eax, [hCurNESW]
.done:
    mov [hActiveCursor], eax
    invoke SetCursor, eax
    ret
endp

section '.idata' import data readable
    library kernel32, 'kernel32.dll', \
            user32, 'user32.dll', \
            gdi32, 'gdi32.dll'

    import kernel32, \
           GetModuleHandle, 'GetModuleHandleA', \
           ExitProcess, 'ExitProcess'

    import user32, \
           RegisterClassEx, 'RegisterClassExA', \
           CreateWindowEx, 'CreateWindowExA', \
           DefWindowProc, 'DefWindowProcA', \
           GetMessage, 'GetMessageA', \
           DispatchMessage, 'DispatchMessageA', \
           PostQuitMessage, 'PostQuitMessage', \
           LoadCursor, 'LoadCursorA', \
           SetCursor, 'SetCursor', \
           BeginPaint, 'BeginPaint', \
           EndPaint, 'EndPaint'

    import gdi32, \
           GetStockObject, 'GetStockObject', \
           SelectObject, 'SelectObject', \
           Rectangle, 'Rectangle'
