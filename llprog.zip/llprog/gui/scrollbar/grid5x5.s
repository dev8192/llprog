format PE
entry start

include 'win32a.inc'
section '.data' data readable writeable
    class_name db 'ExampleWindow', 0
    window_title db 'Example Window', 0
    wc WNDCLASS
    msg MSG
    hwnd dd ?
    rect RECT
    ps PAINTSTRUCT
    hdc dd ?
    scroll_x dd ?
    scroll_y dd ?
    format_str db '%d', 0
    num_buf db 16 dup(?)

section '.text' code readable executable
start:
    mov [wc.style], CS_HREDRAW or CS_VREDRAW
    mov [wc.lpfnWndProc], WindowProc
    invoke GetModuleHandle, 0
    mov [wc.hInstance], eax
    invoke LoadCursor, 0, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.hbrBackground], COLOR_WINDOW + 1
    mov [wc.lpszClassName], class_name
    invoke RegisterClass, wc

    VISIBLE_SIZE equ 190
    mov [rect.left], 0
    mov [rect.top], 0
    mov [rect.right], VISIBLE_SIZE
    mov [rect.bottom], VISIBLE_SIZE
    invoke AdjustWindowRect, rect,\
        WS_OVERLAPPEDWINDOW or WS_HSCROLL or WS_VSCROLL, FALSE

    mov eax, [rect.right]
    sub eax, [rect.left]
    mov ebx, [rect.bottom]
    sub ebx, [rect.top]

    invoke CreateWindowEx, 0, class_name, window_title,\
        WS_VISIBLE or WS_OVERLAPPEDWINDOW or WS_HSCROLL or WS_VSCROLL,\
        CW_USEDEFAULT, CW_USEDEFAULT, eax, ebx,\
        0, 0, [wc.hInstance], 0
    mov [hwnd], eax

msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    test eax, eax
    jz end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp msg_loop

end_loop:
    invoke ExitProcess, [msg.wParam]

proc HandleScroll hwnd, bar, req
    local pos:DWORD
    invoke GetScrollPos, [hwnd], [bar]
    mov [pos], eax
    mov ebx, [req]
    movzx eax, bx

    cmp eax, SB_LINEUP
    je .dec
    cmp eax, SB_PAGEUP
    je .dec
    cmp eax, SB_LINEDOWN
    je .inc
    cmp eax, SB_PAGEDOWN
    je .inc
    cmp eax, SB_THUMBPOSITION
    je .thumb
    cmp eax, SB_THUMBTRACK
    je .thumb
    jmp .end

.dec:
    dec [pos]
    jmp .limit

.inc:
    inc [pos]
    jmp .limit

.thumb:
    shr ebx, 16
    mov [pos], ebx

.limit:
    cmp [pos], 0
    jge .check_max
    mov [pos], 0

.check_max:
    MAX_SCROLL equ 2
    cmp [pos], MAX_SCROLL
    jle .set
    mov [pos], MAX_SCROLL

.set:
    invoke SetScrollPos, [hwnd], [bar], [pos], TRUE
    invoke InvalidateRect, [hwnd], 0, TRUE

.end:
    ret
endp

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp [wmsg], WM_CREATE
    je .wm_create
    cmp [wmsg], WM_HSCROLL
    je .wm_hscroll
    cmp [wmsg], WM_VSCROLL
    je .wm_vscroll
    cmp [wmsg], WM_PAINT
    je .wm_paint
    cmp [wmsg], WM_DESTROY
    je .wm_destroy

.def_proc:
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    jmp .finish

.wm_create:
    invoke SetScrollRange, [hwnd], SB_HORZ, 0, MAX_SCROLL, TRUE
    invoke SetScrollRange, [hwnd], SB_VERT, 0, MAX_SCROLL, TRUE
    xor eax, eax
    jmp .finish

.wm_hscroll:
    stdcall HandleScroll, [hwnd], SB_HORZ, [wparam]
    xor eax, eax
    jmp .finish

.wm_vscroll:
    stdcall HandleScroll, [hwnd], SB_VERT, [wparam]
    xor eax, eax
    jmp .finish

.wm_paint:
    invoke BeginPaint, [hwnd], ps
    mov [hdc], eax

    CELL_PITCH equ 60
    invoke GetScrollPos, [hwnd], SB_HORZ
    imul eax, CELL_PITCH
    mov [scroll_x], eax

    invoke GetScrollPos, [hwnd], SB_VERT
    imul eax, CELL_PITCH
    mov [scroll_y], eax

    mov esi, 0

.draw_row:
    GRID_ROWS equ 5
    cmp esi, GRID_ROWS
    jge .end_draw_row

    mov edi, 0

.draw_col:
    GRID_COLS equ 5
    cmp edi, GRID_COLS
    jge .end_draw_col

    GAP_SIZE equ 10
    SQUARE_SIZE equ 50
    mov eax, edi
    imul eax, CELL_PITCH
    add eax, GAP_SIZE
    sub eax, [scroll_x]
    mov [rect.left], eax
    add eax, SQUARE_SIZE
    mov [rect.right], eax

    mov eax, esi
    imul eax, CELL_PITCH
    add eax, GAP_SIZE
    sub eax, [scroll_y]
    mov [rect.top], eax
    add eax, SQUARE_SIZE
    mov [rect.bottom], eax

    invoke Rectangle, [hdc], [rect.left], [rect.top],\
        [rect.right], [rect.bottom]

    mov eax, esi
    imul eax, GRID_COLS
    add eax, edi
    inc eax

    cinvoke wsprintf, num_buf, format_str, eax

    invoke DrawText, [hdc], num_buf, -1, rect,\
        DT_CENTER or DT_VCENTER or DT_SINGLELINE

    inc edi
    jmp .draw_col

.end_draw_col:
    inc esi
    jmp .draw_row

.end_draw_row:
    invoke EndPaint, [hwnd], ps
    xor eax, eax
    jmp .finish

.wm_destroy:
    invoke PostQuitMessage, 0
    xor eax, eax

.finish:
    ret
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            user32,             'user32.dll',\
            gdi32,              'gdi32.dll'
    import  kernel32,\
            GetModuleHandle,    'GetModuleHandleA',\
            ExitProcess,        'ExitProcess'
    import  user32,\
            AdjustWindowRect,   'AdjustWindowRect',\
            BeginPaint,         'BeginPaint',\
            CreateWindowEx,     'CreateWindowExA',\
            DefWindowProc,      'DefWindowProcA',\
            DispatchMessage,    'DispatchMessageA',\
            DrawText,           'DrawTextA',\
            EndPaint,           'EndPaint',\
            GetMessage,         'GetMessageA',\
            GetScrollPos,       'GetScrollPos',\
            InvalidateRect,     'InvalidateRect',\
            LoadCursor,         'LoadCursorA',\
            PostQuitMessage,    'PostQuitMessage',\
            RegisterClass,      'RegisterClassA',\
            SetScrollPos,       'SetScrollPos',\
            SetScrollRange,     'SetScrollRange',\
            TranslateMessage,   'TranslateMessage',\
            wsprintf,           'wsprintfA'
    import  gdi32,\
            Rectangle,          'Rectangle'
