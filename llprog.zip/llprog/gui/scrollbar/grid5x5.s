format PE
entry start

include 'win32a.inc'

SQUARE_SIZE equ 50
GAP_SIZE equ 10
CELL_PITCH equ 60
GRID_COLS equ 5
GRID_ROWS equ 5
MAX_SCROLL equ 2
VISIBLE_SIZE equ 190

section '.data' data readable writeable
    class_name db 'GridWindowClass', 0
    window_title db '5x5 Grid Scroll', 0
    wc WNDCLASS
    msg MSG
    hinstance dd ?
    hwnd dd ?
    rect RECT
    ps PAINTSTRUCT
    hdc dd ?
    scroll_x dd ?
    scroll_y dd ?
    format_str db '%d', 0
    num_buf db 16 dup(?)

section '.text' code readable executable
start:
    invoke GetModuleHandle, NULL
    mov [hinstance], eax

    mov [wc.style], CS_HREDRAW or CS_VREDRAW
    mov [wc.lpfnWndProc], WindowProc
    mov eax, [hinstance]
    mov [wc.hInstance], eax
    mov [wc.hIcon], NULL
    mov [wc.hCursor], NULL
    mov [wc.hbrBackground], COLOR_WINDOW + 1
    mov [wc.lpszClassName], class_name
    invoke RegisterClass, wc

    mov [rect.left], 0
    mov [rect.top], 0
    mov [rect.right], VISIBLE_SIZE
    mov [rect.bottom], VISIBLE_SIZE
    invoke AdjustWindowRect, rect, \
        WS_OVERLAPPEDWINDOW or WS_HSCROLL or WS_VSCROLL, FALSE

    mov eax, [rect.right]
    sub eax, [rect.left]
    mov ebx, [rect.bottom]
    sub ebx, [rect.top]

    invoke CreateWindowEx, 0, class_name, window_title, \
        WS_VISIBLE or WS_OVERLAPPEDWINDOW or WS_HSCROLL or WS_VSCROLL, \
        CW_USEDEFAULT, CW_USEDEFAULT, eax, ebx, \
        NULL, NULL, [hinstance], NULL
    mov [hwnd], eax

msg_loop:
    invoke GetMessage, msg, NULL, 0, 0
    test eax, eax
    jz end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp msg_loop

end_loop:
    invoke ExitProcess, [msg.wParam]

proc HandleScroll hwnd, bar, req
    local pos:DWORD
    invoke GetScrollPos, [hwnd], [bar]
    mov [pos], eax
    mov ebx, [req]
    movzx eax, bx

    cmp eax, SB_LINEUP
    je .dec
    cmp eax, SB_PAGEUP
    je .dec
    cmp eax, SB_LINEDOWN
    je .inc
    cmp eax, SB_PAGEDOWN
    je .inc
    cmp eax, SB_THUMBPOSITION
    je .thumb
    cmp eax, SB_THUMBTRACK
    je .thumb
    jmp .end

.dec:
    dec [pos]
    jmp .limit

.inc:
    inc [pos]
    jmp .limit

.thumb:
    shr ebx, 16
    mov [pos], ebx

.limit:
    cmp [pos], 0
    jge .check_max
    mov [pos], 0

.check_max:
    cmp [pos], MAX_SCROLL
    jle .set
    mov [pos], MAX_SCROLL

.set:
    invoke SetScrollPos, [hwnd], [bar], [pos], TRUE
    invoke InvalidateRect, [hwnd], NULL, TRUE

.end:
    ret
endp

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp [wmsg], WM_CREATE
    je .wm_create
    cmp [wmsg], WM_HSCROLL
    je .wm_hscroll
    cmp [wmsg], WM_VSCROLL
    je .wm_vscroll
    cmp [wmsg], WM_PAINT
    je .wm_paint
    cmp [wmsg], WM_DESTROY
    je .wm_destroy

.def_proc:
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    jmp .finish

.wm_create:
    invoke SetScrollRange, [hwnd], SB_HORZ, 0, MAX_SCROLL, TRUE
    invoke SetScrollRange, [hwnd], SB_VERT, 0, MAX_SCROLL, TRUE
    xor eax, eax
    jmp .finish

.wm_hscroll:
    invoke HandleScroll, [hwnd], SB_HORZ, [wparam]
    xor eax, eax
    jmp .finish

.wm_vscroll:
    invoke HandleScroll, [hwnd], SB_VERT, [wparam]
    xor eax, eax
    jmp .finish

.wm_paint:
    invoke BeginPaint, [hwnd], ps
    mov [hdc], eax

    invoke GetScrollPos, [hwnd], SB_HORZ
    imul eax, CELL_PITCH
    mov [scroll_x], eax

    invoke GetScrollPos, [hwnd], SB_VERT
    imul eax, CELL_PITCH
    mov [scroll_y], eax

    mov esi, 0

.draw_row:
    cmp esi, GRID_ROWS
    jge .end_draw_row

    mov edi, 0

.draw_col:
    cmp edi, GRID_COLS
    jge .end_draw_col

    mov eax, edi
    imul eax, CELL_PITCH
    add eax, GAP_SIZE
    sub eax, [scroll_x]
    mov [rect.left], eax
    add eax, SQUARE_SIZE
    mov [rect.right], eax

    mov eax, esi
    imul eax, CELL_PITCH
    add eax, GAP_SIZE
    sub eax, [scroll_y]
    mov [rect.top], eax
    add eax, SQUARE_SIZE
    mov [rect.bottom], eax

    invoke Rectangle, [hdc], [rect.left], [rect.top], \
        [rect.right], [rect.bottom]

    mov eax, esi
    imul eax, GRID_COLS
    add eax, edi
    inc eax

    cinvoke wsprintf, num_buf, format_str, eax

    invoke DrawText, [hdc], num_buf, -1, rect, \
        DT_CENTER or DT_VCENTER or DT_SINGLELINE

    inc edi
    jmp .draw_col

.end_draw_col:
    inc esi
    jmp .draw_row

.end_draw_row:
    invoke EndPaint, [hwnd], ps
    xor eax, eax
    jmp .finish

.wm_destroy:
    invoke PostQuitMessage, 0
    xor eax, eax

.finish:
    ret
endp

section '.idata' import data readable

    library kernel32, 'KERNEL32.DLL', \
        user32, 'USER32.DLL', \
        gdi32, 'GDI32.DLL'

    import kernel32, \
        GetModuleHandle, 'GetModuleHandleA', \
        ExitProcess, 'ExitProcess'

    import user32, \
        RegisterClass, 'RegisterClassA', \
        AdjustWindowRect, 'AdjustWindowRect', \
        CreateWindowEx, 'CreateWindowExA', \
        GetMessage, 'GetMessageA', \
        TranslateMessage, 'TranslateMessage', \
        DispatchMessage, 'DispatchMessageA', \
        SetScrollRange, 'SetScrollRange', \
        GetScrollPos, 'GetScrollPos', \
        SetScrollPos, 'SetScrollPos', \
        InvalidateRect, 'InvalidateRect', \
        BeginPaint, 'BeginPaint', \
        EndPaint, 'EndPaint', \
        DrawText, 'DrawTextA', \
        DefWindowProc, 'DefWindowProcA', \
        PostQuitMessage, 'PostQuitMessage', \
        wsprintf, 'wsprintfA'

    import gdi32, \
        Rectangle, 'Rectangle'
