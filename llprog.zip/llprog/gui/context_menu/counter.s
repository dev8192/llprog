format PE GUI 4.0
entry start

include 'win32a.inc'

ID_TIMER  = 1
ID_TOGGLE = 101
ID_RESET  = 102

section '.data' data readable writeable

    hInstance   dd ?
    hwnd        dd ?
    wc          WNDCLASS
    msg         MSG
    ps          PAINTSTRUCT
    rect        RECT
    pt          POINT
    hMenu       dd ?

    counter     dd 0
    is_paused   dd 0

    szClass     db 'CounterApp', 0
    szTitle     db 'FASM Counter', 0
    szFormat    db '%d', 0
    szPause     db 'Pause', 0
    szStart     db 'Start', 0
    szReset     db 'Reset', 0
    buffer      rb 32

section '.text' code readable executable

start:
    invoke  GetModuleHandle, 0
    mov     [hInstance], eax

    mov     [wc.style], CS_HREDRAW or CS_VREDRAW
    mov     [wc.lpfnWndProc], WindowProc
    mov     [wc.hInstance], eax
    invoke  LoadIcon, 0, IDI_APPLICATION
    mov     [wc.hIcon], eax
    invoke  LoadCursor, 0, IDC_ARROW
    mov     [wc.hCursor], eax
    mov     [wc.hbrBackground], COLOR_WINDOW + 1
    mov     [wc.lpszClassName], szClass
    invoke  RegisterClass, wc

    invoke  CreateWindowEx, 0, szClass, szTitle, WS_VISIBLE or WS_OVERLAPPEDWINDOW, \
            CW_USEDEFAULT, CW_USEDEFAULT, 250, 150, 0, 0, [hInstance], 0
    mov     [hwnd], eax

    invoke  SetTimer, [hwnd], ID_TIMER, 1000, 0

msg_loop:
    invoke  GetMessage, msg, 0, 0, 0
    test    eax, eax
    jz      end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     msg_loop

end_loop:
    invoke  ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp     [wmsg], WM_TIMER
    je      .wmtimer
    cmp     [wmsg], WM_PAINT
    je      .wmpaint
    cmp     [wmsg], WM_CONTEXTMENU
    je      .wmcontextmenu
    cmp     [wmsg], WM_COMMAND
    je      .wmcommand
    cmp     [wmsg], WM_DESTROY
    je      .wmdestroy

    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret

.wmtimer:
    cmp     [is_paused], 0
    jne     .finish
    inc     [counter]
    invoke  InvalidateRect, [hwnd], 0, TRUE
    jmp     .finish

.wmpaint:
    invoke  BeginPaint, [hwnd], ps
    invoke  GetClientRect, [hwnd], rect
    cinvoke wsprintf, buffer, szFormat, [counter]
    invoke  DrawText, [ps.hdc], buffer, -1, rect, DT_CENTER or DT_VCENTER or DT_SINGLELINE
    invoke  EndPaint, [hwnd], ps
    jmp     .finish

.wmcontextmenu:
    invoke  CreatePopupMenu
    mov     [hMenu], eax

    cmp     [is_paused], 0
    jne     .menu_paused
    invoke  AppendMenu, [hMenu], MF_STRING, ID_TOGGLE, szPause
    jmp     .menu_reset

.menu_paused:
    invoke  AppendMenu, [hMenu], MF_STRING, ID_TOGGLE, szStart

.menu_reset:
    invoke  AppendMenu, [hMenu], MF_STRING, ID_RESET, szReset

    invoke  GetCursorPos, pt
    invoke  TrackPopupMenu, [hMenu], TPM_RIGHTBUTTON, [pt.x], [pt.y], 0, [hwnd], 0
    invoke  DestroyMenu, [hMenu]
    jmp     .finish

.wmcommand:
    mov     eax, [wparam]
    and     eax, 0FFFFh
    cmp     eax, ID_TOGGLE
    je      .cmd_toggle
    cmp     eax, ID_RESET
    je      .cmd_reset
    jmp     .finish

.cmd_toggle:
    xor     [is_paused], 1
    jmp     .finish

.cmd_reset:
    mov     [counter], 0
    invoke  InvalidateRect, [hwnd], 0, TRUE
    jmp     .finish

.wmdestroy:
    invoke  KillTimer, [hwnd], ID_TIMER
    invoke  PostQuitMessage, 0
    xor     eax, eax
    ret

.finish:
    xor     eax, eax
    ret
endp

section '.idata' import data readable writeable

    library kernel32, 'KERNEL32.DLL',\
            user32, 'USER32.DLL'

    import kernel32,\
        GetModuleHandle, 'GetModuleHandleA',\
        ExitProcess, 'ExitProcess'

    import user32,\
        AppendMenu, 'AppendMenuA',\
        BeginPaint, 'BeginPaint',\
        CreatePopupMenu, 'CreatePopupMenu',\
        CreateWindowEx, 'CreateWindowExA',\
        DefWindowProc, 'DefWindowProcA',\
        DestroyMenu, 'DestroyMenu',\
        DispatchMessage, 'DispatchMessageA',\
        DrawText, 'DrawTextA',\
        EndPaint, 'EndPaint',\
        GetClientRect, 'GetClientRect',\
        GetCursorPos, 'GetCursorPos',\
        GetMessage, 'GetMessageA',\
        InvalidateRect, 'InvalidateRect',\
        KillTimer, 'KillTimer',\
        LoadCursor, 'LoadCursorA',\
        LoadIcon, 'LoadIconA',\
        PostQuitMessage, 'PostQuitMessage',\
        RegisterClass, 'RegisterClassA',\
        SetTimer, 'SetTimer',\
        TrackPopupMenu, 'TrackPopupMenu',\
        TranslateMessage, 'TranslateMessage',\
        wsprintf, 'wsprintfA'
