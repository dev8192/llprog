format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    wc          WNDCLASS
    msg         MSG
    pt          POINT

    szClass     db 'ContextMenuApp', 0
    szTitle     db 'Right-Click inside this window!', 0
    fmt1        db 'GetCursorPos: %d %d', 10, 0
    fmt2        db 'lparam: %d %d', 10, 0

section '.text' code readable executable

start:
    mov     [wc.style], CS_HREDRAW or CS_VREDRAW
    mov     [wc.lpfnWndProc], WindowProc
    invoke  GetModuleHandle, 0
    mov     [wc.hInstance], eax
    invoke  LoadIcon, 0, IDI_APPLICATION
    mov     [wc.hIcon], eax
    invoke  LoadCursor, 0, IDC_ARROW
    mov     [wc.hCursor], eax
    mov     [wc.hbrBackground], COLOR_WINDOW + 1
    mov     [wc.lpszClassName], szClass
    invoke  RegisterClass, wc

    invoke  CreateWindowEx, 0, szClass, szTitle,\
            WS_VISIBLE or WS_OVERLAPPEDWINDOW, \
            CW_USEDEFAULT, CW_USEDEFAULT, 400, 300, 0, 0, [wc.hInstance], 0

msg_loop:
    invoke  GetMessage, msg, 0, 0, 0
    test    eax, eax
    jz      end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     msg_loop

end_loop:
    invoke  ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp     [wmsg], WM_CONTEXTMENU
    je      .wmcontextmenu
    cmp     [wmsg], WM_DESTROY
    je      .wmdestroy
    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret

.wmcontextmenu:
    invoke  GetCursorPos, pt
    cinvoke printf, fmt1, [pt.x], [pt.y]

    mov     eax, [lparam]
    movsx   ecx, ax
    sar     eax, 16
    cinvoke printf, fmt2, ecx, eax

    xor     eax, eax
    ret

.wmdestroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
    ret
endp

section '.idata' import data readable writeable
    library kernel32,           'KERNEL32.DLL',\
            user32,             'USER32.DLL',\
            msvcrt,             'MSVCRT.DLL'
    import  kernel32,\
            GetModuleHandle,    'GetModuleHandleA',\
            ExitProcess,        'ExitProcess'
    import  user32,\
            CreateWindowEx,     'CreateWindowExA',\
            DefWindowProc,      'DefWindowProcA',\
            DispatchMessage,    'DispatchMessageA',\
            GetCursorPos,       'GetCursorPos',\
            GetMessage,         'GetMessageA',\
            LoadCursor,         'LoadCursorA',\
            LoadIcon,           'LoadIconA',\
            PostQuitMessage,    'PostQuitMessage',\
            RegisterClass,      'RegisterClassA',\
            TranslateMessage,   'TranslateMessage'
    import  msvcrt,\
            printf,             'printf'
