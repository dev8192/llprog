format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    wc              WNDCLASS
    msg             MSG
    ps              PAINTSTRUCT
    rect            RECT

    hInst           dd ?
    hwnd            dd ?
    hMenu           dd ?
    menuId          dd ?
    hBrush          dd ?
    bgColor         dd 0x00FFFFFF

    clsName         db 'ColorMenuClass', 0
    winTitle        db 'Right-Click for Colors', 0

    strRed          db 'Red', 0
    strGreen        db 'Green', 0
    strBlue         db 'Blue', 0
    contextmenu_msg1 db 'contextmenu_msg1', 10, 0
    contextmenu_msg2 db 'contextmenu_msg2', 10, 0

section '.text' code readable executable
start:
    invoke  GetModuleHandleA, 0
    mov     [hInst], eax

    mov     [wc.style], CS_HREDRAW or CS_VREDRAW
    mov     [wc.lpfnWndProc], WindowProc
    mov     [wc.hInstance], eax
    invoke  LoadCursor, 0, IDC_ARROW
    mov     [wc.hCursor],eax
    mov     [wc.hbrBackground], COLOR_WINDOW + 1
    mov     [wc.lpszClassName], clsName
    invoke  RegisterClassA, wc

    invoke  CreateWindowExA, 0, clsName, winTitle, WS_VISIBLE or WS_OVERLAPPEDWINDOW,\
        CW_USEDEFAULT, CW_USEDEFAULT, 400, 300, 0, 0, [hInst], 0
    mov     [hwnd], eax

msg_loop:
    invoke  GetMessageA, msg, 0, 0, 0
    test    eax, eax
    jz      end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessageA, msg
    jmp     msg_loop

end_loop:
    invoke  ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp     [wmsg], WM_PAINT
    je      .wm_paint
    cmp     [wmsg], WM_CONTEXTMENU
    je      .wm_contextmenu
    cmp     [wmsg], WM_DESTROY
    je      .wm_destroy
    invoke  DefWindowProcA, [hwnd], [wmsg], [wparam], [lparam]
    ret

.wm_paint:
    invoke  BeginPaint, [hwnd], ps
    invoke  GetClientRect, [hwnd], rect
    invoke  CreateSolidBrush, [bgColor]
    mov     [hBrush], eax
    invoke  FillRect, [ps.hdc], rect, [hBrush]
    invoke  DeleteObject, [hBrush]
    invoke  EndPaint, [hwnd], ps
    xor     eax, eax
    ret

.wm_contextmenu:
    cinvoke printf, contextmenu_msg1
    invoke  CreatePopupMenu
    mov     [hMenu], eax

    invoke  AppendMenuA, [hMenu], 0, 1, strRed
    invoke  AppendMenuA, [hMenu], 0, 2, strGreen
    invoke  AppendMenuA, [hMenu], 0, 3, strBlue

    mov     eax, [lparam]
    movsx   ecx, ax
    shr     eax, 16
    movsx   edx, ax

    invoke  TrackPopupMenu, [hMenu],\
        TPM_RETURNCMD or TPM_NONOTIFY,\     ; uFlags
        ecx, edx,\                          ; x, y
        0, [hwnd], 0                        ; nReserved, hWnd, prcRect
    mov     [menuId], eax
    
    cinvoke printf, contextmenu_msg2

    invoke  DestroyMenu, [hMenu]

    cmp     [menuId], 1
    je      .set_red
    cmp     [menuId], 2
    je      .set_green
    cmp     [menuId], 3
    je      .set_blue
    jmp     .done_menu

.set_red:
    mov     [bgColor], 0x000000FF
    jmp     .repaint
.set_green:
    mov     [bgColor], 0x0000FF00
    jmp     .repaint
.set_blue:
    mov     [bgColor], 0x00FF0000

.repaint:
    invoke  InvalidateRect, [hwnd], 0, 1

.done_menu:
    xor     eax, eax
    ret

.wm_destroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
    ret
endp

section '.idata' import data readable
    library kernel32,           'KERNEL32.DLL',\
            user32,             'USER32.DLL',\
            gdi32,              'GDI32.DLL',\
            msvcrt,             'MSVCRT.DLL'
    import  kernel32,\
            GetModuleHandleA,   'GetModuleHandleA',\
            ExitProcess,        'ExitProcess'
    import  user32,\
            RegisterClassA,     'RegisterClassA',\
            CreateWindowExA,    'CreateWindowExA',\
            GetMessageA,        'GetMessageA',\
            TranslateMessage,   'TranslateMessage',\
            DispatchMessageA,   'DispatchMessageA',\
            DefWindowProcA,     'DefWindowProcA',\
            PostQuitMessage,    'PostQuitMessage',\
            BeginPaint,         'BeginPaint',\
            EndPaint,           'EndPaint',\
            GetClientRect,      'GetClientRect',\
            FillRect,           'FillRect',\
            InvalidateRect,     'InvalidateRect',\
            LoadCursor,         'LoadCursorA',\
            CreatePopupMenu,    'CreatePopupMenu',\
            AppendMenuA,        'AppendMenuA',\
            TrackPopupMenu,     'TrackPopupMenu',\
            DestroyMenu,        'DestroyMenu'
    import  gdi32,\
            CreateSolidBrush,   'CreateSolidBrush',\
            DeleteObject,       'DeleteObject'
    import  msvcrt,\
            printf,             'printf'
