format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable

    class_name      db 'MenuDemoClass', 0
    window_title    db 'Menu API Differences', 0
    str_menu_title  db 'Demo Menu', 0
    option1         db 'Option 1', 0
    option2         db 'Option 2', 0
    option3         db 'Option 3', 0

    wc          WNDCLASS
    msg         MSG
    hwnd        dd ?
    hMainMenu   dd ?
    hSubMenu    dd ?
    mii         MENUITEMINFO

section '.text' code readable executable

start:
    invoke  GetModuleHandle, 0
    mov     [wc.hInstance], eax

    invoke  LoadCursor, 0, IDC_ARROW
    mov     [wc.hCursor], eax

    mov     [wc.style], 0
    mov     [wc.lpfnWndProc], WindowProc
    mov     [wc.lpszClassName], class_name
    mov     [wc.hbrBackground], COLOR_WINDOW+1

    invoke  RegisterClass, wc

    invoke  CreateWindowEx, 0, class_name, window_title,\
        WS_VISIBLE or WS_OVERLAPPEDWINDOW,\
        100, 100, 400, 200, 0, 0, [wc.hInstance], 0
    mov     [hwnd], eax

    invoke  CreateMenu
    mov     [hMainMenu], eax

    invoke  CreatePopupMenu
    mov     [hSubMenu], eax

    invoke  AppendMenu, [hSubMenu], MF_STRING, 101, option3

    uPosition = 0
    uIDNewItem = 102
    invoke  InsertMenu, [hSubMenu], uPosition, MF_BYPOSITION or MF_STRING, uIDNewItem, option1

    mov     [mii.cbSize], sizeof.MENUITEMINFO
    mov     [mii.fMask], MIIM_STRING or MIIM_ID
    mov     [mii.wID], 103
    mov     [mii.dwTypeData], option2
    invoke  InsertMenuItem, [hSubMenu], 1, TRUE, mii

    invoke  AppendMenu, [hMainMenu], MF_POPUP or MF_STRING, [hSubMenu], str_menu_title

    invoke  SetMenu, [hwnd], [hMainMenu]

msg_loop:
    invoke  GetMessage, msg, 0, 0, 0
    test    eax, eax
    jz      end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     msg_loop

end_loop:
    invoke  ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp     [wmsg], WM_DESTROY
    je      .wmdestroy
    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret
.wmdestroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
    ret
endp

section '.idata' import data readable writeable

    library kernel32, 'KERNEL32.DLL',\
            user32, 'USER32.DLL'

    import kernel32,\
           GetModuleHandle, 'GetModuleHandleA',\
           ExitProcess, 'ExitProcess'

    import user32,\
           RegisterClass, 'RegisterClassA',\
           CreateWindowEx, 'CreateWindowExA',\
           DefWindowProc, 'DefWindowProcA',\
           GetMessage, 'GetMessageA',\
           TranslateMessage, 'TranslateMessage',\
           DispatchMessage, 'DispatchMessageA',\
           PostQuitMessage, 'PostQuitMessage',\
           LoadCursor, 'LoadCursorA',\
           CreateMenu, 'CreateMenu',\
           CreatePopupMenu, 'CreatePopupMenu',\
           AppendMenu, 'AppendMenuA',\
           InsertMenu, 'InsertMenuA',\
           InsertMenuItem, 'InsertMenuItemA',\
           SetMenu, 'SetMenu'
