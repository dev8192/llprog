format PE console
entry start

include 'win32a.inc'

ID_CUT   = 101
ID_COPY  = 102
ID_PASTE = 103

section '.data' data readable writeable

    hInstance   dd ?
    hwnd        dd ?
    hAccel      dd ?
    wc          WNDCLASS
    msg         MSG

    szClass     db 'AccelApp', 0
    szTitle     db 'Focus this window and press Ctrl+X, Ctrl+C, Ctrl+V', 0
    szCut       db 'Action: CUT   (Ctrl+X)', 10, 0
    szCopy      db 'Action: COPY  (Ctrl+C)', 10, 0
    szPaste     db 'Action: PASTE (Ctrl+V)', 10, 0

    align 4
    accelList:
        ACCEL FCONTROL or FVIRTKEY, 'X', ID_CUT
        ACCEL FCONTROL or FVIRTKEY, 'C', ID_COPY
        ACCEL FCONTROL or FVIRTKEY, 'V', ID_PASTE

section '.text' code readable executable

start:
    invoke  GetModuleHandle, 0
    mov     [hInstance], eax

    mov     [wc.style], CS_HREDRAW or CS_VREDRAW
    mov     [wc.lpfnWndProc], WindowProc
    mov     [wc.hInstance], eax
    invoke  LoadIcon, 0, IDI_APPLICATION
    mov     [wc.hIcon], eax
    invoke  LoadCursor, 0, IDC_ARROW
    mov     [wc.hCursor], eax
    mov     [wc.hbrBackground], COLOR_WINDOW + 1
    mov     [wc.lpszClassName], szClass
    invoke  RegisterClass, wc

    invoke  CreateWindowEx, 0, szClass, szTitle,\
            WS_VISIBLE or WS_OVERLAPPEDWINDOW, \
            CW_USEDEFAULT, CW_USEDEFAULT, 450, 200, 0, 0, [hInstance], 0
    mov     [hwnd], eax

    invoke  CreateAcceleratorTable, accelList, 3
    mov     [hAccel], eax

msg_loop:
    invoke  GetMessage, msg, 0, 0, 0
    test    eax, eax
    jz      end_loop
    
    invoke  TranslateAccelerator, [hwnd], [hAccel], msg
    test    eax, eax
    jnz     msg_loop

    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     msg_loop

end_loop:
    invoke  ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp     [wmsg], WM_COMMAND
    je      .wmcommand
    cmp     [wmsg], WM_DESTROY
    je      .wmdestroy

.defwndproc:
    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret

.wmcommand:
    mov     eax, [wparam]
    and     eax, 0FFFFh
    
    cmp     eax, ID_CUT
    je      .cmd_cut
    cmp     eax, ID_COPY
    je      .cmd_copy
    cmp     eax, ID_PASTE
    je      .cmd_paste
    jmp     .finish

.cmd_cut:
    cinvoke printf, szCut
    jmp     .finish

.cmd_copy:
    cinvoke printf, szCopy
    jmp     .finish

.cmd_paste:
    cinvoke printf, szPaste
    jmp     .finish

.wmdestroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
    ret

.finish:
    xor     eax, eax
    ret
endp

section '.idata' import data readable writeable

    library kernel32, 'KERNEL32.DLL',\
            user32, 'USER32.DLL',\
            msvcrt, 'MSVCRT.DLL'

    import kernel32,\
        ExitProcess, 'ExitProcess',\
        GetModuleHandle, 'GetModuleHandleA'

    import user32,\
        CreateAcceleratorTable, 'CreateAcceleratorTableA',\
        CreateWindowEx, 'CreateWindowExA',\
        DefWindowProc, 'DefWindowProcA',\
        DispatchMessage, 'DispatchMessageA',\
        GetMessage, 'GetMessageA',\
        LoadCursor, 'LoadCursorA',\
        LoadIcon, 'LoadIconA',\
        PostQuitMessage, 'PostQuitMessage',\
        RegisterClass, 'RegisterClassA',\
        TranslateAccelerator, 'TranslateAcceleratorA',\
        TranslateMessage, 'TranslateMessage'

    import msvcrt,\
        printf, 'printf'
