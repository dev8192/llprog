; garbage
format PE GUI 4.0
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    _class      db 'VerifyClass',0
    _title      db 'HDC Verification',0
    fmt         db 'Immediate EAX: %p',13,10,'Stored ps.hdc: %p',0
    buffer      rb 128

section '.bss' readable writeable
    ps          PAINTSTRUCT
    rect        RECT

section '.code' code readable executable
start:
    invoke GetModuleHandle, 0
    invoke DialogBoxParam, eax, 37, 0, DlgProc, 0 ; Using a simple dialog/window for the test
    invoke ExitProcess, 0

proc DlgProc hwnd, msg, wparam, lparam
    push ebx esi edi
    cmp  [msg], WM_PAINT
    je   .wmpaint
    cmp  [msg], WM_CLOSE
    je   .wmclose
    xor  eax, eax
    jmp  .finish

.wmpaint:
    ; 1. Call BeginPaint
    invoke BeginPaint, [hwnd], ps
    
    ; 2. IMMEDIATELY move EAX to EBX to preserve it.
    ; If we call printf/wsprintf now, EAX will be lost.
    mov    ebx, eax 

    ; 3. Format a string comparing the two values
    ; Note: ps.hdc is a member of the structure, accessed as [ps.hdc]
    cinvoke wsprintf, buffer, fmt, ebx, [ps.hdc]

    ; 4. Draw the result so we can see it
    invoke GetClientRect, [hwnd], rect
    invoke DrawText, [ps.hdc], buffer, -1, rect, DT_CENTER or DT_VCENTER or DT_SINGLELINE
    
    invoke EndPaint, [hwnd], ps
    mov    eax, 1
    jmp    .finish

.wmclose:
    invoke EndDialog, [hwnd], 0
    mov    eax, 1

.finish:
    pop  edi esi ebx
    ret
endp

section '.res' resource data readable
  directory RT_DIALOG, dialogs
  resource dialogs, 37, LANG_ENGLISH+SUBLANG_DEFAULT, verification_dlg

  dialog verification_dlg, 'HDC Test', 100, 100, 200, 100, WS_CAPTION+WS_SYSMENU+WS_VISIBLE
  enddialog
