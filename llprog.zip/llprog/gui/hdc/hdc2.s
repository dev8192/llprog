format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt db 'HDC from EAX:         0x%08X', 10
        db 'HDC from PAINTSTRUCT: 0x%08X', 10, 0
    cls_name db 'WinClass', 0
    wc WNDCLASS
    msg MSG
    ps PAINTSTRUCT

section '.text' code readable executable
start:
    invoke GetModuleHandle, 0
    mov [wc.hInstance], eax
    mov [wc.lpfnWndProc], WindowProc
    mov [wc.lpszClassName], cls_name
    invoke RegisterClass, wc

    invoke CreateWindowEx, 0, cls_name, 0, WS_POPUP or WS_VISIBLE,\
        0, 0, 1, 1, 0, 0, [wc.hInstance], 0

msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    test eax, eax
    jle exit_app
    invoke DispatchMessage, msg
    jmp msg_loop

exit_app:
    invoke ExitProcess, 0

proc WindowProc hwnd, uMsg, wParam, lParam
    cmp [uMsg], WM_PAINT
    je .paint
    cmp [uMsg], WM_DESTROY
    je .destroy
    invoke DefWindowProc, [hwnd], [uMsg], [wParam], [lParam]
    ret

  .paint:
    invoke BeginPaint, [hwnd], ps
    cinvoke printf, fmt, eax, [ps.hdc]
    invoke EndPaint, [hwnd], ps
    invoke DestroyWindow, [hwnd]
    xor eax, eax
    ret

  .destroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    ret
endp

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
        user32, 'user32.dll',\
        msvcrt, 'msvcrt.dll'

    import kernel32,\
        ExitProcess, 'ExitProcess',\
        GetModuleHandle, 'GetModuleHandleA'

    import user32,\
        BeginPaint, 'BeginPaint',\
        CreateWindowEx, 'CreateWindowExA',\
        DefWindowProc, 'DefWindowProcA',\
        DestroyWindow, 'DestroyWindow',\
        DispatchMessage, 'DispatchMessageA',\
        EndPaint, 'EndPaint',\
        GetMessage, 'GetMessageA',\
        PostQuitMessage, 'PostQuitMessage',\
        RegisterClass, 'RegisterClassA'

    import msvcrt,\
        printf, 'printf'
