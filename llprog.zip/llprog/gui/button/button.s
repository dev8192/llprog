format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    ClassName db 'SimpleButtonWindow',0
    ButtonClass db 'BUTTON',0
    ButtonCaption db 'Click Me',0
    WindowTitle db 'Simple GUI',0
    ConsoleMessage db 'Button clicked!',13,10,0
    msg MSG
    wc WNDCLASSEX
    hInstance dd ?
    hMainWnd dd ?
    hButton dd ?
    hConsole dd ?
    bytesWritten dd ?

section '.code' code readable executable
start:
    invoke GetModuleHandleA,0
    mov [hInstance],eax

    mov [wc.cbSize],sizeof.WNDCLASSEX
    mov [wc.style],CS_HREDRAW or CS_VREDRAW
    mov [wc.lpfnWndProc],WndProc
    mov [wc.cbClsExtra],0
    mov [wc.cbWndExtra],0
    mov eax,[hInstance]
    mov [wc.hInstance],eax
    mov [wc.hbrBackground],COLOR_WINDOW+1
    mov [wc.lpszMenuName],0
    mov [wc.lpszClassName],ClassName
    mov [wc.hIcon],0
    mov [wc.hCursor],0
    mov [wc.hIconSm],0
    invoke RegisterClassExA,wc
    test eax,eax
    jz exit

    invoke CreateWindowExA,0,ClassName,WindowTitle,\
        WS_OVERLAPPEDWINDOW or WS_VISIBLE,\
        CW_USEDEFAULT,CW_USEDEFAULT,300,200,\
        0,0,[hInstance],0
    mov [hMainWnd],eax

msg_loop:
    invoke GetMessageA,msg,0,0,0
    test eax,eax
    jz exit
    invoke TranslateMessage,msg
    invoke DispatchMessageA,msg
    jmp msg_loop

exit:
    invoke ExitProcess,0

proc WndProc hwnd,wmsg,wparam,lparam
    cmp [wmsg],WM_CREATE
    je .on_create
    cmp [wmsg],WM_COMMAND
    je .on_command
    cmp [wmsg],WM_DESTROY
    je .on_destroy
    invoke DefWindowProcA,[hwnd],[wmsg],[wparam],[lparam]
    ret
.on_create:
    invoke CreateWindowExA,0,ButtonClass,ButtonCaption,\
        WS_CHILD or WS_VISIBLE or BS_PUSHBUTTON,\
        100,50,100,30,[hwnd],1001,[hInstance],0
    mov [hButton],eax
    xor eax,eax
    ret
.on_command:
    mov eax,[wparam]
    and eax,0FFFFh
    cmp eax,1001
    jne .default
    invoke AllocConsole
    invoke GetStdHandle,-11
    mov [hConsole],eax
    invoke WriteConsoleA,[hConsole],ConsoleMessage,17,bytesWritten,0
    xor eax,eax
    ret
.on_destroy:
    invoke PostQuitMessage,0
    xor eax,eax
    ret
.default:
    invoke DefWindowProcA,[hwnd],[wmsg],[wparam],[lparam]
    ret
endp

section '.idata' import data readable writeable
    library kernel32,'kernel32.dll',\
            user32,'user32.dll'
    import kernel32,\
            GetModuleHandleA,'GetModuleHandleA',\
            AllocConsole,'AllocConsole',\
            GetStdHandle,'GetStdHandle',\
            WriteConsoleA,'WriteConsoleA',\
            ExitProcess,'ExitProcess'
    import user32,\
            RegisterClassExA,'RegisterClassExA',\
            CreateWindowExA,'CreateWindowExA',\
            GetMessageA,'GetMessageA',\
            TranslateMessage,'TranslateMessage',\
            DispatchMessageA,'DispatchMessageA',\
            DefWindowProcA,'DefWindowProcA',\
            PostQuitMessage,'PostQuitMessage'
