format PE
entry start

include 'win32ax.inc'

BUTTON_ID = 1001

section '.data' data readable writeable
    wc                  WNDCLASS
    msg                 MSG
    class_name          db 'ExampleWindow', 0
    window_title        db 'Example Window', 0
    button_class        db 'BUTTON', 0
    button_caption      db 'Click Me', 0

section '.text' code readable executable
start:
    invoke  GetModuleHandle, 0
    mov     [wc.hInstance], eax
    mov     [wc.lpfnWndProc], window_proc
    invoke  LoadCursor, 0, IDC_ARROW
    mov     [wc.hCursor], eax
    mov     [wc.hbrBackground], COLOR_WINDOW + 1
    mov     [wc.lpszClassName], class_name
    invoke  RegisterClass, wc

    invoke  CreateWindowEx, 0, class_name, window_title,\
            WS_OVERLAPPEDWINDOW + WS_VISIBLE,\
            CW_USEDEFAULT, CW_USEDEFAULT, 300, 200,\
            0, 0, [wc.hInstance], 0

.msg_loop:
    invoke  GetMessage, msg, 0, 0, 0
    test    eax, eax
    jz      .end_loop
    invoke  DispatchMessage, msg
    jmp     .msg_loop
.end_loop:
    invoke  ExitProcess, [msg.wParam]

proc window_proc hwnd, wmsg, wparam, lparam
    cmp     [wmsg], WM_CREATE
    je      .wm_create
    cmp     [wmsg], WM_COMMAND
    je      .wm_command
    cmp     [wmsg], WM_DESTROY
    je      .wm_destroy
.defproc:
    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret

.wm_create:
    invoke  CreateWindowEx, 0, button_class, button_caption,\
            WS_CHILD or WS_VISIBLE or BS_PUSHBUTTON,\
            100, 50, 100, 30,\
            [hwnd], BUTTON_ID, [wc.hInstance], 0
    xor     eax, eax
    ret
.wm_command:
    mov     eax, [wparam]
    and     eax, 0FFFFh
    cmp     eax, BUTTON_ID
    jne     .defproc
    cinvoke puts, 'btn_clicked'
    xor     eax, eax
    ret
.wm_destroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
    ret
endp

section '.idata' import data readable
library kernel32,           'kernel32.dll',\
        user32,             'user32.dll',\
        msvcrt,             'msvcrt.dll'
import  kernel32,\
        ExitProcess,        'ExitProcess',\
        GetModuleHandle,    'GetModuleHandleA'
import  user32,\
        CreateWindowEx,     'CreateWindowExA',\
        DefWindowProc,      'DefWindowProcA',\
        DispatchMessage,    'DispatchMessageA',\
        GetMessage,         'GetMessageA',\
        LoadCursor,         'LoadCursorA',\
        PostQuitMessage,    'PostQuitMessage',\
        RegisterClass,      'RegisterClassA'
import  msvcrt,\
        printf,             'printf',\
        puts,               'puts'
