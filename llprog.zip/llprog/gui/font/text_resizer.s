format PE
entry start

include 'win32a.inc'

ID_BTN_PLUS equ 1001
ID_BTN_MINUS equ 1002
INITIAL_FONT_SIZE equ 40
FONT_STEP equ 10
MIN_FONT_SIZE equ 10

section '.data' data readable writeable
    class_name db 'ExampleWindow', 0
    window_name db 'Example Window', 0
    _btn_class db 'BUTTON', 0
    _btn_plus db '+', 0
    _btn_minus db '-', 0
    _font_face db 'Arial', 0
    _text db 'Hello World', 0

    wc WNDCLASS
    msg MSG
    ps PAINTSTRUCT
    rect RECT
    font_size dd INITIAL_FONT_SIZE

section '.text' code readable executable

start:
    mov [wc.style], CS_HREDRAW or CS_VREDRAW
    mov [wc.lpfnWndProc], WindowProc
    invoke GetModuleHandle, 0
    mov [wc.hInstance], eax
    invoke LoadCursor, 0, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.hbrBackground], COLOR_WINDOW + 1
    mov [wc.lpszClassName], class_name
    invoke RegisterClass, wc
    
    invoke CreateWindowEx, 0, class_name, window_name,\
        WS_VISIBLE or WS_OVERLAPPEDWINDOW or WS_MAXIMIZE,\
        CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,\
        0, 0, [wc.hInstance], 0
        
.msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    test eax, eax
    jz .end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp .msg_loop
    
.end_loop:
    invoke ExitProcess, [msg.wParam]
    
proc WindowProc hwnd, wmsg, wparam, lparam
    cmp [wmsg], WM_CREATE
    je .wm_create
    cmp [wmsg], WM_COMMAND
    je .wm_command
    cmp [wmsg], WM_PAINT
    je .wm_paint
    cmp [wmsg], WM_DESTROY
    je .wm_destroy
.def_wnd_proc:
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    jmp .finish
    
.wm_create:
    invoke CreateWindowEx, 0, _btn_class, _btn_plus,\
        WS_CHILD or WS_VISIBLE,\
        20, 20, 50, 50,\
        [hwnd], ID_BTN_PLUS, [wc.hInstance], 0 
    invoke CreateWindowEx, 0, _btn_class, _btn_minus,\
        WS_CHILD or WS_VISIBLE,\
        80, 20, 50, 50,\
        [hwnd], ID_BTN_MINUS, [wc.hInstance], 0
    xor eax, eax
    jmp .finish
    
.wm_command:
    mov eax, [wparam]
    and eax, 0FFFFh
    cmp eax, ID_BTN_PLUS
    je .btn_plus
    cmp eax, ID_BTN_MINUS
    je .btn_minus
    jmp .def_wnd_proc
    
.btn_plus:
    add [font_size], FONT_STEP
    invoke InvalidateRect, [hwnd], 0, TRUE
    xor eax, eax
    jmp .finish
    
.btn_minus:
    mov eax, [font_size]
    sub eax, FONT_STEP
    cmp eax, MIN_FONT_SIZE
    jl .skip_minus
    mov [font_size], eax
    invoke InvalidateRect, [hwnd], 0, TRUE
.skip_minus:
    xor eax, eax
    jmp .finish
    
.wm_paint:
    invoke BeginPaint, [hwnd], ps
    
    invoke CreateFont, [font_size], 0, 0, 0, FW_NORMAL, 0, 0, 0,\
        DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,\
        DEFAULT_QUALITY, DEFAULT_PITCH or FF_DONTCARE, _font_face
    push eax
    
    invoke SelectObject, [ps.hdc], eax
    push eax 
    
    invoke SetBkMode, [ps.hdc], TRANSPARENT
    invoke GetClientRect, [hwnd], rect
    invoke DrawText, [ps.hdc], _text, -1, rect,\
        DT_SINGLELINE or DT_CENTER or DT_VCENTER
        
    pop eax
    invoke SelectObject, [ps.hdc], eax
    
    pop eax
    invoke DeleteObject, eax
    
    invoke EndPaint, [hwnd], ps
    xor eax, eax
    jmp .finish
    
.wm_destroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    
.finish:
    ret
endp

section '.idata' import data readable writeable
    library kernel32, 'kernel32.dll',\
            user32, 'user32.dll',\
            gdi32, 'gdi32.dll'
    import  kernel32,\
            GetModuleHandle, 'GetModuleHandleA',\
            ExitProcess, 'ExitProcess'
    import  user32,\
            RegisterClass, 'RegisterClassA',\
            CreateWindowEx, 'CreateWindowExA',\
            DefWindowProc, 'DefWindowProcA',\
            GetMessage, 'GetMessageA',\
            TranslateMessage, 'TranslateMessage',\
            DispatchMessage, 'DispatchMessageA',\
            InvalidateRect, 'InvalidateRect',\
            BeginPaint, 'BeginPaint',\
            GetClientRect, 'GetClientRect',\
            DrawText, 'DrawTextA',\
            EndPaint, 'EndPaint',\
            LoadCursor, 'LoadCursorA',\
            PostQuitMessage, 'PostQuitMessage'
    import  gdi32,\
            CreateFont, 'CreateFontA',\
            SelectObject, 'SelectObject',\
            SetBkMode, 'SetBkMode',\
            DeleteObject, 'DeleteObject'
