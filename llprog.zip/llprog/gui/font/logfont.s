format PE
entry start

include 'win32a.inc'

TEXT_COLOR equ 0x00A0522D

section '.data' data readable writeable
    _class db 'FASMWIN', 0
    _title db 'LOGFONT Example', 0
    _font_name db 'Georgia', 0
    _text db 'Elegant Text with LOGFONT', 0

    wc WNDCLASS
    msg MSG
    ps PAINTSTRUCT
    rect RECT
    hinst dd ?
    lf LOGFONT

section '.text' code readable executable

start:
    invoke GetModuleHandle, 0
    mov [hinst], eax
    
    mov [wc.style], CS_HREDRAW or CS_VREDRAW
    mov [wc.lpfnWndProc], WindowProc
    mov [wc.cbClsExtra], 0
    mov [wc.cbWndExtra], 0
    mov eax, [hinst]
    mov [wc.hInstance], eax
    invoke LoadIcon, 0, IDI_APPLICATION
    mov [wc.hIcon], eax
    invoke LoadCursor, 0, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.hbrBackground], COLOR_WINDOW + 1
    mov [wc.lpszMenuName], 0
    mov [wc.lpszClassName], _class
    
    invoke RegisterClass, wc
    
    invoke CreateWindowEx, 0, _class, _title, \
        WS_VISIBLE or WS_OVERLAPPEDWINDOW, \
        CW_USEDEFAULT, CW_USEDEFAULT, 600, 300, \
        0, 0, [hinst], 0
        
msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    test eax, eax
    jz end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp msg_loop
    
end_loop:
    invoke ExitProcess, [msg.wParam]
    
proc WindowProc hwnd, wmsg, wparam, lparam
    cmp [wmsg], WM_CREATE
    je .wm_create
    cmp [wmsg], WM_PAINT
    je .wm_paint
    cmp [wmsg], WM_DESTROY
    je .wm_destroy
    
.def_wnd_proc:
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    jmp .finish
    
.wm_create:
    mov [lf.lfHeight], -48
    mov [lf.lfWeight], FW_BOLD
    mov [lf.lfItalic], TRUE
    mov [lf.lfUnderline], TRUE
    mov [lf.lfCharSet], DEFAULT_CHARSET
    mov [lf.lfOutPrecision], OUT_TT_PRECIS
    mov [lf.lfQuality], DEFAULT_QUALITY
    invoke lstrcpy, lf.lfFaceName, _font_name
    xor eax, eax
    jmp .finish
    
.wm_paint:
    invoke BeginPaint, [hwnd], ps
    
    invoke CreateFontIndirect, lf
    push eax
    
    invoke SelectObject, [ps.hdc], eax
    push eax 
    
    invoke SetBkMode, [ps.hdc], TRANSPARENT
    invoke SetTextColor, [ps.hdc], TEXT_COLOR
    
    invoke GetClientRect, [hwnd], rect
    
    invoke DrawText, [ps.hdc], _text, -1, rect, \
        DT_SINGLELINE or DT_CENTER or DT_VCENTER
        
    pop eax
    invoke SelectObject, [ps.hdc], eax
    
    pop eax
    invoke DeleteObject, eax
    
    invoke EndPaint, [hwnd], ps
    xor eax, eax
    jmp .finish
    
.wm_destroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    
.finish:
    ret
endp

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL', \
            user32, 'USER32.DLL', \
            gdi32, 'GDI32.DLL'
    import  kernel32, \
            GetModuleHandle, 'GetModuleHandleA', \
            lstrcpy, 'lstrcpyA', \
            ExitProcess, 'ExitProcess'
    import  user32, \
            RegisterClass, 'RegisterClassA', \
            CreateWindowEx, 'CreateWindowExA', \
            DefWindowProc, 'DefWindowProcA', \
            GetMessage, 'GetMessageA', \
            TranslateMessage, 'TranslateMessage', \
            DispatchMessage, 'DispatchMessageA', \
            BeginPaint, 'BeginPaint', \
            GetClientRect, 'GetClientRect', \
            DrawText, 'DrawTextA', \
            EndPaint, 'EndPaint', \
            LoadIcon, 'LoadIconA', \
            LoadCursor, 'LoadCursorA', \
            PostQuitMessage, 'PostQuitMessage'
    import  gdi32, \
            CreateFontIndirect, 'CreateFontIndirectA', \
            SelectObject, 'SelectObject', \
            SetBkMode, 'SetBkMode', \
            SetTextColor, 'SetTextColor', \
            DeleteObject, 'DeleteObject'
