include 'win32ax.inc'

.data
    _question  db "May I introduce myself?", 0
    _greeting  db "Hi! I'm the example program!", 0
    _title     db "Hello!!", 0
    
.code
    start:
        invoke MessageBox, HWND_DESKTOP, _question, invoke GetCommandLine, MB_YESNO
        .if eax = IDYES
            invoke MessageBox, HWND_DESKTOP, _greeting, _title, MB_OK
        .endif
        invoke ExitProcess, 0
.end start
