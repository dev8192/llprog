
wc.cbClsExtra and wc.cbWndExtra


sprintf and wsprintf

WM_GETDLGCODE and DLGC_WANTARROWS


