format PE GUI 4.0
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    counter      dd 0                   ; Store the click count
    buf          rb 32                  ; Buffer to store the formatted string
    fmt_str      db 'Counter: %d',0     ; Format string for wsprintf

    class_name   db 'CounterApp',0

    hwnd_btn     dd ?                   ; Handle to the button
    hwnd_lbl     dd ?                   ; Handle to the label

    wc           WNDCLASSEX
    msg          MSG

section '.code' code readable executable

start:
    ; Get instance handle
    invoke  GetModuleHandle, 0
    mov     [wc.hInstance], eax

    ; Setup window class
    mov     [wc.cbSize], sizeof.WNDCLASSEX
    mov     [wc.style], CS_HREDRAW or CS_VREDRAW
    mov     [wc.lpfnWndProc], WindowProc
    mov     [wc.cbClsExtra], 0
    mov     [wc.cbWndExtra], 0
    invoke  LoadIcon, 0, IDI_APPLICATION
    mov     [wc.hIcon], eax
    mov     [wc.hIconSm], eax
    invoke  LoadCursor, 0, IDC_ARROW
    mov     [wc.hCursor], eax
    mov     [wc.hbrBackground], COLOR_BTNFACE+1
    mov     [wc.lpszMenuName], 0
    mov     [wc.lpszClassName], class_name
    
    ; Register the window class
    invoke  RegisterClassEx, wc

    ; Create the main window
    invoke CreateWindowEx, \
        0, \                      ; dwExStyle    - Extended window styles (none)
        class_name, \             ; lpClassName  - Name of the registered window class
        'FASM Counter', \         ; lpWindowName - Text to display in the title bar
        WS_VISIBLE or \           ; dwStyle      - Window style: Make it visible immediately
        WS_OVERLAPPEDWINDOW, \    ;              - Standard window (Title bar, Close, Resize)
        CW_USEDEFAULT, \          ; x            - Horizontal position (let Windows decide)
        CW_USEDEFAULT, \          ; y            - Vertical position (let Windows decide)
        300, \                    ; nWidth       - Width of the window in pixels
        200, \                    ; nHeight      - Height of the window in pixels
        HWND_DESKTOP, \           ; hWndParent   - Handle to the parent (0 or HWND_DESKTOP)
        0, \                      ; hMenu        - Handle to menu or child-window identifier
        [wc.hInstance], \         ; hInstance    - Handle to the application instance
        0                         ; lpParam      - Pointer to window-creation data

    ; Main Message Loop
msg_loop:
    invoke  GetMessage, msg, 0, 0, 0
    test    eax, eax
    je      end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     msg_loop

end_loop:
    invoke  ExitProcess, [msg.wParam]

; Window Procedure to handle events
proc WindowProc hwnd, wmsg, wparam, lparam
    cmp     [wmsg], WM_CREATE
    je      .wmcreate
    cmp     [wmsg], WM_COMMAND
    je      .wmcommand
    cmp     [wmsg], WM_DESTROY
    je      .wmdestroy

.defwndproc:
    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    jmp     .finish

.wmcreate:
    invoke CreateWindowEx, \
        0, \                      ; dwExStyle
        'STATIC', \               ; lpClassName
        'counter: 0', \           ; lpWindowName
        WS_CHILD or \
        WS_VISIBLE or \
        SS_CENTER, \              ; dwStyle
        50, \                     ; x
        30, \                     ; y
        180, \                    ; nWidth
        20, \                     ; nHeight
        [hwnd], \                 ; hWndParent
        101, \                    ; hMenu
        [wc.hInstance], \         ; hInstance
        0                         ; lpParam
    mov     [hwnd_lbl], eax

    invoke  CreateWindowEx, \
        0, \                     ; dwExStyle
        'BUTTON', \              ; lpClassName
        'Click Me!!', \          ; lpWindowName
        WS_CHILD or \
        WS_VISIBLE or \
        BS_PUSHBUTTON, \         ; dwStyle
        100, \                   ; x
        80, \                    ; y
        80, \                    ; nWidth
        30, \                    ; nHeight
        [hwnd], \                ; hWndParent
        102, \                   ; hMenu         Control ID (used to identify clicks)
        [wc.hInstance], \        ; hInstance
        0                        ; lpParam
    mov     [hwnd_btn], eax

    xor     eax, eax
    jmp     .finish

.wmcommand:
    ; Check if the button was clicked (Control ID 102)
    mov     eax, [wparam]
    and     eax, 0FFFFh         ; Extract the low-order word (Control ID)
    cmp     eax, 102
    jne     .defwndproc         ; If it wasn't our button, pass it to default handler

    ; Increment the counter
    inc     [counter]

    ; Format the integer into a string (cinvoke is used because wsprintf uses C calling convention)
    cinvoke wsprintf, buf, fmt_str, [counter]

    ; Update the label text
    invoke  SetWindowText, [hwnd_lbl], buf

    xor     eax, eax
    jmp     .finish

.wmdestroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax

.finish:
    ret
endp

; Import Section
section '.idata' import data readable writeable
    library kernel, 'KERNEL32.DLL',\
            user,   'USER32.DLL'

    import kernel,\
           GetModuleHandle, 'GetModuleHandleA',\
           ExitProcess,     'ExitProcess'

    import user,\
           RegisterClassEx, 'RegisterClassExA',\
           CreateWindowEx,  'CreateWindowExA',\
           DefWindowProc,   'DefWindowProcA',\
           GetMessage,      'GetMessageA',\
           TranslateMessage,'TranslateMessage',\
           DispatchMessage, 'DispatchMessageA',\
           LoadCursor,      'LoadCursorA',\
           LoadIcon,        'LoadIconA',\
           SetWindowText,   'SetWindowTextA',\
           wsprintf,        'wsprintfA',\
           PostQuitMessage, 'PostQuitMessage'