format PE GUI 4.0
entry start

include 'win32a.inc'

PROV_RSA_AES        = 24
CRYPT_VERIFYCONTEXT = 0F0000000h
CALG_SHA_256        = 0000800Ch
CALG_AES_256        = 00006610h
CRYPT_STRING_BASE64 = 1

ID_TEXT    = 101
ID_PASS    = 102
ID_ENC     = 103
ID_DEC     = 104

GPTR = 0x0040

section '.data' data readable writeable
    hwnd        dd ?
    hText       dd ?
    hPass       dd ?
    wc          WNDCLASS
    msg         MSG
 
    szClass     db 'AesApp', 0
    szTitle     db 'AES-256 Base64 Encryptor', 0
    szEdit      db 'EDIT', 0
    szButton    db 'BUTTON', 0
    szEncrypt   db 'Encrypt', 0
    szDecrypt   db 'Decrypt', 0
 
    ; Memory and Crypto handles used during operations
    hProv       dd 0
    hHash       dd 0
    hKey        dd 0
 
    passBuf     dd 0
    passLen     dd 0
    textBuf     dd 0
    textLen     dd 0
    dataBuf     dd 0
    dataLen     dd 0
    outBuf      dd 0
    outLen      dd 0
 
section '.text' code readable executable
start: 
    mov     [wc.style], CS_HREDRAW or CS_VREDRAW
    mov     [wc.lpfnWndProc], WindowProc
    invoke  GetModuleHandle, 0
    mov     [wc.hInstance], eax
    invoke  LoadIcon, 0, IDI_APPLICATION
    mov     [wc.hIcon], eax
    invoke  LoadCursor, 0, IDC_ARROW
    mov     [wc.hCursor], eax
    mov     [wc.hbrBackground], COLOR_WINDOW
    mov     [wc.lpszClassName], szClass
    invoke  RegisterClass, wc
 
    invoke  CreateWindowEx, 0, szClass, szTitle,\
            WS_VISIBLE or WS_OVERLAPPEDWINDOW xor WS_THICKFRAME xor WS_MAXIMIZEBOX, \
            CW_USEDEFAULT, CW_USEDEFAULT, 480, 300, 0, 0, [wc.hInstance], 0
    mov     [hwnd], eax
 
    invoke  CreateWindowEx, WS_EX_CLIENTEDGE, szEdit, 0,\
            WS_VISIBLE or WS_CHILD or WS_VSCROLL or ES_MULTILINE or ES_AUTOVSCROLL or ES_WANTRETURN, \
            10, 10, 440, 190, [hwnd], ID_TEXT, [wc.hInstance], 0
    mov     [hText], eax
 
    invoke  CreateWindowEx, WS_EX_CLIENTEDGE, szEdit, 0,\
            WS_VISIBLE or WS_CHILD or ES_PASSWORD or ES_AUTOHSCROLL, \
            10, 215, 150, 25, [hwnd], ID_PASS, [wc.hInstance], 0
    mov     [hPass], eax
 
    invoke  CreateWindowEx, 0, szButton, szEncrypt,\
            WS_VISIBLE or WS_CHILD or BS_PUSHBUTTON, \
            170, 215, 100, 25, [hwnd], ID_ENC, [wc.hInstance], 0
 
    invoke  CreateWindowEx, 0, szButton, szDecrypt,\
            WS_VISIBLE or WS_CHILD or BS_PUSHBUTTON, \
            280, 215, 100, 25, [hwnd], ID_DEC, [wc.hInstance], 0

msg_loop:
    invoke  GetMessage, msg, 0, 0, 0
    test    eax, eax
    jz      end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     msg_loop

end_loop:
    invoke  ExitProcess, [msg.wParam]
 
proc WindowProc hwnd_p, wmsg, wparam, lparam
    cmp     [wmsg], WM_COMMAND
    je      .wmcommand
    cmp     [wmsg], WM_DESTROY
    je      .wmdestroy
 
.defwndproc:
    invoke  DefWindowProc, [hwnd_p], [wmsg], [wparam], [lparam]
    ret
 
.wmcommand:
    mov     eax, [wparam]
    and     eax, 0FFFFh
 
    cmp     eax, ID_ENC
    je      .cmd_encrypt
    cmp     eax, ID_DEC
    je      .cmd_decrypt
    jmp     .finish
 
.cmd_encrypt:
    call    SetupBuffers
    test    eax, eax
    jz      .cleanup
 
    ; Allocate dataBuf large enough for text + AES block padding (16 bytes)
    mov     eax, [textLen]
    add     eax, 64
    invoke  GlobalAlloc, GPTR, eax
    mov     [dataBuf], eax
 
    ; Copy text to data buffer
    mov     esi, [textBuf]
    mov     edi, [dataBuf]
    mov     ecx, [textLen]
    rep     movsb
 
    mov     eax, [textLen]
    mov     [dataLen], eax
 
    call    DeriveKey
    test    eax, eax
    jz      .cleanup

    mov     eax, [textLen]
    add     eax, 64
    invoke  CryptEncrypt, [hKey], 0, TRUE, 0, [dataBuf], dataLen, eax
 
    ; Ask API how large the base64 string will be
    invoke  CryptBinaryToString, [dataBuf], [dataLen], CRYPT_STRING_BASE64, 0, outLen
    invoke  GlobalAlloc, GPTR, [outLen]
    mov     [outBuf], eax
 
    ; Encode to base64
    invoke  CryptBinaryToString, [dataBuf], [dataLen], CRYPT_STRING_BASE64, [outBuf], outLen
    invoke  SetWindowText, [hText], [outBuf]
    jmp     .cleanup
 
.cmd_decrypt:
    call    SetupBuffers
    test    eax, eax
    jz      .cleanup
 
    ; Ask API how large the decoded binary will be
    invoke  CryptStringToBinary, [textBuf], [textLen], CRYPT_STRING_BASE64, 0, dataLen, 0, 0
 
    mov     eax, [dataLen]
    add     eax, 16 
    invoke  GlobalAlloc, GPTR, eax
    mov     [dataBuf], eax
 
    ; Decode from base64 back into raw bytes
    invoke  CryptStringToBinary, [textBuf], [textLen], CRYPT_STRING_BASE64, [dataBuf], dataLen, 0, 0
 
    call    DeriveKey
    test    eax, eax
    jz      .cleanup
 
    invoke  CryptDecrypt, [hKey], 0, TRUE, 0, [dataBuf], dataLen
    test    eax, eax
    jz      .cleanup
 
    ; Append a null-terminator exactly at the end of the plaintext
    mov     edx, [dataBuf]
    mov     eax, [dataLen]
    mov     byte [edx+eax], 0
    invoke  SetWindowText, [hText], [dataBuf]

.cleanup:
    cmp     [hKey], 0
    je      @f
    invoke  CryptDestroyKey, [hKey]
    mov     [hKey], 0
  @@:
    cmp     [hHash], 0
    je      @f
    invoke  CryptDestroyHash, [hHash]
    mov     [hHash], 0
  @@:
    cmp     [hProv], 0
    je      @f
    invoke  CryptReleaseContext, [hProv], 0
    mov     [hProv], 0
  @@:
    cmp     [passBuf], 0
    je      @f
    invoke  GlobalFree, [passBuf]
    mov     [passBuf], 0
  @@:
    cmp     [textBuf], 0
    je      @f
    invoke  GlobalFree, [textBuf]
    mov     [textBuf], 0
  @@:
    cmp     [dataBuf], 0
    je      @f
    invoke  GlobalFree, [dataBuf]
    mov     [dataBuf], 0
  @@:
    cmp     [outBuf], 0
    je      @f
    invoke  GlobalFree, [outBuf]
    mov     [outBuf], 0
  @@:
    jmp     .finish
 
.wmdestroy:
    invoke  PostQuitMessage, 0
 
.finish:
    xor     eax, eax
    ret
endp

; -----------------------------------------------------------------
; Helper procedure: Reads textboxes into memory. Returns EAX=0 on fail.
proc SetupBuffers
    invoke  GetWindowTextLength, [hPass]
    test    eax, eax
    jz      .fail
    mov     [passLen], eax
    inc     eax
    invoke  GlobalAlloc, GPTR, eax
    mov     [passBuf], eax
    invoke  GetWindowText, [hPass], [passBuf], [passLen]
 
    invoke  GetWindowTextLength, [hText]
    test    eax, eax
    jz      .fail
    mov     [textLen], eax
    inc     eax
    invoke  GlobalAlloc, GPTR, eax
    mov     [textBuf], eax
    invoke  GetWindowText, [hText], [textBuf], [textLen]
 
    mov     eax, 1
    ret
.fail:
    xor     eax, eax
    ret
endp
 
; -----------------------------------------------------------------
; Helper procedure: Configures CryptoAPI & derives AES key from password
proc DeriveKey
    invoke  CryptAcquireContext, hProv, 0, 0, PROV_RSA_AES, CRYPT_VERIFYCONTEXT
    test    eax, eax
    jz      .fail
    invoke  CryptCreateHash, [hProv], CALG_SHA_256, 0, 0, hHash
    test    eax, eax
    jz      .fail
    invoke  CryptHashData, [hHash], [passBuf], [passLen], 0
    test    eax, eax
    jz      .fail
    invoke  CryptDeriveKey, [hProv], CALG_AES_256, [hHash], 0, hKey
    test    eax, eax
    jz      .fail
 
    mov     eax, 1
    ret
.fail:
    xor     eax, eax
    ret
endp
 
section '.idata' import data readable writeable
    library kernel32, 'KERNEL32.DLL',\
            user32, 'USER32.DLL',\
            advapi32, 'ADVAPI32.DLL',\
            crypt32, 'CRYPT32.DLL'
 
    import kernel32,\
        ExitProcess, 'ExitProcess',\
        GetModuleHandle, 'GetModuleHandleA',\
        GlobalAlloc, 'GlobalAlloc',\
        GlobalFree, 'GlobalFree'
 
    import user32,\
        CreateWindowEx, 'CreateWindowExA',\
        DefWindowProc, 'DefWindowProcA',\
        DispatchMessage, 'DispatchMessageA',\
        GetMessage, 'GetMessageA',\
        GetWindowText, 'GetWindowTextA',\
        GetWindowTextLength, 'GetWindowTextLengthA',\
        LoadCursor, 'LoadCursorA',\
        LoadIcon, 'LoadIconA',\
        PostQuitMessage, 'PostQuitMessage',\
        RegisterClass, 'RegisterClassA',\
        SetWindowText, 'SetWindowTextA',\
        TranslateMessage, 'TranslateMessage'
 
    import advapi32,\
        CryptAcquireContext, 'CryptAcquireContextA',\
        CryptCreateHash, 'CryptCreateHash',\
        CryptDecrypt, 'CryptDecrypt',\
        CryptDeriveKey, 'CryptDeriveKey',\
        CryptDestroyHash, 'CryptDestroyHash',\
        CryptDestroyKey, 'CryptDestroyKey',\
        CryptEncrypt, 'CryptEncrypt',\
        CryptHashData, 'CryptHashData',\
        CryptReleaseContext, 'CryptReleaseContext'
 
    import crypt32,\
        CryptBinaryToString, 'CryptBinaryToStringA',\
        CryptStringToBinary, 'CryptStringToBinaryA'
