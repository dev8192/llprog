format PE CONSOLE
entry start

include 'win32a.inc'

PROV_RSA_AES        equ 24
CRYPT_VERIFYCONTEXT equ 0xF0000000
CALG_MD5            equ 0x00008003
CALG_SHA_256        equ 0x0000800C
CALG_AES_128        equ 0x0000660e
CALG_AES_256        equ 00006610h
CRYPT_STRING_BASE64 equ 0x00000001

section '.data' data readable writeable
    szHello      db 'hello', 0
    szPassword   db 'aes', 0
    szFmtOrig    db 'Original: %s', 10, 0
    szFmtEnc     db 'Encrypted (Base64): %s', 10, 0
    szFmtDec     db 'Decrypted: %s', 10, 0

    hProv        dd 0
    hHash        dd 0
    hKey         dd 0

    dataLen      dd 5
    bufLen       dd 256
    b64Len       dd 512

    buffer       rb 256
    b64Buffer    rb 512

section '.code' code readable executable
start:
    cinvoke printf, szFmtOrig, szHello

    invoke  lstrcpy, buffer, szHello

    invoke  CryptAcquireContext, hProv, 0, 0, PROV_RSA_AES, CRYPT_VERIFYCONTEXT
    invoke  CryptCreateHash, [hProv], CALG_SHA_256, 0, 0, hHash
    ;invoke  CryptCreateHash, [hProv], CALG_MD5, 0, 0, hHash
    invoke  lstrlen, szPassword
    invoke  CryptHashData, [hHash], szPassword, eax, 0
    ;invoke  CryptDeriveKey, [hProv], CALG_AES_128, [hHash], 0, hKey
    invoke  CryptDeriveKey, [hProv], CALG_AES_256, [hHash], 0, hKey

    invoke  CryptEncrypt, [hKey], 0, TRUE, 0, buffer, dataLen, [bufLen]

    invoke  CryptBinaryToString, buffer, [dataLen], CRYPT_STRING_BASE64, b64Buffer, b64Len

    cinvoke printf, szFmtEnc, b64Buffer

    invoke  CryptStringToBinary, b64Buffer, 0, CRYPT_STRING_BASE64, buffer, dataLen, 0, 0

    invoke  CryptDecrypt, [hKey], 0, TRUE, 0, buffer, dataLen

    mov     eax, [dataLen]
    mov     byte [buffer + eax], 0

    cinvoke printf, szFmtDec, buffer

    invoke  CryptDestroyKey, [hKey]
    invoke  CryptDestroyHash, [hHash]
    invoke  CryptReleaseContext, [hProv], 0

    invoke  ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL',\
            advapi32, 'ADVAPI32.DLL',\
            crypt32,  'CRYPT32.DLL',\
            msvcrt,   'MSVCRT.DLL'

    import  kernel32,\
            ExitProcess, 'ExitProcess',\
            lstrlen, 'lstrlenA',\
            lstrcpy, 'lstrcpyA'

    import  advapi32,\
            CryptAcquireContext, 'CryptAcquireContextA',\
            CryptCreateHash, 'CryptCreateHash',\
            CryptHashData, 'CryptHashData',\
            CryptDeriveKey, 'CryptDeriveKey',\
            CryptEncrypt, 'CryptEncrypt',\
            CryptDecrypt, 'CryptDecrypt',\
            CryptDestroyKey, 'CryptDestroyKey',\
            CryptDestroyHash, 'CryptDestroyHash',\
            CryptReleaseContext, 'CryptReleaseContext'

    import  crypt32,\
            CryptBinaryToString, 'CryptBinaryToStringA',\
            CryptStringToBinary, 'CryptStringToBinaryA'

    import  msvcrt,\
            printf, 'printf'
