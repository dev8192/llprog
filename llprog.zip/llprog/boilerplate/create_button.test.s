format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    include 'create_window.data.inc'
    include 'create_button.data.inc'
    include 'on_command.data.inc'

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, eax

    include 'create_window.text.inc'
    include 'message_loop.inc'
    include 'window_proc_cmd.inc'
    include 'create_button.text.inc'
    include 'on_command.text.inc'

proc main
    cinvoke puts, '*** main1 ***'
    local button_id:DWORD, font_height:DWORD
    mov [button_id], 0x123
    mov [font_height], 60
    stdcall create_window_proc, window_proc_cmd
    stdcall create_button, eax, [font_height], [button_id]
    stdcall message_loop
    ret
endp

section '.idata' import data readable
    library kernel32,               'kernel32.dll',\
            user32,                 'user32.dll',\
            gdi32,                  'gdi32.dll',\
            msvcrt,                 'msvcrt.dll'
    import  kernel32,\
            ExitProcess,            'ExitProcess',\
            GetModuleHandle,        'GetModuleHandleA'
    import  user32,\
            CreateWindowEx,         'CreateWindowExA',\
            DefWindowProc,          'DefWindowProcA',\
            DispatchMessage,        'DispatchMessageA',\
            GetMessage,             'GetMessageA',\
            LoadCursor,             'LoadCursorA',\
            PostQuitMessage,        'PostQuitMessage',\
            RegisterClass,          'RegisterClassA',\
            BeginPaint,             'BeginPaint',\
            EndPaint,               'EndPaint',\
            SendMessage,            'SendMessageA',\
            GetDC,                  'GetDC',\
            ReleaseDC,              'ReleaseDC'
    import  gdi32,\
            CreateFont,             'CreateFontA',\
            SelectObject,           'SelectObject',\
            GetTextExtentPoint32,   'GetTextExtentPoint32A'
    import  msvcrt,\
            printf,                 'printf',\
            puts,                   'puts'
