format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    str1            db 'Hello World', 0
    str1_len        = $ - str1 - 1

include '../create_window.data.inc'

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

include '../create_window.inc'
include '../window_proc/paint_destroy.inc'
include '../message_loop.inc'

proc main
    cinvoke puts, '*** main1 ***'
    stdcall create_window
    stdcall message_loop
    ret
endp

proc do_paint hdc
    cinvoke puts, '*** do_paint1 ***'
    invoke WindowFromDC, [hdc]
    invoke SetWindowText, eax, 'do_paint1'
    invoke TextOut, [hdc], 20, 20, str1, str1_len
    ret
endp

proc do_paint2 hdc
    cinvoke puts, '*** do_paint2 ***'
    invoke WindowFromDC, [hdc]
    invoke SetWindowText, eax, 'do_paint2'
    invoke TextOut, [hdc], 20, 20, str1, str1_len
    ret
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            user32,             'user32.dll',\
            gdi32,              'gdi32.dll',\
            msvcrt,             'msvcrt.dll'
    import  kernel32,\
            ExitProcess,        'ExitProcess',\
            GetModuleHandle,    'GetModuleHandleA'
    import  user32,\
            CreateWindowEx,     'CreateWindowExA',\
            DefWindowProc,      'DefWindowProcA',\
            DispatchMessage,    'DispatchMessageA',\
            GetMessage,         'GetMessageA',\
            LoadCursor,         'LoadCursorA',\
            PostQuitMessage,    'PostQuitMessage',\
            RegisterClass,      'RegisterClassA',\
            BeginPaint,         'BeginPaint',\
            EndPaint,           'EndPaint',\
            SetWindowText,      'SetWindowTextA',\
            WindowFromDC,       'WindowFromDC'
    import  gdi32,\
            TextOut,            'TextOutA'
    import  msvcrt,\
            printf,             'printf',\
            puts,               'puts'
