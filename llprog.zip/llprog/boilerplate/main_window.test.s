format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    str1            db 'Hello World', 0
    str1_len        = $ - str1 - 1

include 'create_window.data.inc'

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, eax

include 'main_window.inc'

    main_window 400, 200

proc window_proc hwnd, wmsg, wparam, lparam
    local ps:PAINTSTRUCT
    cmp [wmsg], WM_PAINT
    je .wm_paint
    cmp [wmsg], WM_DESTROY
    je .wm_destroy
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    jmp .finish
.wm_paint:
    invoke BeginPaint, [hwnd], addr ps
    stdcall do_paint, [ps.hdc]
    invoke EndPaint, [hwnd], addr ps
    xor eax, eax
    jmp .finish
.wm_destroy:
    invoke PostQuitMessage, 0
    xor eax, eax
.finish:
    ret
endp

proc do_paint ps_hdc
    cinvoke puts, '*** do_paint1 ***'
    invoke TextOut, [ps_hdc], 20, 20, str1, str1_len
    ret
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            user32,             'user32.dll',\
            gdi32,              'gdi32.dll',\
            msvcrt,             'msvcrt.dll'
    import  kernel32,\
            ExitProcess,        'ExitProcess',\
            GetModuleHandle,    'GetModuleHandleA'
    import  user32,\
            CreateWindowEx,     'CreateWindowExA',\
            DefWindowProc,      'DefWindowProcA',\
            DispatchMessage,    'DispatchMessageA',\
            GetMessage,         'GetMessageA',\
            LoadCursor,         'LoadCursorA',\
            PostQuitMessage,    'PostQuitMessage',\
            RegisterClass,      'RegisterClassA',\
            BeginPaint,         'BeginPaint',\
            EndPaint,           'EndPaint'
    import  gdi32,\
            TextOut,            'TextOutA'
    import  msvcrt,\
            printf,             'printf',\
            puts,               'puts'
