; not working
format PE console
entry start

section '.text' code readable executable
start:
    push    0
    push    -1
    call    [NtTerminateProcess]

section '.idata' import data readable
    library ntdll, 'ntdll.dll'
    import  ntdll, NtTerminateProcess, 'NtTerminateProcess'
