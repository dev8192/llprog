format PE console
entry start

include 'win32a.inc'

; 0x00000002_540BE400
; 00000000_C6AEA155

section '.data' data readable writeable
    fmt     db 'Result: %08X_%08X', 10, 0
    
    divd_hi dd 0x00000002
    divd_lo dd 0x540BE400
    
    divs_hi dd 0x00000000
    divs_lo dd 0x00000003

section '.text' code readable executable
start:
    invoke  _alldiv, [divd_lo], [divd_hi], [divs_lo], [divs_hi]
    
    cinvoke printf, fmt, edx, eax
    
    invoke  ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            msvcrt, 'msvcrt.dll',\
            ntdll, 'ntdll.dll'

    import  kernel32,\
            ExitProcess, 'ExitProcess'

    import  msvcrt,\
            printf, 'printf'

    import  ntdll,\
            _alldiv, '_alldiv'
