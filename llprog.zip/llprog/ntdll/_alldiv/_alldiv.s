; garbage
format PE CONSOLE
entry start

include 'win32a.inc'

section '.data' readable writeable
    ; Offset between 1601 and 1970 in 100-ns ticks
    EPOCH_OFFSET    dq 116444736000000000
    TICKS_PER_MS    dd 10000
    
    fmt             db 'Date.now(): %llu', 0Dh, 0Ah, 0
    ft              dq ?  ; FileTime (64-bit)
    result_ms       dq ?  ; Milliseconds (64-bit)

section '.code' readable executable
start:
    ; 1. Get current System Time (UTC)
    invoke GetSystemTimeAsFileTime, ft

    ; 2. Subtract the Epoch Offset (64-bit subtraction)
    mov eax, dword [ft]
    mov edx, dword [ft+4]
    sub eax, dword [EPOCH_OFFSET]
    sbb edx, dword [EPOCH_OFFSET+4]

    ; 3. Divide by 10,000 to get milliseconds
    ; We use the CRT _alldiv (64-bit / 64-bit division for 32-bit x86)
    push 0                  ; high dword of divisor (10000)
    push [TICKS_PER_MS]     ; low dword of divisor
    push edx                ; high dword of dividend
    push eax                ; low dword of dividend
    call [_alldiv]         ; result returned in EDX:EAX

    mov dword [result_ms], eax
    mov dword [result_ms+4], edx

    ; 4. Print the result
    ccall [printf], fmt, [result_ms], [result_ms+4]

    invoke ExitProcess, 0

section '.idata' import readable
    library kernel32, 'kernel32.dll', \
            msvcrt,   'msvcrt.dll'

    import kernel32, \
           GetSystemTimeAsFileTime, 'GetSystemTimeAsFileTime', \
           ExitProcess, 'ExitProcess'

    import msvcrt, \
           printf, 'printf', \
           _alldiv, '_alldiv'
