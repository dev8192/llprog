format PE console
entry start

include 'win32a.inc'

section '.text' code readable executable
start:
    push    5
    call    [RtlExitUserProcess]

section '.idata' import data readable
    library ntdll, 'ntdll.dll'
    import  ntdll, RtlExitUserProcess, 'RtlExitUserProcess'
