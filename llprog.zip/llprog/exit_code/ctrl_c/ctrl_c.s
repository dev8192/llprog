format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    start_msg   db 'start', 10, 0
    end_msg     db 'end', 10, 0

section '.text' code readable executable
start:
    cinvoke printf, start_msg
    invoke  Sleep, 3000
    cinvoke printf, end_msg
    invoke  ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            msvcrt, 'msvcrt.dll'
    import  kernel32,\
            Sleep, 'Sleep',\
            ExitProcess, 'ExitProcess'
    import  msvcrt,\
            printf, 'printf'
