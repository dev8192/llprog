format PE console 4.0
entry start

include 'win32a.inc'

STATUS_INTEGER_DIVIDE_BY_ZERO = -1073741676
CHAR_LF = 10
CHAR_CR = 13

section '.data' data readable writeable
    ntdll_name db 'ntdll.dll', 0
    print_fmt db '%s', CHAR_LF, 0
    msg_ptr dd ?

section '.text' code readable executable
    start:
        stdcall PrintNtStatus, STATUS_INTEGER_DIVIDE_BY_ZERO
        invoke ExitProcess, 0

    proc PrintNtStatus uses esi, status_code
        invoke GetModuleHandleA, ntdll_name
        
        invoke FormatMessageA,\
            FORMAT_MESSAGE_ALLOCATE_BUFFER or\
            FORMAT_MESSAGE_FROM_HMODULE or\
            FORMAT_MESSAGE_IGNORE_INSERTS,\
            eax, [status_code], 0, msg_ptr, 0, NULL
            
        mov esi, [msg_ptr]
        
        cinvoke strchr, esi, CHAR_LF
        test eax, eax
        jz .print
        
        inc eax
        mov esi, eax
        
        cinvoke strchr, esi, CHAR_CR
        test eax, eax
        jz .print
        
        mov byte [eax], 0
        
    .print:
        cinvoke printf, print_fmt, esi
        
        invoke LocalFree, [msg_ptr]
        ret
    endp

section '.idata' import data readable writeable
    library kernel32, 'KERNEL32.DLL',\
            msvcrt, 'MSVCRT.DLL'

    import kernel32,\
           ExitProcess, 'ExitProcess',\
           FormatMessageA, 'FormatMessageA',\
           GetModuleHandleA, 'GetModuleHandleA',\
           LocalFree, 'LocalFree'

    import msvcrt,\
           printf, 'printf',\
           strchr, 'strchr'
