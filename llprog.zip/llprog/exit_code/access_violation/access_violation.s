format PE console
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    num1    dd 0xAA
label1:
    cinvoke puts, 'hello'
    jmp label2

section '.text' code readable executable
start:
    stdcall main
    invoke  ExitProcess, 0

proc main1
    cinvoke puts, '*** main1 ***'
    mov eax, [0]
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    mov [num1], 0xBB
    ret
endp

proc main
    cinvoke puts, '*** main3 ***'
    jmp label1
label2:
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
