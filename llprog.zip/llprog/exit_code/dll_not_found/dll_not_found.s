format PE
entry start

include 'win32ax.inc'

section '.text' code readable executable
start:
    stdcall test20
    invoke ExitProcess, 0
    
proc test10
    cinvoke puts, "test10"
    ret
endp
    
proc test20
    cinvoke puts, "test20"
    invoke  Sleep, 3000
    ;invoke func1
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll',\
            lib123,         'lib123.dll'
    import  kernel32,\
            Sleep,          'Sleep',\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            puts,           'puts'
    import  lib123,\
            func1,          'func1'
