format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt db '%d', 10, 0

section '.text' code readable executable
start:
    xor edx, edx
    mov eax, 15
    mov ecx, 0
    div ecx
    cinvoke printf, fmt, eax
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            msvcrt, 'msvcrt.dll'
    import  kernel32,\
            ExitProcess, 'ExitProcess'
    import  msvcrt,\
            printf, 'printf'
