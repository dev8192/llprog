; Access Violation
format PE
entry start

include 'win32a.inc'

section '.code' code readable executable
start:
    invoke GetProcessHeap
    mov ebx, eax
    invoke HeapAlloc, ebx, 0, 16
    mov esi, eax
    mov edi, eax
    add edi, 16
    mov ecx, 64
    xor eax, eax
    rep stosb
    invoke HeapFree, ebx, 0, esi
    invoke ExitProcess, 0

section '.idata' import data readable
library kernel32, 'kernel32.dll'
import kernel32,\
    GetProcessHeap, 'GetProcessHeap',\
    HeapAlloc, 'HeapAlloc',\
    HeapFree, 'HeapFree',\
    ExitProcess, 'ExitProcess'
