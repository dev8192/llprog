format PE
entry start

include 'win32ax.inc'

status_code = -1073741510
LANG_ENGLISH_US = 0x0409

STATUS_SUCCESS = 0x000000000
STATUS_INVALID_HANDLE = 0xC0000008 ; -1073741816
STATUS_INVALID_PARAMETER = 0xC000000D ; -1073741811

section '.data' data readable writeable
    ntdll_name      db 'ntdll.dll', 0
    fmt_s           db '"%s"', 10, 0
    msg_ptr         dd ?
    buffer          rb 256

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc FormatMessage_func, dwFlags, lpSource, dwMessageId,\
    dwLanguageId, lpBuffer, nSize, Arguments

    invoke FormatMessage, [dwFlags], [lpSource], [dwMessageId],\
        [dwLanguageId], [lpBuffer], [nSize], [Arguments]
    ret
endp

proc main
    cinvoke puts, '*** main1 ***'
    invoke GetModuleHandle, ntdll_name
    stdcall FormatMessage_func,\
        FORMAT_MESSAGE_ALLOCATE_BUFFER or \
        FORMAT_MESSAGE_FROM_HMODULE or \
        FORMAT_MESSAGE_MAX_WIDTH_MASK,\
        eax, status_code, LANG_ENGLISH_US, msg_ptr, 0, 0
    cinvoke printf, fmt_s, [msg_ptr]
    invoke LocalFree, [msg_ptr]
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    invoke GetModuleHandle, ntdll_name
    stdcall FormatMessage_func,\
        FORMAT_MESSAGE_FROM_HMODULE or \
        FORMAT_MESSAGE_MAX_WIDTH_MASK,\
        eax, STATUS_INVALID_HANDLE, LANG_ENGLISH_US, buffer, 256, 0
    cinvoke printf, fmt_s, buffer
    ret
endp

section '.idata' import data readable writeable
    library kernel32,           'kernel32.dll',\
            msvcrt,             'msvcrt.dll'
    import  kernel32,\
            ExitProcess,        'ExitProcess',\
            FormatMessage,      'FormatMessageA',\
            GetModuleHandle,    'GetModuleHandleA',\
            LocalFree,          'LocalFree'
    import  msvcrt,\
            printf,             'printf',\
            puts,               'puts'
