format PE console
entry start

include 'win32a.inc'

status_code = -1073741510

section '.data' data readable writeable
    ntdll_name db 'ntdll.dll', 0
    fmt db '"%s"', 10, 0
    msg_ptr dd ?

section '.text' code readable executable
start:
    invoke GetModuleHandle, ntdll_name
    invoke FormatMessage, \
        FORMAT_MESSAGE_ALLOCATE_BUFFER or \
        FORMAT_MESSAGE_FROM_HMODULE or \
        FORMAT_MESSAGE_IGNORE_INSERTS, \
        eax, status_code, 0, msg_ptr, 0, NULL
    cinvoke printf, fmt, [msg_ptr]
    invoke LocalFree, [msg_ptr]
    invoke ExitProcess, 0

section '.idata' import data readable writeable
    library kernel32, 'KERNEL32.DLL', \
            msvcrt, 'MSVCRT.DLL'
    import kernel32, \
           ExitProcess, 'ExitProcess', \
           FormatMessage, 'FormatMessageA', \
           GetModuleHandle, 'GetModuleHandleA', \
           LocalFree, 'LocalFree'
    import msvcrt, \
           printf, 'printf'
