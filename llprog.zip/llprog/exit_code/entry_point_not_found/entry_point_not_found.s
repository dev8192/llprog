format PE
entry start

include 'win32ax.inc'

section '.text' code readable executable
start:
    stdcall test20
    invoke ExitProcess, 0
    
proc test10
    cinvoke puts, '*** test10 ***'
    ret
endp
    
proc test20
    cinvoke puts, '*** test20 ***'
    invoke FunctionThatDoesNotExit
    ret
endp

section '.idata' import data readable
    library kernel32,                   'kernel32.dll',\
            msvcrt,                     'msvcrt.dll'
    import  kernel32,\
            ExitProcess,                'ExitProcess',\
            FunctionThatDoesNotExit,    'FunctionThatDoesNotExit'
    import  msvcrt,\
            printf,                     'printf',\
            puts,                       'puts'
