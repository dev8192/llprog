format PE CONSOLE 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    ; Target NTSTATUS code to format (STATUS_INVALID_PARAMETER)
    STATUS_INVALID_PARAMETER = 0xC000000D

    ntdll_name         db 'ntdll.dll', 0
    fmt_output         db 'Error code: 0x%08X', 13, 10, 'Message: %s', 13, 10, 0
    press_key          db 13, 10, 'Press Enter to exit...', 0

    hNtdll             dd ?
    pBuffer            dd ?    ; Will hold pointer to allocated message string

section '.code' code readable executable

start:
    ; 1. Load ntdll.dll to get its module handle
    invoke  LoadLibrary, ntdll_name
    test    eax, eax
    jz      .exit
    mov     [hNtdll], eax

    ; 2. Call FormatMessageA using the ntdll module handle
    ; Flags used:
    ; FORMAT_MESSAGE_ALLOCATE_BUFFER (0x00000100) -> Let Windows allocate the string memory
    ; FORMAT_MESSAGE_FROM_HMODULE    (0x00000800) -> Search within ntdll.dll
    ; FORMAT_MESSAGE_IGNORE_INSERTS  (0x00000200) -> Prevent issues with embedded placeholders
    
    mov     edx, 0x00000100 or 0x00000800 or 0x00000200
    
    invoke  FormatMessageA, \
            edx, \
            [hNtdll], \
            STATUS_INVALID_PARAMETER, \
            0, \                ; Language ID (0 = Neutral/Default)
            addr pBuffer, \     ; Output: Address of our pointer
            0, \                ; Minimum size to allocate
            0                   ; Arguments array (None)

    test    eax, eax
    jz      .free_lib

    ; 3. Print the formatted message to the console
    cinvoke printf, fmt_output, STATUS_INVALID_PARAMETER, [pBuffer]

    ; 4. Free the buffer allocated by FormatMessage
    invoke  LocalFree, [pBuffer]

.free_lib:
    ; 5. Clean up the ntdll module handle
    invoke  FreeLibrary, [hNtdll]

.exit:
    ; Pause before exiting console
    cinvoke printf, press_key
    cinvoke getchar
    invoke  ExitProcess, 0

section '.idata' import data readable

library kernel32, 'kernel32.dll', \
        msvcrt,   'msvcrt.dll'

import kernel32, \
       LoadLibrary,   'LoadLibraryA', \
       FreeLibrary,   'FreeLibrary', \
       FormatMessageA, 'FormatMessageA', \
       LocalFree,     'LocalFree', \
       ExitProcess,   'ExitProcess'

import msvcrt, \
       printf,        'printf', \
       getchar,       'getchar'
