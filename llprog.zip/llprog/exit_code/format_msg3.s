format PE
entry start

include 'win32ax.inc'

LANG_ENGLISH_US = 0x0409
STATUS_INVALID_PARAMETER = 0xC000000D

section '.data' data readable writeable
    ntdll_name      db 'ntdll.dll', 0
    fmt_output      db 'Error 0x%08X: %s', 10, 0
    hNtdll          dd ?
    pBuffer         dd ?

section '.text' code readable executable
start:
    stdcall main
    invoke  ExitProcess, 0

proc main
    invoke  LoadLibrary, ntdll_name
    test    eax, eax
    jz      .exit
    mov     [hNtdll], eax
    invoke  FormatMessage,\
            FORMAT_MESSAGE_ALLOCATE_BUFFER or\
            FORMAT_MESSAGE_FROM_HMODULE or\
            FORMAT_MESSAGE_IGNORE_INSERTS,\
            [hNtdll], STATUS_INVALID_PARAMETER, LANG_ENGLISH_US, pBuffer, 0, 0
    test    eax, eax
    jz      .free_lib
    cinvoke printf, fmt_output, STATUS_INVALID_PARAMETER, [pBuffer]
    invoke  LocalFree, [pBuffer]
.free_lib:
    invoke  FreeLibrary, [hNtdll]
.exit:
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            LoadLibrary,    'LoadLibraryA',\
            FreeLibrary,    'FreeLibrary',\
            FormatMessage,  'FormatMessageA',\
            LocalFree,      'LocalFree',\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
