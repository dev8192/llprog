format PE
entry start

include 'win32ax.inc'

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main1 uses ebx esi edi
    cinvoke puts, '*** main1 ***'
    invoke GetProcessHeap
    mov ebx, eax
    invoke HeapAlloc, ebx, 0, 16
    mov esi, eax
    lea edi, [eax + 16]
   ;mov ecx, 16
    mov ecx, 32
    xor eax, eax
    rep stosb
    cinvoke puts, 'msg1'
    invoke HeapFree, ebx, 0, esi
    cinvoke puts, 'msg2'
    ret
endp

; no error
proc main uses ebx esi
    cinvoke puts, '*** main2 ***'
    invoke GetProcessHeap
    mov ebx, eax
    invoke HeapAlloc, ebx, 0, 16
    mov esi, eax
    cinvoke puts, 'msg1'
    invoke HeapFree, ebx, 0, esi
    cinvoke puts, 'msg2'
    invoke HeapFree, ebx, 0, esi
    cinvoke puts, 'msg3'
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            GetProcessHeap, 'GetProcessHeap',\
            HeapAlloc,      'HeapAlloc',\
            HeapFree,       'HeapFree',\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
