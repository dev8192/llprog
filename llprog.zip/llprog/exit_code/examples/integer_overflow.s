format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt     db "quotient: %u, remainder: %u", 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main1
    cinvoke puts, '*** main1 ***'
    mov edx, 4294967295
   ;xor edx, edx
    mov eax, 4294967295
    mov ecx, 1
    div ecx
    cinvoke printf, fmt, eax, edx
    ret
endp

proc main
    cinvoke puts, '*** main2 ***'
    mov edx, 1
    mov eax, 0
    mov ecx, 1
   ;mov ecx, 2
    div ecx
    cinvoke printf, fmt, eax, edx
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
