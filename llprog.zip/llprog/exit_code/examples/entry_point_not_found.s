format PE
entry start

include 'win32ax.inc'

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0
    
proc main
    cinvoke puts, '*** main1 ***'
    invoke FunctionThatDoesNotExit
    ret
endp

section '.idata' import data readable
    library kernel32,                   'kernel32.dll',\
            msvcrt,                     'msvcrt.dll'
    import  kernel32,\
            ExitProcess,                'ExitProcess',\
            FunctionThatDoesNotExit,    'FunctionThatDoesNotExit'
    import  msvcrt,\
            printf,                     'printf',\
            puts,                       'puts'
