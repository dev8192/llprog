format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    rect0           RECT
    rect1           RECT 101, 201, 301, 401
    align_breaker   db 0
   ;align 16
    rect2           RECT 102, 202, 302, 402
    fmt_4u          db '%u %u %u %u', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    stdcall .func, rect1
    stdcall .func, rect2
    ret
endp

proc .func rect
    mov eax, [rect]
    movdqa xmm0, [eax]
    movdqa dqword [rect0], xmm0
    cinvoke printf, fmt_4u, [rect0.left], [rect0.top], [rect0.right], [rect0.bottom]
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
