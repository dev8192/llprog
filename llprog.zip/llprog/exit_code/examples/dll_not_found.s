format PE
entry start

include 'win32ax.inc'

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0
    
proc main
    cinvoke puts, '*** main1 ***'
   ;invoke func1
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll',\
            lib123,         'lib123.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            puts,           'puts'
    import  lib123,\
            func1,          'func1'
