format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_xn          db '%x', 10, 0
    fmt_done        db 'done', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main1
    cinvoke puts, '*** main1 ***'
    local low_limit:DWORD
    local high_limit:DWORD
    local old_esp:DWORD
    invoke GetCurrentThreadStackLimits, addr low_limit, addr high_limit
    cinvoke printf, fmt_xn, [low_limit]
    cinvoke printf, fmt_xn, esp
    cinvoke printf, fmt_xn, [high_limit]
    ret
endp

proc main
    cinvoke puts, '*** main2 ***'
    local low_limit:DWORD
    local high_limit:DWORD
    local old_esp:DWORD
    invoke GetCurrentThreadStackLimits, addr low_limit, addr high_limit
    mov [old_esp], esp
    mov eax, [high_limit]
   ;sub eax, 4
    mov esp, eax
    mov dword [esp], 123
    mov esp, [old_esp]
    cinvoke printf, fmt_done
    ret
endp

section '.idata' import data readable
    library kernel32,                       'kernel32.dll',\
            msvcrt,                         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,                    'ExitProcess',\
            GetCurrentThreadStackLimits,    'GetCurrentThreadStackLimits'
    import  msvcrt,\
            printf,                         'printf',\
            puts,                           'puts'
