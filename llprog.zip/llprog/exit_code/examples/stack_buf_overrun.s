format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    buf1        rb 8
    fmt_x       db '%x', 10, 0
    fmt_dd      db '%d %d', 10, 0
    str1        db 'hello', 0

section '.text' code readable executable
start:
    stdcall main
    cinvoke puts, 'done'
    invoke ExitProcess, 0

proc main
    cinvoke puts, '*** main1 ***'
    cinvoke printf, fmt_x, esp
   ;invoke memset, buf1, 97, 3      ; -1073740791
   ;invoke puts, str1               ; -1073741819
    invoke printf, fmt_dd, 5, 10    ; -1073741819
    cinvoke printf, fmt_x, esp
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts',\
            memset,         'memset'
