; not working - no error
format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    h_heap dd ?
    ptr1    dd ?

section '.code' code readable executable
start:
    invoke GetProcessHeap
    mov [h_heap], eax

    invoke HeapAlloc, [h_heap], HEAP_ZERO_MEMORY, 8
    mov [ptr1], eax

    mov edi, [ptr1]
    mov dword [edi-4], 0xAAAAAAAA

    invoke HeapFree, [h_heap], 0, [ptr1]

    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll'

    import kernel32,\
           GetProcessHeap, 'GetProcessHeap',\
           HeapAlloc, 'HeapAlloc',\
           HeapFree, 'HeapFree',\
           ExitProcess, 'ExitProcess'
