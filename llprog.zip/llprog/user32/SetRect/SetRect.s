format PE console
entry start

include 'win32a.inc'

section '.data' data readable writable
    rect RECT 10, 20, 30, 40
    fmt db '%d %d %d %d', 0xA, 0

section '.code' code readable executable
start:
    invoke printf, fmt,\
        [rect.left], [rect.top], [rect.right], [rect.bottom]

    ; SetRect(lprc, xLeft, yTop, xRight, yBottom)
    invoke SetRect, rect, 11, 21, 31, 41
    invoke printf, fmt,\
        [rect.left], [rect.top], [rect.right], [rect.bottom]

    mov [rect.left], 12
    mov [rect.top], 22
    mov [rect.right], 32
    mov [rect.bottom], 42
    invoke printf, fmt,\
        [rect.left], [rect.top], [rect.right], [rect.bottom]

    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll', \
            user32,   'user32.dll', \
            msvcrt,   'msvcrt.dll'

    import kernel32, ExitProcess, 'ExitProcess'
    import user32,   SetRect,     'SetRect'
    import msvcrt,   printf,      'printf'
