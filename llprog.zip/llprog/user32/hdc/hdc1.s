format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt db 'HDC: 0x%08X', 10, 0
    hdc dd ?

section '.text' code readable executable
start:
    invoke GetDC, 0
    mov [hdc], eax

    cinvoke printf, fmt, [hdc]

    invoke ReleaseDC, 0, [hdc]
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
        user32, 'user32.dll',\
        msvcrt, 'msvcrt.dll'

    import kernel32,\
        ExitProcess, 'ExitProcess'

    import user32,\
        GetDC, 'GetDC',\
        ReleaseDC, 'ReleaseDC'

    import msvcrt,\
        printf, 'printf'
