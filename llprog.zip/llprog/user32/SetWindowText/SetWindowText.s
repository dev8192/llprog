format PE console
entry start

include 'win32a.inc'

section '.code' executable
start:
    invoke  GetModuleHandle, NULL
    mov     [hinst], eax
    invoke  LoadIcon, NULL, IDI_APPLICATION
    mov     [wc.hIcon], eax
    invoke  LoadCursor, NULL, IDC_ARROW
    mov     [wc.hCursor], eax
    mov     [wc.style], CS_HREDRAW or CS_VREDRAW
    mov     [wc.lpfnWndProc], WindowProc
    mov     [wc.cbClsExtra], 0
    mov     [wc.cbWndExtra], 0
    mov     eax, [hinst]
    mov     [wc.hInstance], eax
    mov     [wc.hbrBackground], COLOR_BTNFACE + 1
    mov     [wc.lpszMenuName], NULL
    mov     [wc.lpszClassName], class_name
    invoke  RegisterClass, wc

    invoke  CreateWindowEx, 0, class_name, title1, \
            WS_VISIBLE or WS_OVERLAPPEDWINDOW, \
            CW_USEDEFAULT, CW_USEDEFAULT, 300, 200, \
            NULL, NULL, [hinst], NULL
    mov     [hwnd], eax

msg_loop:
    invoke  GetMessage, msg, NULL, 0, 0
    cmp     eax, 0
    je      end_prog
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     msg_loop

end_prog:
    invoke  ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    push    ebx esi edi
    cmp     [wmsg], WM_CREATE
    je      .wmcreate
    cmp     [wmsg], WM_COMMAND
    je      .wmcommand
    cmp     [wmsg], WM_DESTROY
    je      .wmdestroy
  .default:
    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    jmp     .finish
  .wmcreate:
    invoke  CreateWindowEx, 0, btn_class, title1, \
            WS_VISIBLE or WS_CHILD, 10, 10, 80, 25, \
            [hwnd], 1, [hinst], NULL
    invoke  CreateWindowEx, 0, btn_class, title2, \
            WS_VISIBLE or WS_CHILD, 10, 40, 80, 25, \
            [hwnd], 2, [hinst], NULL
    invoke  CreateWindowEx, 0, btn_class, title3, \
            WS_VISIBLE or WS_CHILD, 10, 70, 80, 25, \
            [hwnd], 3, [hinst], NULL
    invoke  CreateWindowEx, 0, btn_class, title4, \
            WS_VISIBLE or WS_CHILD, 10, 100, 80, 25, \
            [hwnd], 4, [hinst], NULL
    xor     eax, eax
    jmp     .finish
  .wmcommand:
    mov     eax, [wparam]
    and     eax, 0xFFFF
    cmp     eax, 1
    je      .set1
    cmp     eax, 2
    je      .set2
    cmp     eax, 3
    je      .set3
    cmp     eax, 4
    je      .set4
    jmp     .finish
  .set1:
    invoke  SetWindowText, [hwnd], title1
    jmp     .finish
  .set2:
    invoke  SetWindowText, [hwnd], title2
    jmp     .finish
  .set3:
    invoke  SetWindowText, [hwnd], title3
    jmp     .finish
  .set4:
    invoke  SetWindowText, [hwnd], title4
    jmp     .finish
  .wmdestroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
  .finish:
    pop     edi esi ebx
    ret
endp

section '.data' data readable writeable
    hinst      dd 0
    hwnd       dd 0
    class_name db 'FASMWinClass', 0
    btn_class  db 'BUTTON', 0
    title1     db 'One', 0
    title2     db 'Two', 0
    title3     db 'Three', 0
    title4     db 'Four', 0
    wc         WNDCLASS
    msg        MSG

section '.idata' import data readable
    library kernel32, 'kernel32.dll', \
            user32, 'user32.dll'

    import kernel32, \
           GetModuleHandle, 'GetModuleHandleA', \
           ExitProcess, 'ExitProcess'

    import user32, \
           RegisterClass, 'RegisterClassA', \
           CreateWindowEx, 'CreateWindowExA', \
           DefWindowProc, 'DefWindowProcA', \
           GetMessage, 'GetMessageA', \
           TranslateMessage, 'TranslateMessage', \
           DispatchMessage, 'DispatchMessageA', \
           SendMessage, 'SendMessageA', \
           SetWindowText, 'SetWindowTextA', \
           LoadIcon, 'LoadIconA', \
           LoadCursor, 'LoadCursorA', \
           PostQuitMessage, 'PostQuitMessage'
