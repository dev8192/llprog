format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    class_name db 'MinWin', 0
    wc WNDCLASS
    msg MSG
    hwnd dd ?

section '.text' code readable executable
start:
    invoke GetModuleHandle, 0
    mov [wc.hInstance], eax
    mov eax, [DefWindowProc]
    mov [wc.lpfnWndProc], eax
    invoke LoadCursor, 0, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.lpszClassName], class_name
    mov [wc.hbrBackground], COLOR_WINDOW + 1
    invoke RegisterClass, wc

    invoke CreateWindowEx, 0, class_name, class_name, \
        WS_VISIBLE + WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, \
        CW_USEDEFAULT, CW_USEDEFAULT, 0, 0, [wc.hInstance], 0
    mov [hwnd], eax

msg_loop:
    invoke IsWindow, [hwnd]
    test eax, eax
    je end_loop

    invoke GetMessage, msg, 0, 0, 0
    test eax, eax
    jle end_loop
    invoke DispatchMessage, msg
    jmp msg_loop

end_loop:
    invoke ExitProcess, 0

section '.idata' import data readable writeable
    library kernel32, 'KERNEL32.DLL', \
        user32, 'USER32.DLL'
    import kernel32, \
        GetModuleHandle, 'GetModuleHandleA', \
        ExitProcess, 'ExitProcess'
    import user32, \
        RegisterClass, 'RegisterClassA', \
        CreateWindowEx, 'CreateWindowExA', \
        DefWindowProc, 'DefWindowProcA', \
        GetMessage, 'GetMessageA', \
        DispatchMessage, 'DispatchMessageA', \
        LoadCursor, 'LoadCursorA', \
        IsWindow, 'IsWindow'
