format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    buffer  rb 256
    fmt1    db 'Window title is: "%s"', 10, 0
    fmt2    db '%u', 10, 0

section '.text' code readable executable
start:
    invoke GetForegroundWindow
    invoke GetWindowText, eax, buffer, 256
    cinvoke printf, fmt1, buffer
    movzx   eax, [buffer + 1]
    cinvoke printf, fmt2, eax
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32,               'kernel32.dll',\
            user32,                 'user32.dll',\
            msvcrt,                 'msvcrt.dll'
    import  kernel32,\
            ExitProcess,            'ExitProcess'
    import  user32,\
            GetForegroundWindow,    'GetForegroundWindow',\
            GetWindowText,          'GetWindowTextA'
    import  msvcrt,\
            printf,                 'printf'
