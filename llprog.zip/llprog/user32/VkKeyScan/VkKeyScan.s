format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    header_fmt db 'Char | ASCII | VK   | Shift', 10, 0
    row_fmt    db '%-4c | 0x%02X  | 0x%02X | %d', 10, 0

section '.text' code readable executable
proc print_vk_info character
    invoke VkKeyScanA, [character]
    movzx ecx, ah
    movzx edx, al
    cinvoke printf, row_fmt, [character], [character], edx, ecx
    ret
endp

proc start
    cinvoke printf, header_fmt
    stdcall print_vk_info, 'a'
    stdcall print_vk_info, 'A'
    stdcall print_vk_info, '2'
    stdcall print_vk_info, '@'
    invoke ExitProcess, 0
endp

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            user32, 'user32.dll',\
            msvcrt, 'msvcrt.dll'

    import kernel32,\
           ExitProcess, 'ExitProcess'

    import user32,\
           VkKeyScanA, 'VkKeyScanA'

    import msvcrt,\
           printf, 'printf'
