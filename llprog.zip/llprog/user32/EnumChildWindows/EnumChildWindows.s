format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    taskbar_class db "Shell_TrayWnd", 0
    format_str db "HWND: %08X | Class: %s", 10, 0
    class_name rb 256

section '.text' code readable executable

proc EnumChildProc hwnd, lParam
    invoke GetClassName, [hwnd], class_name, 256
    cinvoke printf, format_str, [hwnd], class_name
    mov eax, 1
    ret
endp

start:
    invoke FindWindow, taskbar_class, 0
    invoke EnumChildWindows, eax, EnumChildProc, 0
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL',\
        user32, 'USER32.DLL',\
        msvcrt, 'MSVCRT.DLL'

    import kernel32,\
        ExitProcess, 'ExitProcess'

    import user32,\
        EnumChildWindows, 'EnumChildWindows',\
        FindWindow, 'FindWindowA',\
        GetClassName, 'GetClassNameA'

    import msvcrt,\
        printf, 'printf'
