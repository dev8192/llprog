format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    class_parent db "MyParent", 0
    class_button db "BUTTON", 0
    class_edit   db "EDIT", 0
    class_static db "STATIC", 0
    format_str   db "HWND: %08X | Class: %s", 10, 0
    class_name   rb 256
    parent_hwnd  dd 0
    wc           WNDCLASS

section '.text' code readable executable

proc EnumChildProc hwnd, lParam
    invoke GetClassName, [hwnd], class_name, 256
    cinvoke printf, format_str, [hwnd], class_name
    mov eax, 1
    ret
endp

start:
    invoke GetModuleHandle, 0
    mov [wc.hInstance], eax
    mov eax, [DefWindowProc]
    mov [wc.lpfnWndProc], eax
    mov dword [wc.lpszClassName], class_parent
    invoke RegisterClass, wc

    invoke CreateWindowEx, 0, class_parent, 0, WS_OVERLAPPEDWINDOW,\
        0, 0, 400, 400, 0, 0, [wc.hInstance], 0
    mov [parent_hwnd], eax

    invoke CreateWindowEx, 0, class_button, 0, WS_CHILD,\
        10, 10, 100, 30, [parent_hwnd], 0, [wc.hInstance], 0
    invoke CreateWindowEx, 0, class_edit, 0, WS_CHILD,\
        10, 50, 100, 30, [parent_hwnd], 0, [wc.hInstance], 0
    invoke CreateWindowEx, 0, class_static, 0, WS_CHILD,\
        10, 90, 100, 30, [parent_hwnd], 0, [wc.hInstance], 0

    invoke EnumChildWindows, [parent_hwnd], EnumChildProc, 0

    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL',\
        user32, 'USER32.DLL',\
        msvcrt, 'MSVCRT.DLL'

    import kernel32,\
        ExitProcess, 'ExitProcess',\
        GetModuleHandle, 'GetModuleHandleA'

    import user32,\
        CreateWindowEx, 'CreateWindowExA',\
        DefWindowProc, 'DefWindowProcA',\
        EnumChildWindows, 'EnumChildWindows',\
        GetClassName, 'GetClassNameA',\
        RegisterClass, 'RegisterClassA'

    import msvcrt,\
        printf, 'printf'
