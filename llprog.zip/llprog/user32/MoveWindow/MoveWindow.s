format PE console
entry start

include 'win32a.inc'

BUTTON_W = 100
BUTTON_H = 40

section '.data' readable writeable
    _class     db 'CoolWin', 0
    _title     db 'Clicks: 0', 0
    _btn_text  db 'TAP ME!', 0
    _font_name db 'Segoe UI', 0
    _btn_cl    db 'BUTTON', 0
    create_msg db '*** create ***', 0
    
    hBtn       dd 0
    hFont      dd 0
    score      dd 0
    _score_str rb 32
    _caption   db 'Clicks: %d', 0

    wc         WNDCLASS 0,WindowProc,0,0,0,0,0,COLOR_BTNFACE+1,0,_class
    msg        MSG

section '.code' readable executable
start:
    invoke GetModuleHandle, 0
    mov [wc.hInstance], eax
    invoke LoadCursor, 0, IDC_HAND
    mov [wc.hCursor], eax
    invoke RegisterClass, wc

    invoke CreateFont, 18, 0, 0, 0, FW_BOLD, 0, 0, 0, 0, 0, 0, 0, 0, _font_name
    mov [hFont], eax

    invoke  CreateWindowEx, 0, _class, _title,\
            WS_VISIBLE + WS_OVERLAPPED + WS_CAPTION + WS_SYSMENU,\
            CW_USEDEFAULT, CW_USEDEFAULT, 400, 400, 0, 0, [wc.hInstance], 0

msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    test eax, eax
    jz exit
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp msg_loop
exit:
    invoke ExitProcess, 0

proc WindowProc hwnd, umsg, wparam, lparam
    cmp [umsg], WM_CREATE
    je .create
    cmp [umsg], WM_COMMAND
    je .click
    cmp [umsg], WM_DESTROY
    je .destroy
    invoke DefWindowProc, [hwnd], [umsg], [wparam], [lparam]
    ret

.create:
    cinvoke printf, create_msg
    invoke  CreateWindowEx, 0, _btn_cl, _btn_text,\
            WS_VISIBLE + WS_CHILD + BS_FLAT,\
            150, 150, BUTTON_W, BUTTON_H, [hwnd], 101, [wc.hInstance], 0
    mov [hBtn], eax
    invoke SendMessage, [hBtn], WM_SETFONT, [hFont], TRUE
    ret

.click:
    inc [score]
    invoke wsprintf, _score_str, _caption, [score]
    invoke SetWindowText, [hwnd], _score_str

    invoke GetTickCount
    mov edx, eax
    shr edx, 12
    xor eax, edx
    and eax, 0xFF
    mov ebx, eax
    
    add eax, [score] 
    and eax, 0x7F
    add eax, 50
    
    invoke MoveWindow, [hBtn], ebx, eax, BUTTON_W, BUTTON_H, TRUE
    ret

.destroy:
    invoke DeleteObject, [hFont]
    invoke PostQuitMessage, 0
    xor eax, eax
    ret
endp

section '.idata' import data readable
    library kernel32,           'KERNEL32.DLL',\
            user32,             'USER32.DLL',\
            gdi32,              'GDI32.DLL',\
            msvcrt,             'MSVCRT.DLL'
    import  kernel32,\
            GetModuleHandle,    'GetModuleHandleA',\
            ExitProcess,        'ExitProcess',\
            GetTickCount,       'GetTickCount'
    import  user32,\
            RegisterClass,      'RegisterClassA',\
            CreateWindowEx,     'CreateWindowExA',\
            DefWindowProc,      'DefWindowProcA',\
            GetMessage,         'GetMessageA',\
            DispatchMessage,    'DispatchMessageA',\
            TranslateMessage,   'TranslateMessage',\
            SetWindowText,      'SetWindowTextA',\
            MoveWindow,         'MoveWindow',\
            LoadCursor,         'LoadCursorA',\
            SendMessage,        'SendMessageA',\
            PostQuitMessage,    'PostQuitMessage',\
            wsprintf,           'wsprintfA'
    import  gdi32,\
            CreateFont,         'CreateFontA',\
            DeleteObject,       'DeleteObject'
    import  msvcrt,\
            printf,             'printf'
