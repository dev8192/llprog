format PE GUI 4.0
entry start
include 'win32a.inc'

section '.data' data readable writeable

    wc          WNDCLASS
    msg         MSG
    ps          PAINTSTRUCT
    rect        RECT
    seed        dd ?
    szClassName db 'SquaresClass', 0

section '.code' code readable executable

start:
    rdtsc
    mov [seed], eax

    invoke GetModuleHandleA, 0
    mov [wc.hInstance], eax
    mov [wc.lpfnWndProc], WindowProc
    mov [wc.hbrBackground], COLOR_WINDOW+1
    mov [wc.lpszClassName], szClassName
    invoke RegisterClassA, wc

    invoke CreateWindowExA, 0, szClassName, szClassName, WS_OVERLAPPEDWINDOW+WS_VISIBLE, \
            CW_USEDEFAULT, CW_USEDEFAULT, 230, 250, 0, 0, [wc.hInstance], 0

msg_loop:
    invoke GetMessageA, msg, 0, 0, 0
    test eax, eax
    jz end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessageA, msg
    jmp msg_loop

end_loop:
    invoke ExitProcess, [msg.wParam]

proc WindowProc hwnd, uMsg, wParam, lParam
    cmp [uMsg], WM_DESTROY
    je .wmdestroy
    cmp [uMsg], WM_PAINT
    je .wmpaint

    invoke DefWindowProcA, [hwnd], [uMsg], [wParam], [lParam]
    ret

.wmpaint:
    invoke BeginPaint, [hwnd], ps
    mov edi, eax

    xor esi, esi
.draw_loop:
    cmp esi, 16
    je .draw_done

    mov eax, esi
    and eax, 3
    imul eax, 50
    mov [rect.left], eax
    add eax, 50
    mov [rect.right], eax

    mov eax, esi
    shr eax, 2
    imul eax, 50
    mov [rect.top], eax
    add eax, 50
    mov [rect.bottom], eax

    mov eax, [seed]
    imul eax, 214013
    add eax, 2531011
    mov [seed], eax
    shr eax, 8
    and eax, 0FFFFFFh

    invoke CreateSolidBrush, eax
    push eax

    invoke FillRect, edi, rect, eax

    pop eax
    invoke DeleteObject, eax

    inc esi
    jmp .draw_loop

.draw_done:
    invoke EndPaint, [hwnd], ps
    xor eax, eax
    ret

.wmdestroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    ret
endp

section '.idata' import data readable

    library kernel32, 'kernel32.dll',\
            user32,   'user32.dll',\
            gdi32,    'gdi32.dll'

    import kernel32,\
           GetModuleHandleA, 'GetModuleHandleA',\
           ExitProcess,      'ExitProcess'

    import user32,\
           RegisterClassA,   'RegisterClassA',\
           CreateWindowExA,  'CreateWindowExA',\
           GetMessageA,      'GetMessageA',\
           TranslateMessage, 'TranslateMessage',\
           DispatchMessageA, 'DispatchMessageA',\
           DefWindowProcA,   'DefWindowProcA',\
           PostQuitMessage,  'PostQuitMessage',\
           BeginPaint,       'BeginPaint',\
           EndPaint,         'EndPaint',\
           FillRect,         'FillRect'

    import gdi32,\
           CreateSolidBrush, 'CreateSolidBrush',\
           DeleteObject,     'DeleteObject'
