function test() {
    for (let i = 0; i < 16; i++) {
        console.log('row: ', Math.floor(i / 4), 'col: ', i % 4)
        // console.log('row: ', i >> 2, 'col: ', i & 3)
    }
}

test()
