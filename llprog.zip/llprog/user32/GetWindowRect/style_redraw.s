format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    _class      db 'MyWinClass', 0
    _title      db 'Example', 0
    format_str  db 'Hello World', 0
    length_of_str = $ - format_str - 1
    buffer      rb 256
    rect        RECT
    msg         MSG
    ps          PAINTSTRUCT
    wc          WNDCLASS
    paint_msg   db 'paint_msg', 10, 0

section '.code' code readable executable
start:
    invoke GetModuleHandle, 0
    mov [wc.hInstance], eax
    ;mov [wc.style], CS_HREDRAW or CS_VREDRAW
    ;mov [wc.style], CS_HREDRAW
    mov [wc.style], CS_VREDRAW
    mov [wc.lpfnWndProc], WindowProc
    mov [wc.lpszClassName], _class
    invoke  LoadCursor, 0, IDC_ARROW
    mov     [wc.hCursor], eax
    mov [wc.hbrBackground], COLOR_WINDOW+1
    invoke RegisterClass, wc

    invoke CreateWindowEx, 0, _class, _title,\
           WS_VISIBLE or WS_OVERLAPPEDWINDOW,\
           CW_USEDEFAULT, CW_USEDEFAULT, 300, 200,\
           0, 0, [wc.hInstance], 0

msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    or eax, eax
    jz end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp msg_loop

end_loop:
    invoke ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp [wmsg], WM_PAINT
    je .paint
    cmp [wmsg], WM_DESTROY
    je .destroy
    
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    jmp .finish

.paint1:
    cinvoke printf, paint_msg
    invoke GetClientRect, [hwnd], rect
    invoke BeginPaint, [hwnd], ps
    invoke DrawText, eax, format_str, -1, rect, DT_CENTER or DT_VCENTER or DT_SINGLELINE
    invoke EndPaint, [hwnd], ps
    xor eax, eax
    jmp .finish

.paint2:
    cinvoke printf, paint_msg
    invoke BeginPaint, [hwnd], ps
    lea edx, [ps.rcPaint]
    invoke DrawText, eax, format_str, -1, edx, DT_CENTER or DT_VCENTER or DT_SINGLELINE
    invoke EndPaint, [hwnd], ps
    xor eax, eax
    jmp .finish

.paint:
    cinvoke printf, paint_msg
    invoke BeginPaint, [hwnd], ps
    invoke SetTextAlign, [ps.hdc], TA_CENTER or TA_TOP
    mov    eax, [ps.rcPaint.right]
    shr    eax, 1
    mov    ecx, [ps.rcPaint.bottom]
    shr    ecx, 1
    invoke TextOut, [ps.hdc], eax, ecx, format_str, length_of_str
    invoke EndPaint, [hwnd], ps
    xor eax, eax
    jmp .finish

.destroy:
    invoke PostQuitMessage, 0
    xor eax, eax

.finish:
    ret
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            user32,             'user32.dll',\
            msvcrt,             'msvcrt.dll',\
            gdi32,              'gdi32.dll'
    import  kernel32,\
            GetModuleHandle,    'GetModuleHandleA',\
            ExitProcess,        'ExitProcess'
    import  user32,\
            BeginPaint,         'BeginPaint',\
            CreateWindowEx,     'CreateWindowExA',\
            DefWindowProc,      'DefWindowProcA',\
            DispatchMessage,    'DispatchMessageA',\
            DrawText,           'DrawTextA',\
            EndPaint,           'EndPaint',\
            GetClientRect,      'GetClientRect',\
            GetMessage,         'GetMessageA',\
            LoadCursor,         'LoadCursorA',\
            PostQuitMessage,    'PostQuitMessage',\
            RegisterClass,      'RegisterClassA',\
            TranslateMessage,   'TranslateMessage'
    import  msvcrt,\
            printf,             'printf'
    import  gdi32, \
            SetTextAlign,       'SetTextAlign',\
            TextOut,            'TextOutA'
