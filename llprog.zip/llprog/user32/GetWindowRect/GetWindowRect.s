format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    _class      db 'FASMWinClass', 0
    _title      db 'GetWindowRect Example', 0
    window_rect_fmt  db 'window_rect_fmt: %d %d %d %d', 10, 0
    client_rect_fmt  db 'client_rect_fmt: %d %d %d %d', 10, 0
    buffer      rb 256
    rect        RECT
    msg         MSG
    wc          WNDCLASS

section '.code' code readable executable
start:
    invoke GetModuleHandle, 0
    mov [wc.hInstance], eax
    mov [wc.style], CS_HREDRAW or CS_VREDRAW
    mov [wc.lpfnWndProc], WindowProc
    mov [wc.lpszClassName], _class
    invoke  LoadCursor, 0, IDC_ARROW
    mov     [wc.hCursor], eax
    mov [wc.hbrBackground], COLOR_WINDOW+1
    invoke RegisterClass, wc

    invoke CreateWindowEx, 0, _class, _title,\
           WS_VISIBLE or WS_OVERLAPPEDWINDOW,\
           CW_USEDEFAULT, CW_USEDEFAULT, 300, 200,\
           0, 0, [wc.hInstance], 0

msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    or eax, eax
    jz end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp msg_loop

end_loop:
    invoke ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    push ebx esi edi
    cmp [wmsg], WM_PAINT
    je .paint
    cmp [wmsg], WM_DESTROY
    je .destroy
    
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    jmp .finish

.paint:
    invoke BeginPaint, [hwnd], msg
    invoke GetWindowRect, [hwnd], rect
    cinvoke printf, window_rect_fmt,\
            [rect.left], [rect.top], [rect.right], [rect.bottom]
    invoke GetClientRect, [hwnd], rect
    cinvoke printf, client_rect_fmt,\
            [rect.left], [rect.top], [rect.right], [rect.bottom]
    invoke EndPaint, [hwnd], msg
    xor eax, eax
    jmp .finish

.destroy:
    invoke PostQuitMessage, 0
    xor eax, eax

.finish:
    pop edi esi ebx
    ret
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            user32,             'user32.dll',\
            msvcrt,             'msvcrt.dll'
    import  kernel32,\
            GetModuleHandle,    'GetModuleHandleA',\
            ExitProcess,        'ExitProcess'
    import  user32,\
            RegisterClass,      'RegisterClassA',\
            CreateWindowEx,     'CreateWindowExA',\
            DefWindowProc,      'DefWindowProcA',\
            LoadCursor,         'LoadCursorA',\
            GetMessage,         'GetMessageA',\
            TranslateMessage,   'TranslateMessage',\
            DispatchMessage,    'DispatchMessageA',\
            PostQuitMessage,    'PostQuitMessage',\
            BeginPaint,         'BeginPaint',\
            EndPaint,           'EndPaint',\
            GetWindowRect,      'GetWindowRect',\
            GetClientRect,      'GetClientRect',\
            DrawText,           'DrawTextA',\
            wsprintf,           'wsprintfA'
    import  msvcrt,\
            printf,             'printf'
