format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    rect RECT 0, 0, 100, 100
    fmt_rect db '%d %d %d %d', 10, 0

section '.text' code readable executable
start:
;    mov [rect.left], 0
;    mov [rect.top], 0
;    mov [rect.right], 100
;    mov [rect.bottom], 100

    ; +8 +31 +8 +8
    ; 0 0 100 100
    ; -8 -31 108 108
    
    cinvoke printf, fmt_rect,\
        [rect.left], [rect.top], [rect.right], [rect.bottom]
    invoke AdjustWindowRect, rect, WS_OVERLAPPEDWINDOW, FALSE
    cinvoke printf, fmt_rect,\
        [rect.left], [rect.top], [rect.right], [rect.bottom]

    invoke ExitProcess, 0

section '.idata' import data readable writeable
    library kernel32,           'kernel32.dll',\
            user32,             'user32.dll',\
            msvcrt,             'msvcrt.dll'
    import  kernel32,\
            ExitProcess,        'ExitProcess'
    import  user32,\
            AdjustWindowRect,   'AdjustWindowRect'
    import  msvcrt,\
            printf,             'printf'
