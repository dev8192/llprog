format PE
entry start

include 'win32a.inc'

SM_CXPADDEDBORDER = 92
NEWLINE = 10
NULL_CHAR = 0

section '.data' data readable writeable
    fmt db '%d %d %d %d', NEWLINE, NULL_CHAR
    rect RECT 0, 0, 100, 100

section '.text' code readable executable
start:
    invoke CustomAdjustWindowRect, rect, WS_OVERLAPPEDWINDOW, FALSE
    cinvoke printf, fmt, \
        [rect.left], [rect.top], [rect.right], [rect.bottom]
    invoke ExitProcess, 0

proc CustomAdjustWindowRect uses ebx esi edi, prc, dwStyle, bMenu
    mov esi, [prc]
    mov ebx, [dwStyle]
    xor edi, edi
    test ebx, WS_THICKFRAME
    jz .check_border
    invoke GetSystemMetrics, SM_CXFRAME
    mov edi, eax
    invoke GetSystemMetrics, SM_CXPADDEDBORDER
    add edi, eax
    invoke GetSystemMetrics, SM_CYFRAME
    mov ecx, eax
    invoke GetSystemMetrics, SM_CXPADDEDBORDER
    add ecx, eax
    jmp .apply_frame
.check_border:
    test ebx, WS_BORDER
    jz .no_frame
    invoke GetSystemMetrics, SM_CXBORDER
    mov edi, eax
    invoke GetSystemMetrics, SM_CYBORDER
    mov ecx, eax
    jmp .apply_frame
.no_frame:
    xor ecx, ecx
.apply_frame:
    sub [esi+RECT.left], edi
    add [esi+RECT.right], edi
    sub [esi+RECT.top], ecx
    add [esi+RECT.bottom], ecx
    mov eax, WS_CAPTION
    and eax, ebx
    cmp eax, WS_CAPTION
    jne .check_menu
    invoke GetSystemMetrics, SM_CYCAPTION
    sub [esi+RECT.top], eax
.check_menu:
    cmp [bMenu], FALSE
    je .done
    invoke GetSystemMetrics, SM_CYMENU
    sub [esi+RECT.top], eax
.done:
    mov eax, TRUE
    ret
endp

section '.idata' import data readable
    library kernel32, 'kernel32.dll', \
            user32, 'user32.dll', \
            msvcrt, 'msvcrt.dll'

    import kernel32, \
           ExitProcess, 'ExitProcess'

    import user32, \
           GetSystemMetrics, 'GetSystemMetrics'

    import msvcrt, \
           printf, 'printf'
