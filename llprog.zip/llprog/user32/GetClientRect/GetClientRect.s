format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    wc          WNDCLASSEX
    hwnd        dd ?
    rect        RECT
    hInst       dd ?
    szClassName db 'TestClass', 0
    szTitle     db 'Test Window', 0
    reqWidth    dd 800
    reqHeight   dd 600
    fmt         db 'left: %d, top: %d, right: %d, bottom: %d', 10, 0

section '.code' code readable executable
start:
    invoke  GetModuleHandleA, 0
    mov     [hInst], eax

    mov     [wc.cbSize], sizeof.WNDCLASSEX
    mov     [wc.style], 0
    mov     [wc.lpfnWndProc], WindowProc
    mov     [wc.cbClsExtra], 0
    mov     [wc.cbWndExtra], 0
    mov     eax, [hInst]
    mov     [wc.hInstance], eax
    mov     [wc.hIcon], 0
    mov     [wc.hCursor], 0
    mov     [wc.hbrBackground], COLOR_WINDOW+1
    mov     [wc.lpszMenuName], 0
    mov     [wc.lpszClassName], szClassName
    mov     [wc.hIconSm], 0

    invoke  RegisterClassExA, wc

    invoke  CreateWindowExA, 0, szClassName, szTitle, WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT,\
        [reqWidth], [reqHeight], 0, 0, [hInst], 0
    mov     [hwnd], eax

    invoke  GetClientRect, [hwnd], rect

    cinvoke printf, fmt, [rect.left], [rect.top], [rect.right], [rect.bottom]

    invoke  ExitProcess, 0

WindowProc:
    jmp     [DefWindowProcA]

section '.idata' import data readable writeable
    library kernel32,'KERNEL32.DLL',\
            user32,'USER32.DLL',\
            msvcrt,'MSVCRT.DLL'

    import  kernel32,\
            GetModuleHandleA,'GetModuleHandleA',\
            ExitProcess,'ExitProcess'

    import  user32,\
            RegisterClassExA,'RegisterClassExA',\
            CreateWindowExA,'CreateWindowExA',\
            GetClientRect,'GetClientRect',\
            DefWindowProcA,'DefWindowProcA'

    import  msvcrt,\
            printf,'printf'
