format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt     db '%u', 10, 0

section '.bss' readable writeable
    outbuf  rb 32
    hOut    dd ?

section '.code' code readable executable

start:
    invoke  GetStdHandle, STD_OUTPUT_HANDLE
    mov     [hOut], eax

    cinvoke wsprintf, outbuf, fmt, esp
    invoke  lstrlen, outbuf
    invoke  WriteConsole, [hOut], outbuf, eax, 0, 0

    cinvoke wsprintf, outbuf, fmt, esp
    invoke  lstrlen, outbuf
    invoke  WriteConsole, [hOut], outbuf, eax, 0, 0

    cinvoke wsprintf, outbuf, fmt, esp
    invoke  lstrlen, outbuf
    invoke  WriteConsole, [hOut], outbuf, eax, 0, 0

    invoke  ExitProcess, 0

section '.idata' import data readable writeable

    library kernel32, 'kernel32.dll', \
            user32,   'user32.dll'

    import kernel32, \
        ExitProcess,    'ExitProcess', \
        GetStdHandle,   'GetStdHandle', \
        WriteConsole,   'WriteConsoleA', \
        lstrlen,        'lstrlenA'

    import user32, \
        wsprintf,       'wsprintfA'
