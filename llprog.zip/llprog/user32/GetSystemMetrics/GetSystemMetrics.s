format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt     db "%d", 10, 0

section '.code' code readable executable

start:
    invoke GetSystemMetrics, SM_CXSCREEN
    cinvoke printf, fmt, eax
    invoke GetSystemMetrics, SM_CYSCREEN
    cinvoke printf, fmt, eax
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll',\
            user32, 'user32.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
    import user32,\
            GetSystemMetrics, 'GetSystemMetrics'
