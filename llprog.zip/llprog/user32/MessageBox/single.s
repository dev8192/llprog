format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    msg     db 'Hello from MessageBox', 0
    title   db 'Title', 0
    msg1    db 'msg1', 10, 0
    msg2    db 'msg2', 10, 0

section '.text' code readable executable
start:
    cinvoke printf, msg1
    invoke  MessageBox, 0, msg, title, 0
    cinvoke printf, msg2
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt,     'msvcrt.dll',\
            user32,     'user32.dll'
    import  msvcrt,\
            exit,       'exit',\
            printf,     'printf'
    import  user32,\
            MessageBox, 'MessageBoxA'
