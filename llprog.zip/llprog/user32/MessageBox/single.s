format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    msg     db 'Hello from MessageBox',0
    title   db 'Title',0

section '.text' code readable executable
start:
    invoke  MessageBoxA, 0, msg, title, 0
    invoke  ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll', \
            user32,  'user32.dll'
    import  kernel32, ExitProcess,  'ExitProcess'
    import  user32,   MessageBoxA,  'MessageBoxA'
