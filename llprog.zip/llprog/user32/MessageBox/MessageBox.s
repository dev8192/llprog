format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    msg     db 'Hello from MessageBox',0
    title   db 'Title',0

section '.text' code readable executable
start:
    push    0
    push    title
    push    msg
    push    0
    call    [MessageBoxA]

    push    0
    call    [ExitProcess]

section '.idata' import data readable
    library kernel32, 'kernel32.dll', \
            user32,  'user32.dll'
    import  kernel32, ExitProcess,  'ExitProcess'
    import  user32,   MessageBoxA,  'MessageBoxA'
