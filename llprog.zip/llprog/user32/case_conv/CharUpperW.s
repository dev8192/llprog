format PE Console 4.0
entry start

include 'win32a.inc'

section '.text' code readable executable

start:
    invoke  GetStdHandle, STD_OUTPUT_HANDLE
    mov     [hStdOut], eax

    invoke  GetCommandLineW
    invoke  CommandLineToArgvW, eax, argc
    mov     [argv], eax

    test    eax, eax
    jz      .exit

    cmp     dword [argc], 1
    jle     .cleanup

    mov     ebx, 1

.print_loop:
    mov     esi, [argv]
    mov     edi, [esi + ebx * 4]

    invoke  CharUpperW, edi

    invoke  lstrlenW, edi
    invoke  WriteConsoleW, [hStdOut], edi, eax, chars_written, 0

    inc     ebx
    cmp     ebx, [argc]
    jge     .done

    invoke  WriteConsoleW, [hStdOut], space, 1, chars_written, 0
    jmp     .print_loop

.done:
    invoke  WriteConsoleW, [hStdOut], newline, 2, chars_written, 0

.cleanup:
    invoke  LocalFree, [argv]

.exit:
    invoke  ExitProcess, 0

section '.data' data readable writeable

    argc            dd ?
    argv            dd ?
    hStdOut         dd ?
    chars_written   dd ?
    space           dw ' '
    newline         dw 13, 10

section '.idata' import data readable writeable

    library kernel32, 'KERNEL32.DLL',\
            user32,   'USER32.DLL',\
            shell32,  'SHELL32.DLL'

    import kernel32,\
           GetStdHandle,    'GetStdHandle',\
           WriteConsoleW,   'WriteConsoleW',\
           GetCommandLineW, 'GetCommandLineW',\
           LocalFree,       'LocalFree',\
           lstrlenW,        'lstrlenW',\
           ExitProcess,     'ExitProcess'

    import user32,\
           CharUpperW,      'CharUpperW'

    import shell32,\
           CommandLineToArgvW, 'CommandLineToArgvW'
