format PE GUI 4.0
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    ; A string with a null terminator in the middle (byte 0 in Unicode is 00 00)
    ; "A" (0041), null (0000), "b" (0062)
    testString  du 'A', 0, 'b', 0
    buffer      db 256 dup(0)

section '.code' code readable executable

start:
    ; --- Case 1: CharUpperW ---
    ; It will stop at the first null. 'b' will remain lowercase.
    invoke  CharUpperW, testString
    
    ; --- Case 2: CharUpperBuffW ---
    ; We tell it to process 3 characters (A, null, b).
    ; It ignores the null and converts 'b' to 'B'.
    invoke  CharUpperBuffW, testString, 3

    ; Final check: Displaying results would require a debugger or 
    ; manual byte inspection since MessageBox also stops at nulls.
    invoke  MessageBox, 0, "Check testString in a debugger to see 'A' (00) 'B'", "Done", MB_OK
    invoke  ExitProcess, 0

section '.idata' import data readable
    library kernel32,'KERNEL32.DLL',user32,'USER32.DLL'
    import kernel32, ExitProcess,'ExitProcess'
    import user32, MessageBox,'MessageBoxA',\
                   CharUpperW,'CharUpperW',\
                   CharUpperBuffW,'CharUpperBuffW'
