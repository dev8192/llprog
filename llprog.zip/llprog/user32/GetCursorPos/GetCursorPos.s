format PE Console 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    pt          POINT
    szFormat    db 'Cursor Position -> X: %04d, Y: %04d', 13, 0

section '.text' code readable executable
start:
.loop:
    invoke  GetCursorPos, pt
    cinvoke printf, szFormat, [pt.x], [pt.y]
    invoke  Sleep, 50

    cinvoke _kbhit
    test    eax, eax
    jz      .loop

    invoke  ExitProcess, 0

section '.idata' import data readable writeable
    library kernel32,       'KERNEL32.DLL',\
            user32,         'USER32.DLL',\
            msvcrt,         'MSVCRT.DLL'
    import  kernel32,\
            ExitProcess,    'ExitProcess',\
            Sleep,          'Sleep'
    import  user32,\
            GetCursorPos,   'GetCursorPos'
    import  msvcrt,\
            _kbhit,         '_kbhit',\
            printf,         'printf'
