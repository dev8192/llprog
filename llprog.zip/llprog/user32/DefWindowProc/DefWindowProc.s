format PE GUI
;format PE console
entry start

include 'win32a.inc'

section '.text' code readable executable

start:
    mov     [wc.cbSize], sizeof.WNDCLASSEX
    mov     [wc.lpfnWndProc], WindowProc
    invoke  GetModuleHandleA, 0
    mov     [wc.hInstance], eax
    invoke  LoadIconA, 0, IDI_APPLICATION
    mov     [wc.hIcon], eax
    mov     [wc.hIconSm], eax
    invoke  LoadCursorA, 0, IDC_ARROW
    mov     [wc.hCursor], eax
    mov     [wc.hbrBackground], COLOR_WINDOW+1
    mov     [wc.lpszClassName], _class
    invoke  RegisterClassExA, wc

    invoke  CreateWindowExA, 0, _class, _title, WS_VISIBLE + WS_OVERLAPPEDWINDOW, CW_USEDEFAULT,\
        CW_USEDEFAULT, 400, 300, 0, 0, [wc.hInstance], 0

msg_loop:
    invoke  GetMessageA, msg, 0, 0, 0
    test    eax, eax
    jz      end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessageA, msg
    jmp     msg_loop

end_loop:
    invoke  ExitProcess, [msg.wParam]

proc WindowProc1 hwnd, wmsg, wparam, lparam
    cmp     [wmsg], WM_DESTROY
    je      .wmdestroy
    invoke  DefWindowProcA, [hwnd], [wmsg], [wparam], [lparam]
    ret
    .wmdestroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
    ret
endp

; without PostQuitMessage, the app keeps running!
proc WindowProc hwnd, wmsg, wparam, lparam
    invoke  DefWindowProcA, [hwnd], [wmsg], [wparam], [lparam]
    ret
endp

section '.data' data readable writeable

    _class db 'FASM_WIN', 0
    _title db 'DefWindowProc Example', 0
    wc WNDCLASSEX
    msg MSG

section '.idata' import data readable

    library kernel32, 'KERNEL32.DLL',\
        user32, 'USER32.DLL'

    import kernel32,\
        ExitProcess, 'ExitProcess',\
        GetModuleHandleA, 'GetModuleHandleA'

    import user32,\
        CreateWindowExA, 'CreateWindowExA',\
        DefWindowProcA, 'DefWindowProcA',\
        DispatchMessageA, 'DispatchMessageA',\
        GetMessageA, 'GetMessageA',\
        LoadCursorA, 'LoadCursorA',\
        LoadIconA, 'LoadIconA',\
        PostQuitMessage, 'PostQuitMessage',\
        RegisterClassExA, 'RegisterClassExA',\
        TranslateMessage, 'TranslateMessage'
