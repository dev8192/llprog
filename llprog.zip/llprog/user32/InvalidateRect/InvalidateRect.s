format PE GUI 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable

    class_name      db 'InvalidateRectClass', 0
    window_title    db 'InvalidateRect bErase Demo', 0
    str_inst1       db 'Left Click + Drag: InvalidateRect with TRUE (Clears screen)', 0
    str_inst2       db 'Right Click + Drag: InvalidateRect with FALSE (Leaves trail)', 0

    wc              WNDCLASS
    msg             MSG
    ps              PAINTSTRUCT
    rect            RECT
    mouse_x         dd 0
    mouse_y         dd 0

section '.text' code readable executable
start:
    invoke  GetModuleHandle, 0
    mov     [wc.hInstance], eax

    invoke  LoadCursor, 0, IDC_ARROW
    mov     [wc.hCursor], eax

    mov     [wc.style], 0
    mov     [wc.lpfnWndProc], WindowProc
    mov     [wc.lpszClassName], class_name
    mov     [wc.hbrBackground], COLOR_WINDOW+1

    invoke  RegisterClass, wc

    invoke  CreateWindowEx, 0, class_name, window_title,\
        WS_VISIBLE or WS_OVERLAPPEDWINDOW,\
        100, 100, 500, 400, 0, 0, [wc.hInstance], 0

msg_loop:
    invoke  GetMessage, msg, 0, 0, 0
    test    eax, eax
    jz      end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     msg_loop

end_loop:
    invoke  ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp     [wmsg], WM_MOUSEMOVE
    je      .wmmousemove
    cmp     [wmsg], WM_PAINT
    je      .wmpaint
    cmp     [wmsg], WM_DESTROY
    je      .wmdestroy
.defwndproc:
    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret

.wmmousemove:
    mov     eax, [lparam]
    movsx   ecx, ax
    shr     eax, 16
    movsx   edx, ax
    mov     [mouse_x], ecx
    mov     [mouse_y], edx

    test    [wparam], MK_LBUTTON
    jnz     .left_down
    test    [wparam], MK_RBUTTON
    jnz     .right_down
    jmp     .defwndproc

.left_down:
    invoke  InvalidateRect, [hwnd], 0, TRUE
    xor     eax, eax
    ret

.right_down:
    invoke  InvalidateRect, [hwnd], 0, FALSE
    xor     eax, eax
    ret

.wmpaint:
    invoke  BeginPaint, [hwnd], ps

    mov     [rect.left], 10
    mov     [rect.top], 10
    mov     [rect.right], 400
    mov     [rect.bottom], 30
    invoke  DrawText, [ps.hdc], str_inst1, -1, rect, DT_LEFT or DT_SINGLELINE

    mov     [rect.top], 30
    mov     [rect.bottom], 50
    invoke  DrawText, [ps.hdc], str_inst2, -1, rect, DT_LEFT or DT_SINGLELINE

    cmp     [mouse_x], 0
    je      .endpaint
    
    mov     eax, [mouse_x]
    sub     eax, 10
    mov     [rect.left], eax
    add     eax, 20
    mov     [rect.right], eax

    mov     eax, [mouse_y]
    sub     eax, 10
    mov     [rect.top], eax
    add     eax, 20
    mov     [rect.bottom], eax

    invoke  FillRect, [ps.hdc], rect, COLOR_HIGHLIGHT+1

.endpaint:
    invoke  EndPaint, [hwnd], ps
    xor     eax, eax
    ret

.wmdestroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
    ret
endp

section '.idata' import data readable writeable
    library kernel32, 'KERNEL32.DLL',\
            user32, 'USER32.DLL'

    import kernel32,\
           GetModuleHandle, 'GetModuleHandleA',\
           ExitProcess, 'ExitProcess'

    import user32,\
           RegisterClass, 'RegisterClassA',\
           CreateWindowEx, 'CreateWindowExA',\
           DefWindowProc, 'DefWindowProcA',\
           GetMessage, 'GetMessageA',\
           TranslateMessage, 'TranslateMessage',\
           DispatchMessage, 'DispatchMessageA',\
           PostQuitMessage, 'PostQuitMessage',\
           LoadCursor, 'LoadCursorA',\
           InvalidateRect, 'InvalidateRect',\
           BeginPaint, 'BeginPaint',\
           EndPaint, 'EndPaint',\
           DrawText, 'DrawTextA',\
           FillRect, 'FillRect'
