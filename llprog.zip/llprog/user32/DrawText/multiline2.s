;format PE GUI
format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    _class      db 'FasmDrawTextClass',0
    _title      db 'FASM DrawText Example',0
    text        db 'Line #1', 10, 'Line #2',0
    msg         MSG
    wc          WNDCLASSEX
    rect        RECT
    ps          PAINTSTRUCT
    fmt         db 'left: %d, top: %d, right: %d, bottom: %d', 10, 0

section '.code' code readable executable

start:
    mov     [wc.cbSize], sizeof.WNDCLASSEX
    mov     [wc.lpfnWndProc], window_procedure
    invoke  GetModuleHandle, 0
    mov     [wc.hInstance], eax
    mov     [wc.lpszClassName], _class
    mov     [wc.hbrBackground], COLOR_WINDOW+1
    invoke  LoadIcon, 0, IDI_APPLICATION
    mov     [wc.hIcon], eax
    invoke  LoadCursor, 0, IDC_ARROW
    mov     [wc.hCursor], eax
    
    invoke  RegisterClassEx, wc
    
    invoke  CreateWindowEx, 0, _class, _title, WS_VISIBLE or WS_OVERLAPPEDWINDOW,\
            CW_USEDEFAULT, CW_USEDEFAULT, 400, 300, 0, 0, [wc.hInstance], 0
            
  msg_loop:
    invoke  GetMessage, msg, 0, 0, 0
    or      eax, eax
    jz      end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     msg_loop

  end_loop:
    invoke  ExitProcess, [msg.wParam]

proc window_procedure hwnd, umsg, wparam, lparam
    cmp     [umsg], WM_PAINT
    je      .on_paint
    cmp     [umsg], WM_DESTROY
    je      .on_destroy
    invoke  DefWindowProc, [hwnd], [umsg], [wparam], [lparam]
    ret

  .on_paint:
    local hdc:DWORD
    local fullRect:RECT   ; Прямоугольник всего окна
    local textRect:RECT   ; Прямоугольник для расчетов текста
    
    invoke  BeginPaint, [hwnd], addr ps
    mov     [hdc], eax
    
    ; 1. Получаем РЕАЛЬНЫЙ размер клиентской области окна
    invoke  GetClientRect, [hwnd], addr fullRect
    
    ; 2. Копируем размеры окна в textRect для расчета
    ; Мы фиксируем ширину (left/right), чтобы DrawText знал, где переносить строки
    push    [fullRect.left] [fullRect.top] [fullRect.right] [fullRect.bottom]
    pop     [textRect.bottom] [textRect.right] [textRect.top] [textRect.left]
    
    ; 3. Считаем высоту текста при текущей ширине окна
    ; После вызова textRect.bottom будет содержать высоту всего текстового блока
    invoke  DrawText, [hdc], _text, -1, addr textRect,\
            DT_CENTER or DT_WORDBREAK or DT_CALCRECT
            
    ; 4. Центрируем textRect вертикально внутри fullRect
    ; Формула: TopOffset = (WindowHeight - TextHeight) / 2
    mov     eax, [fullRect.bottom]
    sub     eax, [textRect.bottom]
    shr     eax, 1                 ; Делим на 2
    
    ; Обновляем координаты для финальной отрисовки
    mov     ebx, [textRect.bottom] ; Сохраняем высоту текста
    mov     [textRect.top], eax    ; Устанавливаем верхнюю границу
    add     eax, ebx
    mov     [textRect.bottom], eax ; Устанавливаем нижнюю границу (top + height)
    
    ; 5. Рисуем текст по вычисленным координатам
    invoke  DrawText, [hdc], _text, -1, addr textRect,\
            DT_CENTER or DT_WORDBREAK
            
    invoke  EndPaint, [hwnd], addr ps
    xor     eax, eax
    ret

  .on_destroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
    ret
endp

section '.idata' import data readable
  library kernel32, 'KERNEL32.DLL',\
          user32,   'USER32.DLL',\
          msvcrt,   'MSVCRT.DLL'

    import kernel32,\
        ExitProcess, 'ExitProcess',\
        GetModuleHandle, 'GetModuleHandleA'

    import user32,\
        BeginPaint, 'BeginPaint',\
        LoadIcon, 'LoadIconA',\
        LoadCursor, 'LoadCursorA',\
        RegisterClassEx, 'RegisterClassExA',\
        CreateWindowEx, 'CreateWindowExA',\
        GetMessage, 'GetMessageA',\
        TranslateMessage, 'TranslateMessage',\
        DispatchMessage, 'DispatchMessageA',\
        DefWindowProc, 'DefWindowProcA',\
        GetClientRect, 'GetClientRect',\
        DrawText, 'DrawTextA',\
        EndPaint, 'EndPaint',\
        PostQuitMessage, 'PostQuitMessage'

    import msvcrt,\
        printf, 'printf'
