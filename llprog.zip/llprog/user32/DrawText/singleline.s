;format PE GUI
format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    _class      db 'FasmDrawTextClass',0
    _title      db 'FASM DrawText Example',0
    text        db 'Hello from FASM!!',0
    msg         MSG
    wc          WNDCLASSEX
    rect        RECT
    ps          PAINTSTRUCT

section '.code' code readable executable

start:
    mov     [wc.cbSize], sizeof.WNDCLASSEX
    mov     [wc.lpfnWndProc], window_procedure
    invoke  GetModuleHandle, 0
    mov     [wc.hInstance], eax
    mov     [wc.lpszClassName], _class
    mov     [wc.hbrBackground], COLOR_WINDOW+1
    invoke  LoadIcon, 0, IDI_APPLICATION
    mov     [wc.hIcon], eax
    invoke  LoadCursor, 0, IDC_ARROW
    mov     [wc.hCursor], eax
    
    invoke  RegisterClassEx, wc
    
    invoke  CreateWindowEx, 0, _class, _title, WS_VISIBLE or WS_OVERLAPPEDWINDOW,\
            CW_USEDEFAULT, CW_USEDEFAULT, 400, 300, 0, 0, [wc.hInstance], 0
            
  msg_loop:
    invoke  GetMessage, msg, 0, 0, 0
    or      eax, eax
    jz      end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     msg_loop

  end_loop:
    invoke  ExitProcess, [msg.wParam]

proc window_procedure hwnd, umsg, wparam, lparam
    cmp     [umsg], WM_PAINT
    je      .on_paint
    cmp     [umsg], WM_DESTROY
    je      .on_destroy
    invoke  DefWindowProc, [hwnd], [umsg], [wparam], [lparam]
    ret

  .on_paint:
    invoke  BeginPaint, [hwnd], ps    
    invoke  GetClientRect, [hwnd], rect
    invoke  DrawText,\
        [ps.hdc],\          ; HDC
        text,\              ; String
        -1,\                ; Count (-1 for null-term)
        rect,\              ; RECT
        DT_CENTER or\
        DT_VCENTER or\
        DT_SINGLELINE       ; Format Flags
            
    invoke  EndPaint, [hwnd], ps
    xor     eax, eax
    ret

  .on_destroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
    ret
endp

; --- Import Section ---
section '.idata' import data readable
  library kernel32, 'KERNEL32.DLL',\
          user32,   'USER32.DLL'

  include 'api\kernel32.inc'
  include 'api\user32.inc'
