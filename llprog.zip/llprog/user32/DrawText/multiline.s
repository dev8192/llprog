;format PE GUI
format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    _class      db 'FasmDrawTextClass',0
    _title      db 'FASM DrawText Example',0
    text        db 'Line #1', 10, 'Line #2',0
    msg         MSG
    wc          WNDCLASSEX
    rect        RECT
    ps          PAINTSTRUCT
    fmt         db 'left: %d, top: %d, right: %d, bottom: %d', 10, 0

section '.code' code readable executable

start:
    mov     [wc.cbSize], sizeof.WNDCLASSEX
    mov     [wc.lpfnWndProc], window_procedure
    invoke  GetModuleHandle, 0
    mov     [wc.hInstance], eax
    mov     [wc.lpszClassName], _class
    mov     [wc.hbrBackground], COLOR_WINDOW+1
    invoke  LoadIcon, 0, IDI_APPLICATION
    mov     [wc.hIcon], eax
    invoke  LoadCursor, 0, IDC_ARROW
    mov     [wc.hCursor], eax
    
    invoke  RegisterClassEx, wc
    
    invoke  CreateWindowEx, 0, _class, _title, WS_VISIBLE or WS_OVERLAPPEDWINDOW,\
            CW_USEDEFAULT, CW_USEDEFAULT, 400, 300, 0, 0, [wc.hInstance], 0
            
  msg_loop:
    invoke  GetMessage, msg, 0, 0, 0
    or      eax, eax
    jz      end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     msg_loop

  end_loop:
    invoke  ExitProcess, [msg.wParam]

proc window_procedure hwnd, umsg, wparam, lparam
    cmp     [umsg], WM_PAINT
    je      .on_paint
    cmp     [umsg], WM_DESTROY
    je      .on_destroy
    invoke  DefWindowProc, [hwnd], [umsg], [wparam], [lparam]
    ret

  .on_paint:
    invoke  BeginPaint, [hwnd], ps
    invoke  GetClientRect, [hwnd], rect
    cinvoke printf, fmt,\
        [rect.left], [rect.top], [rect.right], [rect.bottom]
    
    invoke  DrawText, [ps.hdc], text, -1, rect,\
            DT_CENTER or DT_WORDBREAK or DT_CALCRECT
    cinvoke printf, fmt,\
        [rect.left], [rect.top], [rect.right], [rect.bottom]
            
    ; top = (высота_окна - высота_текста) / 2
    mov     ebx, [ps.rcPaint.bottom] ; общая высота клиентской области
    sub     ebx, [rect.bottom]
    shr     ebx, 1
    
    mov     eax, [rect.bottom]
    mov     [rect.top], ebx          ; новый верх
    add     eax, ebx
    mov     [rect.bottom], eax       ; новый низ (старая высота + отступ)
    
    invoke  GetClientRect, [hwnd], ps.rcPaint
    mov     eax, [ps.rcPaint.right]
    mov     [rect.right], eax
    mov     [rect.left], 0

    cinvoke printf, fmt,\
        [rect.left], [rect.top], [rect.right], [rect.bottom]
        
    invoke  DrawText, [ps.hdc], text, -1, rect,\
            DT_CENTER or DT_WORDBREAK
            
    invoke  EndPaint, [hwnd], ps
    xor     eax, eax
    ret

  .on_destroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
    ret
endp

section '.idata' import data readable
  library kernel32, 'KERNEL32.DLL',\
          user32,   'USER32.DLL',\
          msvcrt,   'MSVCRT.DLL'

    import kernel32,\
        ExitProcess, 'ExitProcess',\
        GetModuleHandle, 'GetModuleHandleA'

    import user32,\
        BeginPaint, 'BeginPaint',\
        LoadIcon, 'LoadIconA',\
        LoadCursor, 'LoadCursorA',\
        RegisterClassEx, 'RegisterClassExA',\
        CreateWindowEx, 'CreateWindowExA',\
        GetMessage, 'GetMessageA',\
        TranslateMessage, 'TranslateMessage',\
        DispatchMessage, 'DispatchMessageA',\
        DefWindowProc, 'DefWindowProcA',\
        GetClientRect, 'GetClientRect',\
        DrawText, 'DrawTextA',\
        EndPaint, 'EndPaint',\
        PostQuitMessage, 'PostQuitMessage'

    import msvcrt,\
        printf, 'printf'
