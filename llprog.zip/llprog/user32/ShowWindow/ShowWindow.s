; does something strange
format PE Console 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    msg_start db 'Hiding console in 3 seconds...', 10, 0
    msg_show  db 'Console restored! Press Enter to exit.', 10, 0

section '.text' code readable executable
start:
    invoke GetConsoleWindow
    mov ebx, eax

    cinvoke printf, msg_start
    invoke Sleep, 3000

    invoke ShowWindow, ebx, SW_HIDE

    invoke Sleep, 30000

    invoke ShowWindow, ebx, SW_SHOW

    cinvoke printf, msg_show
    cinvoke getchar

    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL',\
        user32, 'USER32.DLL',\
        msvcrt, 'MSVCRT.DLL'

    import kernel32,\
        ExitProcess, 'ExitProcess',\
        GetConsoleWindow, 'GetConsoleWindow',\
        Sleep, 'Sleep'

    import user32,\
        ShowWindow, 'ShowWindow'

    import msvcrt,\
        getchar, 'getchar',\
        printf, 'printf'
