/*
proc window_proc hwnd, wmsg, wparam, lparam
    cmp     [wmsg], WM_PAINT
    je      .wm_paint
    cmp     [wmsg], WM_DESTROY
    je      .wm_destroy

    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret

  .wm_paint:
    invoke  BeginPaint, [hwnd], ps
    invoke  Ellipse, eax, 50, 50, 330, 200
    invoke  EndPaint, [hwnd], ps
    xor     eax, eax
    ret

  .wm_destroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
    ret
endp
*/

// mocks
function BeginPaint() {}
function Ellipse() { console.log('Ellipse') }
function EndPaint() {}
function PostQuitMessage() { console.log('PostQuitMessage') }
function DefWindowProc() { console.log('DefWindowProc') }
const WM_PAINT = 123
const WM_DESTROY = 456
let ps, hwnd

let eax
function window_proc(hwnd, wmsg, wparam, lparam) {
    if (wmsg === WM_PAINT) {
      BeginPaint(hwnd, ps)
      Ellipse(eax, 50, 50, 330, 200)
      EndPaint(hwnd, ps)
      eax = 0
      return
    } else if (wmsg === WM_DESTROY) {
      PostQuitMessage(0)
      eax = 0
      return
    }
    eax = DefWindowProc(hwnd, wmsg, wparam, lparam)
}

// window_proc(hwnd, WM_PAINT)
// window_proc(hwnd, WM_DESTROY)
window_proc()
