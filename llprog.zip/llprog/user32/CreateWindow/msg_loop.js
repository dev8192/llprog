/*
  .msg_loop:
    invoke  GetMessage, msg, 0, 0, 0
    test    eax, eax
    je      .end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     .msg_loop

  .end_loop:
    invoke  ExitProcess, [msg.wParam]
*/

// https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-getmessage
let counter = 5
function GetMessage(lpMsg, hWnd, wMsgFilterMin, wMsgFilterMax) {
    console.log('********** GetMessage **********')
    return counter--
}
// https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-translatemessage
function TranslateMessage(lpMsg) {
    console.log('TranslateMessage')
}
// https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-dispatchmessage
function DispatchMessage(lpMsg) {
    console.log('DispatchMessage')
}
// https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-exitprocess
function ExitProcess(uExitCode) {
    console.log('ExitProcess')
    process.exit()
}

let msg
while(true) {
    const eax = GetMessage(msg, 0, 0, 0)
    if (eax === 0) {
        ExitProcess()
    }
    TranslateMessage()
    DispatchMessage()
}
