format PE GUI 4.0
entry start

include 'win32a.inc'

ID_BTN_TOGGLE = 100
WINDOW_WIDTH = 400
WINDOW_HEIGHT = 300
BTN_X = 20
BTN_Y = 20
BTN_W = 150
BTN_H = 40
WORD_MASK = 0FFFFh

section '.data' data readable writeable
    wc WNDCLASSEX
    msg MSG
    hInstance dd ?
    hwnd dd ?

    className db 'FasmWindow', 0
    windowName db 'Toggle Borders App', 0
    buttonClass db 'BUTTON', 0
    buttonText db 'Toggle borders', 0

section '.text' code readable executable
    start:
        invoke GetModuleHandleA, NULL
        mov [hInstance], eax

        mov [wc.cbSize], sizeof.WNDCLASSEX
        mov [wc.style], CS_HREDRAW or CS_VREDRAW
        mov [wc.lpfnWndProc], WindowProc
        mov [wc.cbClsExtra], 0
        mov [wc.cbWndExtra], 0
        mov eax, [hInstance]
        mov [wc.hInstance], eax
        mov [wc.hIcon], NULL
        invoke LoadCursorA, NULL, IDC_ARROW
        mov [wc.hCursor], eax
        mov [wc.hbrBackground], COLOR_WINDOW + 1
        mov [wc.lpszMenuName], NULL
        mov [wc.lpszClassName], className
        mov [wc.hIconSm], NULL

        invoke RegisterClassExA, wc

        invoke CreateWindowExA, 0, className, windowName, WS_VISIBLE or WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, WINDOW_WIDTH, WINDOW_HEIGHT, NULL, NULL, [hInstance], NULL
        mov [hwnd], eax

    msg_loop:
        invoke GetMessageA, msg, NULL, 0, 0
        test eax, eax
        jz end_loop
        invoke TranslateMessage, msg
        invoke DispatchMessageA, msg
        jmp msg_loop

    end_loop:
        invoke ExitProcess, [msg.wParam]

    proc WindowProc hwndWnd, wmsg, wparam, lparam
        cmp [wmsg], WM_CREATE
        je .wmcreate
        cmp [wmsg], WM_COMMAND
        je .wmcommand
        cmp [wmsg], WM_DESTROY
        je .wmdestroy
        jmp .defwndproc

    .wmcreate:
        invoke CreateWindowExA, 0, buttonClass, buttonText, WS_CHILD or WS_VISIBLE or BS_PUSHBUTTON, BTN_X, BTN_Y, BTN_W, BTN_H, [hwndWnd], ID_BTN_TOGGLE, [hInstance], NULL
        xor eax, eax
        ret

    .wmcommand:
        mov eax, [wparam]
        and eax, WORD_MASK
        cmp eax, ID_BTN_TOGGLE
        jne .defwndproc

        invoke GetWindowLongA, [hwndWnd], GWL_STYLE
        mov edx, eax
        test eax, WS_CAPTION
        jnz .make_borderless

    .make_normal:
        mov eax, edx
        and eax, not WS_POPUP
        or eax, WS_OVERLAPPEDWINDOW
        jmp .apply_style

    .make_borderless:
        mov eax, edx
        and eax, not WS_OVERLAPPEDWINDOW
        or eax, WS_POPUP

    .apply_style:
        invoke SetWindowLongA, [hwndWnd], GWL_STYLE, eax
        invoke SetWindowPos, [hwndWnd], NULL, 0, 0, 0, 0, SWP_NOMOVE or SWP_NOSIZE or SWP_NOZORDER or SWP_FRAMECHANGED
        xor eax, eax
        ret

    .wmdestroy:
        invoke PostQuitMessage, 0
        xor eax, eax
        ret

    .defwndproc:
        invoke DefWindowProcA, [hwndWnd], [wmsg], [wparam], [lparam]
        ret
    endp

section '.idata' import data readable writeable
    library kernel32, 'KERNEL32.DLL',\
            user32, 'USER32.DLL'

    import kernel32,\
           ExitProcess, 'ExitProcess',\
           GetModuleHandleA, 'GetModuleHandleA'

    import user32,\
           CreateWindowExA, 'CreateWindowExA',\
           DefWindowProcA, 'DefWindowProcA',\
           DispatchMessageA, 'DispatchMessageA',\
           GetMessageA, 'GetMessageA',\
           GetWindowLongA, 'GetWindowLongA',\
           LoadCursorA, 'LoadCursorA',\
           PostQuitMessage, 'PostQuitMessage',\
           RegisterClassExA, 'RegisterClassExA',\
           SetWindowLongA, 'SetWindowLongA',\
           SetWindowPos, 'SetWindowPos',\
           TranslateMessage, 'TranslateMessage'
