format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    wc WNDCLASS
    msg MSG
    class_name db 'UserDataClass', 0
    my_secret_data db 'Hello from GWL_USERDATA!', 0
    msg_caption db 'User Data Retrieved', 0

section '.text' code readable executable

start:
    invoke GetModuleHandle, 0
    mov [wc.hInstance], eax
    mov [wc.lpfnWndProc], WindowProc
    invoke LoadCursor, 0, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.lpszClassName], class_name
    mov [wc.hbrBackground], COLOR_WINDOW+1
    invoke RegisterClass, wc
    invoke CreateWindowEx, 0, class_name, class_name,\
        WS_OVERLAPPEDWINDOW or WS_VISIBLE,\
        CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,\
        0, 0, [wc.hInstance], my_secret_data
msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    test eax, eax
    jz end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp msg_loop
end_loop:
    invoke ExitProcess, [msg.wParam]

proc WindowProc uses ebx, hwnd, wmsg, wparam, lparam
    cmp [wmsg], WM_CREATE
    je .wmcreate
    cmp [wmsg], WM_LBUTTONDOWN
    je .wmlbuttondown
    cmp [wmsg], WM_DESTROY
    je .wmdestroy
.defwndproc:
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret
.wmcreate:
    mov eax, [lparam]
    mov ebx, [eax + CREATESTRUCT.lpCreateParams]
    invoke SetWindowLong, [hwnd], GWL_USERDATA, ebx
    xor eax, eax
    ret
.wmlbuttondown:
    invoke GetWindowLong, [hwnd], GWL_USERDATA
    invoke MessageBox, [hwnd], eax, msg_caption, MB_OK
    xor eax, eax
    ret
.wmdestroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    ret
endp

section '.idata' import data readable
    library kernel32,         'KERNEL32.DLL',\
            user32,           'USER32.DLL',\
            msvcrt,           'MSVCRT.DLL'
    import  kernel32,\
            GetModuleHandle,  'GetModuleHandleA',\
            ExitProcess,      'ExitProcess'
    import  user32,\
            LoadCursor,       'LoadCursorA',\
            RegisterClass,    'RegisterClassA',\
            CreateWindowEx,   'CreateWindowExA',\
            GetMessage,       'GetMessageA',\
            TranslateMessage, 'TranslateMessage',\
            DispatchMessage,  'DispatchMessageA',\
            DefWindowProc,    'DefWindowProcA',\
            SetWindowLong,    'SetWindowLongA',\
            GetWindowLong,    'GetWindowLongA',\
            MessageBox,       'MessageBoxA',\
            PostQuitMessage,  'PostQuitMessage'
    import  msvcrt,\
            printf,           'printf'
