format PE GUI 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    clsName     db 'SysMenuDemo', 0
    title       db 'Disabled Maximize Button', 0
    wc          WNDCLASS
    msg         MSG
    hwnd        dd 0
    hSysMenu    dd ?

; Restore   0
; Move      1   SC_MOVE
; Size      2   SC_SIZE
; Minimize  3
; Maximize  4   SC_MAXIMIZE
; --------  5
; Close     6   SC_CLOSE

section '.text' code readable executable
start:
    invoke  GetModuleHandle, 0
    mov     [wc.hInstance], eax

    invoke  LoadCursor, 0, IDC_ARROW
    mov     [wc.hCursor], eax

    mov     [wc.lpfnWndProc], WindowProc
    mov     [wc.hbrBackground], COLOR_WINDOW+1
    mov     [wc.lpszClassName], clsName

    invoke  RegisterClass, wc
    invoke  CreateWindowEx, 0, clsName, title, WS_OVERLAPPEDWINDOW + WS_VISIBLE,\
        100, 100, 400, 350, 0, 0, [wc.hInstance], 0
    mov     [hwnd], eax

    invoke  GetSystemMenu, [hwnd], 0
    mov     [hSysMenu], eax
    ;invoke  DeleteMenu, [hSysMenu], SC_MOVE, MF_BYCOMMAND
    ;invoke  DeleteMenu, [hSysMenu], SC_SIZE, MF_BYCOMMAND

    ;invoke DeleteMenu, [hSysMenu], 0, MF_BYPOSITION
    ;invoke DeleteMenu, [hSysMenu], 0, MF_BYPOSITION
    ;invoke DeleteMenu, [hSysMenu], 0, MF_BYPOSITION
    ;invoke DeleteMenu, [hSysMenu], 0, MF_BYPOSITION
    ;invoke DeleteMenu, [hSysMenu], 0, MF_BYPOSITION
    ;invoke DeleteMenu, [hSysMenu], 0, MF_BYPOSITION
    ;invoke DeleteMenu, [hSysMenu], 0, MF_BYPOSITION

    invoke DeleteMenu, [hSysMenu], 6, MF_BYPOSITION

msg_loop:
    invoke  GetMessage, msg, 0, 0, 0
    test    eax, eax
    jz      end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     msg_loop

end_loop:
    invoke  ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp     [wmsg], WM_DESTROY
    je      .wmdestroy

    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret

.wmdestroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
    ret
endp

section '.idata' import data readable

library kernel32, 'KERNEL32.DLL',\
        user32, 'USER32.DLL'

import kernel32,\
       ExitProcess, 'ExitProcess',\
       GetModuleHandle, 'GetModuleHandleA'

import user32,\
       CreateWindowEx, 'CreateWindowExA',\
       DefWindowProc, 'DefWindowProcA',\
       DeleteMenu, 'DeleteMenu',\
       DispatchMessage, 'DispatchMessageA',\
       GetMessage, 'GetMessageA',\
       GetSystemMenu, 'GetSystemMenu',\
       LoadCursor, 'LoadCursorA',\
       PostQuitMessage, 'PostQuitMessage',\
       RegisterClass, 'RegisterClassA',\
       TranslateMessage, 'TranslateMessage'
