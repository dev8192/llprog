format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    header_fmt  db 'HWND       | Class                      | Title', 10, 0
    row_fmt db '0x%08X | %-26s | %s', 10, 0
    empty_cell db '---', 0
    title_ptr dd ?
    class_ptr dd ?
    title_buf rb 256
    class_buf rb 256

section '.text' code readable executable

proc EnumWindowsProc hwnd, lparam
    invoke IsWindowVisible, [hwnd]
    test eax, eax
    jz .done
.get_class_name:
    invoke GetClassName, [hwnd], class_buf, 256
    test eax, eax
    jz @f
    mov [class_ptr], class_buf
    jmp .get_window_text
@@:
    mov [class_ptr], empty_cell
.get_window_text:
    invoke GetWindowText, [hwnd], title_buf, 256
    test eax, eax
    jz @f
    mov [title_ptr], title_buf
    jmp .print_msg
@@:
    mov [title_ptr], empty_cell
.print_msg:
    cinvoke printf, row_fmt, [hwnd], [class_ptr], [title_ptr]
.done:
    mov eax, 1
    ret
endp

proc start
    cinvoke printf, header_fmt
    invoke EnumWindows, EnumWindowsProc, 0
    invoke ExitProcess, 0
endp

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            user32, 'user32.dll',\
            msvcrt, 'msvcrt.dll'
    import  kernel32,\
            ExitProcess, 'ExitProcess'
    import  user32,\
            EnumWindows, 'EnumWindows',\
            IsWindowVisible, 'IsWindowVisible',\
            GetClassName, 'GetClassNameA',\
            GetWindowText, 'GetWindowTextA'
    import  msvcrt,\
            printf, 'printf'
