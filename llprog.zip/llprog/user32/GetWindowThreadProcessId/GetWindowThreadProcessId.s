format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt_str db 'HWND: 0x%08X', 10
            db 'Thread ID: %u', 10
            db 'Process ID: %u', 10, 0
    process_id dd 0

section '.text' code readable executable

proc ShowProcessAndThreadId hwnd
    invoke GetWindowThreadProcessId, [hwnd], process_id
    cinvoke printf, fmt_str, [hwnd], eax, [process_id]
    ret
endp

start:
    invoke GetForegroundWindow
    stdcall ShowProcessAndThreadId, eax
    invoke ExitProcess, 0

section '.idata' import data readable

    library kernel32, 'KERNEL32.DLL',\
        user32, 'USER32.DLL',\
        msvcrt, 'MSVCRT.DLL'

    import kernel32,\
        ExitProcess, 'ExitProcess'

    import user32,\
        GetForegroundWindow, 'GetForegroundWindow',\
        GetWindowThreadProcessId, 'GetWindowThreadProcessId'

    import msvcrt,\
        printf, 'printf'
