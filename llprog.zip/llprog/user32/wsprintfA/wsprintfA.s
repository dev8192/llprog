format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt     db '%u',0

section '.bss' readable writeable
    outbuf  rb 32
    hOut    dd ?

section '.code' code readable executable

start:
    invoke  GetStdHandle, STD_OUTPUT_HANDLE
    mov     [hOut], eax

    mov     eax, 12345
    cinvoke wsprintfA, outbuf, fmt, eax

    invoke  lstrlenA, outbuf
    mov     ecx, eax

    invoke  WriteConsoleA, [hOut], outbuf, ecx, 0, 0

    invoke  ExitProcess, 0

section '.idata' import data readable writeable

    library kernel32, 'kernel32.dll', \
            user32,   'user32.dll'

    import kernel32, \
        ExitProcess,   'ExitProcess', \
        GetStdHandle,  'GetStdHandle', \
        WriteConsoleA, 'WriteConsoleA', \
        lstrlenA,      'lstrlenA'

    import user32, \
        wsprintfA, 'wsprintfA'
