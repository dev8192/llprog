format PE
entry start

include 'win32ax.inc'

CDERR_STRUCTSIZE = 0x0001

section '.data' data readable writeable
    ofn             OPENFILENAME 0
    buffer          db MAX_PATH dup(0)
    fmt_success     db 'success', 10, 0
    fmt_cancel      db 'closed by user', 10, 0
    fmt_err         db 'Common Dialog Error Code: 0x%04X', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc CommDlgExtendedError_func
    invoke CommDlgExtendedError
    test eax, eax
    jz .cancelled
    cinvoke printf, fmt_err, eax
    jmp .exit
.cancelled:
    cinvoke printf, fmt_cancel
.exit:
    ret
endp

proc GetOpenFileName_func, ofn
    invoke GetOpenFileName, [ofn]
    test eax, eax
    jz .error
    cinvoke printf, fmt_success
    jmp .exit
.error:
    stdcall CommDlgExtendedError_func
.exit:
    ret
endp

; --------------------------------------
; 0x0002    CDERR_INITIALIZATION
; --------------------------------------
proc main1
    cinvoke puts, '*** main1 ***'
    stdcall GetOpenFileName_func, 0
    ret
endp

; --------------------------------------
; 0x0001    CDERR_STRUCTSIZE
; --------------------------------------
proc main
    cinvoke puts, '*** main2 ***'
    mov [ofn.lStructSize], sizeof.OPENFILENAME - 4
    mov [ofn.lpstrFile], buffer
    mov [ofn.nMaxFile], MAX_PATH
    stdcall GetOpenFileName_func, ofn
    ret
endp

section '.idata' import data readable
    library kernel32,               'kernel32.dll',\
            comdlg32,               'comdlg32.dll',\
            msvcrt,                 'msvcrt.dll'
    import  kernel32,\
            ExitProcess,            'ExitProcess'
    import  comdlg32,\
            GetOpenFileName,        'GetOpenFileNameA',\
            CommDlgExtendedError,   'CommDlgExtendedError'
    import  msvcrt,\
            printf,                 'printf',\
            puts,                   'puts'
