format PE
entry start

include 'win32ax.inc'

INVALID_FILE_SIZE = 0xffffffff

section '.data' data readable writeable
    ofn             OPENFILENAME 0
    buf1            db MAX_PATH dup(0)
    buf2            db 0, 15 dup(-1)
    fmt_size        db 'size: %llu', 10, 0
    fmt_s           db '%s', 10, 0
    fmt_d           db '%d', 10, 0
    fmt_cancel      db 'closed by user', 10, 0
    fmt_err         db 'Common Dialog Error Code: 0x%04X', 10, 0

include '../util/print_bytes.data.inc'

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

include '../util/print_bytes.text.inc'

proc print_file_name, ofn
    mov eax, [ofn]
    cinvoke printf, fmt_s, [eax + OPENFILENAME.lpstrFile]
    ret
endp

proc print_file_size, ofn
    local size_high:DWORD
    local hFile:DWORD
    mov eax, [ofn]
    invoke  CreateFile, [eax + OPENFILENAME.lpstrFile],\
            GENERIC_READ, FILE_SHARE_READ, 0,\
            OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0
    cmp eax, INVALID_HANDLE_VALUE
    je .CreateFile_error
    mov [hFile], eax
    invoke GetFileSize, [hFile], addr size_high
    cmp eax, INVALID_FILE_SIZE
    je .GetFileSize_error
    cinvoke printf, fmt_size, eax, [size_high]
    jmp .exit
.CreateFile_error:
    cinvoke puts, 'CreateFile_error'
    jmp .exit
.GetFileSize_error:
    cinvoke puts, 'GetFileSize_error'
    invoke CloseHandle, [hFile]
.exit:
    ret
endp

proc GetOpenFileName_func, unnamedParam1, callback
    invoke GetOpenFileName, [unnamedParam1]
    test eax, eax
    jz .error
    cmp [callback], 0
    jz .exit
    stdcall [callback], [unnamedParam1]
    jmp .exit
.error:
    invoke CommDlgExtendedError
    test eax, eax
    jz .cancelled
    cinvoke printf, fmt_err, eax
    jmp .exit
.cancelled:
    cinvoke printf, fmt_cancel
.exit:
    ret
endp

; ------------------
; Success
; ------------------
proc main1
    cinvoke puts, '*** main1 ***'
    mov [ofn.lStructSize], sizeof.OPENFILENAME
    mov [ofn.lpstrFile], buf1
    mov [ofn.nMaxFile], MAX_PATH
    mov [ofn.Flags], OFN_FILEMUSTEXIST + OFN_PATHMUSTEXIST
    stdcall GetOpenFileName_func, ofn, print_file_name
   ;stdcall GetOpenFileName_func, ofn, print_file_size
    ret
endp

; --------------------------------------
; 0x0002    CDERR_INITIALIZATION
; --------------------------------------
proc main2
    cinvoke puts, '*** main2 ***'
    stdcall GetOpenFileName_func, 0, 0
    ret
endp

; --------------------------------------
; 0x0001    CDERR_STRUCTSIZE
; --------------------------------------
proc main3
    cinvoke puts, '*** main3 ***'
    mov [ofn.lStructSize], sizeof.OPENFILENAME - 4
    mov [ofn.lpstrFile], buf1
    mov [ofn.nMaxFile], MAX_PATH
    mov [ofn.Flags], OFN_FILEMUSTEXIST + OFN_PATHMUSTEXIST
    stdcall GetOpenFileName_func, ofn, 0
    ret
endp

; --------------------------------------
; 0x3003    FNERR_BUFFERTOOSMALL
; --------------------------------------
proc main
    cinvoke puts, '*** main4 ***'
    mov [ofn.lStructSize], sizeof.OPENFILENAME
    mov [ofn.lpstrFile], buf2
    mov [ofn.nMaxFile], 10
    stdcall print_bytes, buf2, 16
    stdcall GetOpenFileName_func, ofn, 0
    stdcall print_bytes, buf2, 16
    mov eax, [ofn.lpstrFile]
    movzx eax, word [eax]
    cinvoke printf, fmt_d, eax
    ret
endp

section '.idata' import data readable
    library kernel32,               'kernel32.dll',\
            comdlg32,               'comdlg32.dll',\
            msvcrt,                 'msvcrt.dll'
    import  kernel32,\
            CreateFile,             'CreateFileA',\
            GetFileSize,            'GetFileSize',\
            CloseHandle,            'CloseHandle',\
            ExitProcess,            'ExitProcess'
    import  comdlg32,\
            GetOpenFileName,        'GetOpenFileNameA',\
            CommDlgExtendedError,   'CommDlgExtendedError'
    import  msvcrt,\
            printf,                 'printf',\
            puts,                   'puts'
