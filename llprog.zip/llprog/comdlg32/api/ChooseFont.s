format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    cf              CHOOSEFONT
    lf              LOGFONT
    fmt_font        db 'Selected Font: %s', 10
                    db 'Size (Points): %d', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    mov [cf.lStructSize], sizeof.CHOOSEFONT
    mov [cf.lpLogFont], lf
    mov [cf.Flags], CF_SCREENFONTS or CF_EFFECTS
    invoke ChooseFont, cf
    test eax, eax
    jz .exit
    mov eax, [cf.iPointSize]
    xor edx, edx
    mov ecx, 10
    div ecx
    cinvoke printf, fmt_font, lf.lfFaceName, eax
.exit:
    ret
endp

section '.idata' import data readable writeable
    library kernel32,           'kernel32.dll',\
            comdlg32,           'comdlg32.dll',\
            msvcrt,             'msvcrt.dll'
    import  kernel32,\
            GetModuleHandle,    'GetModuleHandleA',\
            ExitProcess,        'ExitProcess'
    import  comdlg32,\
            ChooseFont,         'ChooseFontA'
    import  msvcrt,\
            printf,             'printf'
