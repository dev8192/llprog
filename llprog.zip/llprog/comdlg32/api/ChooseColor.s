format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    cc              CHOOSECOLOR 0
    cust_colors1    dd 16 dup(0)
    cust_colors2:   dd 0x0000FF00
                    dd 0x0000FF00
                    dd 0x0000FF00
                    dd 0x0000FF00
                    dd 0x0000FF00
                    dd 0x0000FF00
                    dd 0x0000FF00
                    dd 0x0000FF00
                    dd 0x0000FF00
                    dd 0x0000FF00
                    dd 0x0000FF00
                    dd 0x0000FF00
                    dd 0x0000FF00
                    dd 0x0000FF00
                    dd 0x0000FF00
                    dd 0x0000FF00
    fmt_rgb         db 'R=%d, G=%d, B=%d', 10, 0
    fmt_cancel      db 'Dialog cancelled.', 10, 0

include '../../util/print_bytes.data.inc'

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

include '../../util/print_bytes.text.inc'

proc print_color1, color_ref
    mov eax, [color_ref]
    movzx ecx, al
    movzx edx, ah
    shr eax, 16
    movzx eax, al
    cinvoke printf, fmt_rgb, ecx, edx, eax
    ret
endp

proc print_color, color_ref
    movzx ecx, byte [color_ref]
    movzx edx, byte [color_ref + 1]
    movzx eax, byte [color_ref + 2]
    cinvoke printf, fmt_rgb, ecx, edx, eax
    ret
endp

proc main
    mov [cc.lStructSize], sizeof.CHOOSECOLOR
    mov [cc.lpCustColors], cust_colors2
    mov [cc.rgbResult], 0x0000FF00
    or [cc.Flags], CC_FULLOPEN
    or [cc.Flags], CC_RGBINIT
    invoke ChooseColor, cc
    test eax, eax
    jz .cancelled
    stdcall print_color, [cc.rgbResult]
    stdcall print_bytes, cust_colors2, 16 * 4
    jmp .exit
.cancelled:
    cinvoke printf, fmt_cancel
    jmp .exit
.exit:
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            comdlg32,       'comdlg32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  comdlg32,\
            ChooseColor,    'ChooseColorA'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
