format PE
entry start

include 'win32ax.inc'

macro CREATE_COLORREF_ARRAY name, [red, green, blue] {
    common
        name:
    forward
        dd (blue shl 16) or (green shl 8) or red
       ;dd ((b and 0xFF) shl 16) or ((g and 0xFF) shl 8) or (r and 0xFF)
    common
        name#_count = ($ - name) / 4
}

section '.data' data readable writeable
    fmt_x       db '0x%08X', 10, 0

    CREATE_COLORREF_ARRAY colors1,\
        255, 0, 0,\
        0, 255, 0,\
        0, 0, 255

    colors2:
            dd 0x000000ff
            dd 0x0000ff00
            dd 0x00ff0000
    colors2_count = ($ - colors2) / 4

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc print_colors uses ebx esi, arr, arr_len
    xor ebx, ebx
.loop:
    cmp ebx, [arr_len]
    jae .exit
    mov eax, [arr]
    cinvoke printf, fmt_x, ebx, dword [eax + ebx * 4]
    inc ebx
    jmp .loop
.exit:
    ret
endp

proc print_colors2 uses ebx esi, arr, arr_len
    cinvoke puts, '*** colors ***'
    mov esi, [arr]
    mov ebx, [arr_len]
.loop:
    cmp ebx, 0
    jbe .exit
    cinvoke printf, fmt_x, dword [esi]
    dec ebx
    add esi, 4
    jmp .loop
.exit:
    ret
endp

proc main1
    cinvoke puts, '*** main1 ***'
    cinvoke printf, fmt_x, dword [colors2]
    cinvoke printf, fmt_x, dword [colors2 + 4]
    cinvoke printf, fmt_x, dword [colors2 + 8]
    stdcall print_colors, 0, 0
    ret
endp

proc main
    cinvoke puts, '*** main2 ***'
    stdcall print_colors, colors1, 3
    stdcall print_colors, colors2, 3
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
