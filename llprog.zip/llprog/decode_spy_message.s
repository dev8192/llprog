format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    input_text      db "H3ello Pyt2hon 1Is Awe5some", 0
    buf_size        = $ - input_text
    result_buf      db buf_size dup(0)
    checksum        dd 0
    fmt_d           db '%d', 10, 0

section '.text' code readable executable
start:
    stdcall decode_spy_message
    cinvoke printf, result_buf
    cinvoke printf, fmt_d, [checksum]
    invoke ExitProcess, 0

proc decode_spy_message uses ebx edi
    xor ebx, ebx
    xor edi, edi
.loop:
    mov al, [input_text + ebx]
    cmp eax, '0'
    jb .copy
    cmp eax, '9'
    ja .copy
    sub eax, '0'
    add [checksum], eax
    jmp .continue
.copy:
    cinvoke puts, '!!!'
    mov al, [input_text + ebx]
    mov [result_buf + esi], al
    inc esi
.continue:
    inc ebx
    cmp ebx, buf_size
    jl .loop
    mov [result_buf + esi], 0
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
