format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    characters  rb 100h      ; SOURCE\VARIABLE.INC:153
    converted   rb 100h      ; SOURCE\VARIABLE.INC:154
    fmt_x       db '%x', 10, 0
    fmt_s       db '%s', 10, 0
    str1        db 'ABCDEF', 0

include '../util/print_bytes.data.inc'

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

include '../util/print_bytes.text.inc'

proc populate_lookup_table
    mov    edi, characters
    xor    al, al
make_characters_table:
    stosb
    inc    al
    jnz    make_characters_table
    mov    esi, characters + 'a'
    mov    edi, characters + 'A'
    mov    ecx, 26
    rep    movsb
    ret
endp

proc lower_case uses ebx esi edi
    mov    edi, converted
    mov    ebx, characters
convert_case:
    lods    byte [esi]
    xlat    byte [ebx]
    stos    byte [edi]
    loop    convert_case
    ret
endp

proc main uses esi
    cinvoke puts, '*** main1 ***'
    stdcall populate_lookup_table
    
    mov esi, str1
    mov ecx, 3
    stdcall lower_case
    cinvoke printf, fmt_s, converted

    mov esi, str1
    mov ecx, 4
    stdcall lower_case
    cinvoke printf, fmt_s, converted
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
