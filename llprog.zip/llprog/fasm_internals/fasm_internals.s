format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_x               db '%x', 10, 0
    locals_counter      rb 8

include '../util/print_bytes.data.inc'

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

include '../util/print_bytes.text.inc'

proc main1
    cinvoke puts, '*** main1 ***'
    xor eax, eax
    mov ax, 1 + '0' shl 8
    cinvoke printf, fmt_x, eax
    ret
endp

proc main
    cinvoke puts, '*** main2 ***'
    mov edi, locals_counter
    mov ax, 1 + '0' shl 8
    stos word [edi]
    stdcall print_bytes, locals_counter, 8
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
