format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt_hex     db '%x', 10, 0
    mod_name    db 'kernel32.dll', 0
    func_name   db 'ExitProcess', 0

section '.text' code readable executable

;403060
;76a37380
;6aec8b55
proc test10
    cinvoke printf, fmt_hex, ExitProcess        ; Address of the IAT Slot
    cinvoke printf, fmt_hex, [ExitProcess]      ; Actual Function Address
    mov eax, [ExitProcess]
    cinvoke printf, fmt_hex, [eax]              ; First 4 Bytes of Code
    ret
endp

proc test20 uses ebx
    cinvoke printf, fmt_hex, [ExitProcess]
    invoke GetModuleHandle, mod_name
    mov ebx, eax
    invoke GetProcAddress, ebx, func_name
    cinvoke printf, fmt_hex, eax
    ret
endp

start:
    stdcall test20
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            msvcrt, 'msvcrt.dll'
    import  kernel32,\
            GetModuleHandle, 'GetModuleHandleA',\
            GetProcAddress, 'GetProcAddress',\
            ExitProcess, 'ExitProcess'
    import  msvcrt,\
            printf, 'printf'
