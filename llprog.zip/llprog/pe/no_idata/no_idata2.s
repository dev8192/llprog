format PE console
entry start

include 'win32a.inc'

FS_PEB_OFFSET            = 0x30
PEB_LDR_OFFSET           = 0x0C
LDR_INMEMORYORDER_OFFSET = 0x14
LDR_MODULE_BASE_OFFSET   = 0x10

DOS_MAGIC                = 0x5A4D
PE_MAGIC                 = 0x00004550

DOS_LFANEW_OFFSET        = 0x3C
PE_EXPORT_DIR_OFFSET     = 0x78

EXP_NUM_NAMES_OFFSET     = 0x18
EXP_FUNCTIONS_OFFSET     = 0x1C
EXP_NAMES_OFFSET         = 0x20
EXP_ORDINALS_OFFSET      = 0x24

STR_EXIT                 = 0x74697845
STR_PROC                 = 0x636F7250
STR_ESS                  = 0x00737365

EXIT_CODE                = 42

section '.text' code readable executable

start:
    stdcall GetExitProcessAddress
    stdcall eax, EXIT_CODE

proc GetExitProcessAddress
    mov eax, [fs:FS_PEB_OFFSET]
    mov eax, [eax + PEB_LDR_OFFSET]
    mov esi, [eax + LDR_INMEMORYORDER_OFFSET]

.next_module:
    mov ebx, [esi + LDR_MODULE_BASE_OFFSET]
    test ebx, ebx
    jz .module_not_found

    cmp word [ebx], DOS_MAGIC
    jne .skip_module
    
    mov eax, [ebx + DOS_LFANEW_OFFSET]
    add eax, ebx
    cmp dword [eax], PE_MAGIC
    jne .skip_module

    mov ecx, [eax + PE_EXPORT_DIR_OFFSET]
    test ecx, ecx
    jz .skip_module
    add ecx, ebx

    mov edi, [ecx + EXP_NAMES_OFFSET]
    add edi, ebx
    mov edx, [ecx + EXP_NUM_NAMES_OFFSET]
    xor ebp, ebp

.find_name:
    test edx, edx
    jz .skip_module

    mov eax, [edi + ebp * 4]
    add eax, ebx

    cmp dword [eax], STR_EXIT
    jne .next_name
    cmp dword [eax + 4], STR_PROC
    jne .next_name
    cmp dword [eax + 8], STR_ESS
    je .found_exitprocess

.next_name:
    inc ebp
    dec edx
    jmp .find_name

.skip_module:
    mov esi, [esi]
    jmp .next_module

.found_exitprocess:
    mov eax, [ecx + EXP_ORDINALS_OFFSET]
    add eax, ebx
    movzx ebp, word [eax + ebp * 2]

    mov eax, [ecx + EXP_FUNCTIONS_OFFSET]
    add eax, ebx
    mov eax, [eax + ebp * 4]
    add eax, ebx
    ret

.module_not_found:
    int3
    ret
endp
