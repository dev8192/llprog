format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt     db 'abc123', 10, 0

section '.text' code readable executable
start:
    cinvoke printf, fmt
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
