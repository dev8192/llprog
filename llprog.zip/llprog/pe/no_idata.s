; not working. looks like pure bs

format PE console
entry start

section '.text' code readable executable

start:
    call    get_kernel32
    mov     ebx, eax
    call    get_GetProcAddress
    mov     esi, eax
    call    get_LoadLibraryA
    mov     edi, eax

    sub     esp, 16
    mov     byte [esp], 'H'
    mov     byte [esp+1], 'e'
    mov     byte [esp+2], 'l'
    mov     byte [esp+3], 'l'
    mov     byte [esp+4], 'o'
    mov     byte [esp+5], 13
    mov     byte [esp+6], 10
    mov     byte [esp+7], 0

    push    esp
    push    7
    push    esp
    push    -11
    call    [esi]          ; GetProcAddress(kernel32, "WriteConsoleA")
    call    eax            ; call WriteConsoleA

    push    0
    call    [esi]          ; GetProcAddress(kernel32, "ExitProcess")
    call    eax

get_kernel32:
    mov     eax, [fs:0x30]
    mov     eax, [eax+0x0C]
    mov     eax, [eax+0x1C]
    mov     eax, [eax]
    mov     eax, [eax+0x08]
    ret

get_GetProcAddress:
    push    ebx
    call    resolve
    db 'GetProcAddress',0

get_LoadLibraryA:
    push    ebx
    call    resolve
    db 'LoadLibraryA',0

resolve:
    pop     edx
    mov     eax, [esp+4]
    mov     eax, [eax+0x3C]
    add     eax, [esp+4]
    mov     eax, [eax+0x78]
    add     eax, [esp+4]
    mov     ecx, [eax+0x18]
    mov     ebx, [eax+0x20]
    add     ebx, [esp+4]
next_name:
    dec     ecx
    js      not_found
    mov     esi, [ebx+ecx*4]
    add     esi, [esp+4]
    push    ecx
    push    edx
    call    strcmp
    pop     edx
    pop     ecx
    jnz     next_name
    mov     ebx, [eax+0x24]
    add     ebx, [esp+4]
    mov     cx, [ebx+ecx*2]
    mov     ebx, [eax+0x1C]
    add     ebx, [esp+4]
    mov     eax, [ebx+ecx*4]
    add     eax, [esp+4]
    ret

not_found:
    xor     eax, eax
    ret

strcmp:
    mov     edi, edx
    mov     esi, [esp+4]
s1:
    mov     al, [edi]
    mov     bl, [esi]
    cmp     al, bl
    jne     s2
    test    al, al
    je      s3
    inc     edi
    inc     esi
    jmp     s1
s2:
    mov     eax, 1
    ret
s3:
    xor     eax, eax
    ret
