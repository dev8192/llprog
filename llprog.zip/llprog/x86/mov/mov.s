; not working
format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    num1        db 0x12
    num2        dw 0x1234
    num3        dd 0x12345678
    fmt         db '%x', 10, 0

section '.text' code readable executable
start:
    xor     eax, eax
    mov     eax, [num1]
    cinvoke printf, fmt, eax
    
    xor     eax, eax
    mov     eax, [num2]
    cinvoke printf, fmt, eax
    
    xor     eax, eax
    mov     eax, [num3]
    cinvoke printf, fmt, eax
    
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
