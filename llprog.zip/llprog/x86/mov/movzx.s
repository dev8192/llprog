format PE console
entry start

include 'win32a.inc'

section '.data' data readable writable
    num1     db 0xAB
    num2     db 0xCD
    num3     db 0x12
    num4     db 0x34
    fmt      db '%x', 10, 0

section '.code' code readable executable
start:
    ; broken cast - reads 3 bytes of garbage after 'num1'
    cinvoke printf, fmt, dword [num1]

    movzx eax, byte [num1]
    cinvoke printf, fmt, eax

    cinvoke exit, 0

section '.idata' import readable
    library msvcrt, 'msvcrt.dll'
    import msvcrt,\
        printf, 'printf',\
        exit, 'exit'
