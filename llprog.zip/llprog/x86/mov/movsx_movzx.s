format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    val    db 0xFF
    fmt db '%d (0x%08X)', 10, 0

section '.text' code readable executable
start:
    movzx eax, [val]
    cinvoke printf, fmt, eax, eax

    movsx eax, [val]
    cinvoke printf, fmt, eax, eax

    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
        msvcrt, 'msvcrt.dll'

    import kernel32,\
        ExitProcess, 'ExitProcess'

    import msvcrt,\
        printf, 'printf'
