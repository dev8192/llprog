format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt1         db "%08x", 10, 0
    fmt2         db "x: %d, y: %d", 10, 0
    lparam1      dd (12 shl 16) or 34
    lparam2      dd (-12 shl 16) or ((-34) and 0xFFFF)

section '.code' code readable executable
example1:
    cinvoke printf, fmt1, [lparam1]
    mov     eax, [lparam1]
    movzx   ecx, ax
    shr     eax, 16
    cinvoke printf, fmt2, eax, ecx
    ret

example2:
    cinvoke printf, fmt1, [lparam2]
    mov     eax, [lparam2]
    movsx   ecx, ax
    sar     eax, 16
    cinvoke printf, fmt2, eax, ecx
    ret

example3:
    cinvoke printf, fmt1, [lparam1]
    movzx   ecx, word [lparam1]
    movzx   eax, word [lparam1 + 2]
    cinvoke printf, fmt2, eax, ecx
    ret

example4:
    cinvoke printf, fmt1, [lparam2]
    movsx   ecx, word [lparam2]
    movsx   eax, word [lparam2 + 2]
    cinvoke printf, fmt2, eax, ecx
    ret

start:
    call example1
    call example2
    call example3
    call example4
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
