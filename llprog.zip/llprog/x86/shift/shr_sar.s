format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt db "%x", 10, 0

section '.code' code readable executable
start:
    mov     eax, 0xabcd0000
    shr     eax, 16
    cinvoke printf, fmt, eax

    mov     eax, 0xabcd0000
    sar     eax, 16
    cinvoke printf, fmt, eax

    cinvoke  exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import msvcrt,\
           exit, 'exit',\
           printf, 'printf'
