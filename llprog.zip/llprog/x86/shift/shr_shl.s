format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt db "%d", 10, 0

section '.code' code readable executable
start:
    mov     eax, 10
    shl     eax, 1
    cinvoke printf, fmt, eax

    mov     eax, 40
    shr     eax, 1
    cinvoke printf, fmt, eax

    cinvoke  exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import msvcrt,\
           exit, 'exit',\
           printf, 'printf'
