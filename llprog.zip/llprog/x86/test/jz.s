format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    success        db 'success', 10, 0
    failure        db 'failure', 10, 0

section '.code' code readable executable
start:
    mov     eax, 0 ; failure
    ;mov     eax, 1 ; success
    test    eax, eax
    jz      .error

    cinvoke printf, success
    jmp     .exit

.error:
    cinvoke printf, failure

.exit:
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit, 'exit',\
            printf, 'printf'
