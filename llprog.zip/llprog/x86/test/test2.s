format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    msg1     db 'msg1', 10, 0
    msg2     db 'msg2', 10, 0

section '.text' code readable executable
func1:
    ;mov     eax, 1              ;   msg1
    ;mov     eax, 0              ;   msg2
    mov     eax, -1     ;   msg2
    test    eax, eax
    jle     @f
    cinvoke printf, msg1
    jmp     .end
@@:
    cinvoke printf, msg2
.end:
    ret

start:
    call func1
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
