format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    msg1        db 'msg1', 10, 0
    msg2        db 'msg2', 10, 0

section '.code' code readable executable
; test reg reg
example1:
    mov     eax, 0
    test    eax, eax
    jz      @f
    cinvoke printf, msg1
    jmp     .exit
@@:
    cinvoke printf, msg2
.exit:
    ret

; test reg mem
; test mem reg
example2:
    mov     eax, 1010b
    push    0100b
    ;test    eax, [esp]
    test    [esp], eax
    jz      @f
    cinvoke printf, msg1
    jmp     .exit
@@:
    cinvoke printf, msg2
.exit:
    add     esp, 4
    ret

; test reg imm
example3:
    mov     eax, 1010b
    test    eax, 1100b
    jz      @f
    cinvoke printf, msg1
    jmp     .exit
@@:
    cinvoke printf, msg2
.exit:
    add     esp, 4
    ret

; test mem imm
example:
    push    1100b
    ;test    eax, [esp]
    ;test    byte [esp], 1010b
    test    word [esp], 0xFFFF
    ;test    dword [esp], 0xFFFFFFFF
    jz      @f
    cinvoke printf, msg1
    jmp     .exit
@@:
    cinvoke printf, msg2
.exit:
    add     esp, 4
    ret

start:
    call example
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit, 'exit',\
            printf, 'printf'
