format PE CONSOLE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    szIntro       db 'Comparing eax = -1 (0xFFFFFFFF) and ebx = 1', 10, 0
    szJlTaken     db 'jl jumped: -1 is less than 1 (Signed)', 10, 0
    szJlNotTaken  db 'jl did NOT jump', 10, 0
    szJbTaken     db 'jb jumped: 0xFFFFFFFF is below 1 (Unsigned)', 10, 0
    szJbNotTaken  db 'jb did NOT jump: 0xFFFFFFFF is greater than 1', 10, 0

section '.text' code readable executable
start:
    cinvoke printf, szIntro

    mov     eax, -1
    mov     ebx, 1

    cmp     eax, ebx
    jl      signed_jump

    cinvoke printf, szJlNotTaken
    jmp     test_unsigned

signed_jump:
    cinvoke printf, szJlTaken

test_unsigned:
    mov     eax, -1
    mov     ebx, 1

    cmp     eax, ebx
    jb      unsigned_jump

    cinvoke printf, szJbNotTaken
    jmp     finish

unsigned_jump:
    cinvoke printf, szJbTaken

finish:
    invoke  ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL',\
            msvcrt,   'MSVCRT.DLL'

    import  kernel32,\
            ExitProcess, 'ExitProcess'

    import  msvcrt,\
            printf, 'printf'
