format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    msg_carry       db 'CF = 1', 10, 0
    msg_no_carry    db 'CF = 0', 10, 0

section '.text' code readable executable
start:
    ;mov     eax, 0xFFFFFFFF ; overflow
    mov     eax, 0xFFFFFFFE ; no overflow
    add     eax, 1
    jc      carry_detected  ; Jump if Carry

    cinvoke printf, msg_no_carry
    jmp     exit_program

carry_detected:
    cinvoke printf, msg_carry

exit_program:
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt,     'msvcrt.dll'
    import  msvcrt,\
            exit,       'exit',\
            printf,     'printf'
