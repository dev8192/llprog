format PE console
entry test1

include 'win32a.inc'

section '.data' data readable writeable
    msg1        db 'msg1', 10, 0
    msg2        db 'msg2', 10, 0

section '.text' code readable executable
test1:  mov eax, 5
        cmp eax, 5
        je @f
        cinvoke printf, msg1
        jmp test2
@@:     cinvoke printf, msg2
test2:  mov eax, 5
        sub eax, 5
        jz @f
        cinvoke printf, msg1
        jmp test3
@@:     cinvoke printf, msg2
test3:  mov eax, 5
        cmp eax, 9
        jne @f
        cinvoke printf, msg1
        jmp test4
@@:     cinvoke printf, msg2
test4:  mov eax, 5
        sub eax, 9
        jnz @f
        cinvoke printf, msg1
        jmp done
@@:     cinvoke printf, msg2
done:   invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            msvcrt, 'msvcrt.dll'
    import kernel32,\
           ExitProcess, 'ExitProcess'
    import msvcrt,\
           printf, 'printf'
