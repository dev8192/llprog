format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    msg_jb_jump    db 'jb jumped', 10, 0
    msg_jb_no_jump db 'jb did not jump', 10, 0
    msg_jl_jump    db 'jl jumped', 10, 0
    msg_jl_no_jump db 'jl did not jump', 10, 0
    msg_pause      db 'pause', 0

section '.text' code readable executable
start:
    mov eax, -1
    cmp eax, 1
    jb jb_jumped
    cinvoke printf, msg_jb_no_jump
    jmp jl_test

jb_jumped:
    cinvoke printf, msg_jb_jump

jl_test:
    mov eax, -1
    cmp eax, 1
    jl jl_jumped
    cinvoke printf, msg_jl_no_jump
    jmp finish

jl_jumped:
    cinvoke printf, msg_jl_jump

finish:
    cinvoke system, msg_pause
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
        msvcrt, 'msvcrt.dll'

    import kernel32,\
        ExitProcess, 'ExitProcess'

    import msvcrt,\
        printf, 'printf',\
        system, 'system'
