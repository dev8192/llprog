format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    msg1    db 'aaaaaaaaaa', 0
    msg2    db 'bbbbbbbbbbbbbbbbbbbb', 0
    msg3    db 'cccccccccccccccccccccccccccccc', 0
    fmt     db '%d', 10, 0

section '.text' code readable executable
proc get_strlen str_ptr
    push edi ecx
    
    mov edi, [str_ptr]
    xor al, al
    or  ecx, -1
    cld
    repne scasb
    
    not ecx
    dec ecx
    mov eax, ecx
    
    pop ecx edi
    ret
endp

start:
    stdcall get_strlen, msg1
    cinvoke printf, fmt, eax

    stdcall get_strlen, msg2
    cinvoke printf, fmt, eax
    
    stdcall get_strlen, msg3
    cinvoke printf, fmt, eax

    invoke  ExitProcess, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
