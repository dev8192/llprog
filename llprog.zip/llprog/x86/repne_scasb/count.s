; not working
format PE console
entry start

include 'win32a.inc'

section '.data' data readable writable
    str_data db 'assembly language is amazing!', 0
    target   db 'a'
    count    dd 0
    fmt      db "Character '%c' found %d times.", 10, 0

section '.text' code readable executable
    start:
        mov edi, str_data
        mov al, [target]    ; AL = character to find ('a')
        xor ebx, ebx        ; EBX = our counter, start at 0
        cld                 ; Scan forward

    @@:
        mov ecx, -1         ; Set ECX to max to scan until null or match
        repne scasb         ; Scan for AL. Stops if ZF=1 (found) or ECX=0
        
        jne finished        ; If ZF=0 after scan, no more matches found
        
        inc ebx             ; Found one! Increment counter
        
        ; EDI now points to the byte *after* the match.
        ; Check if the byte we just passed was the end of the string.
        cmp byte [edi-1], 0 
        je finished
        jmp @b

    finished:
        mov [count], ebx
        movzx eax, [target]
        cinvoke printf, fmt, eax, [count]
        
        invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll', \
            msvcrt, 'msvcrt.dll'

    import kernel32, ExitProcess, 'ExitProcess'
    import msvcrt, printf, 'printf'
