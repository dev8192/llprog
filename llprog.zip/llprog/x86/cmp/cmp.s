format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    msg1        db 'msg1', 10, 0
    msg2        db 'msg2', 10, 0

section '.code' code readable executable
example1:
    mov     eax, 1234
    push    123
    cmp     eax, [esp]
    jz      @f
    cinvoke printf, msg1
    jmp     .exit
@@:
    cinvoke printf, msg2
.exit:
    add     esp, 4
    ret

start:
    call example1
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit, 'exit',\
            printf, 'printf'
