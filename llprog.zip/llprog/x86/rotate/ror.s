include 'win32a.inc'

format PE console
entry start

section '.data' data readable writeable
    fmt db '%x', 10, 0

section '.text' code readable executable
start:
    mov     eax, 0x12345678
    cinvoke printf, fmt, eax

    mov     eax, 0x12345678
    ror     eax, 8
    cinvoke printf, fmt, eax

    mov     eax, 0x12345678
    ror     eax, 16
    cinvoke printf, fmt, eax

    mov     eax, 0x12345678
    ror     eax, 24
    cinvoke printf, fmt, eax

    mov     eax, 0x12345678
    ror     eax, 32
    cinvoke printf, fmt, eax

    mov     eax, 0x12345678
    ror     eax, 248 ; wtf?
    cinvoke printf, fmt, eax

    invoke  ExitProcess, 0

section '.idata' import data readable writeable
    library kernel32, 'KERNEL32.DLL',\
        msvcrt, 'MSVCRT.DLL'

    import kernel32,\
        ExitProcess, 'ExitProcess'

    import msvcrt,\
        printf, 'printf'
