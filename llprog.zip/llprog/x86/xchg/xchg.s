format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt     db "eax: %d, ebx: %d", 10, 0

section '.code' code readable executable

start:
    mov eax, 123
    mov ebx, 456
    xchg eax, ebx
    cinvoke printf, fmt, eax, ebx
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'

    import msvcrt,\
           exit, 'exit',\
           printf, 'printf'
