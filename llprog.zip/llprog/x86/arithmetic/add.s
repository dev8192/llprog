format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt  db '%d', 10, 0
    mem1 dd 10
    mem2 dd 20
    mem3 dd 30

section '.text' code readable executable
start:
    ; -------------------- Reg + Imm --------------------
    mov     eax, 5
    add     eax, 5
    cinvoke printf, fmt, eax
    ; -------------------- Reg + Reg --------------------
    mov     ebx, 10
    mov     ecx, 10
    add     ebx, ecx
    cinvoke printf, fmt, ebx
    ; -------------------- Reg + Mem --------------------
    mov     edx, 20
    add     edx, [mem1]
    cinvoke printf, fmt, edx
    ; -------------------- Mem + Imm --------------------
    add     [mem2], 20
    cinvoke printf, fmt, [mem2]
    ; -------------------- Mem + Reg --------------------
    mov     esi, 20
    add     [mem3], esi
    cinvoke printf, fmt, [mem3]

    invoke  ExitProcess, 0

section '.idata' import data readable writeable
    library kernel32, 'KERNEL32.DLL',\
        msvcrt, 'MSVCRT.DLL'

    import kernel32,\
        ExitProcess, 'ExitProcess'

    import msvcrt,\
        printf, 'printf'
