format PE console
entry start

include 'win32a.inc'

; (0x1_00000000 - 0x0_00000001).toString(16)
; ffffffff

section '.data' data readable writeable
    fmt     db 'Result: %X %d', 10, 0
    ;val1 dd 0x00000005
    val1 dd 0x00000000
    val2 dd 0x00000001

section '.code' code readable executable
start:
    mov     eax, [val1]
    sub     eax, [val2]
    cinvoke printf, fmt, eax, eax
    
    invoke  ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            msvcrt, 'msvcrt.dll'

    import  kernel32,\
            ExitProcess, 'ExitProcess'

    import  msvcrt,\
            printf, 'printf'
