format PE console
entry start

include 'win32a.inc'

; 00000005_00000000
; 00000002_00000001
; 00000002_FFFFFFFF
; (0x5_00000000 - 0x2_00000001).toString(16)
; 2ffffffff

section '.data' data readable writeable
    fmt     db 'Result: %08X_%08X', 10, 0
    
    val1_hi dd 0x00000005
    val1_lo dd 0x00000000
    
    val2_hi dd 0x00000002
    val2_lo dd 0x00000001

section '.code' code readable executable
start:
    mov     eax, [val1_lo]
    sub     eax, [val2_lo]
    
    mov     edx, [val1_hi]
    sbb     edx, [val2_hi]
    
    cinvoke printf, fmt, edx, eax
    
    invoke  ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            msvcrt, 'msvcrt.dll'

    import  kernel32,\
            ExitProcess, 'ExitProcess'

    import  msvcrt,\
            printf, 'printf'
