; works!!

format PE console
entry start

include 'win32a.inc'

section '.idata' import data readable writeable

    library kernel32,'kernel32.dll'

    import kernel32,\
        GetStdHandle,'GetStdHandle',\
        WriteConsoleA,'WriteConsoleA',\
        ExitProcess,'ExitProcess'

section '.bss' data readable writeable

    written    dd ?

section '.text' code readable executable

start:
    invoke  GetStdHandle,-11
    mov     ebx,eax

    push    ebp
    mov     ebp,esp
    sub     esp,8

    mov     byte [ebp-8],'h'
    mov     byte [ebp-7],'e'
    mov     byte [ebp-6],'l'
    mov     byte [ebp-5],'l'
    mov     byte [ebp-4],'o'
    mov     byte [ebp-3],10
    mov     byte [ebp-2],0

    lea     eax,[ebp-8]
    invoke  WriteConsoleA,ebx,eax,6,written,0

    mov     esp,ebp
    pop     ebp

    invoke  ExitProcess,0
