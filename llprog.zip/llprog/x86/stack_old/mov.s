format PE console
entry start

include 'win32a.inc'

section '.text' code readable executable
start:
    invoke  GetStdHandle, -11
    
    sub     esp, 16
    mov     byte [esp], 'H'
    mov     byte [esp+1], 'e'
    mov     byte [esp+2], 'l'
    mov     byte [esp+3], 'l'
    mov     byte [esp+4], 'o'
    mov     byte [esp+5], 13
    mov     byte [esp+6], 10
    mov     byte [esp+7], 0

    invoke  WriteConsoleA, eax, esp, 7, 0, 0
    invoke  ExitProcess, 0

section '.idata' import data readable writeable
    library kernel32, 'kernel32.dll'

    import kernel32, \
        ExitProcess,   'ExitProcess', \
        GetStdHandle,  'GetStdHandle', \
        WriteConsoleA, 'WriteConsoleA'
