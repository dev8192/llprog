; works!!!
format PE console
entry start

include 'win32a.inc'

section '.text' code executable
start:
    sub esp, 8
    mov byte [esp+0], 'h'
    mov byte [esp+1], 'e'
    mov byte [esp+2], 'l'
    mov byte [esp+3], 'l'
    mov byte [esp+4], 'o'
    
    mov byte [esp+5], 13    ; Carriage Return (CR)
    mov byte [esp+6], 10    ; Line Feed (LF)
    mov byte [esp+7], 0
    
    ;mov byte [esp+5], 10
    ;mov byte [esp+6], 0

    cinvoke printf, esp
    add esp, 8

    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import msvcrt, printf, 'printf', exit, 'exit'
