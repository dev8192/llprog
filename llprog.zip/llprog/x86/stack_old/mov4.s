; not working
format PE console 4.0
entry start

include 'win32a.inc'

section '.text' code readable executable
start:
    ; 1. Standard handle for STDOUT is -11
    invoke  GetStdHandle, -11
    
    ; Check if handle is valid (not 0 or -1)
    test    eax, eax
    jz      exit_error
    cmp    eax, -1
    je      exit_error
    mov     ebx, eax

    ; 2. Create stack space (16-byte aligned for safety)
    sub     esp, 16
    
    ; 3. Byte-by-byte string (7 chars: Hello\r\n)
    mov     byte [esp+0], 'H'
    mov     byte [esp+1], 'e'
    mov     byte [esp+2], 'l'
    mov     byte [esp+3], 'l'
    mov     byte [esp+4], 'o'
    mov     byte [esp+5], 13
    mov     byte [esp+6], 10

    ; 4. lpNumberOfCharsWritten MUST be a valid pointer
    ; We use esp+8 as a scratch space for this 4-byte variable
    lea     ecx, [esp+8]
    invoke  WriteConsoleA, ebx, esp, 7, ecx, 0

    ; 5. Restore stack before exiting
    add     esp, 16

exit_error:
    invoke  ExitProcess, 0

section '.idata' import data readable writeable
    library kernel32, 'kernel32.dll'

    import kernel32, \
        ExitProcess,   'ExitProcess', \
        GetStdHandle,  'GetStdHandle', \
        WriteConsoleA, 'WriteConsoleA'
