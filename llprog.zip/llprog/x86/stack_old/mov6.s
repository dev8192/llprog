format PE console
entry start

include 'win32a.inc'

section '.idata' import data readable writeable

    library kernel32,'kernel32.dll'

    import kernel32,\
        GetStdHandle,'GetStdHandle',\
        WriteConsoleA,'WriteConsoleA',\
        ExitProcess,'ExitProcess'

section '.bss' data readable writeable

    written    dd ?

section '.text' code readable executable

start:
    invoke  GetStdHandle,-11
    mov     ebx,eax

    sub     esp,8
    mov     byte [esp+0],'h'
    mov     byte [esp+1],'e'
    mov     byte [esp+2],'l'
    mov     byte [esp+3],'l'
    mov     byte [esp+4],'o'
    mov     byte [esp+5],10

    invoke  WriteConsoleA,ebx,esp,6,written,0

    add     esp,8

    invoke  ExitProcess,0
