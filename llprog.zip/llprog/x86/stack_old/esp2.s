; not working
format PE console 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable

    msg_before      db 'before push: ',0
    msg_after_push  db 'after push:  ',0
    msg_after_pop   db 'after pop:   ',0
    newline         db 13,10,0

    array           dd 11111111h,22222222h,33333333h,44444444h

section '.bss' readable writeable

    hOut            dd ?
    buf             db 32 dup(?)
    bytesWritten    dd ?
    saved_esp       dd ?
    tmp_label       dd ?

section '.code' code readable executable

start:
    invoke  GetStdHandle, STD_OUTPUT_HANDLE
    mov     [hOut], eax

    mov     esi, array
    mov     ecx, 4

.loop:
    mov     eax, esp
    mov     [saved_esp], eax
    mov     [tmp_label], msg_before
    call    print_saved

    push    dword [esi]

    mov     eax, esp
    mov     [saved_esp], eax
    mov     [tmp_label], msg_after_push
    call    print_saved

    pop     eax

    mov     eax, esp
    mov     [saved_esp], eax
    mov     [tmp_label], msg_after_pop
    call    print_saved

    add     esi, 4
    loop    .loop

    invoke  ExitProcess, 0

print_saved:
    push    ebx
    push    esi
    push    edi

    mov     eax, [tmp_label]
    call    write_string

    mov     eax, [saved_esp]
    lea     edi, [buf]
    call    dword_to_hex
    lea     eax, [buf]
    call    write_string

    mov     eax, newline
    call    write_string

    pop     edi
    pop     esi
    pop     ebx
    ret

write_string:
    push    eax
    mov     esi, eax
    xor     ecx, ecx
.len:
    cmp     byte [esi+ecx], 0
    je      .got
    inc     ecx
    jmp     .len
.got:
    mov     eax, [hOut]
    push    0
    push    bytesWritten
    push    ecx
    push    esi
    push    eax
    call    [WriteConsoleA]
    add     esp, 20
    pop     eax
    ret

dword_to_hex:
    mov     ebx, eax
    mov     ecx, 8
.hex:
    mov     eax, ebx
    shl     eax, 4
    shr     eax, 28
    cmp     al, 9
    jbe     .dig
    add     al, 'A' - 10
    jmp     .store
.dig:
    add     al, '0'
.store:
    mov     [edi], al
    inc     edi
    loop    .hex
    mov     byte [edi], 0
    ret

section '.idata' import data readable writeable

    library kernel32,'KERNEL32.DLL'

    import  kernel32,\
            GetStdHandle,'GetStdHandle',\
            WriteConsoleA,'WriteConsoleA',\
            ExitProcess,'ExitProcess'
