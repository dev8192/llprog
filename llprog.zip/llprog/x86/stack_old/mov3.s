; not working
format PE console
entry start

include 'win32a.inc'

section '.text' code readable executable
start:
    ; 1. Get the handle
    invoke  GetStdHandle, -11
    mov     ebx, eax

    ; 2. Create space on stack: 8 bytes for "Hello\r\n" + 4 bytes for "written" count
    sub     esp, 12
    
    ; 3. Fill the string (esp+0 to esp+6)
    mov     byte [esp+0], 'H'
    mov     byte [esp+1], 'e'
    mov     byte [esp+2], 'l'
    mov     byte [esp+3], 'l'
    mov     byte [esp+4], 'o'
    mov     byte [esp+5], 13
    mov     byte [esp+6], 10

    ; 4. Call WriteConsoleA
    ; [esp+8] is the address of our 4-byte "written" variable
    lea     ecx, [esp+8]
    invoke  WriteConsoleA, ebx, esp, 7, ecx, 0

    ; 5. CLEAN UP THE STACK
    add     esp, 12

    ; 6. Exit
    invoke  ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll'

    import kernel32, \
        ExitProcess,   'ExitProcess', \
        GetStdHandle,  'GetStdHandle', \
        WriteConsoleA, 'WriteConsoleA'
