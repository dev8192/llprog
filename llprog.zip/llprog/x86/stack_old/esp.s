; not working
format PE console 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable

    before_push     db 'Before push: ',0
    after_push      db 'After push:  ',0
    after_pop       db 'After pop:   ',0
    newline         db 13,10,0

    array           dd 11111111h, 22222222h, 33333333h, 44444444h

section '.bss' readable writeable

    hOut            dd ?
    buf             db 32 dup(?)
    bytesWritten    dd ?
    saved_esp       dd ?
    tmp_label       dd ?

section '.code' code readable executable

start:
    invoke  GetStdHandle, STD_OUTPUT_HANDLE
    mov     [hOut], eax

    mov     esi, array
    mov     ecx, 4

.next_element:
    mov     eax, esp
    mov     [saved_esp], eax
    mov     [tmp_label], before_push
    call    print_saved_esp

    push    [esi]

    mov     eax, esp
    mov     [saved_esp], eax
    mov     [tmp_label], after_push
    call    print_saved_esp

    pop     eax

    mov     eax, esp
    mov     [saved_esp], eax
    mov     [tmp_label], after_pop
    call    print_saved_esp

    add     esi, 4
    loop    .next_element

    invoke  ExitProcess, 0

print_saved_esp:
    push    ebx
    push    esi
    push    edi

    mov     eax, [tmp_label]
    call    write_string

    mov     eax, [saved_esp]
    lea     edi, [buf]
    call    dword_to_hex
    lea     eax, [buf]
    call    write_string

    mov     eax, newline
    call    write_string

    pop     edi
    pop     esi
    pop     ebx
    ret

write_string:
    push    eax
    mov     esi, eax
    xor     ecx, ecx
.wlen:
    cmp     byte [esi+ecx], 0
    je      .gotlen
    inc     ecx
    jmp     .wlen
.gotlen:
    mov     eax, [hOut]
    push    0
    push    bytesWritten
    push    ecx
    push    esi
    push    eax
    call    [WriteConsoleA]
    add     esp, 20
    pop     eax
    ret

dword_to_hex:
    mov     ebx, eax
    mov     ecx, 8
.hex_loop:
    mov     eax, ebx
    shl     eax, 4
    shr     eax, 28
    cmp     al, 9
    jbe     .digit
    add     al, 'A' - 10
    jmp     .store
.digit:
    add     al, '0'
.store:
    mov     [edi], al
    inc     edi
    loop    .hex_loop
    mov     byte [edi], 0
    ret

section '.idata' import data readable writeable

    library kernel32,'KERNEL32.DLL'

    import  kernel32,\
            GetStdHandle,'GetStdHandle',\
            WriteConsoleA,'WriteConsoleA',\
            ExitProcess,'ExitProcess'
