; The stack grows down in memory
; ESP moves constantly and always points to the top of the stack.
; EBP stays fixed inside a function and helps access arguments and locals.


