format PE console
entry start

include 'win32a.inc'

section '.data' data readable
    fmt db 'EFLAGS: %08X', 10, 0

section '.code' executable
example1:
    pushfd
    pop     eax
    cinvoke printf, fmt, eax
    ret

example2:
    pushfd
    push fmt
    call [printf]
    add esp, 8
    ret

start:
    call example2
    invoke  ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll', \
            msvcrt,   'msvcrt.dll'

    import kernel32, \
           ExitProcess, 'ExitProcess'

    import msvcrt, \
           printf, 'printf'
