format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt     db '%d', 10, 0

section '.code' code readable executable
example1:
    push    123
    cinvoke printf, fmt, [esp]
    add     esp, 4
    ret

example2:
    push    123
    push    456
    push    789
    cinvoke printf, fmt, [esp + 8]
    cinvoke printf, fmt, [esp + 4]
    cinvoke printf, fmt, [esp]
    add     esp, 12
    ret

proc example3
    local val1:DWORD, val2:DWORD, val3:DWORD
    mov [val1], 111
    mov [val2], 222
    mov [val3], 333
    cinvoke printf, fmt, [val1]
    cinvoke printf, fmt, [val2]
    cinvoke printf, fmt, [val3]
    ret
endp

start:
    call example3
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit, 'exit',\
            printf, 'printf'
