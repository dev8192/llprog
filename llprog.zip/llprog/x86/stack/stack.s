format PE console
entry start

include 'win32a.inc'

ARRAY_SIZE = 7
section '.data' data readable writeable
    esp_array dd ARRAY_SIZE dup(?)
    fmt       db "Step %d: ESP = 0x%08X", 10, 0

section '.text' code readable executable
start:
    mov     [esp_array], esp

    push    0
    mov     [esp_array + 4], esp

    push    0
    mov     [esp_array + 8], esp

    push    0
    mov     [esp_array + 12], esp

    pop     eax
    mov     [esp_array + 16], esp

    pop     eax
    mov     [esp_array + 20], esp

    pop     eax
    mov     [esp_array + 24], esp

    xor     ebx, ebx

print_loop:
    cmp     ebx, ARRAY_SIZE
    je      end_loop

    mov     eax, [esp_array + ebx * 4]
    cinvoke printf, fmt, ebx, eax

    inc     ebx
    jmp     print_loop

end_loop:
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
