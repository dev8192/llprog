format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt db 'Result: %d', 10, 0

section '.text' code readable executable

proc add_numbers
    enter 4, 0
    mov eax, dword [ebp+8]
    add eax, dword [ebp+12]
    mov dword [ebp-4], eax
    mov eax, dword [ebp-4]
    leave
    ret 8
endp

proc start
    push 15
    push 27
    call add_numbers
    cinvoke printf, fmt, eax
    invoke ExitProcess, 0
endp

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            msvcrt, 'msvcrt.dll'

    import kernel32,\
           ExitProcess, 'ExitProcess'

    import msvcrt,\
           printf, 'printf'
