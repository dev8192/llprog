format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt     db "%x", 10, 0
    num     dd 0xABCD1234

section '.text' code readable executable
start:
    mov eax, [num]
    movzx ebx, ax
    cinvoke printf, fmt, ebx

    mov eax, [num]
    movzx ebx, ah
    cinvoke printf, fmt, ebx
    
    mov eax, [num]
    movzx ebx, al
    cinvoke printf, fmt, ebx

    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
        msvcrt, 'msvcrt.dll'

    import kernel32,\
        ExitProcess, 'ExitProcess'

    import msvcrt,\
        printf, 'printf'
