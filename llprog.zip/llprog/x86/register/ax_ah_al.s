format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt     db "%x", 10, 0
    num     dd 0xABCD1234

section '.code' code readable executable

start:
    mov eax, [num]
    cinvoke printf, fmt, eax

    mov eax, [num]
    mov ah, 0
    cinvoke printf, fmt, eax

    mov eax, [num]
    mov al, 0
    cinvoke printf, fmt, eax

    mov eax, [num]
    mov ax, 0
    cinvoke printf, fmt, eax
    
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
