format PE console
entry start

include 'win32a.inc'

section '.code' executable
start:
    pushfd
    pop     eax

    mov     ebx, eax
    shr     ebx, 0
    and     ebx, 1
    mov     [cf], ebx

    mov     ebx, eax
    shr     ebx, 6
    and     ebx, 1
    mov     [zf], ebx

    mov     ebx, eax
    shr     ebx, 7
    and     ebx, 1
    mov     [sf], ebx

    mov     ebx, eax
    shr     ebx, 11
    and     ebx, 1
    mov     [of], ebx

    cinvoke printf, fmt, eax, [cf], [zf], [sf], [of]
    invoke  ExitProcess, 0

section '.data' data readable writeable
    cf dd 0
    zf dd 0
    sf dd 0
    of dd 0
    fmt db 'EFLAGS: %08X', 10, \
           'CF: %d', 10, \
           'ZF: %d', 10, \
           'SF: %d', 10, \
           'OF: %d', 10, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll', \
            msvcrt,   'msvcrt.dll'

    import kernel32, \
           ExitProcess, 'ExitProcess'

    import msvcrt, \
           printf, 'printf'
