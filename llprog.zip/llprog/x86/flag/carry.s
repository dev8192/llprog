format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt db 'Carry Flag: %d', 10, 0

section '.text' code readable executable
start:
    ;stc            ; Set Carry Flag
    clc             ; Clear Carry Flag
    jc    cf_set
    mov   eax, 0
    jmp   print_val

cf_set:
    mov   eax, 1

print_val:
    cinvoke printf, fmt, eax
    invoke  ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll', \
            msvcrt,   'msvcrt.dll'

    import kernel32, \
           ExitProcess, 'ExitProcess'

    import msvcrt, \
           printf, 'printf'
