format PE console
entry start

include 'win32a.inc'

section '.data' data readable writable
    val     dd 42
    fmt     db '%08x %d', 10, 0

section '.text' code readable executable
    start:
        cinvoke printf, fmt, [val], [val]
        mov eax, [val]
        neg eax
        cinvoke printf, fmt, eax, eax
        cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
