; --- ASCII Case Conversion ---
; OR with 0x20 converts to lowercase. AND with ~0x20 converts to uppercase.
; XOR with 0x20 toggles case.

format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt db "Example 7 (ASCII): 'A'|0x20='%c', 'b'&0xDF='%c', 'C'^0x20='%c'", 10, 0

section '.code' code readable executable

start:
    mov     eax, 'A'
    or      eax, 0x20           ; 'A' to 'a'
    mov     ebx, 'b'
    and     ebx, 0xFFFFFFDF     ; 'b' to 'B'
    mov     ecx, 'C'
    xor     ecx, 0x20           ; 'C' to 'c'
    cinvoke printf, fmt, eax, ebx, ecx

    invoke  ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            msvcrt, 'msvcrt.dll'

    import kernel32,\
           ExitProcess, 'ExitProcess'

    import msvcrt,\
           printf, 'printf'
