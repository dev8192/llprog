; Swap two registers without using a temporary variable.
format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt db "esi = %d, edi = %d", 10, 0

section '.code' code readable executable

start:
    mov     esi, 123
    mov     edi, 456
    cinvoke printf, fmt, esi, edi

    xor     esi, edi
    xor     edi, esi
    xor     esi, edi
    cinvoke printf, fmt, esi, edi

    invoke  ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            msvcrt, 'msvcrt.dll'
    import kernel32,\
           ExitProcess, 'ExitProcess'
    import msvcrt,\
           printf, 'printf'
