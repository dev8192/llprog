format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable

    szEx4 db "Example 4 (Shift): 10 shl 3 = %d, 80 shr 2 = %d", 10, 0

section '.code' code readable executable

start:
    ; --- EXAMPLE 4: Multiply and Divide by Power of 2 ---
    ; SHL multiplies by 2^n, SHR divides unsigned by 2^n.
    mov     eax, 10
    shl     eax, 3              ; 10 * (2^3) = 80
    mov     ebx, 80
    shr     ebx, 2              ; 80 / (2^2) = 20
    cinvoke printf, szEx4, eax, ebx

    invoke  ExitProcess, 0

section '.idata' import data readable

    library kernel32, 'kernel32.dll',\
            msvcrt, 'msvcrt.dll'

    import kernel32,\
           ExitProcess, 'ExitProcess'

    import msvcrt,\
           printf, 'printf'
