format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable

    szEx3 db "Example 3 (Bit Manip): Set=%d, Cleared=%d, Toggled=%d", 10, 0

section '.code' code readable executable

start:

    ; --- EXAMPLE 3: Set, Clear, and Toggle a Bit ---
    ; Set bit 3 (OR), Clear bit 3 (AND NOT), Toggle bit 3 (XOR).
    mov     eax, 0
    or      eax, 8              ; Set bit 3 (value becomes 8)
    mov     ebx, eax
    and     ebx, 0xFFFFFFF7     ; Clear bit 3 (value becomes 0)
    mov     ecx, eax
    xor     ecx, 8              ; Toggle bit 3 (value becomes 0)
    cinvoke printf, szEx3, eax, ebx, ecx

    invoke  ExitProcess, 0

section '.idata' import data readable

    library kernel32, 'kernel32.dll',\
            msvcrt, 'msvcrt.dll'

    import kernel32,\
           ExitProcess, 'ExitProcess'

    import msvcrt,\
           printf, 'printf'
