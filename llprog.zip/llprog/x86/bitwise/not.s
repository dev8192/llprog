format PE console
entry start

include 'win32a.inc'

section '.data' data readable writable
    val     dd 42
    fmt     db '%08x %d', 10, 0

; 1010  A   10
; 1011  B   11
; 1100  C   12
; 1101  D   13
; 1110  E   14
; 1111  F   15

;0000002a    00000000 00000000 00000000 00101010
;ffffffd5    11111111 11111111 11111111 11010101

section '.text' code readable executable
    start:
        cinvoke printf, fmt, [val], [val]
        mov eax, [val]
        not eax
        cinvoke printf, fmt, eax, eax
        cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
