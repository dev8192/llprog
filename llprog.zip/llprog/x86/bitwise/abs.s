format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable

    szEx5 db "Example 5 (Abs Val): abs(-55) = %d", 10, 0

section '.code' code readable executable

start:
    ; --- EXAMPLE 5: Branchless Absolute Value ---
    ; Uses SAR, XOR, and SUB to get the absolute value of a signed integer.
    mov     eax, -55
    mov     ebx, eax
    sar     ebx, 31             ; ebx = 0xFFFFFFFF if negative, 0 if positive
    xor     eax, ebx            ; Invert bits if negative
    sub     eax, ebx            ; Add 1 if negative (two's complement)
    cinvoke printf, szEx5, eax

    invoke  ExitProcess, 0

section '.idata' import data readable

    library kernel32, 'kernel32.dll',\
            msvcrt, 'msvcrt.dll'

    import kernel32,\
           ExitProcess, 'ExitProcess'

    import msvcrt,\
           printf, 'printf'
