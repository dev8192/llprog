format PE CONSOLE 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt_before db 'Before: A = %d, B = %d', 10, 0
    fmt_after  db 'After:  A = %d, B = %d', 10, 0
    val_a      dd 123
    val_b      dd 456

section '.text' code readable executable
start:
    cinvoke printf, fmt_before, [val_a], [val_b]

    mov eax, [val_a]
    mov ebx, [val_b]

    xor eax, ebx
    xor ebx, eax
    xor eax, ebx

    mov [val_a], eax
    mov [val_b], ebx

    cinvoke printf, fmt_after, [val_a], [val_b]

    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL', \
            msvcrt, 'MSVCRT.DLL'

    import kernel32, \
           ExitProcess, 'ExitProcess'

    import msvcrt, \
           printf, 'printf'
