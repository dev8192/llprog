; Even/Odd Check
; Use AND to isolate the least significant bit.
format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt db "%d & 1 = %d (1=odd, 0=even)", 10, 0

section '.code' code readable executable

start:
    mov     eax, 26
    mov     ebx, eax
    and     ebx, 1
    cinvoke printf, fmt, eax, ebx

    mov     eax, 27
    mov     ebx, eax
    and     ebx, 1
    cinvoke printf, fmt, eax, ebx

    invoke  ExitProcess, 0

section '.idata' import data readable

    library kernel32, 'kernel32.dll',\
            msvcrt, 'msvcrt.dll'

    import kernel32,\
           ExitProcess, 'ExitProcess'

    import msvcrt,\
           printf, 'printf'
