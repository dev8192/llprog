format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    szEx6 db "Example 6 (Popcount): Set bits in 29 (11101b) = %d", 10, 0

section '.code' code readable executable

start:

    ; --- EXAMPLE 6: Count Set Bits (Brian Kernighan's Algorithm) ---
    ; Clears the lowest set bit in each iteration using n & (n - 1).
    mov     eax, 29             ; Binary 11101 (4 set bits)
    mov     ecx, 0
.count_loop:
    test    eax, eax
    jz      .count_done
    mov     ebx, eax
    dec     ebx                 ; n - 1
    and     eax, ebx            ; n & (n - 1)
    inc     ecx
    jmp     .count_loop
.count_done:
    cinvoke printf, szEx6, ecx

    invoke  ExitProcess, 0

section '.idata' import data readable

    library kernel32, 'kernel32.dll',\
            msvcrt, 'msvcrt.dll'

    import kernel32,\
           ExitProcess, 'ExitProcess'

    import msvcrt,\
           printf, 'printf'
