include 'win32a.inc'

format PE console
entry start

section '.data' data readable writeable
    fmt db 'Original: 0x%08X', 10
        db 'Swapped:  0x%08X', 10, 0

section '.text' code readable executable
start:
    mov     eax, 0x12345678
    mov     ebx, eax

    xchg    al, ah
    ror     eax, 16
    xchg    al, ah

    cinvoke printf, fmt, ebx, eax

    invoke  ExitProcess, 0

section '.idata' import data readable writeable
    library kernel32, 'KERNEL32.DLL',\
        msvcrt, 'MSVCRT.DLL'

    import kernel32,\
        ExitProcess, 'ExitProcess'

    import msvcrt,\
        printf, 'printf'
