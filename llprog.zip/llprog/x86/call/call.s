format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    msgA        db 'Direct call',13,10,0
    msgB        db 'Indirect call',13,10,0
    FuncPtr     dd FuncB

section '.text' code readable executable
start:
    invoke  GetStdHandle, -11
    mov     [stdout], eax
    call    FuncA
    call    [FuncPtr]
    invoke  ExitProcess, 0

FuncA:
    invoke  WriteConsoleA, [stdout], msgA, 13, 0, 0
    ret

FuncB:
    invoke  WriteConsoleA, [stdout], msgB, 15, 0, 0
    ret

section '.bss' readable writeable
    stdout      dd ?

section '.idata' import data readable writeable
    library kernel32, 'kernel32.dll'

    import kernel32, \
        ExitProcess,   'ExitProcess', \
        GetStdHandle,  'GetStdHandle', \
        WriteConsoleA, 'WriteConsoleA'
