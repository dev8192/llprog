format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt_abs db 'TSC 1: %llu', 10
            db 'TSC 2: %llu', 10, 0
    fmt_dif db 'Diff : %u cycles', 10, 0

section '.bss' readable writeable
    cnt1_lo dd ?
    cnt1_hi dd ?
    cnt2_lo dd ?
    cnt2_hi dd ?
    diff    dd ?

section '.text' code readable executable
start:
    lfence                  ; Serialize CPU pipeline
    rdtsc
    mov [cnt1_lo], eax      ; Save low 32 bits
    mov [cnt1_hi], edx      ; Save high 32 bits

    lfence                  ; Serialize CPU pipeline
    rdtsc
    mov [cnt2_lo], eax
    mov [cnt2_hi], edx

    sub eax, [cnt1_lo]
    mov [diff], eax

    cinvoke printf, fmt_abs, [cnt1_lo], [cnt1_hi], [cnt2_lo], [cnt2_hi]
    cinvoke printf, fmt_dif, [diff]

    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'

    import msvcrt,\
        exit, 'exit',\
        printf, 'printf'
