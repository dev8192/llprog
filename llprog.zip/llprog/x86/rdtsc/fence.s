    xor eax, eax
    cpuid            ; CPU Fence: finish all pending work
    rdtsc
    mov [cnt1], eax
    
    xor eax, eax
    cpuid            ; Fence again
    rdtsc
    mov [cnt2], eax


;rdtscp
