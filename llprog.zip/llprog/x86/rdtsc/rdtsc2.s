format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt      db '%u', 10, 0
    cnt1 dd ?
    cnt2 dd ?
    diff dd ?

section '.text' code readable executable
start:
    rdtsc
    mov [cnt1], eax
    rdtsc
    mov [cnt2], eax
    sub eax, [cnt1]
    mov [diff], eax
    cinvoke printf, fmt, [cnt1]
    cinvoke printf, fmt, [cnt2]
    cinvoke printf, fmt, [diff]
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import msvcrt,\
           exit, 'exit',\
           printf, 'printf'
