format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt      db 'Cycles elapsed: %u', 10, 0
    start_lo dd ?
    start_hi dd ?

section '.text' code readable executable

start:
    ; 1. Get starting cycle count
    rdtsc
    mov [start_lo], eax
    mov [start_hi], edx

    ; 2. Code to measure (a simple loop)
    mov ecx, 1
  .test_loop:
    nop
    loop .test_loop

    ; 3. Get ending cycle count
    rdtsc
    
    ; 4. Calculate difference (Low 32-bits only for simplicity)
    sub eax, [start_lo]
    
    ; 5. Print the result
    cinvoke printf, fmt, eax
    
    ; 6. Exit
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            msvcrt, 'msvcrt.dll'

    import kernel32,\
           ExitProcess, 'ExitProcess'

    import msvcrt,\
           printf, 'printf'
