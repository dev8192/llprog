format PE64 console
entry start

include 'win64ax.inc'

section '.data' readable writeable
    ; Резервируем 64 байта для буфера (заполнены нулями по умолчанию)
    buffer rb 64
    db 0 ; Нуль-терминатор для корректного вывода строки

section '.code' readable executable

start:
    ; 1. Подготовка параметров для заполнения
    mov al, 'A'          ; Символ для заполнения
    lea rdi, [buffer]    ; Адрес начала буфера в RDI
    mov rcx, 64          ; Количество байт (счетчик в RCX)
    
    ; 2. Сброс флага направления (DF=0)
    ; Это гарантирует, что RDI будет увеличиваться (вперед)
    cld
    
    ; 3. Выполнение операции
    ; Записывает AL в [RDI], делает RDI+1, уменьшает RCX. Повторяет, пока RCX > 0.
    rep stosb

    ; 4. Вывод результата в консоль для проверки
    invoke  GetStdHandle, STD_OUTPUT_HANDLE
    mov     rcx, rax     ; Handle
    lea     rdx, [buffer]; Строка
    mov     r8, 64       ; Длина
    xor     r9, r9       ; lpNumberOfBytesWritten (необязательно)
    push    0            ; lpOverlapped
    sub     rsp, 32      ; Shadow space для Windows x64 ABI
    call    [WriteFile]
    add     rsp, 32 + 8  ; Очистка стека (Shadow space + push)

    ; Выход
    invoke  ExitProcess, 0

section '.idata' import readable
    library kernel32, 'kernel32.dll'
    import kernel32, \
           GetStdHandle, 'GetStdHandle', \
           WriteFile, 'WriteFile', \
           ExitProcess, 'ExitProcess'
