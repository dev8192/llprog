format PE console
entry start

include 'win32a.inc'

section '.data' readable writeable
    ;buffer db 64 dup(0)
    buffer db 64 dup('#')
    count  dd 0

section '.code' readable executable

start:
    mov al, '!'
    mov edi, buffer
    mov ecx, 64
    cld
    rep stosb

    invoke GetStdHandle, STD_OUTPUT_HANDLE
    invoke WriteFile, eax, buffer, 64, count, 0

    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32,'KERNEL32.DLL'
    import kernel32,\
           GetStdHandle,'GetStdHandle',\
           WriteFile,'WriteFile',\
           ExitProcess,'ExitProcess'
