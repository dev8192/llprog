format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt1      db "%d / %d = %d", 10, 0
    fmt2      db "%d %% %d = %d", 10, 0
    dividend  dd 100
    divisor   dd 3
    quotient  dd ?
    remainder dd ?

section '.code' code readable executable

start:
    xor edx, edx
    mov eax, [dividend]
    mov ecx, [divisor]

    div ecx

    mov [quotient], eax
    mov [remainder], edx

    cinvoke printf, fmt1, [dividend], [divisor], [quotient]
    cinvoke printf, fmt2, [dividend], [divisor], [remainder]

    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'

    import msvcrt,\
           exit, 'exit',\
           printf, 'printf'
