format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt     db "quotient: %d, remainder: %d", 10, 0

section '.code' code readable executable

start:
    ;xor edx, edx
    mov edx, 0      ; high 32 bits of 64-bit dividend
    mov eax, 100    ; low 32 bits of 64-bit dividend
    mov ecx, 3      ; divisor

    ; edx:eax / ecx = eax (quotient)
    ; edx:eax % ecx = edx (remainder)
    div ecx

    cinvoke printf, fmt, eax, edx

    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'

    import msvcrt,\
           exit, 'exit',\
           printf, 'printf'
