format PE CONSOLE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    data_array db 0x11, 0x22, 0x33, 0x44

    fmt_out  db "%s: EAX = 0x%08X, ESI advanced by %d bytes", 10, 0

    str_b    db "lodsb", 0
    str_w    db "lodsw", 0
    str_d    db "lodsd", 0

section '.code' code readable executable
start:
    cld

    mov     esi, data_array
    xor     eax, eax        ; Clear EAX so we only see the newly loaded byte
    lodsb                   ; Loads 1 byte into AL, increments ESI by 1
    mov     edx, esi
    sub     edx, data_array ; Calculate how many bytes ESI advanced
    cinvoke printf, fmt_out, str_b, eax, edx

    mov     esi, data_array
    xor     eax, eax
    lodsw                   ; Loads 2 bytes into AX, increments ESI by 2
    mov     edx, esi
    sub     edx, data_array
    cinvoke printf, fmt_out, str_w, eax, edx

    mov     esi, data_array
    xor     eax, eax
    lodsd                   ; Loads 4 bytes into EAX, increments ESI by 4
    mov     edx, esi
    sub     edx, data_array
    cinvoke printf, fmt_out, str_d, eax, edx

    cinvoke getchar
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            printf, 'printf',\
            exit,   'exit'
