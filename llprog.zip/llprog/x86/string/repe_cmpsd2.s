format PE CONSOLE 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    array1   dd 100, 200, 800, 400
    array2   dd 100, 200, 300, 400
    msg_diff db 'Difference found at index: %d', 10, 0
    msg_same db 'Arrays are identical.', 10, 0

section '.code' code readable executable
    start:
        cld
        mov esi, array1
        mov edi, array2
        mov ecx, 4

        repe cmpsd
        je .equal

    .not_equal:
        sub esi, array1
        sub esi, 4
        shr esi, 2
        cinvoke printf, msg_diff, esi
        jmp .exit

    .equal:
        cinvoke printf, msg_same

    .exit:
        cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'

    import msvcrt,\
           printf, 'printf',\
           exit,   'exit'
