format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    msg db 'FASM', 0
    fmt db 'Loaded character: %c', 10, 0

section '.text' code readable executable
start:
    ;cld
    mov esi, msg

process_loop:
    lodsb
    test al, al
    jz finished
    
    movzx eax, al
    cinvoke printf, fmt, eax
    jmp process_loop

finished:
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import msvcrt, \
        printf, 'printf', \
        exit, 'exit'
