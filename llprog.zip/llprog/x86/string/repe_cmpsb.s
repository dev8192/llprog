format PE CONSOLE 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    str1    db 'aaaaaaaaaa', 0
    str2    db 'aaaaaaaaab', 0
    msg_yes db 'Strings match: %d', 10, 0
    msg_no  db 'Strings do not match: %d', 10, 0

section '.text' code readable executable
start:
    cld
    mov esi, str1
    mov edi, str2
    mov ecx, 10
    repe cmpsb
    je .match
    
.no_match:
    cinvoke printf, msg_no, ecx
    jmp .exit

.match:
    cinvoke printf, msg_yes, ecx

.exit:
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'

    import msvcrt,\
           printf, 'printf',\
           exit,   'exit'
