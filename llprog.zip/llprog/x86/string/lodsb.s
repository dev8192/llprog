include 'win32a.inc'

format PE console
entry start

section '.data' data readable writeable
    string db 'AB'
    fmt    db '%d %d', 10, 0

section '.text' code readable executable
start:
    mov     esi, string
    xor     eax, eax
    lodsb
    mov     ebx, eax
    lodsb
    cinvoke printf, fmt, ebx, eax

    mov     esi, string + 1
    std
    xor     eax, eax
    lodsb
    mov     ebx, eax
    lodsb
    cld
    cinvoke printf, fmt, ebx, eax

    invoke  ExitProcess, 0

section '.idata' import data readable writeable
    library kernel32, 'KERNEL32.DLL',\
        msvcrt, 'MSVCRT.DLL'

    import kernel32,\
        ExitProcess, 'ExitProcess'

    import msvcrt,\
        printf, 'printf'
