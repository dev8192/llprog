; garbage
format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    sample_data db 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88
    msg_lodsb db 10, 13, 'LODSB - Load byte:', 10, 13, 0
    msg_lodsw db 10, 13, 'LODSW - Load word:', 10, 13, 0
    msg_lodsd db 10, 13, 'LODSD - Load doubleword:', 10, 13, 0
    msg_al db 'AL = 0x%02X', 10, 13, 0
    msg_ax db 'AX = 0x%04X', 10, 13, 0
    msg_eax db 'EAX = 0x%08X', 10, 13, 0
    msg_esi db 'ESI moved by %d bytes', 10, 13, 0

section '.code' code readable executable
start:
    mov esi, sample_data
    push esi
    
    invoke printf, msg_lodsb
    pop esi
    push esi
    lodsb
    push eax
    invoke printf, msg_al
    pop eax
    
    ; Show ESI movement
    pop esi
    push esi
    sub esi, sample_data
    push esi
    invoke printf, msg_esi
    pop esi
    pop esi
    
    ; Demonstrate LODSW
    invoke printf, msg_lodsw
    mov esi, sample_data
    push esi
    lodsw
    push eax
    invoke printf, msg_ax
    pop eax
    
    ; Show ESI movement
    pop esi
    sub esi, sample_data
    push esi
    invoke printf, msg_esi
    pop esi
    
    ; Demonstrate LODSD
    invoke printf, msg_lodsd
    mov esi, sample_data
    push esi
    lodsd
    push eax
    invoke printf, msg_eax
    pop eax
    
    ; Show ESI movement
    pop esi
    sub esi, sample_data
    push esi
    invoke printf, msg_esi
    pop esi
    
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll', \
            msvcrt, 'msvcrt.dll'
    
    import kernel32, \
           ExitProcess, 'ExitProcess'
    
    import msvcrt, \
           printf, 'printf'
