format PE CONSOLE 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    array1  dd 100, 200, 300, 400
    array2  dd 100, 200, 300, 400
    msg_ok  db 'Arrays are identical.', 10, 0
    msg_err db 'Arrays differ!', 10, 0

section '.text' code readable executable
start:
    cld
    mov esi, array1
    mov edi, array2
    mov ecx, 4
    repe cmpsd
    je .equal

.not_equal:
    cinvoke printf, msg_err
    jmp .exit

.equal:
    cinvoke printf, msg_ok

.exit:
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'

    import msvcrt,\
           printf, 'printf',\
           exit,   'exit'
