format PE64 console
entry start

include 'win64ax.inc'

section '.data' readable writeable
    hello        db 'Hello World!', 0
    hello_len    = $ - hello
    bytes_written dq ?

section '.text' code readable executable

start:
    mov rcx, -11
    call [GetStdHandle]
    mov rbx, rax

    sub rsp, 48
    mov rcx, rbx
    lea rdx, [hello]
    mov r8d, hello_len
    lea r9, [bytes_written]
    mov qword [rsp+32], 0
    call [WriteFile]
    add rsp, 48

    mov ecx, 0
    call [ExitProcess]

section '.idata' import data readable
    library kernel32, 'kernel32.dll'
    import kernel32,\
           GetStdHandle, 'GetStdHandle',\
           WriteFile, 'WriteFile',\
           ExitProcess, 'ExitProcess'
