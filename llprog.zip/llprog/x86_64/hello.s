format PE64 console
entry start

include 'win64ax.inc'

section '.data' readable writeable
    hello        db 'Hello World!', 0
    hello_len    = $ - hello
    bytes_written dq ?

section '.text' code readable executable
start:
    ; 1. Get the Handle for Standard Output (the terminal)
    ; STD_OUTPUT_HANDLE = -11
    mov rcx, -11
    call [GetStdHandle]
    mov rbx, rax ; Store handle in rbx

    ; 2. WriteFile(handle, buffer, len, &written, overlap)
    sub rsp, 40             ; Shadow space for Win64 calling convention
    mov rcx, rbx            ; Argument 1: Handle
    lea rdx, [hello]        ; Argument 2: Pointer to string
    mov r8d, hello_len      ; Argument 3: Length of string
    lea r9, [bytes_written] ; Argument 4: Pointer to written count
    mov qword [rsp+32], 0   ; Argument 5: Overlapped (must be on stack)
    call [WriteFile]
    add rsp, 40             ; Clean up shadow space
    mov rcx, 0
    call [ExitProcess]

section '.idata' import data readable
    library kernel32, 'kernel32.dll'

    import kernel32,\
           GetStdHandle, 'GetStdHandle',\
           WriteFile, 'WriteFile',\
           ExitProcess, 'ExitProcess'
