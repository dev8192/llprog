format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    szTitle   db 'FASM TaskDialog', 0
    szHeader  db 'Success!', 0
    szContent db 'The program is now using Comctl32.dll version 6.0.', 0

section '.code' code readable executable
    start:
        ; TaskDialog parameters: HWND, HINSTANCE, Title, MainInstruction, Content, Buttons, Icon, OutButton
        invoke TaskDialog, \
               NULL, \
               NULL, \
               szTitle, \
               szHeader, \
               szContent, \
               1, \          ; TDCBF_OK_BUTTON
               8, \          ; TD_INFORMATION_ICON
               NULL
        
        invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll', \
            comctl32, 'comctl32.dll'

    import kernel32, \
           ExitProcess, 'ExitProcess'

    import comctl32, \
           TaskDialog, 'TaskDialog'

section '.rsrc' resource data readable
    directory RT_MANIFEST, manifests

    resource manifests, 1, LANG_NEUTRAL, manifest_res

    resdata manifest_res
        db '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        db '<assembly xmlns="urn:schemas-microsoft-com:asm.v1" manifestVersion="1.0">'
        db '<dependency>'
        db '<dependentAssembly>'
        db ''
        db '</dependentAssembly>'
        db '</dependency>'
        db '</assembly>'
    endres
