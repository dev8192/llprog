format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    szTitle   db 'FASM TaskDialog', 0
    szHeader  db 'Greetings from TaskDialog!', 0
    szContent db 'This is an example of using the modern TaskDialog API '
              db 'instead of the standard MessageBox.', 0

section '.code' code readable executable
  start:
    invoke TaskDialog, \
           NULL, \
           NULL, \
           szTitle, \
           szHeader, \
           szContent, \
           1, \          ; TDCBF_OK_BUTTON
           8, \          ; TD_INFORMATION_ICON
           NULL
    
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll', \
            comctl32, 'comctl32.dll'

    import kernel32, \
           ExitProcess, 'ExitProcess'

    import comctl32, \
           TaskDialog, 'TaskDialog'
