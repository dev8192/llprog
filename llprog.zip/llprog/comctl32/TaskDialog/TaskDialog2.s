format PE GUI 4.0 DLL
entry DllEntryPoint

include 'win32a.inc'

section '.code' code readable executable

proc DllEntryPoint hinstDLL, fdwReason, lpvReserved
    cmp [fdwReason], DLL_PROCESS_ATTACH
    jne .success

    ; TaskDialog is silent by default
    ; Parameters: HWND, HINSTANCE, Title, MainInstruction, Content, Buttons, Icon, OutButton
    invoke TaskDialog, 0, [hinstDLL], "Silent DLL", "Initialization Successful", \
                       "The buffer has been filled with 'Hello'.", TDCBF_OK_BUTTON, \
                       TD_INFORMATION_ICON, 0

.success:
    mov eax, TRUE
    ret
endp

section '.idata' import data readable
    library comctl32, 'comctl32.dll'
    import comctl32, TaskDialog, 'TaskDialog'
