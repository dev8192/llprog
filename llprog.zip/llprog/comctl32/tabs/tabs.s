format PE GUI 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    wc              WNDCLASS
    msg             MSG
    icex            INITCOMMONCONTROLSEX
    tci             TC_ITEM

    hInst           dd ?
    hwnd            dd ?
    htab            dd ?

    clsName         db 'ChromeTabClass', 0
    winTitle        db 'Browser', 0
    tabClass        db 'SysTabControl32', 0

    tab1            db 'New Tab', 0
    tab2            db 'Reddit', 0
    tab3            db 'YouTube', 0

section '.text' code readable executable
start:
    invoke  GetModuleHandleA, 0
    mov     [hInst], eax
    ;mov     [wc.style], CS_HREDRAW or CS_VREDRAW
    mov     [wc.lpfnWndProc], WindowProc
    mov     [wc.hInstance], eax
    invoke  LoadCursor, 0, IDC_ARROW
    mov     [wc.hCursor],eax
    mov     [wc.hbrBackground], COLOR_WINDOW + 1
    mov     [wc.lpszClassName], clsName
    invoke  RegisterClassA, wc

    invoke  CreateWindowExA, 0, clsName, winTitle, WS_VISIBLE or WS_OVERLAPPEDWINDOW,\
        CW_USEDEFAULT, CW_USEDEFAULT, 800, 600, 0, 0, [hInst], 0
    mov     [hwnd], eax

msg_loop:
    invoke  GetMessageA, msg, 0, 0, 0
    test    eax, eax
    jz      end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessageA, msg
    jmp     msg_loop

end_loop:
    invoke  ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp     [wmsg], WM_CREATE
    je      .wm_create
    cmp     [wmsg], WM_SIZE
    je      .wm_size
    cmp     [wmsg], WM_DESTROY
    je      .wm_destroy
    invoke  DefWindowProcA, [hwnd], [wmsg], [wparam], [lparam]
    ret

.wm_create:
    mov     [icex.dwSize], 8
    mov     [icex.dwICC], ICC_TAB_CLASSES
    invoke  InitCommonControlsEx, icex

    invoke  CreateWindowExA, 0, tabClass, 0, WS_CHILD or WS_VISIBLE or WS_CLIPSIBLINGS,\
        0, 0, 0, 0, [hwnd], 100, [hInst], 0
    mov     [htab], eax

    mov     [tci.mask], TCIF_TEXT

    mov     [tci.pszText], tab1
    invoke  SendMessageA, [htab], TCM_INSERTITEMA, 0, tci

    mov     [tci.pszText], tab2
    invoke  SendMessageA, [htab], TCM_INSERTITEMA, 1, tci

    mov     [tci.pszText], tab3
    invoke  SendMessageA, [htab], TCM_INSERTITEMA, 2, tci
    xor     eax, eax
    ret

.wm_size:
    mov     eax, [lparam]
    movzx   ecx, ax
    shr     eax, 16
    invoke  MoveWindow, [htab], 0, 0, ecx, eax, 1
    xor     eax, eax
    ret

.wm_destroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
    ret
endp

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL',\
            user32, 'USER32.DLL',\
            comctl32, 'COMCTL32.DLL'

    import  kernel32,\
            GetModuleHandleA, 'GetModuleHandleA',\
            ExitProcess, 'ExitProcess'

    import  user32,\
            RegisterClassA, 'RegisterClassA',\
            CreateWindowExA, 'CreateWindowExA',\
            GetMessageA, 'GetMessageA',\
            TranslateMessage, 'TranslateMessage',\
            DispatchMessageA, 'DispatchMessageA',\
            DefWindowProcA, 'DefWindowProcA',\
            SendMessageA, 'SendMessageA',\
            LoadCursor, 'LoadCursorA',\
            MoveWindow, 'MoveWindow',\
            PostQuitMessage, 'PostQuitMessage'

    import  comctl32,\
            InitCommonControlsEx, 'InitCommonControlsEx'
