; probably broken
format PE console
entry start

include 'win32a.inc'

tvins_hParent      equ tvins + 0
tvins_hInsertAfter equ tvins + 4
tvins_mask         equ tvins + 8
tvins_pszText      equ tvins + 24

section '.data' data readable writeable
    wc WNDCLASS
    msg MSG
    hwndMain dd ?
    hwndTV dd ?
    hInstance dd ?

    tvins rb 48
    parents dd 256 dup(?)

    className db 'FasmHierView', 0
    tvClass db 'SysTreeView32', 0
    fileName db 'comctl32\tree_view\files.txt', 0
    fmt db 'Clicked at X: %d, Y: %d', 10, 0

    bytes_read dd ?
    read_buf rb 65536

section '.code' code readable executable
start:
    invoke GetModuleHandle, 0
    mov [hInstance], eax

    invoke InitCommonControls

    mov [wc.style], CS_HREDRAW or CS_VREDRAW
    mov [wc.lpfnWndProc], WndProc
    mov [wc.cbClsExtra], 0
    mov [wc.cbWndExtra], 0
    mov eax, [hInstance]
    mov [wc.hInstance], eax
    invoke LoadIcon, 0, IDI_APPLICATION
    mov [wc.hIcon], eax
    invoke LoadCursor, 0, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.hbrBackground], COLOR_WINDOW + 1
    mov [wc.lpszMenuName], 0
    mov [wc.lpszClassName], className
    invoke RegisterClass, wc

    invoke CreateWindowEx, 0, className, 'Hierarchy View', \
           WS_VISIBLE or WS_OVERLAPPEDWINDOW, \
           CW_USEDEFAULT, CW_USEDEFAULT, 600, 500, \
           0, 0, [hInstance], 0
    mov [hwndMain], eax

msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    cmp eax, 0
    je end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp msg_loop

end_loop:
    invoke ExitProcess, [msg.wParam]

proc WndProc hwnd, wmsg, wparam, lparam
    cmp [wmsg], WM_CREATE
    je .wm_create
    cmp [wmsg], WM_LBUTTONDOWN
    je .wm_lbuttondown
    cmp [wmsg], WM_SIZE
    je .wm_size
    cmp [wmsg], WM_DESTROY
    je .wm_destroy
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    jmp .finish

.wm_create:
    invoke CreateWindowEx, 0, tvClass, 0, \
           WS_CHILD or WS_VISIBLE or WS_BORDER or 0x0007, \
           0, 0, 300, 500, \
           [hwnd], 0, [hInstance], 0
    mov [hwndTV], eax

    stdcall LoadData
    xor eax, eax
    jmp .finish

.wm_size:
    mov eax, [lparam]
    and eax, 0FFFFh
    shr eax, 1
    mov ebx, [lparam]
    shr ebx, 16
    invoke SetWindowPos, [hwndTV], 0, 0, 0, eax, ebx, 0x0004 or 0x0002
    xor eax, eax
    jmp .finish

.wm_lbuttondown:
    mov eax, [lparam]
    mov ebx, eax
    and eax, 0FFFFh
    shr ebx, 16
    cinvoke printf, fmt, eax, ebx
    xor eax, eax
    jmp .finish

.wm_destroy:
    invoke PostQuitMessage, 0
    xor eax, eax

.finish:
    ret
endp

proc LoadData
    invoke CreateFile, fileName, GENERIC_READ, FILE_SHARE_READ, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0
    cmp eax, INVALID_HANDLE_VALUE
    je .done
    mov ebx, eax

    invoke ReadFile, ebx, read_buf, 65535, bytes_read, 0
    invoke CloseHandle, ebx

    mov ecx, [bytes_read]
    test ecx, ecx
    jz .done

    mov esi, read_buf
    mov byte [esi + ecx], 0
    mov dword [parents], 0xFFFF0000

.parse_loop:
    cmp ecx, 0
    jle .done
    xor edi, edi

.count_spaces:
    cmp byte [esi], ' '
    jne .calc_depth
    inc edi
    inc esi
    dec ecx
    jmp .count_spaces

.calc_depth:
    shr edi, 2
    cmp edi, 255
    jl .depth_ok
    mov edi, 255
.depth_ok:
    mov ebx, esi

.find_eol:
    cmp ecx, 0
    jle .eol_found
    cmp byte [esi], 13
    je .eol_found
    cmp byte [esi], 10
    je .eol_found
    inc esi
    dec ecx
    jmp .find_eol

.eol_found:
    mov byte [esi], 0
    cmp ecx, 0
    jle .do_insert
    inc esi
    dec ecx

.skip_crlf:
    cmp ecx, 0
    jle .do_insert
    cmp byte [esi], 13
    je .do_skip
    cmp byte [esi], 10
    je .do_skip
    jmp .do_insert

.do_skip:
    inc esi
    dec ecx
    jmp .skip_crlf

.do_insert:
    cmp byte [ebx], 0
    je .parse_loop

    push ecx
    push esi

    mov eax, [parents + edi * 4]
    mov dword [tvins_hParent], eax
    mov dword [tvins_hInsertAfter], 0xFFFF0002
    mov dword [tvins_mask], 1
    mov dword [tvins_pszText], ebx

    invoke SendMessage, [hwndTV], 0x1100, 0, tvins
    mov dword [parents + edi * 4 + 4], eax

    pop esi
    pop ecx
    jmp .parse_loop

.done:
    ret
endp

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL',\
            user32, 'USER32.DLL',\
            comctl32, 'COMCTL32.DLL',\
            msvcrt, 'MSVCRT.DLL'

    import kernel32,\
           GetModuleHandle, 'GetModuleHandleA',\
           CreateFile, 'CreateFileA',\
           ReadFile, 'ReadFile',\
           CloseHandle, 'CloseHandle',\
           ExitProcess, 'ExitProcess'

    import user32,\
           RegisterClass, 'RegisterClassA',\
           CreateWindowEx, 'CreateWindowExA',\
           DefWindowProc, 'DefWindowProcA',\
           GetMessage, 'GetMessageA',\
           TranslateMessage, 'TranslateMessage',\
           DispatchMessage, 'DispatchMessageA',\
           LoadCursor, 'LoadCursorA',\
           LoadIcon, 'LoadIconA',\
           PostQuitMessage, 'PostQuitMessage',\
           SendMessage, 'SendMessageA',\
           SetWindowPos, 'SetWindowPos'

    import comctl32,\
           InitCommonControls, 'InitCommonControls'

    import msvcrt,\
           printf, 'printf'
