format PE console 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    className       db 'TreeViewTestClass', 0
    windowTitle     db 'Hierarchy Viewer', 0
    tvClassName     db 'SysTreeView32', 0
    filename        db 'comctl32/tree_view/files.txt', 0
    err_msg         db 'Error: Could not read tree.txt from the current directory.', 10, 0

    hInstance       dd ?
    hwnd            dd ?
    hTreeView       dd ?
    hMem            dd ?
    fileSize        dd ?
    bytesRead       dd ?
    current_depth   dd ?

    wc              WNDCLASSEX
    msg             MSG
    icex            INITCOMMONCONTROLSEX
    tvinsert        TV_INSERTSTRUCT

    parents         rd 256

section '.text' code readable executable

start:
    mov     [icex.dwSize], sizeof.INITCOMMONCONTROLSEX
    mov     [icex.dwICC], 2
    invoke  InitCommonControlsEx, icex

    invoke  GetModuleHandleA, 0
    mov     [hInstance], eax

    mov     [wc.cbSize], sizeof.WNDCLASSEX
    mov     [wc.style], CS_HREDRAW or CS_VREDRAW
    mov     [wc.lpfnWndProc], WindowProc
    mov     [wc.cbClsExtra], 0
    mov     [wc.cbWndExtra], 0
    mov     eax, [hInstance]
    mov     [wc.hInstance], eax
    mov     [wc.hIcon], 0
    mov     [wc.hCursor], 0
    mov     [wc.hbrBackground], COLOR_WINDOW+1
    mov     [wc.lpszMenuName], 0
    mov     [wc.lpszClassName], className
    mov     [wc.hIconSm], 0
    invoke  RegisterClassExA, wc

    invoke  CreateWindowExA, 0, className, windowTitle, WS_OVERLAPPEDWINDOW,\
            CW_USEDEFAULT, CW_USEDEFAULT, 400, 500, 0, 0, [hInstance], 0
    mov     [hwnd], eax

    invoke  CreateWindowExA, 0, tvClassName, 0, 0x50800007,\
            0, 0, 0, 0, [hwnd], 0, [hInstance], 0
    mov     [hTreeView], eax

    invoke  ShowWindow, [hwnd], SW_SHOWDEFAULT

    invoke  CreateFileA, filename, GENERIC_READ, FILE_SHARE_READ, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0
    cmp     eax, INVALID_HANDLE_VALUE
    je      .file_error

    mov     ebx, eax
    invoke  GetFileSize, ebx, 0
    mov     [fileSize], eax

    mov     ecx, eax
    inc     ecx
    invoke  VirtualAlloc, 0, ecx, MEM_COMMIT or MEM_RESERVE, PAGE_READWRITE
    mov     [hMem], eax

    invoke  ReadFile, ebx, [hMem], [fileSize], bytesRead, 0
    invoke  CloseHandle, ebx

    mov     esi, [hMem]
    mov     edi, esi
    add     edi, [fileSize]

.parse_line:
    cmp     esi, edi
    jge     .parse_done

    xor     ecx, ecx
.count_spaces:
    cmp     esi, edi
    jge     .line_end
    cmp     byte [esi], ' '
    jne     .spaces_done
    inc     ecx
    inc     esi
    jmp     .count_spaces
.spaces_done:

    cmp     byte [esi], 13
    je      .skip_empty
    cmp     byte [esi], 10
    je      .skip_empty

    shr     ecx, 2
    mov     [current_depth], ecx

    mov     edx, esi
.find_eol:
    cmp     esi, edi
    jge     .eol_found
    cmp     byte [esi], 13
    je      .eol_found
    cmp     byte [esi], 10
    je      .eol_found
    inc     esi
    jmp     .find_eol
.eol_found:
    mov     al, [esi]
    push    eax
    mov     byte [esi], 0

    mov     ecx, [current_depth]
    test    ecx, ecx
    je      .is_root
    mov     eax, [parents + ecx*4 - 4]
    jmp     .set_parent
.is_root:
    mov     eax, 0xFFFF0000
.set_parent:
    mov     [tvinsert.hParent], eax
    mov     [tvinsert.hInsertAfter], 0xFFFF0002
    mov     [tvinsert.item.mask], 1
    mov     [tvinsert.item.pszText], edx
    invoke  SendMessageA, [hTreeView], 0x1100, 0, tvinsert
    
    mov     ecx, [current_depth]
    mov     [parents + ecx*4], eax

    pop     eax
    mov     byte [esi], al

.skip_empty:
.skip_crlf_loop:
    cmp     esi, edi
    jge     .parse_done
    cmp     byte [esi], 13
    je      .do_skip
    cmp     byte [esi], 10
    je      .do_skip
    jmp     .parse_line
.do_skip:
    inc     esi
    jmp     .skip_crlf_loop

.line_end:
    jmp     .parse_done

.parse_done:
    invoke  VirtualFree, [hMem], 0, MEM_RELEASE
    jmp     .msg_loop

.file_error:
    cinvoke printf, err_msg

.msg_loop:
    invoke  GetMessageA, msg, 0, 0, 0
    test    eax, eax
    je      .end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessageA, msg
    jmp     .msg_loop

.end_loop:
    invoke  ExitProcess, 0

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp     [wmsg], WM_SIZE
    je      .wmsize
    cmp     [wmsg], WM_DESTROY
    je      .wmdestroy
    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret

.wmsize:
    movzx   eax, word [lparam]
    movzx   ecx, word [lparam+2]
    invoke  MoveWindow, [hTreeView], 0, 0, eax, ecx, 1
    xor     eax, eax
    ret

.wmdestroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
    ret
endp

section '.idata' import data readable
    library kernel32,               'KERNEL32.DLL',\
            user32,                 'USER32.DLL',\
            comctl32,               'COMCTL32.DLL',\
            msvcrt,                 'MSVCRT.DLL'
    import kernel32,\
            GetModuleHandleA,       'GetModuleHandleA',\
            ExitProcess,            'ExitProcess',\
            CreateFileA,            'CreateFileA',\
            GetFileSize,            'GetFileSize',\
            ReadFile,               'ReadFile',\
            CloseHandle,            'CloseHandle',\
            VirtualAlloc,           'VirtualAlloc',\
            VirtualFree,            'VirtualFree'
    import user32,\
            RegisterClassExA,       'RegisterClassExA',\
            CreateWindowExA,        'CreateWindowExA',\
            DefWindowProc,          'DefWindowProcA',\
            GetMessageA,            'GetMessageA',\
            TranslateMessage,       'TranslateMessage',\
            DispatchMessageA,       'DispatchMessageA',\
            ShowWindow,             'ShowWindow',\
            PostQuitMessage,        'PostQuitMessage',\
            MoveWindow,             'MoveWindow',\
            SendMessageA,           'SendMessageA'
    import comctl32,\
            InitCommonControlsEx,   'InitCommonControlsEx'
    import msvcrt,\
            printf,                 'printf'
