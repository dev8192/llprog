format PE GUI 4.0
entry start

include 'win32a.inc'
include 'equates/kernel32.inc'
include 'equates/user32.inc'
include 'equates/comctl32.inc'

section '.data' data readable writeable

    wc          WNDCLASS
    msg         MSG
    icex        INITCOMMONCONTROLSEX
    tvis        TV_INSERTSTRUCT

    hInst       dd ?
    hwnd        dd ?
    hTree       dd ?
    hRoot       dd ?

    clsName     db 'TreeWindowClass', 0
    winTitle    db 'Tree View Example', 0
    treeClass   db 'SysTreeView32', 0

    strRoot     db 'Root Node', 0
    strChild1   db 'Child Node 1', 0
    strChild2   db 'Child Node 2', 0

section '.text' code readable executable

start:
    invoke  GetModuleHandleA, 0
    mov     [hInst], eax

    mov     [wc.style], CS_HREDRAW or CS_VREDRAW
    mov     [wc.lpfnWndProc], WindowProc
    mov     [wc.hInstance], eax
    mov     [wc.hbrBackground], COLOR_WINDOW + 1
    mov     [wc.lpszClassName], clsName
    invoke  RegisterClassA, wc

    invoke  CreateWindowExA, 0, clsName, winTitle, WS_VISIBLE or WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, 400, 300, 0, 0, [hInst], 0
    mov     [hwnd], eax

msg_loop:
    invoke  GetMessageA, msg, 0, 0, 0
    test    eax, eax
    jz      end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessageA, msg
    jmp     msg_loop

end_loop:
    invoke  ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp     [wmsg], WM_CREATE
    je      .wm_create
    cmp     [wmsg], WM_SIZE
    je      .wm_size
    cmp     [wmsg], WM_DESTROY
    je      .wm_destroy
    invoke  DefWindowProcA, [hwnd], [wmsg], [wparam], [lparam]
    ret

.wm_create:
    mov     [icex.dwSize], 8
    mov     [icex.dwICC], ICC_TREEVIEW_CLASSES
    invoke  InitCommonControlsEx, icex

    invoke  CreateWindowExA, 0, treeClass, 0, WS_CHILD or WS_VISIBLE or TVS_HASLINES or TVS_LINESATROOT or TVS_HASBUTTONS, 0, 0, 0, 0, [hwnd], 100, [hInst], 0
    mov     [hTree], eax

    mov     [tvis.hParent], TVI_ROOT
    mov     [tvis.hInsertAfter], TVI_LAST
    mov     [tvis.item.mask], TVIF_TEXT
    mov     [tvis.item.pszText], strRoot
    invoke  SendMessageA, [hTree], TVM_INSERTITEMA, 0, tvis
    mov     [hRoot], eax

    mov     eax, [hRoot]
    mov     [tvis.hParent], eax
    mov     [tvis.item.pszText], strChild1
    invoke  SendMessageA, [hTree], TVM_INSERTITEMA, 0, tvis

    mov     eax, [hRoot]
    mov     [tvis.hParent], eax
    mov     [tvis.item.pszText], strChild2
    invoke  SendMessageA, [hTree], TVM_INSERTITEMA, 0, tvis

    xor     eax, eax
    ret

.wm_size:
    mov     eax, [lparam]
    movzx   ecx, ax
    shr     eax, 16
    invoke  MoveWindow, [hTree], 0, 0, ecx, eax, 1
    xor     eax, eax
    ret

.wm_destroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
    ret
endp

section '.idata' import data readable

    library kernel32, 'KERNEL32.DLL', \
            user32, 'USER32.DLL', \
            comctl32, 'COMCTL32.DLL'

    import  kernel32, \
            GetModuleHandleA, 'GetModuleHandleA', \
            ExitProcess, 'ExitProcess'

    import  user32, \
            RegisterClassA, 'RegisterClassA', \
            CreateWindowExA, 'CreateWindowExA', \
            GetMessageA, 'GetMessageA', \
            TranslateMessage, 'TranslateMessage', \
            DispatchMessageA, 'DispatchMessageA', \
            DefWindowProcA, 'DefWindowProcA', \
            SendMessageA, 'SendMessageA', \
            MoveWindow, 'MoveWindow', \
            PostQuitMessage, 'PostQuitMessage'

    import  comctl32, \
            InitCommonControlsEx, 'InitCommonControlsEx'
