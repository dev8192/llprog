format PE console 4.0
entry start

include 'win32a.inc'

struct NODE
    pszName  dd ?
    pChild   dd ?
    pSibling dd ?
ends

section '.data' data readable writeable

    strRoot db 'Root', 0
    strSrc  db 'Source', 0
    strMain db 'main.asm', 0
    strRes  db 'Resources', 0
    strIcon db 'icon.ico', 0
    strDoc  db 'Readme.txt', 0

    ; Define the tree structure recursively (Name, Child, Sibling)
    nodeDoc  NODE strDoc,  0, 0
    nodeIcon NODE strIcon, 0, nodeDoc
    nodeRes  NODE strRes,  nodeIcon, 0
    nodeMain NODE strMain, 0, 0
    nodeSrc  NODE strSrc,  nodeMain, nodeRes
    nodeRoot NODE strRoot, nodeSrc,  0

    fmtPrefix db '|-- ', 0
    fmtSpace  db '|   ', 0
    fmtNode   db '%s', 10, 0

section '.text' code readable executable

start:
    invoke  PrintTree, nodeRoot, 0
    invoke  ExitProcess, 0

proc PrintTree pNode, level
    push    ebx
    push    esi

    mov     ebx, [pNode]

.loop_nodes:
    test    ebx, ebx
    jz      .done

    mov     esi, [level]
    test    esi, esi
    jz      .print_name

.loop_indent:
    cmp     esi, 1
    jbe     .print_prefix
    cinvoke printf, fmtSpace
    dec     esi
    jmp     .loop_indent

.print_prefix:
    cinvoke printf, fmtPrefix

.print_name:
    cinvoke printf, fmtNode, [ebx+NODE.pszName]

    ; Recursively print child nodes at the next indentation level
    mov     eax, [level]
    inc     eax
    invoke  PrintTree, [ebx+NODE.pChild], eax

    ; Proceed to the next sibling node at the current level
    mov     ebx, [ebx+NODE.pSibling]
    jmp     .loop_nodes

.done:
    pop     esi
    pop     ebx
    ret
endp

section '.idata' import data readable

    library kernel32, 'KERNEL32.DLL', \
            msvcrt, 'MSVCRT.DLL'

    import  kernel32, \
            ExitProcess, 'ExitProcess'

    import  msvcrt, \
            printf, 'printf'
