format PE
entry start

include 'win32a.inc'

struc GUID def {
    match d1-d2-d3-d4-d5, def
    \{
        .Data1 dd 0x\#d1
        .Data2 dw 0x\#d2
        .Data3 dw 0x\#d3
        .Data4 db 0x\#d4 shr 8,\
                  0x\#d4 and 0FFh
        .Data5 db 0x\#d5 shr 40,\
                  0x\#d5 shr 32 and 0FFh,\
                  0x\#d5 shr 24 and 0FFh,\
                  0x\#d5 shr 16 and 0FFh,\
                  0x\#d5 shr 8 and 0FFh,\
                  0x\#d5 and 0FFh
    \}
}

interface ITaskBarList,\
        QueryInterface,\
        AddRef,\
        Release,\
        HrInit,\
        AddTab,\
        DeleteTab,\
        ActivateTab,\
        SetActiveAlt

CLSCTX_INPROC_SERVER        = 0x1
CLSCTX_INPROC_HANDLER       = 0x2
CLSCTX_LOCAL_SERVER         = 0x4
CLSCTX_INPROC_SERVER16      = 0x8
CLSCTX_REMOTE_SERVER        = 0x10
CLSCTX_INPROC_HANDLER16     = 0x20
CLSCTX_INPROC_SERVERX86     = 0x40
CLSCTX_INPROC_HANDLERX86    = 0x80
CLSCTX_ESERVER_HANDLER      = 0x100
CLSCTX_NO_CODE_DOWNLOAD     = 0x400
CLSCTX_NO_CUSTOM_MARSHAL    = 0x1000
CLSCTX_ENABLE_CODE_DOWNLOAD = 0x2000
CLSCTX_NO_FAILURE_LOG       = 0x4000
CLSCTX_DISABLE_AAA          = 0x8000
CLSCTX_ENABLE_AAA           = 0x10000
CLSCTX_FROM_DEFAULT_CONTEXT = 0x20000

ID_EXIT = IDCANCEL
ID_SHOW = 100
ID_HIDE = 101

IDD_COMDEMO = 1

section '.data' data readable writeable
    CLSID_TaskbarList   GUID 56FDF344-FD6D-11D0-958A-006097C9A090
    IID_ITaskbarList    GUID 56FDF342-FD6D-11D0-958A-006097C9A090
    ShellTaskBar        ITaskBarList
    ShellTaskBar_len    = $ - ShellTaskBar

section '.text' code readable executable
start:
    invoke CoInitialize, NULL
    invoke CoCreateInstance, CLSID_TaskbarList, NULL,\
           CLSCTX_INPROC_SERVER, IID_ITaskbarList, ShellTaskBar
    invoke GetModuleHandle, 0
    invoke DialogBoxParam, eax, IDD_COMDEMO, HWND_DESKTOP, COMDemo, 0
    cominvk ShellTaskBar, Release
    invoke ExitProcess, 0

proc COMDemo uses ebx esi edi, hwnd, msg, wparam, lparam
    cmp    [msg], WM_INITDIALOG
    je    .wm_initdialog
    cmp    [msg], WM_COMMAND
    je    .wm_command
    cmp    [msg], WM_CLOSE
    je    .wm_close
    xor    eax, eax
    jmp    .finish
.wm_initdialog:
    jmp    .processed
.wm_command:
    cmp    [wparam], BN_CLICKED shl 16 + ID_EXIT
    je    .wm_close
    cmp    [wparam], BN_CLICKED shl 16 + ID_SHOW
    je    .show
    cmp    [wparam], BN_CLICKED shl 16 + ID_HIDE
    jne    .processed
.hide:
    cominvk ShellTaskBar, HrInit
    cominvk ShellTaskBar, DeleteTab, [hwnd]
    jmp    .processed
.show:
    mov    ebx, [ShellTaskBar]
    comcall ebx, ITaskBarList, HrInit
    comcall ebx, ITaskBarList, AddTab, [hwnd]
    comcall ebx, ITaskBarList, ActivateTab, [hwnd]
    jmp    .processed
.wm_close:
    invoke    EndDialog, [hwnd], 0
.processed:
    mov    eax, 1
.finish:
    ret
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            user32,             'user32.dll',\
            ole32,              'ole32.dll'
    import  kernel32,\
            GetModuleHandle,    'GetModuleHandleA',\
            ExitProcess,        'ExitProcess'
    import  user32,\
            DialogBoxParam,     'DialogBoxParamA',\
            EndDialog,          'EndDialog'
    import  ole32,\
            CoInitialize,       'CoInitialize',\
            CoCreateInstance,   'CoCreateInstance'

section '.rsrc' resource data readable
    directory RT_DIALOG,dialogs
    resource dialogs,\
        IDD_COMDEMO,LANG_ENGLISH+SUBLANG_DEFAULT,comdemo
    dialog comdemo,'Taskbar item control',70,70,170,24,WS_CAPTION+WS_POPUP+WS_SYSMENU+DS_MODALFRAME
        dialogitem 'BUTTON','Show',ID_SHOW,4,4,45,15,WS_VISIBLE+WS_TABSTOP
        dialogitem 'BUTTON','Hide',ID_HIDE,54,4,45,15,WS_VISIBLE+WS_TABSTOP
        dialogitem 'BUTTON','Exit',ID_EXIT,120,4,45,15,WS_VISIBLE+WS_TABSTOP
    enddialog
