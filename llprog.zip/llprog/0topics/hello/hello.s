format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    str1            db 'hello', 0
    str2            db 'hello', 10, 0
    str3            db 'hello', 10
    str3_len        = $ - str3
    bytes_written   dd 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    cinvoke puts, str1
    ret
endp

proc main2
    cinvoke printf, str2
    ret
endp

proc main3
    invoke GetStdHandle, STD_OUTPUT_HANDLE
    invoke WriteFile, eax, str3, str3_len, bytes_written, 0
    ret
endp

proc main4
    invoke GetStdHandle, STD_OUTPUT_HANDLE
    invoke WriteConsole, eax, str3, str3_len, bytes_written, 0
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            GetStdHandle,   'GetStdHandle',\
            WriteFile,      'WriteFile',\
            WriteConsole,   'WriteConsoleA',\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
