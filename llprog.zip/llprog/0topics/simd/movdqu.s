format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
   ;align_breaker   db 0
    rect1           RECT 100, 200, 300, 400
    rect2           RECT 10, 20, 30, 40
    fmt_4u          db '%u %u %u %u', 10, 0

include '../util/print_bytes.data.inc'

section '.text' code readable executable
start:
    stdcall main
    invoke  ExitProcess, 0

include '../util/print_bytes.text.inc'

proc main
    movdqa xmm0, dqword [rect1]
    movdqa xmm1, dqword [rect2]
    paddd xmm0, xmm1
    movdqa dqword [rect2], xmm0
    cinvoke printf, fmt_4u, [rect2.left], [rect2.top], [rect2.right], [rect2.bottom]
    ret
endp

section '.idata' import data readable
library kernel32,       'kernel32.dll',\
        msvcrt,         'msvcrt.dll'
import  kernel32,\
        ExitProcess,    'ExitProcess'
import  msvcrt,\
        printf,         'printf'
