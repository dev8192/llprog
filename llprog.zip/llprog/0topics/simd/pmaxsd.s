
; Data Size       | Maximum Mnemonic | Minimum Mnemonic
; 8-bit (Bytes)   | pmaxub / pmaxsb  | pminub / pminsb
; 16-bit (Words)  | pmaxuw / pmaxsw  | pminuw / pminsw
; 32-bit (Dwords) | pmaxud / pmaxsd  | pminud / pminsd

format PE
entry start

include 'win32ax.inc'

macro create_proc name, op {
    proc name num1, num2
        movd xmm0, [num1]
        movd xmm1, [num2]
        op xmm0, xmm1
        movd eax, xmm0
    cinvoke printf, fmt_x, eax
        ret
    endp
}

create_proc max_signed, pmaxsd
create_proc max_unsigned, pmaxud

section '.data' data readable writeable
    fmt_x       db '%x', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    cinvoke puts, '*** main1 ***'
    stdcall max_signed, 0x7fffffff, 0x80000000
    stdcall max_unsigned, 0x7fffffff, 0x80000000
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
