format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt     db 'hello', 10, 0

section '.text' code readable executable
start:
    stdcall test10
    invoke ExitProcess, 0

proc test10
    movq xmm0, [num1]    ; Load 64 bits into low half of xmm0
    movq xmm1, [num2]    ; Load 64 bits into low half of xmm1
    pcmpeqq xmm0, xmm1   ; Compare them
    cinvoke printf, fmt
    ret
endp

section '.idata' import data readable
library kernel32,       'kernel32.dll',\
        msvcrt,         'msvcrt.dll'
import  kernel32,\
        ExitProcess,    'ExitProcess'
import  msvcrt,\
        printf,         'printf'
