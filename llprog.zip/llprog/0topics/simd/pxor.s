format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    buf1    db 8 dup(-1, 0)
    buf2    db 8 dup(0, -1)
    buf3    db 16 dup(0)

include '../util/print_bytes.data.inc'

section '.text' code readable executable
start:
    stdcall test1
    invoke ExitProcess, 0

include '../util/print_bytes.text.inc'

proc test1
    movdqu xmm0, dqword [buf1]
    pxor xmm0, dqword [buf2]
    movdqu dqword [buf3], xmm0
    stdcall print_bytes, buf1, 16
    stdcall print_bytes, buf2, 16
    stdcall print_bytes, buf3, 16
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
