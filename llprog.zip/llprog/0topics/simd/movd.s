format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    buf1    db 16 dup(-1)
    buf2    db 0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15
    fmt_x   db '%x', 10, 0

include '../util/print_bytes.data.inc'

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

include '../util/print_bytes.text.inc'

proc main1
    movdqu xmm0, dqword [buf1]
    mov eax, 0x12345678
    movd xmm0, eax
    movdqu dqword [buf1], xmm0
    stdcall print_bytes, buf1, 16
    ret
endp

proc main
    movdqu xmm0, dqword [buf2]
    movd eax, xmm0
    cinvoke printf, fmt_x, eax
    ret
endp

section '.idata' import data readable
library kernel32,       'kernel32.dll',\
        msvcrt,         'msvcrt.dll'
import  kernel32,\
        ExitProcess,    'ExitProcess'
import  msvcrt,\
        printf,         'printf'
