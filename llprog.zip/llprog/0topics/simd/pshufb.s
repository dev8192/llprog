format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    buf1            db 15,14,13,12,11,10,9,8,7,6,5,4,3,2,1,0
    buf2            db 'abcdefghijklmnop'
    buf3:
        db 0xA0, 0xA1, 0xA2, 0xA3, 0xA4, 0xA5, 0xA6, 0xA7
        db 0xA8, 0xA9, 0xAA, 0xAB, 0xAC, 0xAD, 0xAE, 0xAF

include '../util/print_bytes.data.inc'

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

include '../util/print_bytes.text.inc'

proc main1
    stdcall print_bytes, buf1, 16
    movdqu xmm0, dqword [buf1]
    pshufb xmm0, xmm0
    movdqu dqword [buf1], xmm0
    stdcall print_bytes, buf1, 16
    ret
endp

proc main
    stdcall print_bytes, buf2, 16
    movdqu xmm0, dqword [buf2]
    movdqu xmm1, dqword [buf1]
    pshufb xmm0, xmm1
    movdqu dqword [buf2], xmm0
    stdcall print_bytes, buf2, 16
    ret
endp

section '.idata' import data readable
library kernel32,       'kernel32.dll',\
        msvcrt,         'msvcrt.dll'
import  kernel32,\
        ExitProcess,    'ExitProcess'
import  msvcrt,\
        printf,         'printf'
