format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    val0        db 16 dup(0)
    val1        db 'aaaaaaaaaaaaaaaa'
    val21       db 'baaaabaaaabaaaab' ; 0111_1011_1101_1110
    val2        db 'bbabababbaabaaab' ; 0000_0000_0000_0000
    val3        db '1111----1111----'
    fmt_x       db '%x', 10, 0
    
include '../util/print_bytes.data.inc'

section '.text' code readable executable
start:
    stdcall test1
    invoke  ExitProcess, 0

include '../util/print_bytes.text.inc'

proc test1 uses ebx
    movdqu xmm0, dqword [val1]
    movdqu xmm1, dqword [val2]
    pcmpeqb xmm0, xmm1
    movdqu dqword [val0], xmm0
    mov ebx, 0x12345678
    pmovmskb ebx, xmm0
    stdcall print_bytes, val1, 16
    stdcall print_bytes, val2, 16
    stdcall print_bytes, val0, 16
    cinvoke printf, fmt_x, ebx
    ret
endp

proc test2
    stdcall .compare, val1, val2
    stdcall .compare, val2, val3
    ret
endp

proc .compare, p1, p2
    mov eax, [p1]
    movdqu xmm0, [eax]
    mov eax, [p2]
    movdqu xmm1, [eax]

    ; 2. Compare bytes. 
    ; If byte X in xmm0 == byte X in xmm1, byte X in xmm0 becomes 0xFF.
    ; Otherwise, it becomes 0x00.
    pcmpeqb xmm0, xmm1

    ; 3. Move the most significant bit of each byte into EAX.
    ; Since a match is 0xFF (binary 11111111), its high bit is 1.
    ; 16 bytes = 16 bits in EAX.
    pmovmskb eax, xmm0
    cmp eax, 0xFFFF
    jne .not_equal
    cinvoke puts, 'equal'
    jmp .exit
.not_equal:
    cinvoke puts, 'not equal'
.exit:
    ret
endp

section '.import' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
