format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    buf1:
        db 0xA0, 0xA1, 0xA2, 0xA3, 0xA4, 0xA5, 0xA6, 0xA7
        db 0xA8, 0xA9, 0xAA, 0xAB, 0xAC, 0xAD, 0xAE, 0xAF
    buf2    db 16 dup(0)
    fmt_x   db '%x', 10, 0

include '../util/print_bytes.data.inc'

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

include '../util/print_bytes.text.inc'

proc main1
    stdcall print_bytes, buf1, 16
    movdqu xmm0, dqword [buf1]
    pslldq xmm0, 4
    movdqu dqword [buf2], xmm0
    stdcall print_bytes, buf2, 16
    ret
endp

proc main
    stdcall print_bytes, buf1, 16
    movdqu xmm0, dqword [buf1]
    psrldq xmm0, 4
    movdqu dqword [buf2], xmm0
    stdcall print_bytes, buf2, 16
    ret
endp

section '.idata' import data readable
library kernel32,       'kernel32.dll',\
        msvcrt,         'msvcrt.dll'
import  kernel32,\
        ExitProcess,    'ExitProcess'
import  msvcrt,\
        printf,         'printf'
