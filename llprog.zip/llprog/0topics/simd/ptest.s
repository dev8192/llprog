format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    buf1    db 16 dup(-1)
    buf2    db 16 dup(0)

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    stdcall .helper, buf1
    stdcall .helper, buf2
    ret
endp

proc .helper, mem_ptr
    mov eax, [mem_ptr]
    movdqu xmm0, [eax]
    ptest xmm0, xmm0
    jz .empty
    cinvoke puts, 'not empty'
    jmp .done
.empty:
    cinvoke puts, 'empty'
.done:
    ret
endp

section '.idata' import data readable
library kernel32,       'kernel32.dll',\
        msvcrt,         'msvcrt.dll'
import  kernel32,\
        ExitProcess,    'ExitProcess'
import  msvcrt,\
        printf,         'printf',\
        puts,           'puts'
