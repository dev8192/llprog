format PE
entry start

include 'win32ax.inc'

PE_SIG_OFF    = 0x80
OPT_HDR_OFF   = PE_SIG_OFF + 0x18
SEC_TBL_OFF   = PE_SIG_OFF + 0xF8
DATA_RAW_OFF  = 0x200
TEXT_RAW_OFF  = 0x400
IDAT_RAW_OFF  = 0x600

BUF_SIZE      = 2048
DOS_STUB_LEN  = 39

IMAGE_BASE    = 0x00400000
DATA_RVA      = 0x1000
TEXT_RVA      = 0x2000
IDAT_RVA      = 0x3000

section '.data' data readable writeable
    out_name        db 'dump.exe',0
    h_file          dd ?
    written         dd ?
    buffer          rb BUF_SIZE
    dos_msg         db 'This program cannot be run in DOS mode.', 13, 10, '$'
    k32_str         db 'kernel32.dll',0
    mvc_str         db 'msvcrt.dll',0
    exit_str        db 0, 0, 'ExitProcess', 0
    prnt_str        db 0, 0, 'printf', 0
    e_magic         db 'MZ' ; 4D 5A

include '../../util/print_bytes.data.inc'

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

include '../../util/print_bytes.text.inc'

proc main
    cinvoke puts, '*** main1 ***'
    mov edi, buffer
    mov ax, word [e_magic]
    mov [edi], ax
    stdcall print_bytes, buffer, 512
    ret
endp

proc main5 uses esi edi
    mov edi, buffer
    xor al, al
    mov ecx, BUF_SIZE
    rep stosb

    mov edi, buffer
    mov word [edi], 0x5A4D               ; e_magic
    mov byte [edi+0x3C], PE_SIG_OFF      ; e_lfanew

    ; --- DOS Stub ---
    lea edi, [buffer + 0x40]
    mov dword [edi], 0x0EBA1F0E
    mov dword [edi+4], 0xCD09B400
    mov esi, dos_msg
    mov ecx, DOS_STUB_LEN
    rep movsb

    ; --- PE Header ---
    lea edi, [buffer + PE_SIG_OFF]
    mov dword [edi], 0x00004550          ; Signature 'PE'
    mov word [edi+4], 0x014C             ; Machine (x86)
    mov word [edi+6], 3                  ; NumberOfSections
    mov dword [edi+8], 0x69D4ED57        ; TimeDateStamp
    mov word [edi+20], 0x00E0            ; SizeOfOptionalHeader
    mov word [edi+22], 0x010F            ; Characteristics

    ; --- Optional Header ---
    lea edi, [buffer + OPT_HDR_OFF]
    mov word [edi], 0x010B               ; Magic (PE32)
    mov dword [edi+16], TEXT_RVA         ; AddressOfEntryPoint
    mov dword [edi+28], IMAGE_BASE       ; ImageBase
    mov dword [edi+32], 0x1000           ; SectionAlignment
    mov dword [edi+36], 0x0200           ; FileAlignment
    mov dword [edi+56], 0x4000           ; SizeOfImage
    mov dword [edi+60], 0x0200           ; SizeOfHeaders
    mov word [edi+68], 3                 ; Subsystem (Console)
    
    ; Data Directories
    mov dword [edi+104], IDAT_RVA        ; Import Table RVA
    mov dword [edi+108], 0x92            ; Import Table Size

    ; --- Section Table ---
    lea edi, [buffer + SEC_TBL_OFF]
    
    ; .data
    mov dword [edi], '.dat'
    mov word [edi+4], 'a'
    mov dword [edi+8], 0x08              ; VirtualSize
    mov dword [edi+12], DATA_RVA         ; VirtualAddress
    mov dword [edi+16], 0x0200           ; SizeOfRawData
    mov dword [edi+20], DATA_RAW_OFF     ; PointerToRawData
    mov dword [edi+36], 0xC0000040       ; Characteristics
    
    ; .text
    add edi, 40
    mov dword [edi], '.tex'
    mov byte [edi+4], 't'
    mov dword [edi+8], 0x16
    mov dword [edi+12], TEXT_RVA
    mov dword [edi+16], 0x0200
    mov dword [edi+20], TEXT_RAW_OFF
    mov dword [edi+36], 0x60000020
    
    ; .idata
    add edi, 40
    mov dword [edi], '.ida'
    mov word [edi+4], 'ta'
    mov dword [edi+8], 0x92
    mov dword [edi+12], IDAT_RVA
    mov dword [edi+16], 0x0200
    mov dword [edi+20], IDAT_RAW_OFF
    mov dword [edi+36], 0x40000040

    ; --- Section Data: .data ---
    lea edi, [buffer + DATA_RAW_OFF]
    mov dword [edi], 'abc1'
    mov dword [edi+4], 0x000A3332        ; '23\n\0'

    ; --- Section Data: .text ---
    lea edi, [buffer + TEXT_RAW_OFF]
    mov byte [edi], 0x68                 ; push
    mov dword [edi+1], IMAGE_BASE + DATA_RVA
    mov word [edi+5], 0x15FF             ; call dword ptr []
    mov dword [edi+7], IMAGE_BASE + IDAT_RVA + 0x80 ; printf IAT
    mov dword [edi+11], 0x04C4836A       ; add esp, 4 / push 0
    mov word [edi+15], 0x15FF
    mov dword [edi+17], IMAGE_BASE + IDAT_RVA + 0x60 ; ExitProcess IAT

    ; --- Section Data: .idata ---
    lea edi, [buffer + IDAT_RAW_OFF]
    mov dword [edi+0], IDAT_RVA + 0x58   ; OriginalFirstThunk K32
    mov dword [edi+12], IDAT_RVA + 0x3C  ; Name K32
    mov dword [edi+16], IDAT_RVA + 0x60  ; FirstThunk K32
    mov dword [edi+20], IDAT_RVA + 0x78  ; OriginalFirstThunk MSV
    mov dword [edi+32], IDAT_RVA + 0x4A  ; Name MSV
    mov dword [edi+36], IDAT_RVA + 0x80  ; FirstThunk MSV
    
    ; Strings & Import Tables
    lea edi, [buffer + IDAT_RAW_OFF + 0x3C]
    mov esi, k32_str
    mov ecx, 13
    rep movsb
    mov esi, mvc_str
    mov ecx, 11
    rep movsb
    
    ; Function hints/names
    lea edi, [buffer + IDAT_RAW_OFF + 0x60]
    mov dword [edi], IDAT_RVA + 0x68     ; IAT entry for ExitProcess
    mov dword [edi+32], IDAT_RVA + 0x88  ; IAT entry for printf
    
    lea edi, [buffer + IDAT_RAW_OFF + 0x68]
    mov esi, exit_str
    mov ecx, 12
    rep movsb
    lea edi, [buffer + IDAT_RAW_OFF + 0x88]
    mov esi, prnt_str
    mov ecx, 7
    rep movsb

    ; Save to file
    invoke CreateFile, out_name, GENERIC_WRITE, 0, 0, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0
    mov [h_file], eax
    invoke WriteFile, [h_file], buffer, BUF_SIZE, written, 0
    invoke CloseHandle, [h_file]
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            CreateFile,     'CreateFileA',\
            WriteFile,      'WriteFile',\
            CloseHandle,    'CloseHandle',\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
