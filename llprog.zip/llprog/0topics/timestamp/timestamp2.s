format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_x       db '%x', 10, 0
    fmt_llu     db '%llu', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main1 uses
    cinvoke puts, '*** main1 ***'
    mov eax, 0xFFFFFFFF
    mov edx, 0xFFFFFFFF
    cinvoke printf, fmt_llu, eax, edx
    mov eax, 0xFFFFFFFE
    mov edx, 0xFFFFFFFF
    cinvoke printf, fmt_llu, eax, edx
    mov eax, 0xFFFFFFFD
    mov edx, 0xFFFFFFFF
    cinvoke printf, fmt_llu, eax, edx
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    cinvoke printf, fmt_llu, 0xFFFFFFFF, 0xFFFFFFFF
   ;stdcall CreateUnixMsTimestamp1, 10, 5, 30, 15, 500
    stdcall CreateUnixMsTimestamp1, 0, 0, 0, 0, -1
    cinvoke printf, fmt_llu, eax, edx
    stdcall CreateUnixMsTimestamp1, 0, 0, 0, -1, 0
    cinvoke printf, fmt_llu, eax, edx
    stdcall CreateUnixMsTimestamp1, 0, 0, -1, 0, 0
    cinvoke printf, fmt_llu, eax, edx
    stdcall CreateUnixMsTimestamp1, 0, -1, 0, 0, 0
    cinvoke printf, fmt_llu, eax, edx
    stdcall CreateUnixMsTimestamp1, -1, 0, 0, 0, 0
    cinvoke printf, fmt_llu, eax, edx
    stdcall CreateUnixMsTimestamp1, -1, -1, -1, -1, -1
    cinvoke printf, fmt_llu, eax, edx
    ret
endp

proc main
    cinvoke puts, '*** main3 ***'
    stdcall CreateUnixMsTimestamp1, -1, -1, -1, -1, -1
    cinvoke printf, fmt_llu, eax, edx
    stdcall CreateUnixMsTimestamp2, -1, -1, -1, -1, -1
    cinvoke printf, fmt_llu, eax, edx
    stdcall CreateUnixMsTimestamp3, -1, -1, -1, -1, -1
    cinvoke printf, fmt_llu, eax, edx
    stdcall CreateUnixMsTimestamp4, -1, -1, -1, -1, -1
    cinvoke printf, fmt_llu, eax, edx
    stdcall CreateUnixMsTimestamp5, -1, -1, -1, -1, -1
    cinvoke printf, fmt_llu, eax, edx
    ret
endp

; a * (b + c) = ab + ac (distributive property)
; (EDX * EAX) * 60 = (EDX * 60) + (EAX * 60)
proc CreateUnixMsTimestamp1 uses ebx, days, hours, mins, secs, msecs
    mov eax, [days]
    mov ecx, 24
    mul ecx
    add eax, [hours]
    adc edx, 0

    mov ebx, edx
    mov ecx, 60
    mul ecx
    imul ebx, ecx
    add edx, ebx
    add eax, [mins]
    adc edx, 0

    mov ebx, edx
    mov ecx, 60
    mul ecx
    imul ebx, ecx
    add edx, ebx
    add eax, [secs]
    adc edx, 0
    
    mov ebx, edx
    mov ecx, 1000
    mul ecx
    imul ebx, ecx
    add edx, ebx
    add eax, [msecs]
    adc edx, 0
    ret
endp

proc CreateUnixMsTimestamp2 uses ebx, days, hours, mins, secs, msecs
    mov eax, [days]
    imul eax, 24
    add eax, [hours]
    imul eax, 60
    add eax, [mins]
    imul eax, 60
    add eax, [secs]
    mov ecx, 1000
    mul ecx
    add eax, [msecs]
    adc edx, 0
    ret
endp

proc CreateUnixMsTimestamp3 uses ebx esi, days, hours, mins, secs, msecs
    mov eax, [days]
    xor esi, esi

    mov ecx, 24
    mul ecx             ; EDX:EAX = EAX * 24
    imul esi, ecx       ; ESI = ESI * 24 (Safe because ESI started at 0)
    add esi, edx        ; ESI now holds total High 32-bits
    add eax, [hours]
    adc esi, 0

    ; Stage 2: * 60 + mins
    mov ecx, 60
    mov ebx, eax        ; Save current Low 32-bits
    mov eax, esi        ; Multiply High 32-bits by 60
    mul ecx
    mov esi, eax        ; ESI handles the shifted high accumulation
    mov eax, ebx        ; Restore Low 32-bits
    mul ecx             ; EDX:EAX = Low * 60
    add esi, edx        ; Accumulate overflowed bits
    add eax, [mins]
    adc esi, 0

    ; Stage 3: * 60 + secs
    mov ebx, eax
    mov eax, esi
    mul ecx
    mov esi, eax
    mov eax, ebx
    mul ecx
    add esi, edx
    add eax, [secs]
    adc esi, 0

    ; Stage 4: * 1000 + msecs
    mov ecx, 1000
    mov ebx, eax
    mov eax, esi
    mul ecx
    mov esi, eax
    mov eax, ebx
    mul ecx
    add esi, edx
    add eax, [msecs]
    adc esi, 0

    mov edx, esi
    ret
endp

proc CreateUnixMsTimestamp4 uses ebx esi edi, days, hours, mins, secs, msecs
    locals
        factors dd 24, 60, 60, 1000
        inputs  dd ?, ?, ?, ?
    endl

    mov eax, [hours]
    mov [inputs], eax
    mov eax, [mins]
    mov [inputs+4], eax
    mov eax, [secs]
    mov [inputs+8], eax
    mov eax, [msecs]
    mov [inputs+12], eax

    mov eax, [days]
    xor esi, esi            ; ESI = running high 32 bits
    xor edi, edi            ; EDI = loop counter (0 to 3)
.loop:
    mov ecx, [factors + edi*4]

    ; 1. Multiply High 32 bits (ESI) by factor
    mov ebx, eax            ; Save low 32 bits
    mov eax, esi
    mul ecx
    mov esi, eax            ; ESI = High * factor (Ignore EDX overflow past 64-bit)

    ; 2. Multiply Low 32 bits (EBX) by factor
    mov eax, ebx
    mul ecx                 ; EDX:EAX = Low * factor

    ; 3. Combine partial products and add the next input
    add esi, edx            ; Accumulate overflow from low multiplication
    add eax, [inputs + edi*4]
    adc esi, 0              ; Ripple carry into high 32 bits

    inc edi                 ; Move to next step
    cmp edi, 4
    jl .loop

    mov edx, esi            ; Return final 64-bit result in EDX:EAX
    ret
endp

align 4
factors dd 24, 60, 60, 1000
proc CreateUnixMsTimestamp5 uses ebx esi edi, days, hours, mins, secs, msecs
    mov eax, [days]
    xor esi, esi            ; ESI = running high 32 bits
    xor edi, edi            ; EDI = loop index (0 to 3)
.loop:
    mov ecx, [factors + edi*4]

    ; 1. Multiply High 32 bits (ESI) by factor
    mov ebx, eax            ; Save low 32 bits
    mov eax, esi
    mul ecx
    mov esi, eax            ; ESI = High * factor

    ; 2. Multiply Low 32 bits (EBX) by factor
    mov eax, ebx
    mul ecx                 ; EDX:EAX = Low * factor

    ; 3. Combine products and add the next consecutive parameter from the stack
    add esi, edx            
    add eax, [hours + edi*4]; Directly indexes hours, mins, secs, msecs
    adc esi, 0              

    inc edi
    cmp edi, 4
    jl .loop

    mov edx, esi            ; Return final 64-bit result in EDX:EAX
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
