format PE
entry start

include 'win32ax.inc'

SERVICE_CONTROL_STOP = 1
SERVICE_WIN32_OWN_PROCESS = 16
SERVICE_RUNNING           = 4
SERVICE_ACCEPT_STOP       = 1
NO_ERROR                  = 0
SERVICE_STOP_PENDING      = 3
SERVICE_STOPPED           = 1

struct SERVICE_STATUS
    dwServiceType             dd ?
    dwCurrentState            dd ?
    dwControlsAccepted        dd ?
    dwWin32ExitCode           dd ?
    dwServiceSpecificExitCode dd ?
    dwCheckPoint              dd ?
    dwWaitHint                dd ?
ends

section '.data' data readable writeable
    service_name        db 'FasmService', 0
    log_file            db '0files/service_log.txt', 0
    msg_start           db 'Service Started', 10, 0
    msg_stop            db 'Service Stopped', 10, 0
    
    service_status      SERVICE_STATUS
    status_handle       dd ?

    service_table:
        dd service_name
        dd service_main
        dd 0, 0

section '.text' code readable executable
start:
    invoke StartServiceCtrlDispatcher, service_table
    invoke ExitProcess, 0

proc service_main dwArgc, lpszArgv
    invoke RegisterServiceCtrlHandler, service_name, service_handler
    mov [status_handle], eax
    
    test eax, eax
    jz .exit

    mov [service_status.dwServiceType], SERVICE_WIN32_OWN_PROCESS
    mov [service_status.dwCurrentState], SERVICE_RUNNING
    mov [service_status.dwControlsAccepted], SERVICE_ACCEPT_STOP
    mov [service_status.dwWin32ExitCode], NO_ERROR
    
    invoke SetServiceStatus, [status_handle], service_status
    
    stdcall log_message, msg_start

    .wait_loop:
        cmp [service_status.dwCurrentState], SERVICE_RUNNING
        jne .cleanup
        invoke Sleep, 1000
        jmp .wait_loop

    .cleanup:
        stdcall log_message, msg_stop
    .exit:
        ret
endp

proc service_handler dwControl
    cmp [dwControl], SERVICE_CONTROL_STOP
    je .stop
    ret

.stop:
    mov [service_status.dwCurrentState], SERVICE_STOP_PENDING
    invoke SetServiceStatus, [status_handle], service_status
    
    mov [service_status.dwCurrentState], SERVICE_STOPPED
    invoke SetServiceStatus, [status_handle], service_status
    ret
endp

proc log_message uses ebx lpText
    local bytes_written:DWORD
    invoke CreateFile, log_file, GENERIC_WRITE, 0, 0, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0
    mov ebx, eax
    invoke SetFilePointer, ebx, 0, 0, FILE_END
    invoke lstrlen, [lpText]
    invoke WriteFile, ebx, [lpText], eax, addr bytes_written, 0
    invoke CloseHandle, ebx
    ret
endp

section '.idata' import data readable
    library kernel32,                   'kernel32.dll',\
            advapi32,                   'advapi32.dll'
    import  kernel32,\
            ExitProcess,                'ExitProcess',\
            Sleep,                      'Sleep',\
            CreateFile,                 'CreateFileA',\
            WriteFile,                  'WriteFile',\
            CloseHandle,                'CloseHandle',\
            SetFilePointer,             'SetFilePointer',\
            lstrlen,                    'lstrlenA'
    import  advapi32,\
            StartServiceCtrlDispatcher, 'StartServiceCtrlDispatcherA',\
            RegisterServiceCtrlHandler, 'RegisterServiceCtrlHandlerA',\
            SetServiceStatus,           'SetServiceStatus'
