format PE GUI 4.0
entry start

include 'win32a.inc'

; Additional constants not in standard win32a.inc
SERVICE_CONFIG_FAILURE_ACTIONS = 2
SC_ACTION_RESTART              = 1

struct SC_ACTION
    Type    dd ?
    Delay   dd ?
ends

struct SERVICE_FAILURE_ACTIONS
    dwResetPeriod   dd ?
    lpRebootMsg     dd ?
    lpCommand       dd ?
    cActions        dd ?
    lpsaActions     dd ?
ends

section '.data' data readable writeable
    service_name    db 'FasmService',0
    log_file        db 'C:\service_log.txt',0
    msg_start       db 'Service Started',13,10,0
    msg_stop        db 'Service Stopped',13,10,0
    
    service_status  SERVICE_STATUS
    status_handle   dd 0

    ; Recovery structures
    recovery_actions:
        SC_ACTION SC_ACTION_RESTART, 5000 ; 1st failure: restart after 5s
        SC_ACTION SC_ACTION_RESTART, 5000 ; 2nd failure: restart after 5s
    
    failure_settings:
        SERVICE_FAILURE_ACTIONS 86400, 0, 0, 2, recovery_actions

    service_table:
        dd service_name
        dd service_main
        dd 0, 0

section '.code' code readable executable

start:
    invoke StartServiceCtrlDispatcher, service_table
    invoke ExitProcess, 0

proc service_main dwArgc, lpszArgv
    invoke RegisterServiceCtrlHandler, service_name, service_handler
    mov [status_handle], eax
    test eax, eax
    jz .exit

    ; Set up recovery options once when the service starts
    stdcall setup_recovery

    mov [service_status.dwServiceType], SERVICE_WIN32_OWN_PROCESS
    mov [service_status.dwCurrentState], SERVICE_RUNNING
    mov [service_status.dwControlsAccepted], SERVICE_ACCEPT_STOP
    mov [service_status.dwWin32ExitCode], NO_ERROR
    
    invoke SetServiceStatus, [status_handle], service_status
    stdcall log_message, msg_start

    .wait_loop:
        cmp [service_status.dwCurrentState], SERVICE_RUNNING
        jne .cleanup
        invoke Sleep, 1000
        jmp .wait_loop

    .cleanup:
        stdcall log_message, msg_stop
    .exit:
        ret
endp

proc setup_recovery
    local hSCM:DWORD, hSvc:DWORD
    
    invoke OpenSCManager, 0, 0, SC_MANAGER_ALL_ACCESS
    mov [hSCM], eax
    test eax, eax
    jz .done
    
    invoke OpenService, [hSCM], service_name, SERVICE_ALL_ACCESS
    mov [hSvc], eax
    test eax, eax
    jz .close_scm
    
    invoke ChangeServiceConfig2, [hSvc], SERVICE_CONFIG_FAILURE_ACTIONS, failure_settings
    
    invoke CloseServiceHandle, [hSvc]
    .close_scm:
    invoke CloseServiceHandle, [hSCM]
    .done:
    ret
endp

proc service_handler dwControl
    cmp [dwControl], SERVICE_CONTROL_STOP
    jne .done
    mov [service_status.dwCurrentState], SERVICE_STOPPED
    invoke SetServiceStatus, [status_handle], service_status
    .done:
    ret
endp

proc log_message lpText
    local bytes_written:DWORD
    invoke CreateFile, log_file, GENERIC_WRITE, 0, 0, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0
    mov ebx, eax
    invoke SetFilePointer, ebx, 0, 0, FILE_END
    invoke lstrlen, [lpText]
    invoke WriteFile, ebx, [lpText], eax, addr bytes_written, 0
    invoke CloseHandle, ebx
    ret
endp

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL', \
            advapi32, 'ADVAPI32.DLL'

    import kernel32, \
           ExitProcess, 'ExitProcess', \
           Sleep, 'Sleep', \
           CreateFile, 'CreateFileA', \
           WriteFile, 'WriteFile', \
           CloseHandle, 'CloseHandle', \
           SetFilePointer, 'SetFilePointer', \
           lstrlen, 'lstrlenA'

    import advapi32, \
           StartServiceCtrlDispatcher, 'StartServiceCtrlDispatcherA', \
           RegisterServiceCtrlHandler, 'RegisterServiceCtrlHandlerA', \
           SetServiceStatus, 'SetServiceStatus', \
           OpenSCManager, 'OpenSCManagerA', \
           OpenService, 'OpenServiceA', \
           ChangeServiceConfig2, 'ChangeServiceConfig2A', \
           CloseServiceHandle, 'CloseServiceHandle'
