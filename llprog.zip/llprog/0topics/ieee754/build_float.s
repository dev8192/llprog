format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_f       db '%f', 10, 0
    fmt_d       db '%d', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc build_float32_v1 sign, exp, frac
    mov eax, [sign]
    and eax, 1
    shl eax, 31

    mov ecx, [exp]
    and ecx, 0x7F
    add ecx, 127
    shl ecx, 23
    or  eax, ecx

    mov ecx, [frac]
    and ecx, 0x7FFFFF
    or  eax, ecx
    ret
endp

; 0x7FEFFFFFFFFFFFFF
; 0111 1111 1110 1111 ...
; 0 11111111110 1111 ...
proc main1
    cinvoke puts, '*** main1 ***'
    locals
        num1    dq ?
    endl
    stdcall build_float32_v1, 0, 6, 0x760000 ; 0x42F60000    123.0
    mov dword [num1], eax
    fld dword [num1]
    fstp [num1]
    cinvoke printf, fmt_f, dword [num1], dword [num1 + 4]
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    locals
       ;num1 dd 11000010111101100000000000000000b
       ;num1 dd (1 shl 31) or (10000101b shl 23) or 11101100000000000000000b
        num1 dd (1 shl 31) or ((6 + 127) shl 23) or 11101100000000000000000b
        num2 dq ?
        num3 dd 11101100000000000000000b
    endl
    fld [num1]
    fstp [num2]
    cinvoke printf, fmt_f, dword [num2], dword [num2 + 4]
    cinvoke printf, fmt_d, [num3]
    ret
endp

proc int_to_float32 num
    mov eax, [num]
    test eax, eax
    jz .done

    mov edx, eax
    and edx, 0x80000000

    jns .is_positive
    neg eax
.is_positive:
    bsr ecx, eax

    ; 5. Align the Mantissa (Fraction bits)
    ;    We need the bits following the highest bit to line up with float bits 0-22.
    ;    Since the highest bit index is in ECX, we shift the number left 
    ;    to push the highest bit exactly into bit 23.
    mov ebx, ecx
    neg ebx
    add ebx, 23          ; EBX = 23 - ECX (Shift distance)
    
    mov ecx, ebx         ; Move shift distance into count register
    shl eax, cl          ; Shift left. The implicit '1' is now at bit position 23.
    and eax, 0x7FFFFF

    ; 7. Calculate the Biased Exponent
    ;    Take the raw exponent index (stored back in step 4's calculations) 
    ;    and add the IEEE 754 Single-Precision Bias (127).
    mov ecx, 23
    sub ecx, ebx         ; Recover original raw exponent index (ECX = 23 - shift_distance)
    add ecx, 127         ; Add Bias: Stored Exponent = Raw + 127
    shl ecx, 23          ; Move exponent into float bits 23-30

    or eax, edx         ; Merge the Sign field into the final result
    or eax, ecx         ; Merge the Exponent field into the Fraction field
.done:
    ret
endp

proc main
    cinvoke puts, '*** main5 ***'
    locals
        num1    dq ?
    endl
    stdcall int_to_float32, 123
    mov dword [num1], eax
    fld dword [num1]
    fstp [num1]
    cinvoke printf, fmt_f, dword [num1], dword [num1 + 4]
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
