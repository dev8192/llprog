format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_f       db '%f', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc    build_float64_v1 uses ebx esi,\
        pOutput:DWORD, sign:DWORD, exp:DWORD, frac_hi:DWORD, frac_lo:DWORD
    mov eax, [sign]
    and eax, 1
    shl eax, 31

    mov ecx, [exp]
    add ecx, 1023
    and ecx, 0x7FF
    shl ecx, 20
    or  eax, ecx

    mov ecx, [frac_hi]
    and ecx, 0xFFFFF
    or  eax, ecx

    mov edx, [frac_lo]

    mov esi, [pOutput]
    mov [esi], edx
    mov [esi + 4], eax
    ret
endp

proc main
    cinvoke puts, '*** main1 ***'
    local num1:QWORD
    stdcall build_float64_v1, addr num1, 0, 6, 0xEC000, 0x00000000 ; 123.0
    cinvoke printf, fmt_f, dword [num1], dword [num1 + 4]
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
