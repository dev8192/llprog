format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    num1        dt -1.0
    num1_len    = $ - num1
    fmt_d       db '%d', 10, 0

include '../../util/print_bytes.data.inc'

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, eax

include '../../util/print_bytes.text.inc'

proc main1
    cinvoke puts, '*** main1 ***'
    cinvoke printf, fmt_d, num1_len
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    locals
        num1 dt 0.0
        num2 rb 10
    endl
    fld1
    fstp [num1]
    stdcall print_bytes, addr num1, 10
    fld1
    fstp tbyte [num2]
    stdcall print_bytes, addr num2, 10
    ret
endp

proc main
    cinvoke puts, '*** main3 ***'
    locals
        num1 db 20 dup(-1)
        num2 db 20 dup(-1)
    endl
    stdcall print_bytes, addr num1, 30
    fldz
    fstp tbyte [num1]
    stdcall print_bytes, addr num1, 30
    fldz
    fstp tbyte [num1 + 10]
    stdcall print_bytes, addr num1, 30
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
