format binary as 'txt'

macro create_fp_array2 name, [type, val] {
    common
        display name, 10
    forward
    display '0', 10
}

macro main1 {
    display '*** main1 ***', 10
    create_fp_array2, 'arr',\
        db, 1,\
        db, 2,\
        db, 3,\
        db, 4,\
        db, 5,\
        db, 6
}

macro print_text name, [size, arg] {
    common
        local count
        count = 0
    forward
        count = count + 1
        label1 = '0' + count
        name#name size 'A' + arg, 10
    common
        display '0' + count, 10
}

macro main {
    display '*** main2 ***', 10
    print_text one,\
        db, 23,\
        db, 24,\
        db, 25
}

main
