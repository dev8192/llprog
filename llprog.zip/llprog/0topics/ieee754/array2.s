format ELF use32 ; Or 'format PE console' depending on your OS

section '.text' executable
public main
main:
    finit               ; Initialize FPU
    fldz                ; ST0 = 0.0 (This will accumulate our sum)

    mov ecx, [arr2_len] ; Total number of items to process
    xor ebx, ebx        ; Index offset for our arrays (starts at 0)

.loop_start:
    cmp ecx, 0
    je .loop_done       ; Exit if we processed all elements

    ; 1. Get the address of the number from arr2
    ;    ebx * 4 moves through the 32-bit address pointers
    mov esi, [arr2 + ebx*4]

    ; 2. Check the size map to see if it is a DD (4) or DQ (8)
    mov al, [size_map + ebx]
    cmp al, 4
    je .load_32bit

.load_64bit:
    fld qword [esi]     ; Correctly loads the 64-bit float from address in ESI
    jmp .do_math

.load_32bit:
    fld dword [esi]     ; Correctly loads the 32-bit float from address in ESI

.do_math:
    ; Stack right now: ST0 = current number, ST1 = running sum
    faddp st1, st0      ; Add current number to sum and pop ST0.
                        ; New ST0 is our updated running sum.

    inc ebx             ; Move to next element index
    dec ecx             ; Decrement loop counter
    jmp .loop_start

.loop_done:
    ; ST0 now contains the exact total sum: 1.0 + 2.0 + 3.0 + 4.0 = 10.0
    fstp st0            ; Clean up FPU stack
    ret

section '.data' writeable
    ; Raw data values (scattered sizes)
    num1        dd 1.0
    num2        dq 2.0
    num3        dd 3.0
    num4        dq 4.0

    ; Array of 32-bit pointers pointing to the variables above
    arr2        dd num1, num2, num3, num4
    arr2_len    dd ($ - arr2) / 4

    ; A parallel size map tracking the byte size of each index sequentially
    size_map    db 4, 8, 4, 8 
