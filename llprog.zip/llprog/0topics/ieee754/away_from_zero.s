; Round to Nearest, Away-from-Zero
; commercial rounding
; standard schoolbook rounding
format PE
entry start

include 'win32ax.inc'

SIGN_MASK = 0x80000000
HALF_MASK = 0x3f000000

section '.data' data readable writeable
    fmt_d       db '%d', 10, 0
    fmt_fd      db '%.1f --> %d', 10, 0
    fmt_x       db '%x', 10, 0
    fmt_f       db '%.1f', 10, 0
    arr1:       dd 10.0, 10.1, 10.2, 10.3, 10.4, 10.5, 10.6, 10.7, 10.8, 10.9
                dd 11.0, 11.1, 11.2, 11.3, 11.4, 11.5, 11.6, 11.7, 11.8, 11.9
                dd 12.0, 12.1, 12.2, 12.3, 12.4, 12.5
    arr1_len    = ($ - arr1) / 4

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, eax

proc round_to_nearest_away_from_zero, num
    local res:DWORD
    mov eax, [num]
    and eax, SIGN_MASK
    or eax, HALF_MASK
    mov [res], eax
    fld [num]
    fadd [res]
    fistp [res]
    mov eax, [res]
    ret
endp

proc main1
    cinvoke puts, '*** main1 ***'
    locals
        num1 dd 0.5
    endl
    cinvoke printf, fmt_x, [num1]
    ret
endp

proc main5
    cinvoke puts, '*** main5 ***'
    locals
        num1     dd 13.6
        num2     dd -13.6
    endl
    local fpu_cw:WORD
    fstcw [fpu_cw]
    or word [fpu_cw], 0xC00
    fldcw [fpu_cw]
    stdcall round_to_nearest_away_from_zero, [num1]
    cinvoke printf, fmt_d, eax
    stdcall round_to_nearest_away_from_zero, [num2]
    cinvoke printf, fmt_d, eax
    ret
endp

proc main uses ebx esi
    cinvoke puts, '*** main6 ***'
    local out:QWORD
    local fpu_cw:WORD
    fstcw [fpu_cw]
    or word [fpu_cw], 0xC00
    fldcw [fpu_cw]
    mov ebx, arr1_len
    mov esi, arr1
.loop:
    stdcall round_to_nearest_away_from_zero, dword [esi]
    fld dword [esi]
    fstp [out]
    cinvoke printf, fmt_fd, dword [out], dword [out + 4], eax
    add esi, 4
    dec ebx
    jnz .loop
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'

