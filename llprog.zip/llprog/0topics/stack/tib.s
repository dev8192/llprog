format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    low_limit       dd ?
    high_limit      dd ?
    stack_size      dd ?
    fmt_xn          db '%x', 10, 0
    fmt_dn          db '%d', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main11
    cinvoke puts, '*** main11 ***'
    invoke GetCurrentThreadStackLimits, low_limit, high_limit
    cinvoke printf, fmt_xn, [low_limit]
    cinvoke printf, fmt_xn, esp
    cinvoke printf, fmt_xn, [high_limit]

    cinvoke puts, '*** Thread Information Block ***'
    mov eax, [fs:0x08]
    cinvoke printf, fmt_xn, eax
    mov eax, [fs:0x04]
    cinvoke printf, fmt_xn, eax
    mov eax, [fs:0x04]
    sub eax, [fs:0x08]
    cinvoke printf, fmt_dn, eax
    cinvoke printf, fmt_xn, dword [fs:0x08]
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    push ebp
    mov ebp, esp

    cinvoke printf, fmt_xn, dword [fs:0x08]

   ;cinvoke printf, fmt_xn, esp
   ;mov eax, esp
   ;sub eax, [fs:0x08]
   ;cinvoke printf, fmt_dn, eax

    sub esp, 8048
   ;sub esp, 8044
    mov dword [esp], 123
    cinvoke printf, fmt_xn, dword [fs:0x08]
    cinvoke printf, fmt_xn, dword [fs:0x08]

    sub esp, 8048 + 4 * 36
   ;sub esp, 8048 + 4 * 35
    mov dword [esp], 123
    cinvoke printf, fmt_xn, dword [fs:0x08]
    cinvoke printf, fmt_xn, dword [fs:0x08]
    
    mov esp, ebp
    pop ebp
    ret
endp

section '.idata' import data readable
    library kernel32,                       'kernel32.dll',\
            msvcrt,                         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,                    'ExitProcess',\
            GetCurrentThreadStackLimits,    'GetCurrentThreadStackLimits'
    import  msvcrt,\
            printf,                         'printf',\
            puts,                           'puts'
