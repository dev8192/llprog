format PE console
entry start

include 'win32a.inc'

struct WINUSB_SETUP_PACKET
    RequestType   db ?
    Request       db ?
    Value         dw ?
    Index         dw ?
    Length        dw ?
ends

section '.data' data readable writeable
    hDevice             dd ?
    hWinusbInterface    dd ?
    bytes_transferred   dd ?
    device_path         db '\\.\USB#VID_1234&PID_5678#5&3a1a2b3c&0&1#{a5dcbf10-6530-11d2-901f-00c04fb951ed}', 0
    setup_pkt           WINUSB_SETUP_PACKET

; TODO: Find the device using SetupDi API functions via its GUID

section '.text' code readable executable
start:
    invoke CreateFile, device_path, GENERIC_WRITE or GENERIC_READ, \
        FILE_SHARE_READ or FILE_SHARE_WRITE, 0, OPEN_EXISTING, FILE_FLAG_OVERLAPPED, 0
    mov [hDevice], eax
    cmp eax, INVALID_HANDLE_VALUE
    je exit_error

    invoke WinUsb_Initialize, [hDevice], hWinusbInterface
    test eax, eax
    jz exit_close_file

    mov [setup_pkt.RequestType], 0x40  ; Host-to-Device | Vendor Specific Type | Device Target
    mov [setup_pkt.Request],     0x42  ; Your custom defined command identifier (e.g., 0x42 = TOGGLE_LED)
    mov [setup_pkt.Value],       1     ; 1 = LED On, 0 = LED Off
    mov [setup_pkt.Index],       0     ; Target interface index
    mov [setup_pkt.Length],      0     ; No extra data payload payload payload payload beyond the header

    invoke WinUsb_ControlTransfer, [hWinusbInterface], setup_pkt, 0, 0, bytes_transferred, 0

    invoke WinUsb_Free, [hWinusbInterface]

exit_close_file:
    invoke CloseHandle, [hDevice]
exit_error:
    invoke ExitProcess, 0


section '.idata' import data readable
    library kernel32,               'kernel32.dll',\
            winusb,                 'winusb.dll'
    import  kernel32,\
            CreateFileA,            'CreateFileA',\
            CloseHandle,            'CloseHandle',\
            ExitProcess,            'ExitProcess'
    import  winusb,\
            WinUsb_Initialize,      'WinUsb_Initialize',\
            WinUsb_ControlTransfer, 'WinUsb_ControlTransfer',\
            WinUsb_Free,            'WinUsb_Free'
