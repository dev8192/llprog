format PE
entry start

include 'win32ax.inc'

SHA512_BLOCK_SIZE equ 128
SHA512_ROUNDS equ 80
BIT_SHIFT_MULTIPLIER equ 3

section '.data' data readable writeable
    str1            db 'abc', 0
    str1_len        = $ - str1 - 1
    expected1       db 'fff'
                    db 'fff'
                    db 'fff'
                    db 'fff', 0

    str2            db 'The quick brown fox jumps over the lazy dog', 0
    str2_len        = $ - str2 - 1
    expected2       db '07e547d9586f6a73f73fbac0435ed769'
                    db '51218fb7d0c8d788a309d785436bbb64'
                    db '2e93a252a954f23912547d1e8a3b5ed6'
                    db 'e1bfd7097821233fa0538f3db854fee6', 0

    output_format   db '%08x%08x%08x%08x'
                    db '%08x%08x%08x%08x'
                    db '%08x%08x%08x%08x'
                    db '%08x%08x%08x%08x', 0

    buffer          db 128 dup(0)
    buffer_len      dd 0
    total_len_low   dd 0
    total_len_high  dd 0

    H0_low          dd 0
    H0_high         dd 0
    H1_low          dd 0
    H1_high         dd 0
    H2_low          dd 0
    H2_high         dd 0
    H3_low          dd 0
    H3_high         dd 0
    H4_low          dd 0
    H4_high         dd 0
    H5_low          dd 0
    H5_high         dd 0
    H6_low          dd 0
    H6_high         dd 0
    H7_low          dd 0
    H7_high         dd 0

    a_low           dd 0
    a_high          dd 0
    b_low           dd 0
    b_high          dd 0
    c_low           dd 0
    c_high          dd 0
    d_low           dd 0
    d_high          dd 0
    e_low           dd 0
    e_high          dd 0
    f_low           dd 0
    f_high          dd 0
    g_low           dd 0
    g_high          dd 0
    h_low           dd 0
    h_high          dd 0

    T1_low          dd 0
    T1_high         dd 0
    T2_low          dd 0
    T2_high         dd 0
    tmp_low         dd 0
    tmp_high        dd 0

    W_array         rd 160

    K_array:
        dd 0xd728ae22, 0x428a2f98, 0x23ef65cd, 0x71374491
        dd 0xec4d3b2f, 0xb5c0fbcf, 0x8189dbbc, 0xe9b5dba5
        dd 0xf348b538, 0x3956c25b, 0xb605d019, 0x59f111f1
        dd 0xaf194f9b, 0x923f82a4, 0xda6d8118, 0xab1c5ed5
        dd 0xa3030242, 0xd807aa98, 0x45706fbe, 0x12835b01
        dd 0x4ee4b28c, 0x243185be, 0xd5ffb4e2, 0x550c7dc3
        dd 0xf27b896f, 0x72be5d74, 0x3b1696b1, 0x80deb1fe
        dd 0x25c71235, 0x9bdc06a7, 0xc19bf174, 0xcf692694
        dd 0xe49b69c1, 0x9ef14ad2, 0xefbe4786, 0x384f25e3
        dd 0x0fc19dc6, 0x8b8cd5b5, 0x240ca1cc, 0x77ac9c65
        dd 0x2de92c6f, 0x592b0275, 0x4a7484aa, 0x6ea6e483
        dd 0x5cb0a9dc, 0xbd41fbd4, 0x76f988da, 0x831153b5
        dd 0x983e5152, 0xee66dfab, 0xa831c66d, 0x2db43210
        dd 0xb00327c8, 0x98fb213f, 0xbf597fc7, 0xbeef0ee4
        dd 0xc6e00bf3, 0x3da88fc2, 0xd5a79147, 0x930aa725
        dd 0x06ca6351, 0xe003826f, 0x14292967, 0x0a0e6e70
        dd 0x27b70a85, 0x46d22ffc, 0x2e1b2138, 0x5c26c926
        dd 0x4d2c6dfc, 0x5ac42aed, 0x53380d13, 0x9d95b3df
        dd 0x650a7354, 0x8baf63de, 0x766a0abb, 0x3c77b2a8
        dd 0x81c2c92e, 0x47edaee6, 0x92722c85, 0x1482353b
        dd 0xa2bfe8a1, 0x4cf10364, 0xa81a664b, 0xbc423001
        dd 0xc24b8b70, 0xd0f89791, 0xc76c51a3, 0x0654be30
        dd 0xd192e819, 0xd6ef5218, 0xd6990624, 0x5565a910
        dd 0xf40e3585, 0x5771202a, 0x106aa070, 0x32bbd1b8
        dd 0x19a4c116, 0xb8d2d0c8, 0x1e376c08, 0x5141ab53
        dd 0x2748774c, 0xdf8eeb99, 0x34b0bcb5, 0xe19b48a8
        dd 0x391c0cb3, 0xc5c95a63, 0x4ed8aa4a, 0xe3418acb
        dd 0x5b9cca4f, 0x7763e373, 0x682e6ff3, 0xd6b2b8a3
        dd 0x748f82ee, 0x5defb2fc, 0x78a5636f, 0x43172f60
        dd 0x84c87814, 0xa1f0ab72, 0x8cc70208, 0x1a6439ec
        dd 0x90befffa, 0x23631e28, 0xa4506ceb, 0xde82bde9
        dd 0xbef9a3f7, 0xb2c67915, 0xc67178f2, 0xe372532b
        dd 0xca273ece, 0xea26619c, 0xd186b8c7, 0x21c0c207
        dd 0xeada7dd6, 0xcde0eb1e, 0xf57d4f7f, 0xee6ed178
        dd 0x06f067aa, 0x72be5c74, 0x0a637dc5, 0xa2c898a6
        dd 0x113f9804, 0xbef90dae, 0x1b710b35, 0x131c471b
        dd 0x28db77f5, 0x23047d84, 0x32caab7b, 0x40c72493
        dd 0x3c9ebe0a, 0x15c9bebc, 0x431d67c4, 0x9c100d4c
        dd 0x4cc5d4be, 0xcb3e42b6, 0x597f299c, 0xfc657e2a
        dd 0x5fcb6fab, 0x3ad6faec, 0x6c44198c, 0x4a475817

include 'sha512.data.inc'

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

include 'sha512.text.inc'

proc main
    cinvoke puts, '*** main1 ***'
    local buf1[129]:BYTE
    stdcall sha512_init
    cinvoke wsprintf, addr buf1, output_format, \
        [H0_high], [H0_low], [H1_high], [H1_low], \
        [H2_high], [H2_low], [H3_high], [H3_low], \
        [H4_high], [H4_low], [H5_high], [H5_low], \
        [H6_high], [H6_low], [H7_high], [H7_low]
    cinvoke puts, addr buf1
    ret
endp

proc sha512, buf, buf_size
    local buf1[129]:BYTE
    stdcall sha512_init
    stdcall sha512_update, test_string, test_string_len
    stdcall sha512_final
    cinvoke wsprintf, addr buf1, output_format, \
        [H0_high], [H0_low], [H1_high], [H1_low], \
        [H2_high], [H2_low], [H3_high], [H3_low], \
        [H4_high], [H4_low], [H5_high], [H5_low], \
        [H6_high], [H6_low], [H7_high], [H7_low]
    cinvoke puts, addr buf1
    ret
endp

proc main10
    cinvoke puts, '*** main10 ***'
    stdcall sha512, str1, str1_len
    stdcall sha512, str2, str2_len
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            user32,         'user32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  user32,\
            wsprintf,       'wsprintfA'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
