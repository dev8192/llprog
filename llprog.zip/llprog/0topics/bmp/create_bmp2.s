format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable

    fname db 'image.bmp', 0
    fmode db 'wb', 0

    bfh BITMAPFILEHEADER bfType:'BM', bfSize:196662, bfOffBits:54
    bih BITMAPINFOHEADER biSize:40, biWidth:256, biHeight:256, biPlanes:1, biBitCount:24, biSizeImage:196608

section '.bss' readable writeable

    pixels rb 196608

section '.text' code readable executable

start:
    mov edi, pixels
    mov ecx, 65536
    xor eax, eax
.fill:
    mov [edi], al
    mov [edi+1], ah
    mov byte [edi+2], 255
    add edi, 3
    inc eax
    loop .fill

    cinvoke fopen, fname, fmode
    test eax, eax
    jz .exit
    mov ebx, eax

    cinvoke fwrite, bfh, 1, 14, ebx
    cinvoke fwrite, bih, 1, 40, ebx
    cinvoke fwrite, pixels, 1, 196608, ebx
    cinvoke fclose, ebx

.exit:
    invoke ExitProcess, 0

section '.idata' import data readable

    library kernel32, 'kernel32.dll',\
        msvcrt, 'msvcrt.dll'

    import kernel32,\
        ExitProcess, 'ExitProcess'

    import msvcrt,\
        fopen, 'fopen',\
        fwrite, 'fwrite',\
        fclose, 'fclose'
