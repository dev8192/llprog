format PE
entry start

include 'win32ax.inc'

BUTTON_ID = 1001
FONT_HEIGHT = 60

section '.data' data readable writeable
    wc                  WNDCLASS
    msg                 MSG
    class_name          db 'ExampleWindow', 0
    window_title        db 'Example Window', 0
    button_class        db 'BUTTON', 0
    button_text         db 'Click Me', 0
    button_text_len     = $ - button_text - 1
    font_name           db 'Consolas', 0
    hFont               dd 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

include '../../../boilerplate/main_window.inc'

proc window_proc hwnd, wmsg, wparam, lparam
    cmp     [wmsg], WM_CREATE
    je      .wm_create
    cmp     [wmsg], WM_COMMAND
    je      .wm_command
    cmp     [wmsg], WM_DESTROY
    je      .wm_destroy
.defproc:
    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret
.wm_create:
    stdcall on_create, [hwnd]
    xor     eax, eax
    ret
.wm_command:
    mov     eax, [wparam]
    and     eax, 0FFFFh
    cmp     eax, BUTTON_ID
    jne     .defproc
    cinvoke puts, 'btn_clicked'
    xor     eax, eax
    ret
.wm_destroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
    ret
endp

proc on_create1, hwnd
    cinvoke puts, '*** on_create1 ***'
    invoke  CreateWindowEx, 0, button_class, button_text,\
            WS_CHILD or WS_VISIBLE or BS_PUSHBUTTON,\
            50, 50, 100, 30, [hwnd], BUTTON_ID, [wc.hInstance], 0
    ret
endp

proc on_create2, hwnd
    cinvoke puts, '*** on_create2 ***'
    local hButton:DWORD
    invoke  CreateWindowEx, 0, button_class, button_text,\
            WS_CHILD or WS_VISIBLE or BS_PUSHBUTTON,\
            50, 50, 300, 70, [hwnd], BUTTON_ID, [wc.hInstance], 0
    mov [hButton], eax
    invoke  CreateFont, FONT_HEIGHT, 0, 0, 0, FW_BOLD, 0, 0, 0,\
            DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,\
            DEFAULT_QUALITY, FIXED_PITCH, font_name
    mov [hFont], eax
    invoke SendMessage, [hButton], WM_SETFONT, [hFont], TRUE
    ret
endp

include '../../../boilerplate/create_button.inc'

proc on_create uses ebx, hwnd
    cinvoke puts, '*** on_create3 ***'
    stdcall create_button, [hwnd], FONT_HEIGHT
    ret
endp

section '.idata' import data readable
    library kernel32,               'kernel32.dll',\
            user32,                 'user32.dll',\
            gdi32,                  'gdi32.dll',\
            msvcrt,                 'msvcrt.dll'
    import  kernel32,\
            ExitProcess,            'ExitProcess',\
            GetModuleHandle,        'GetModuleHandleA'
    import  user32,\
            CreateWindowEx,         'CreateWindowExA',\
            DefWindowProc,          'DefWindowProcA',\
            DispatchMessage,        'DispatchMessageA',\
            GetMessage,             'GetMessageA',\
            LoadCursor,             'LoadCursorA',\
            PostQuitMessage,        'PostQuitMessage',\
            RegisterClass,          'RegisterClassA',\
            SendMessage,            'SendMessageA',\
            GetDC,                  'GetDC',\
            ReleaseDC,              'ReleaseDC'
    import  gdi32,\
            CreateFont,             'CreateFontA',\
            SelectObject,           'SelectObject',\
            GetTextExtentPoint32,   'GetTextExtentPoint32A'
    import  msvcrt,\
            printf,                 'printf',\
            puts,                   'puts'
