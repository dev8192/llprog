format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    btnClass        db 'BUTTON', 0
    btn_text        db 'Click me', 0
    btn_text_len    = $ - btn_text - 1
    oldBtnProc      dd ?
    fmt_d           db '%d', 10, 0
    fmt_dd          db '%d %d', 10, 0
    fontName        db 'Segoe UI', 0
    hFont           dd ?

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc create_button1 uses ebx
    cinvoke puts, '*** create_button1 ***'
    invoke  GetModuleHandle, 0
    invoke  CreateWindowEx, 0, btnClass, btn_text, WS_VISIBLE,\
            0, 0, 120, 80, 0, 0, eax, 0
    mov     ebx, eax
    invoke  ShowWindow, ebx, SW_SHOWDEFAULT
   ;invoke  UpdateWindow, ebx
    mov     eax, ebx
    ret
endp

proc create_button2
    cinvoke puts, '*** create_button2 ***'
    invoke  GetModuleHandle, 0
    invoke  CreateWindowEx, WS_EX_TOPMOST, btnClass, btn_text,\
            WS_VISIBLE,\
            0, 0, 120, 80, 0, 0, eax, 0
    ret
endp

proc create_button3
    cinvoke puts, '*** create_button3 ***'
    invoke  GetModuleHandle, 0
    invoke  CreateWindowEx, WS_EX_TOPMOST, btnClass, btn_text,\
            WS_VISIBLE or BS_PUSHBUTTON,\
            0, 0, 120, 80, 0, 0, eax, 0
    ret
endp

proc create_button4
    cinvoke puts, '*** create_button4 ***'
    invoke  GetModuleHandle, 0
    invoke  CreateWindowEx, WS_EX_TOPMOST, btnClass, btn_text,\
            WS_VISIBLE or WS_POPUP,\
            0, 0, 120, 40, 0, 0, eax, 0
    ret
endp

proc create_button5 uses ebx
    cinvoke puts, '*** create_button5 ***'
    local btnX:DWORD, btnY:DWORD, btnHeight:DWORD, btnWidth:DWORD
    local textSize:SIZE

    invoke  GetDC, 0
    mov     ebx, eax
    invoke  GetTextExtentPoint32, ebx, btn_text, btn_text_len, addr textSize
    invoke  ReleaseDC, 0, ebx

   ;PAD_X = 25
   ;PAD_Y = 12

    PAD_X = 0
    PAD_Y = 0

    mov     eax, [textSize.cx]
    add     eax, PAD_X * 2
    mov     [btnWidth], eax
    
    mov     eax, [textSize.cy]
    add     eax, PAD_Y * 2
    mov     [btnHeight], eax

    invoke  GetSystemMetrics, SM_CXSCREEN
    sub     eax, [btnWidth]
    sar     eax, 1
    mov     [btnX], eax

    invoke  GetSystemMetrics, SM_CYSCREEN
    sub     eax, [btnHeight]
    sar     eax, 1
    mov     [btnY], eax

    invoke  GetModuleHandle, 0
    invoke  CreateWindowEx, WS_EX_TOPMOST, btnClass, btn_text,\
            WS_POPUP or WS_VISIBLE,\
            [btnX], [btnY], [btnWidth], [btnHeight],\
            0, 0, eax, 0
    ret
endp

FONT_SIZE = -20

proc create_button uses ebx
    cinvoke puts, '*** create_button6 ***'
    local btnX:DWORD, btnY:DWORD, btnHeight:DWORD, btnWidth:DWORD
    local textSize:SIZE, hwnd:DWORD

    invoke CreateFont, FONT_SIZE, 0, 0, 0, FW_NORMAL, 0, 0, 0,\
        DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,\
        DEFAULT_QUALITY, DEFAULT_PITCH, fontName
    mov     [hFont], eax

    invoke  GetDC, 0
    mov     ebx, eax
    invoke  SelectObject, ebx, [hFont]
    push    eax
    invoke  GetTextExtentPoint32, ebx, btn_text, btn_text_len, addr textSize
    pop     eax
    invoke  SelectObject, ebx, eax
    invoke  ReleaseDC, 0, ebx

   ;PAD_X = 25
   ;PAD_Y = 12

    PAD_X = 100
    PAD_Y = 100

    mov     eax, [textSize.cx]
    add     eax, PAD_X * 2
    mov     [btnWidth], eax
    
    mov     eax, [textSize.cy]
    add     eax, PAD_Y * 2
    mov     [btnHeight], eax

    invoke  GetSystemMetrics, SM_CXSCREEN
    sub     eax, [btnWidth]
    sar     eax, 1
    mov     [btnX], eax

    invoke  GetSystemMetrics, SM_CYSCREEN
    sub     eax, [btnHeight]
    sar     eax, 1
    mov     [btnY], eax

    invoke  GetModuleHandle, 0
    invoke  CreateWindowEx, WS_EX_TOPMOST, btnClass, btn_text,\
            WS_POPUP or WS_VISIBLE,\
            [btnX], [btnY], [btnWidth], [btnHeight],\
            0, 0, eax, 0
    mov     [hwnd], eax
    invoke  SendMessage, [hwnd], WM_SETFONT, [hFont], TRUE
    mov     [textSize.cx], 0
    mov     [textSize.cy], 0
    mov     eax, [hwnd]
    ret
endp

proc msg_loop1, hwnd
    cinvoke puts, '*** msg_loop1 ***'
    local msg:MSG
.loop:
    invoke  GetMessage, addr msg, 0, 0, 0
    test    eax, eax
    jz      .exit
    invoke  TranslateMessage, addr msg
    invoke  DispatchMessage, addr msg
    jmp     .loop
.exit:
    ret
endp

proc msg_loop2, hwnd
    cinvoke puts, '*** msg_loop2 ***'
    local msg:MSG
.loop:
    invoke  GetMessage, addr msg, 0, 0, 0
    test    eax, eax
    jz      .exit
    invoke  TranslateMessage, addr msg
    invoke  DispatchMessage, addr msg
    jmp     .loop
.exit:
    invoke  DeleteObject, [hFont]
    ret
endp


proc msg_loop3, hwnd
    cinvoke puts, '*** msg_loop3 ***'
    local msg:MSG
.loop:
    invoke  GetMessage, addr msg, 0, 0, 0
    test    eax, eax
    jz      .exit
    cmp     [msg.message], WM_LBUTTONUP
    jne     .dispatch_msg
    mov     eax, [msg.hwnd]
    cmp     eax, [hwnd]
    je      .exit
.dispatch_msg:
    invoke  TranslateMessage, addr msg
    invoke  DispatchMessage, addr msg
    jmp     .loop
.exit:
    ret
endp

proc ButtonProc hwnd, wmsg, wparam, lparam
    cmp     [wmsg], WM_LBUTTONUP
    je      .wm_lbuttonup
    cmp     [wmsg], WM_KEYDOWN
    je      .wm_keydown
    cmp     [wmsg], WM_DESTROY
    je      .wm_destroy
.default_processing:
    invoke  CallWindowProc, [oldBtnProc], [hwnd], [wmsg], [wparam], [lparam]
    jmp     .finish
.wm_lbuttonup:
    invoke  DestroyWindow, [hwnd]
    xor     eax, eax
    jmp     .finish
.wm_keydown:
    cmp     [wparam], VK_SPACE
    je      .wm_lbuttonup
    cmp     [wparam], VK_RETURN
    je      .wm_lbuttonup
    jmp     .default_processing
.wm_destroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
.finish:
    ret
endp

proc main1
    cinvoke puts, '*** main1 ***'
    stdcall create_button
    stdcall msg_loop3, eax
    ret
endp

proc main
    cinvoke puts, '*** main2 ***'
    local hwnd:DWORD
    stdcall create_button
    mov     [hwnd], eax
    invoke  SetWindowLong, [hwnd], GWL_WNDPROC, ButtonProc
    mov     [oldBtnProc], eax
    invoke  SetFocus, 0
    stdcall msg_loop2, [hwnd]
    ret
endp

section '.idata' import data readable
    library kernel32,               'kernel32.dll',\
            user32,                 'user32.dll',\
            gdi32,                  'gdi32.dll',\
            msvcrt,                 'msvcrt.dll'
    import  kernel32,\
            GetModuleHandle,        'GetModuleHandleA',\
            ExitProcess,            'ExitProcess'
    import  user32,\
            CreateWindowEx,         'CreateWindowExA',\
            GetSystemMetrics,       'GetSystemMetrics',\
            GetMessage,             'GetMessageA',\
            TranslateMessage,       'TranslateMessage',\
            DispatchMessage,        'DispatchMessageA',\
            ShowWindow,             'ShowWindow',\
            UpdateWindow,           'UpdateWindow',\
            SetWindowLong,          'SetWindowLongA',\
            CallWindowProc,         'CallWindowProcA',\
            DestroyWindow,          'DestroyWindow',\
            PostQuitMessage,        'PostQuitMessage',\
            GetDC,                  'GetDC',\
            ReleaseDC,              'ReleaseDC',\
            SetFocus,               'SetFocus',\
            SendMessage,            'SendMessageA'
    import  gdi32,\
            CreateFont,             'CreateFontA',\
            DeleteObject,           'DeleteObject',\
            GetTextExtentPoint32,   'GetTextExtentPoint32A',\
            SelectObject,           'SelectObject'
    import  msvcrt,\
            printf,                 'printf',\
            puts,                   'puts'
