format PE
entry start

include 'win32ax.inc'

macro DEFINE_MESSAGES [id, id2, name] {
common
    msg_table:
forward
    dd id, .str_#name
common
    MSG_COUNT = ($ - msg_table) / 8
forward
    .str_#name db `name, 0
common
    .str_unknown db '???', 0
}

section '.data' data readable writeable
    wc                  WNDCLASS
    msg                 MSG
    class_name          db 'ExampleWindow', 0
    window_title        db 'Example Window', 0
    fmt_wmsg            db '%10d %8x %s', 10, 0
    fmt_d               db '%d', 10, 0

ignore_list1:
    dd WM_SETCURSOR
    dd WM_MOUSEMOVE
    dd WM_NCHITTEST
ignore_list1_len = ($ - ignore_list1) / 4

include 'messages.inc'

section '.text' code readable executable
start:
    invoke  GetModuleHandle, 0
    mov     [wc.hInstance], eax
    mov     [wc.lpfnWndProc], window_proc
    invoke  LoadCursor, 0, IDC_ARROW
    mov     [wc.hCursor], eax
    mov     [wc.hbrBackground], COLOR_WINDOW + 1
    mov     [wc.lpszClassName], class_name
    invoke  RegisterClass, wc

    cinvoke puts, '*************** before ***************'
    invoke  CreateWindowEx, 0, class_name, window_title,\
            WS_OVERLAPPEDWINDOW + WS_VISIBLE,\
            CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,\
            0, 0, [wc.hInstance], 0
    cinvoke puts, '*************** after ***************'

.msg_loop:
    invoke  GetMessage, msg, 0, 0, 0
    test    eax, eax
    jz      .end_loop
    invoke  DispatchMessage, msg
    jmp     .msg_loop
.end_loop:
    invoke  ExitProcess, [msg.wParam]

; ------------------------------ window_proc ------------------------------
proc window_proc hwnd, wmsg, wparam, lparam
   ;stdcall simple_logger, [wmsg]
   ;stdcall skip_messages, [wmsg]
    stdcall find_new_messages, [wmsg]

    cmp     [wmsg], WM_DESTROY
    je      .wm_destroy
    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret

.wm_destroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
    ret
endp

proc get_message_name msg_id
    mov ecx, MSG_COUNT
    mov edx, msg_table
.search:
    mov eax, [edx]
    cmp eax, [msg_id]
    je .found
    add edx, 8
    loop .search
    mov eax, msg_table.str_unknown
    ret
.found:
    mov eax, [edx + 4]
    ret
endp

; ------------------------------ loggers ------------------------------
proc simple_logger, wmsg
    stdcall get_message_name, [wmsg]
    cinvoke printf, fmt_wmsg, [wmsg], [wmsg], eax
    ret
endp

proc skip_messages, wmsg
    mov ecx, ignore_list1_len
    mov eax, [wmsg]
    mov edx, ignore_list1
.loop:
    cmp [edx], eax
    je .exit
    add edx, 4
    loop .loop
    stdcall get_message_name, [wmsg]
    cinvoke printf, fmt_wmsg, [wmsg], [wmsg], eax
.exit:
    ret
endp

proc find_new_messages, wmsg
    stdcall get_message_name, [wmsg]
    cmp eax, msg_table.str_unknown
    jnz .exit
    cinvoke printf, fmt_wmsg, [wmsg], [wmsg], eax
.exit:
    ret
endp

section '.idata' import data readable
library kernel32,           'kernel32.dll',\
        user32,             'user32.dll',\
        msvcrt,             'msvcrt.dll'
import  kernel32,\
        ExitProcess,        'ExitProcess',\
        GetModuleHandle,    'GetModuleHandleA'
import  user32,\
        CreateWindowEx,     'CreateWindowExA',\
        DefWindowProc,      'DefWindowProcA',\
        DispatchMessage,    'DispatchMessageA',\
        GetMessage,         'GetMessageA',\
        LoadCursor,         'LoadCursorA',\
        PostQuitMessage,    'PostQuitMessage',\
        RegisterClass,      'RegisterClassA'
import  msvcrt,\
        printf,             'printf',\
        puts,               'puts'
