format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    wc          WNDCLASS
    msg         MSG
    hwnd        dd ?
    hFont       dd ?
    hOldFont    dd ?
    ps          PAINTSTRUCT
    rect        RECT
    buffer      rb 64
    fmt         db '%d x %d', 0
    log_wmpaint db 'wmpaint: %d x %d', 10, 0
    log_wmsize  db 'wmsize: %d x %d', 10, 0
    className   db 'SizeWindow', 0
    titleName   db 'Window Dimensions', 0
    win_width   dd ?
    win_height  dd ?

section '.text' code readable executable
start:
    mov     [wc.style], CS_HREDRAW or CS_VREDRAW
    mov     [wc.lpfnWndProc], WindowProc
    invoke  GetModuleHandle, 0
    mov     [wc.hInstance], eax
    invoke  LoadCursor, 0, IDC_ARROW
    mov     [wc.hCursor], eax
    mov     [wc.hbrBackground], COLOR_WINDOW + 1
    mov     [wc.lpszClassName], className
    invoke  RegisterClass, wc

    WIN_WIDTH = 500 + 8 * 2
    WIN_HEIGHT = 500 + 8 + 31
    invoke  CreateWindowEx, 0, className, titleName,\
        WS_OVERLAPPEDWINDOW or WS_VISIBLE,\
        CW_USEDEFAULT, CW_USEDEFAULT, WIN_WIDTH, WIN_HEIGHT,\
        0, 0, [wc.hInstance], 0
    mov     [hwnd], eax

.msg_loop:
    invoke  GetMessage, msg, 0, 0, 0
    test    eax, eax
    jle     .end_loop
    invoke  DispatchMessage, msg
    jmp     .msg_loop

.end_loop:
    invoke  ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp     [wmsg], WM_CREATE
    je      .wm_create
    cmp     [wmsg], WM_SIZE
    je      .wm_size
    cmp     [wmsg], WM_PAINT
    je      .wm_paint
    cmp     [wmsg], WM_DESTROY
    je      .wm_destroy

.defwndproc:
    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret

.wm_create:
    invoke CreateFont, \
        30, \                    ; int nHeight
        20, \                    ; int nWidth
        0, \                     ; int nEscapement
        0, \                     ; int nOrientation
        FW_BOLD, \               ; int fnWeight
        0, \                     ; DWORD fdwItalic
        0, \                     ; DWORD fdwUnderline
        0, \                     ; DWORD fdwStrikeOut
        DEFAULT_CHARSET, \       ; DWORD fdwCharSet
        OUT_DEFAULT_PRECIS, \    ; DWORD fdwOutputPrecision
        CLIP_DEFAULT_PRECIS, \   ; DWORD fdwClipPrecision
        DEFAULT_QUALITY, \       ; DWORD fdwQuality
        DEFAULT_PITCH or\ 
        FF_DONTCARE, \           ; DWORD fdwPitchAndFamily
        0                        ; LPCTSTR lpszFace

    mov     [hFont], eax
    xor     eax, eax
    ret

.wm_size:
    mov eax, [lparam]
    movzx ecx, ax 
    shr eax, 16
    mov [win_width], ecx
    mov [win_height], eax
    cinvoke printf, log_wmsize, ecx, eax
    invoke  InvalidateRect, [hwnd], 0, TRUE
    xor     eax, eax
    ret

.wm_paint:
    invoke  BeginPaint, [hwnd], ps
    invoke  GetClientRect, [hwnd], rect
    cinvoke printf, log_wmpaint, [rect.right], [rect.bottom]
    cinvoke wsprintf, buffer, fmt, [rect.right], [rect.bottom]
    invoke  SelectObject, [ps.hdc], [hFont]
    mov     [hOldFont], eax
    ;invoke  SetBkMode, [ps.hdc], TRANSPARENT
    invoke  DrawText, [ps.hdc], buffer, -1, rect,\
        DT_CENTER or DT_VCENTER or DT_SINGLELINE
    invoke  SelectObject, [ps.hdc], [hOldFont]
    invoke  EndPaint, [hwnd], ps
    xor     eax, eax
    ret

.wm_destroy:
    invoke  DeleteObject, [hFont]
    invoke  PostQuitMessage, 0
    xor     eax, eax
    ret
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            user32,             'user32.dll',\
            gdi32,              'gdi32.dll',\
            msvcrt,             'msvcrt.dll'
    import  kernel32,\
            ExitProcess,        'ExitProcess',\
            GetModuleHandle,    'GetModuleHandleA'
    import  user32,\
            BeginPaint,         'BeginPaint',\
            CreateWindowEx,     'CreateWindowExA',\
            DefWindowProc,      'DefWindowProcA',\
            DispatchMessage,    'DispatchMessageA',\
            DrawText,           'DrawTextA',\
            EndPaint,           'EndPaint',\
            GetClientRect,      'GetClientRect',\
            GetMessage,         'GetMessageA',\
            InvalidateRect,     'InvalidateRect',\
            LoadCursor,         'LoadCursorA',\
            PostQuitMessage,    'PostQuitMessage',\
            RegisterClass,      'RegisterClassA',\
            wsprintf,           'wsprintfA'
    import  gdi32,\
            CreateFont,         'CreateFontA',\
            DeleteObject,       'DeleteObject',\
            SelectObject,       'SelectObject',\
            SetBkMode,          'SetBkMode'
    import  msvcrt,\
            printf,             'printf'
