format PE
entry start

include 'win32a.inc'

NUM_CELLS = 9
GRID_ROWS = 3
GRID_COLS = 3

FMT_TL = DT_TOP or DT_LEFT or DT_SINGLELINE
FMT_TC = DT_TOP or DT_CENTER or DT_SINGLELINE
FMT_TR = DT_TOP or DT_RIGHT or DT_SINGLELINE
FMT_ML = DT_VCENTER or DT_LEFT or DT_SINGLELINE
FMT_MC = DT_VCENTER or DT_CENTER or DT_SINGLELINE
FMT_MR = DT_VCENTER or DT_RIGHT or DT_SINGLELINE
FMT_BL = DT_BOTTOM or DT_LEFT or DT_SINGLELINE
FMT_BC = DT_BOTTOM or DT_CENTER or DT_SINGLELINE
FMT_BR = DT_BOTTOM or DT_RIGHT or DT_SINGLELINE

section '.data' data readable writeable
    class_name db 'ExampleWindow', 0
    window_name db 'Example Window', 0
    staticCls db 'STATIC', 0
    wc WNDCLASS
    msg MSG
    hwnd_array dd 9 dup(0)
    cell_w dd ?
    cell_h dd ?

    str0 db 'Top Left', 0
    str1 db 'Top', 0
    str2 db 'Top Right', 0
    str3 db 'Left', 0
    str4 db 'Center', 0
    str5 db 'Right', 0
    str6 db 'Bottom Left', 0
    str7 db 'Bottom', 0
    str8 db 'Bottom Right', 0
    align 4
    text_array:
        dd str0, str1, str2
        dd str3, str4, str5
        dd str6, str7, str8
    format_array:
        dd FMT_TL, FMT_TC, FMT_TR
        dd FMT_ML, FMT_MC, FMT_MR
        dd FMT_BL, FMT_BC, FMT_BR

section '.text' code readable executable
start:
    invoke GetModuleHandle, 0
    mov [wc.hInstance], eax
    mov [wc.style], CS_HREDRAW or CS_VREDRAW
    mov [wc.lpfnWndProc], WindowProc
    invoke LoadCursor, 0, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.hbrBackground], COLOR_WINDOW + 1
    mov [wc.lpszMenuName], 0
    mov [wc.lpszClassName], class_name
    invoke RegisterClass, wc

    invoke CreateWindowEx, 0, class_name, window_name,\
        WS_OVERLAPPEDWINDOW or WS_MAXIMIZE or WS_VISIBLE,\
        CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,\
        0, 0, [wc.hInstance], 0

.msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    cmp eax, 0
    jle .end_loop
    invoke DispatchMessage, msg
    jmp .msg_loop

.end_loop:
    invoke ExitProcess, [msg.wParam]

proc WindowProc uses ebx esi edi, hwnd, wmsg, wparam, lparam
    cmp [wmsg], WM_CREATE
    je .wm_create
    cmp [wmsg], WM_SIZE
    je .wm_size
    cmp [wmsg], WM_DRAWITEM
    je .wm_drawitem
    cmp [wmsg], WM_DESTROY
    je .wm_destroy

.defwindowproc:
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    jmp .finish

.wm_create:
    xor edi, edi
.create_loop:
    invoke CreateWindowEx, 0, staticCls, 0,\
        WS_CHILD or WS_VISIBLE or WS_BORDER or SS_OWNERDRAW,\
        0, 0, 0, 0, [hwnd], edi, [wc.hInstance], 0
    mov [hwnd_array + edi * 4], eax
    inc edi
    cmp edi, NUM_CELLS
    jl .create_loop
    xor eax, eax
    jmp .finish

.wm_size:
    movzx eax, word [lparam]
    xor edx, edx
    mov ecx, GRID_COLS
    div ecx
    mov [cell_w], eax

    movzx eax, word [lparam + 2]
    xor edx, edx
    mov ecx, GRID_ROWS
    div ecx
    mov [cell_h], eax

    xor edi, edi
.size_loop:
    mov eax, edi
    mov ecx, GRID_COLS
    xor edx, edx
    div ecx
    mov ebx, eax
    mov esi, edx
    imul ebx, [cell_h]
    imul esi, [cell_w]
    invoke MoveWindow, [hwnd_array + edi*4],\
        esi, ebx, [cell_w], [cell_h], TRUE
    inc edi
    cmp edi, NUM_CELLS
    jl .size_loop
    xor eax, eax
    jmp .finish

.wm_drawitem:
    mov ebx, [lparam]
    mov edi, [ebx + DRAWITEMSTRUCT.CtlID]
    cmp edi, NUM_CELLS
    jge .defwindowproc

    lea edx, [ebx + DRAWITEMSTRUCT.rcItem]
    invoke FillRect, [ebx + DRAWITEMSTRUCT.hDC], edx, COLOR_WINDOW + 1

    invoke SetBkMode, [ebx + DRAWITEMSTRUCT.hDC], TRANSPARENT

    lea edx, [ebx + DRAWITEMSTRUCT.rcItem]
    invoke DrawText, [ebx + DRAWITEMSTRUCT.hDC], [text_array + edi*4], -1,\
        edx, [format_array + edi*4]

    mov eax, TRUE
    jmp .finish

.wm_destroy:
    invoke PostQuitMessage, 0
    xor eax, eax

.finish:
    ret
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            user32,             'user32.dll',\
            gdi32,              'gdi32.dll'
    import  kernel32,\
            GetModuleHandle,    'GetModuleHandleA',\
            ExitProcess,        'ExitProcess'
    import  user32,\
            CreateWindowEx,     'CreateWindowExA',\
            DefWindowProc,      'DefWindowProcA',\
            DispatchMessage,    'DispatchMessageA',\
            DrawText,           'DrawTextA',\
            FillRect,           'FillRect',\
            GetMessage,         'GetMessageA',\
            LoadCursor,         'LoadCursorA',\
            MoveWindow,         'MoveWindow',\
            PostQuitMessage,    'PostQuitMessage',\
            RegisterClass,      'RegisterClassA'
    import  gdi32,\
            SetBkMode,          'SetBkMode'
