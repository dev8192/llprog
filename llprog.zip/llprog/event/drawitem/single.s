format PE
entry start

include 'win32a.inc'

BTN_ID = 100
BTN_X = 60
BTN_Y = 50
BTN_W = 150
BTN_H = 50

WND_W = 300
WND_H = 200

COLOR_IDLE = 0x00994422
COLOR_PUSHED = 0x00224499
COLOR_TEXT = 0x00FFFFFF

section '.data' data readable writeable
    class_name db 'ExampleWindow', 0
    window_name db 'Example Window', 0
    btnClass db 'BUTTON', 0
    btnText db 'Owner Drawn', 0
    wc WNDCLASS
    msg MSG

section '.text' code readable executable
start:
    mov [wc.style], CS_HREDRAW or CS_VREDRAW
    mov [wc.lpfnWndProc], WindowProc
    invoke GetModuleHandle, 0
    mov [wc.hInstance], eax
    invoke LoadCursor, 0, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.hbrBackground], COLOR_WINDOW + 1
    mov [wc.lpszClassName], class_name
    invoke RegisterClass, wc

    invoke CreateWindowEx, 0, class_name, window_name,\
        WS_VISIBLE or WS_OVERLAPPEDWINDOW,\
        CW_USEDEFAULT, CW_USEDEFAULT, WND_W, WND_H,\
        0, 0, [wc.hInstance], 0

.msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    test eax, eax
    jz .end_loop
    invoke DispatchMessage, msg
    jmp .msg_loop

.end_loop:
    invoke ExitProcess, [msg.wParam]

proc WindowProc uses ebx esi edi, hwnd, wmsg, wparam, lparam
    cmp [wmsg], WM_CREATE
    je .wm_create
    cmp [wmsg], WM_DRAWITEM
    je .wm_drawitem
    cmp [wmsg], WM_DESTROY
    je .wm_destroy
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret

.wm_create:
    invoke CreateWindowEx, 0, btnClass, 0,\
        WS_CHILD or WS_VISIBLE or BS_OWNERDRAW,\
        BTN_X, BTN_Y, BTN_W, BTN_H,\
        [hwnd], BTN_ID, [wc.hInstance], 0
    xor eax, eax
    ret

.wm_drawitem:
    mov edi, [lparam]
    mov esi, [edi + DRAWITEMSTRUCT.hDC]

    test [edi + DRAWITEMSTRUCT.itemState], ODS_SELECTED
    jnz .is_pressed
    invoke CreateSolidBrush, COLOR_IDLE
    jmp .fill_bg
.is_pressed:
    invoke CreateSolidBrush, COLOR_PUSHED

.fill_bg:
    mov ebx, eax
    lea ecx, [edi + DRAWITEMSTRUCT.rcItem]
    invoke FillRect, esi, ecx, ebx
    invoke DeleteObject, ebx

    invoke SetBkMode, esi, TRANSPARENT
    invoke SetTextColor, esi, COLOR_TEXT
    lea ecx, [edi + DRAWITEMSTRUCT.rcItem]
    invoke DrawText, esi, btnText, -1, ecx,\
        DT_CENTER or DT_VCENTER or DT_SINGLELINE

    mov eax, 1
    ret

.wm_destroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    ret
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            user32,             'user32.dll',\
            gdi32,              'gdi32.dll'
    import  kernel32,\
            GetModuleHandle,    'GetModuleHandleA',\
            ExitProcess,        'ExitProcess'
    import  user32,\
            RegisterClass,      'RegisterClassA',\
            CreateWindowEx,     'CreateWindowExA',\
            DefWindowProc,      'DefWindowProcA',\
            GetMessage,         'GetMessageA',\
            DispatchMessage,    'DispatchMessageA',\
            PostQuitMessage,    'PostQuitMessage',\
            LoadCursor,         'LoadCursorA',\
            FillRect,           'FillRect',\
            DrawText,           'DrawTextA'
    import  gdi32,\
            CreateSolidBrush,   'CreateSolidBrush',\
            DeleteObject,       'DeleteObject',\
            SetBkMode,          'SetBkMode',\
            SetTextColor,       'SetTextColor'
