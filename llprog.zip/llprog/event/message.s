format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt_d     db '%d', 10, 0

section '.text' code readable executable
start:
    stdcall test10
    invoke ExitProcess, 0

proc test10
    cinvoke printf, fmt_d, BM_SETCHECK
    cinvoke printf, fmt_d, WM_USER+0
    ret
endp

section '.idata' import data readable
library kernel32,       'kernel32.dll',\
        msvcrt,         'msvcrt.dll'
import  kernel32,\
        ExitProcess,    'ExitProcess'
import  msvcrt,\
        printf,         'printf'
