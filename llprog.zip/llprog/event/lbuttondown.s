format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt_xy      db 'x: %d, y: %d', 10, 0
    cls_name    db 'ExampleWindow', 0
    win_title   db 'Example Window', 0
    wc          WNDCLASS
    msg         MSG

section '.text' code readable executable
start:
    invoke  GetModuleHandle, 0
    mov     [wc.hInstance], eax
    mov     [wc.lpfnWndProc], WindowProc
    mov     [wc.lpszClassName], cls_name
    mov     [wc.hbrBackground], COLOR_WINDOW + 1
    invoke  LoadCursor, 0, IDC_ARROW
    mov     [wc.hCursor], eax
    invoke  RegisterClass, wc

    invoke  CreateWindowEx, 0, cls_name, win_title,\
            WS_OVERLAPPEDWINDOW + WS_VISIBLE,\
            CW_USEDEFAULT, CW_USEDEFAULT, 400, 400,\
            0, 0, [wc.hInstance], 0

.msg_loop:
    invoke  GetMessage, msg, 0, 0, 0
    test    eax, eax
    jz      .end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     .msg_loop
.end_loop:
    invoke  ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp     [wmsg], WM_LBUTTONDOWN
    je      .wm_lbuttondown
    cmp     [wmsg], WM_DESTROY
    je      .wm_destroy
    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret

.wm_lbuttondown:
    mov     ecx, [lparam]
    movsx   eax, cx
    sar     ecx, 16
    cinvoke printf, fmt_xy, eax, ecx
    xor     eax, eax
    ret

.wm_destroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
    ret
endp

section '.idata' import data readable
library kernel32,           'kernel32.dll',\
        user32,             'user32.dll',\
        msvcrt,             'msvcrt.dll'
import  kernel32,\
        GetModuleHandle,    'GetModuleHandleA',\
        ExitProcess,        'ExitProcess'
import  user32,\
        RegisterClass,      'RegisterClassA',\
        CreateWindowEx,     'CreateWindowExA',\
        LoadCursor,         'LoadCursorA',\
        GetMessage,         'GetMessageA',\
        TranslateMessage,   'TranslateMessage',\
        DispatchMessage,    'DispatchMessageA',\
        DefWindowProc,      'DefWindowProcA',\
        PostQuitMessage,    'PostQuitMessage'
import  msvcrt,\
        printf,             'printf'
