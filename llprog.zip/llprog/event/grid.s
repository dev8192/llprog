format PE
entry start

include 'win32a.inc'

GRID_SIZE = 10
CELL_PITCH = 30
CELL_DRAW_SIZE = 28
GAP_SIZE = 2
MAX_INDEX = GRID_SIZE - 1

section '.data' data readable writeable
    grid rb GRID_SIZE * GRID_SIZE
    cursor_x dd 0
    cursor_y dd 0

    hBrushUnselected dd ?
    hBrushSelected dd ?
    hBrushBorder dd ?

    wc WNDCLASS
    msg MSG
    ps PAINTSTRUCT
    rect RECT

    class_name db "GridApp", 0
    window_title db "Grid", 0

    fmt_rect db '%d %d %d %d', 10, 0

section '.text' code readable executable
start:
    invoke GetModuleHandle, NULL
    mov [wc.hInstance], eax
    mov [wc.lpfnWndProc], WindowProc
    invoke LoadCursor, NULL, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.hbrBackground], COLOR_BTNFACE + 1
    mov [wc.lpszClassName], class_name
    invoke RegisterClass, wc

    invoke GetStockObject, WHITE_BRUSH
    mov [hBrushUnselected], eax
    invoke GetStockObject, LTGRAY_BRUSH
    mov [hBrushSelected], eax
    invoke GetStockObject, BLACK_BRUSH
    mov [hBrushBorder], eax

    mov [rect.left], 0
    mov [rect.top], 0
    mov [rect.right], GRID_SIZE * CELL_PITCH + GAP_SIZE
    mov [rect.bottom], GRID_SIZE * CELL_PITCH + GAP_SIZE

    cinvoke printf, fmt_rect,\
        [rect.left], [rect.top], [rect.right], [rect.bottom]
    invoke AdjustWindowRect, rect, WS_OVERLAPPEDWINDOW, FALSE
    cinvoke printf, fmt_rect,\
        [rect.left], [rect.top], [rect.right], [rect.bottom]
    
    mov eax, [rect.right]
    sub eax, [rect.left]
    mov edx, [rect.bottom]
    sub edx, [rect.top]

    invoke CreateWindowEx, 0, class_name, window_title,\
        WS_OVERLAPPEDWINDOW,\
        CW_USEDEFAULT, CW_USEDEFAULT, eax, edx,\
        NULL, NULL, [wc.hInstance], NULL
    mov ebx, eax

    invoke ShowWindow, ebx, SW_SHOWDEFAULT
    invoke UpdateWindow, ebx

.msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    test eax, eax
    jz .end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp .msg_loop

.end_loop:
    invoke ExitProcess, [msg.wParam]

proc WindowProc uses ebx esi edi, hwnd, uMsg, wParam, lParam
    cmp [uMsg], WM_PAINT
    je .on_paint
    cmp [uMsg], WM_KEYDOWN
    je .on_keydown
    cmp [uMsg], WM_DESTROY
    je .on_destroy
    invoke DefWindowProc, [hwnd], [uMsg], [wParam], [lParam]
    ret

.on_paint:
    invoke BeginPaint, [hwnd], ps

    mov esi, 0
.row_loop:
    mov edi, 0
.col_loop:
    mov eax, edi
    imul eax, CELL_PITCH
    add eax, GAP_SIZE
    mov [rect.left], eax
    add eax, CELL_DRAW_SIZE
    mov [rect.right], eax

    mov eax, esi
    imul eax, CELL_PITCH
    add eax, GAP_SIZE
    mov [rect.top], eax
    add eax, CELL_DRAW_SIZE
    mov [rect.bottom], eax

    mov eax, esi
    imul eax, GRID_SIZE
    add eax, edi
    mov cl, [grid + eax]
    test cl, cl
    jnz .selected
    
    mov ebx, [hBrushUnselected]
    jmp .draw_cell
    
.selected:
    mov ebx, [hBrushSelected]
    
.draw_cell:
    invoke FillRect, [ps.hdc], rect, ebx

    cmp edi, [cursor_x]
    jne .next_col
    cmp esi, [cursor_y]
    jne .next_col
    
    invoke FrameRect, [ps.hdc], rect, [hBrushBorder]
    
.next_col:
    inc edi
    cmp edi, GRID_SIZE
    jl .col_loop
    inc esi
    cmp esi, GRID_SIZE
    jl .row_loop

    invoke EndPaint, [hwnd], ps
    xor eax, eax
    ret

.on_keydown:
    mov eax, [wParam]
    cmp eax, VK_UP
    je .do_up
    cmp eax, VK_DOWN
    je .do_down
    cmp eax, VK_LEFT
    je .do_left
    cmp eax, VK_RIGHT
    je .do_right
    cmp eax, VK_SPACE
    je .do_space
    xor eax, eax
    ret

.do_up:
    cmp [cursor_y], 0
    je .done_key
    dec [cursor_y]
    jmp .redraw
    
.do_down:
    cmp [cursor_y], MAX_INDEX
    je .done_key
    inc [cursor_y]
    jmp .redraw
    
.do_left:
    cmp [cursor_x], 0
    je .done_key
    dec [cursor_x]
    jmp .redraw
    
.do_right:
    cmp [cursor_x], MAX_INDEX
    je .done_key
    inc [cursor_x]
    jmp .redraw

.do_space:
    mov eax, [cursor_y]
    imul eax, GRID_SIZE
    add eax, [cursor_x]
    xor byte [grid + eax], 1
    
.redraw:
    invoke InvalidateRect, [hwnd], NULL, TRUE
    
.done_key:
    xor eax, eax
    ret

.on_destroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    ret
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            user32,             'user32.dll',\
            gdi32,              'gdi32.dll',\
            msvcrt,             'msvcrt.dll'
    import  kernel32,\
            ExitProcess,        'ExitProcess',\
            GetModuleHandle,    'GetModuleHandleA'
    import  user32,\
            AdjustWindowRect,   'AdjustWindowRect',\
            BeginPaint,         'BeginPaint',\
            CreateWindowEx,     'CreateWindowExA',\
            DefWindowProc,      'DefWindowProcA',\
            DispatchMessage,    'DispatchMessageA',\
            EndPaint,           'EndPaint',\
            FillRect,           'FillRect',\
            FrameRect,          'FrameRect',\
            GetMessage,         'GetMessageA',\
            InvalidateRect,     'InvalidateRect',\
            LoadCursor,         'LoadCursorA',\
            PostQuitMessage,    'PostQuitMessage',\
            RegisterClass,      'RegisterClassA',\
            ShowWindow,         'ShowWindow',\
            TranslateMessage,   'TranslateMessage',\
            UpdateWindow,       'UpdateWindow'
    import  gdi32,\
            GetStockObject,     'GetStockObject'
    import  msvcrt,\
            printf,             'printf'
