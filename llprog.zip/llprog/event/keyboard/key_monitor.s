format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    className  db 'KeyMonitor', 0
    fontName   db 'Arial', 0
    ctrlStr    db 'Ctrl + ', 0
    shiftStr   db 'Shift + ', 0
    altStr     db 'Alt + ', 0
    initial    db 'Press any key', 0
    
    wc         WNDCLASS
    msg        MSG
    ps         PAINTSTRUCT
    rect       RECT
    
    hFont      dd ?
    
    keyText    rb 256
    keyNameBuf rb 64

section '.text' code readable executable
start:
    invoke GetModuleHandle, 0
    mov [wc.hInstance], eax
    mov [wc.lpfnWndProc], WindowProc
    mov [wc.lpszClassName], className
    mov [wc.hbrBackground], COLOR_WINDOW+1
    invoke LoadCursor, 0, IDC_ARROW
    mov [wc.hCursor], eax
    invoke RegisterClass, wc

    invoke CreateWindowEx, 0, className, className,\
        WS_VISIBLE or WS_OVERLAPPEDWINDOW,\
        CW_USEDEFAULT, CW_USEDEFAULT, 800, 600,\
        0, 0, [wc.hInstance], 0

.msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    test eax, eax
    jz .end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp .msg_loop

.end_loop:
    invoke ExitProcess, [msg.wParam]

proc WindowProc hWnd, wMsg, wParam, lParam
    cmp [wMsg], WM_PAINT
    je .wm_paint
    cmp [wMsg], WM_CREATE
    je .wm_create
    cmp [wMsg], WM_KEYDOWN
    je .on_key
    cmp [wMsg], WM_SYSKEYDOWN
    je .on_syskey
    cmp [wMsg], WM_DESTROY
    je .wm_destroy
    invoke DefWindowProc, [hWnd], [wMsg], [wParam], [lParam]
    ret

.wm_create:
    invoke CreateFont, 72, 0, 0, 0, FW_BOLD, 0, 0, 0, DEFAULT_CHARSET,\
        OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,\
        DEFAULT_PITCH, fontName
    mov [hFont], eax

    invoke lstrcpy, keyText, initial
    xor eax, eax
    ret

.on_key:
    stdcall UpdateText, [hWnd], [wParam], [lParam]
    xor eax, eax
    ret

.on_syskey:
    stdcall UpdateText, [hWnd], [wParam], [lParam]
    invoke DefWindowProc, [hWnd], [wMsg], [wParam], [lParam]
    ret

.wm_paint:
    invoke BeginPaint, [hWnd], ps    
    invoke SelectObject, [ps.hdc], [hFont]
    push eax
    invoke GetClientRect, [hWnd], rect
    invoke SetBkMode, [ps.hdc], TRANSPARENT
    invoke lstrlen, keyText
    invoke DrawText, [ps.hdc], keyText, eax, rect,\
        DT_CENTER or DT_VCENTER or DT_SINGLELINE
    pop eax
    invoke SelectObject, [ps.hdc], eax
    invoke EndPaint, [hWnd], ps
    xor eax, eax
    ret

.wm_destroy:
    invoke DeleteObject, [hFont]
    invoke PostQuitMessage, 0
    xor eax, eax
    ret
endp

proc UpdateText hWnd, wParam, lParam
    mov byte [keyText], 0
    
    cmp [wParam], VK_CONTROL
    je .get_name
    cmp [wParam], VK_SHIFT
    je .get_name
    cmp [wParam], VK_MENU
    je .get_name

    invoke GetKeyState, VK_CONTROL
    test ax, 0x8000
    jz .check_shift
    invoke lstrcat, keyText, ctrlStr

.check_shift:
    invoke GetKeyState, VK_SHIFT
    test ax, 0x8000
    jz .check_alt
    invoke lstrcat, keyText, shiftStr

.check_alt:
    invoke GetKeyState, VK_MENU
    test ax, 0x8000
    jz .get_name
    invoke lstrcat, keyText, altStr

.get_name:
    invoke GetKeyNameText, [lParam], keyNameBuf, 64
    invoke lstrcat, keyText, keyNameBuf

    invoke InvalidateRect, [hWnd], 0, 1
    ret
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            user32,             'user32.dll',\
            gdi32,              'gdi32.dll'
    import  kernel32,\
            GetModuleHandle,    'GetModuleHandleA',\
            ExitProcess,        'ExitProcess',\
            lstrcpy,            'lstrcpyA',\
            lstrcat,            'lstrcatA',\
            lstrlen,            'lstrlenA'
    import  user32,\
            LoadCursor,         'LoadCursorA',\
            RegisterClass,      'RegisterClassA',\
            CreateWindowEx,     'CreateWindowExA',\
            GetMessage,         'GetMessageA',\
            TranslateMessage,   'TranslateMessage',\
            DispatchMessage,    'DispatchMessageA',\
            DefWindowProc,      'DefWindowProcA',\
            PostQuitMessage,    'PostQuitMessage',\
            BeginPaint,         'BeginPaint',\
            EndPaint,           'EndPaint',\
            GetClientRect,      'GetClientRect',\
            DrawText,           'DrawTextA',\
            InvalidateRect,     'InvalidateRect',\
            GetKeyState,        'GetKeyState',\
            GetKeyNameText,     'GetKeyNameTextA'
    import  gdi32,\
            CreateFont,         'CreateFontA',\
            SelectObject,       'SelectObject',\
            SetBkMode,          'SetBkMode',\
            DeleteObject,       'DeleteObject'
