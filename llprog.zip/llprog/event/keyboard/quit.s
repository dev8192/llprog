format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    class_name db 'ExampleWindow', 0
    window_name db 'Press Q to close', 0
    wc WNDCLASS
    msg MSG

section '.text' code readable executable
start:
    invoke GetModuleHandle, 0
    mov [wc.hInstance], eax
    mov [wc.style], CS_HREDRAW or CS_VREDRAW
    mov [wc.lpfnWndProc], WindowProc
    invoke LoadCursor, 0, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.hbrBackground], COLOR_WINDOW + 1
    mov [wc.lpszClassName], class_name
    invoke RegisterClass, wc

    invoke CreateWindowEx, 0, class_name, window_name,\
        WS_VISIBLE or WS_OVERLAPPEDWINDOW,\
        CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,\
        0, 0, [wc.hInstance], 0

.msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    cmp eax, 0
    jle .end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp .msg_loop

.end_loop:
    invoke ExitProcess, [msg.wParam]

proc WindowProc hWnd, wMsg, wParam, lParam
    cmp [wMsg], WM_KEYDOWN
    je .wm_keydown
    cmp [wMsg], WM_DESTROY
    je .wm_destroy
.defwindowproc:
    invoke DefWindowProc, [hWnd], [wMsg], [wParam], [lParam]
    ret

.wm_keydown:
    cmp [wParam], 'Q'
    jne .defwindowproc
    invoke DestroyWindow, [hWnd]
    xor eax, eax
    ret

.wm_destroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    ret
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            user32,             'user32.dll'
    import  kernel32,\
            GetModuleHandle,    'GetModuleHandleA',\
            ExitProcess,        'ExitProcess'
    import  user32,\
            RegisterClass,      'RegisterClassA',\
            CreateWindowEx,     'CreateWindowExA',\
            GetMessage,         'GetMessageA',\
            TranslateMessage,   'TranslateMessage',\
            DispatchMessage,    'DispatchMessageA',\
            DefWindowProc,      'DefWindowProcA',\
            DestroyWindow,      'DestroyWindow',\
            LoadCursor,         'LoadCursorA',\
            PostQuitMessage,    'PostQuitMessage'
