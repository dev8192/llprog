format PE GUI 4.0
entry start

include 'win32a.inc'

CIRCLE_START_X = 100
CIRCLE_START_Y = 100
CIRCLE_END_X = 300
CIRCLE_END_Y = 300
SCROLL_DIVISOR = 10
WINDOW_WIDTH = 600
WINDOW_HEIGHT = 600

section '.data' data readable writeable
    wc WNDCLASSEX
    msg MSG
    ps PAINTSTRUCT
    class_name db 'WheelAppClass', 0
    window_name db 'Mouse Wheel Demo', 0
    offset_x dd 0
    offset_y dd 0

section '.text' code readable executable
start:
    invoke GetModuleHandle, NULL
    mov [wc.hInstance], eax
    mov [wc.cbSize], sizeof.WNDCLASSEX
    mov [wc.style], CS_HREDRAW or CS_VREDRAW
    mov [wc.lpfnWndProc], WindowProc
    mov [wc.cbClsExtra], 0
    mov [wc.cbWndExtra], 0
    invoke LoadIcon, NULL, IDI_APPLICATION
    mov [wc.hIcon], eax
    mov [wc.hIconSm], eax
    invoke LoadCursor, NULL, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.hbrBackground], COLOR_WINDOW + 1
    mov [wc.lpszMenuName], NULL
    mov [wc.lpszClassName], class_name
    invoke RegisterClassEx, wc

    invoke CreateWindowEx, 0, class_name, window_name, \
        WS_VISIBLE or WS_OVERLAPPEDWINDOW, \
        CW_USEDEFAULT, CW_USEDEFAULT, \
        WINDOW_WIDTH, WINDOW_HEIGHT, \
        NULL, NULL, [wc.hInstance], NULL

.msg_loop:
    invoke GetMessage, msg, NULL, 0, 0
    test eax, eax
    je .end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp .msg_loop

.end_loop:
    invoke ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp [wmsg], WM_PAINT
    je .wm_paint
    cmp [wmsg], WM_MOUSEWHEEL
    je .wm_mousewheel
    cmp [wmsg], WM_DESTROY
    je .wm_destroy
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret

.wm_paint:
    invoke BeginPaint, [hwnd], ps
    mov eax, CIRCLE_START_X
    sub eax, [offset_x]
    mov ebx, CIRCLE_START_Y
    sub ebx, [offset_y]
    mov ecx, CIRCLE_END_X
    sub ecx, [offset_x]
    mov edx, CIRCLE_END_Y
    sub edx, [offset_y]
    invoke Ellipse, [ps.hdc], eax, ebx, ecx, edx
    invoke EndPaint, [hwnd], ps
    xor eax, eax
    ret

.wm_mousewheel:
    mov eax, [wparam]
    shr eax, 16
    movsx eax, ax
    mov ecx, SCROLL_DIVISOR
    cdq
    idiv ecx
    test [wparam], MK_SHIFT
    jnz .shift_pressed
    sub [offset_y], eax
    jmp .redraw

.shift_pressed:
    sub [offset_x], eax

.redraw:
    invoke InvalidateRect, [hwnd], NULL, TRUE
    xor eax, eax
    ret

.wm_destroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    ret
endp

section '.idata' import data readable
    library kernel32, 'kernel32.dll', \
        user32, 'user32.dll', \
        gdi32, 'gdi32.dll'

    import kernel32, \
        ExitProcess, 'ExitProcess', \
        GetModuleHandle, 'GetModuleHandleA'

    import user32, \
        BeginPaint, 'BeginPaint', \
        CreateWindowEx, 'CreateWindowExA', \
        DefWindowProc, 'DefWindowProcA', \
        DispatchMessage, 'DispatchMessageA', \
        EndPaint, 'EndPaint', \
        GetMessage, 'GetMessageA', \
        InvalidateRect, 'InvalidateRect', \
        LoadCursor, 'LoadCursorA', \
        LoadIcon, 'LoadIconA', \
        PostQuitMessage, 'PostQuitMessage', \
        RegisterClassEx, 'RegisterClassExA', \
        TranslateMessage, 'TranslateMessage'

    import gdi32, \
        Ellipse, 'Ellipse'
