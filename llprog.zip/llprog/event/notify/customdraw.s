format PE
entry start

include 'win32a.inc'

TRACKBAR_ID equ 1001
FRAME_COLOR equ 0x000000FF

NM_CUSTOMDRAW equ -12
CDDS_PREPAINT equ 0x00000001
CDDS_POSTPAINT equ 0x00000002
CDRF_DODEFAULT equ 0x00000000
CDRF_NOTIFYPOSTPAINT equ 0x00000010

struct NMCUSTOMDRAW
    hdr NMHDR
    dwDrawStage dd ?
    hdc dd ?
    rc RECT
    dwItemSpec dd ?
    uItemState dd ?
    lItemlParam dd ?
ends

section '.data' data readable writeable
    _class db 'FASMWIN', 0
    _title db 'NM_CUSTOMDRAW Post-Paint', 0
    _tb_class db 'msctls_trackbar32', 0
    
    wc WNDCLASS
    msg MSG
    hinst dd ?
    hwnd_tb dd ?
    hbr_temp dd ?

section '.text' code readable executable
start:
    invoke GetModuleHandle, 0
    mov [hinst], eax
    
    invoke InitCommonControls
    
    mov [wc.style], CS_HREDRAW or CS_VREDRAW
    mov [wc.lpfnWndProc], WindowProc
    mov eax, [hinst]
    mov [wc.hInstance], eax
    invoke LoadCursor, 0, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.hbrBackground], COLOR_BTNFACE + 1
    mov [wc.lpszClassName], _class
    invoke RegisterClass, wc
    
    invoke CreateWindowEx, 0, _class, _title, \
        WS_VISIBLE or WS_OVERLAPPEDWINDOW, \
        CW_USEDEFAULT, CW_USEDEFAULT, 400, 200, \
        0, 0, [hinst], 0

msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    test eax, eax
    jz end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp msg_loop
    
end_loop:
    invoke ExitProcess, [msg.wParam]
    
proc WindowProc hwnd, wmsg, wparam, lparam
    cmp [wmsg], WM_CREATE
    je .wm_create
    cmp [wmsg], WM_NOTIFY
    je .wm_notify
    cmp [wmsg], WM_DESTROY
    je .wm_destroy
    
.def_wnd_proc:
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret
    
.wm_create:
    invoke CreateWindowEx, 0, _tb_class, 0, \
        WS_CHILD or WS_VISIBLE, \
        50, 50, 280, 40, \
        [hwnd], TRACKBAR_ID, [hinst], 0
    mov [hwnd_tb], eax
    xor eax, eax
    ret
    
.wm_notify:
    mov edx, [lparam]
    cmp [edx + NMHDR.code], NM_CUSTOMDRAW
    jne .def_wnd_proc
    
    cmp [edx+NMHDR.idFrom], TRACKBAR_ID
    jne .def_wnd_proc
    
    mov eax, [edx + NMCUSTOMDRAW.dwDrawStage]
    
    cmp eax, CDDS_PREPAINT
    je .prepaint
    
    cmp eax, CDDS_POSTPAINT
    je .postpaint
    
    jmp .do_default
    
.prepaint:
    mov eax, CDRF_NOTIFYPOSTPAINT
    ret
    
.postpaint:
    invoke CreateSolidBrush, FRAME_COLOR
    mov [hbr_temp], eax
    
    mov edx, [lparam]
    lea ecx, [edx + NMCUSTOMDRAW.rc]
    invoke FrameRect, [edx + NMCUSTOMDRAW.hdc], ecx, [hbr_temp]
    
    invoke DeleteObject, [hbr_temp]
    
    mov eax, CDRF_DODEFAULT
    ret
    
.do_default:
    mov eax, CDRF_DODEFAULT
    ret
    
.wm_destroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    ret
endp

section '.idata' import data readable writeable

    library kernel32, 'KERNEL32.DLL', \
            user32, 'USER32.DLL', \
            gdi32, 'GDI32.DLL', \
            comctl32, 'COMCTL32.DLL'

    import kernel32, \
           GetModuleHandle, 'GetModuleHandleA', \
           ExitProcess, 'ExitProcess'

    import user32, \
           RegisterClass, 'RegisterClassA', \
           CreateWindowEx, 'CreateWindowExA', \
           DefWindowProc, 'DefWindowProcA', \
           GetMessage, 'GetMessageA', \
           TranslateMessage, 'TranslateMessage', \
           DispatchMessage, 'DispatchMessageA', \
           LoadIcon, 'LoadIconA', \
           LoadCursor, 'LoadCursorA', \
           PostQuitMessage, 'PostQuitMessage', \
           FrameRect, 'FrameRect'

    import gdi32, \
           CreateSolidBrush, 'CreateSolidBrush', \
           DeleteObject, 'DeleteObject'
           
    import comctl32, \
           InitCommonControls, 'InitCommonControls'
