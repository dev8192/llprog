format PE
entry start

include 'win32a.inc'

BG_COLOR equ 0x00FF00

section '.data' data readable writeable
    _class db 'FASMWIN', 0
    _title db 'WM_ERASEBKGND Example', 0

    wc WNDCLASS
    msg MSG
    rect RECT
    hinst dd ?
    hbr_bg dd ?

section '.text' code readable executable
start:
    invoke GetModuleHandle, 0
    mov [hinst], eax
    
    invoke CreateSolidBrush, BG_COLOR
    mov [hbr_bg], eax
    
    mov [wc.style], CS_HREDRAW or CS_VREDRAW
    mov [wc.lpfnWndProc], WindowProc
    mov [wc.cbClsExtra], 0
    mov [wc.cbWndExtra], 0
    mov eax, [hinst]
    mov [wc.hInstance], eax
    invoke LoadIcon, 0, IDI_APPLICATION
    mov [wc.hIcon], eax
    invoke LoadCursor, 0, IDC_ARROW
    mov [wc.hCursor], eax
    invoke CreateSolidBrush, 0x0000FF
    mov [wc.hbrBackground], eax
    mov [wc.lpszMenuName], 0
    mov [wc.lpszClassName], _class
    
    invoke RegisterClass, wc
    
    invoke CreateWindowEx, 0, _class, _title,\
        WS_VISIBLE or WS_OVERLAPPEDWINDOW,\
        CW_USEDEFAULT, CW_USEDEFAULT, 500, 350,\
        0, 0, [hinst], 0
        
.msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    test eax, eax
    jz .end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp .msg_loop
    
.end_loop:
    invoke ExitProcess, [msg.wParam]
    
proc WindowProc hwnd, wmsg, wparam, lparam
;    cmp [wmsg], WM_ERASEBKGND
;    je .wm_erasebkgnd
    cmp [wmsg], WM_DESTROY
    je .wm_destroy
    
.def_wnd_proc:
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    jmp .finish
    
.wm_erasebkgnd:
    invoke GetClientRect, [hwnd], rect
    invoke FillRect, [wparam], rect, [hbr_bg]
    mov eax, 1
    jmp .finish
    
.wm_destroy:
    invoke DeleteObject, [hbr_bg]
    invoke PostQuitMessage, 0
    xor eax, eax
    
.finish:
    ret
endp

section '.idata' import data readable writeable
    library kernel32, 'kernel32.dll',\
            user32, 'user32.dll',\
            gdi32, 'gdi32.dll'
    import  kernel32,\
            GetModuleHandle, 'GetModuleHandleA',\
            ExitProcess, 'ExitProcess'
    import  user32,\
            RegisterClass, 'RegisterClassA',\
            CreateWindowEx, 'CreateWindowExA',\
            DefWindowProc, 'DefWindowProcA',\
            GetMessage, 'GetMessageA',\
            TranslateMessage, 'TranslateMessage',\
            DispatchMessage, 'DispatchMessageA',\
            GetClientRect, 'GetClientRect',\
            FillRect, 'FillRect',\
            LoadIcon, 'LoadIconA',\
            LoadCursor, 'LoadCursorA',\
            PostQuitMessage, 'PostQuitMessage'
    import  gdi32,\
            CreateSolidBrush, 'CreateSolidBrush',\
            DeleteObject, 'DeleteObject'
