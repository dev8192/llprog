format PE GUI 4.0
entry start

include 'win32a.inc'

STATIC_ID equ 1001
TEXT_COLOR equ 0x000000FF
BG_COLOR equ 0x0000FFFF
BG_COLOR2 equ 0x00FFFF00

section '.data' data readable writeable
    wc WNDCLASS
    msg MSG
    hbr_bg dd ?
    clas_name db 'ExampleWindow', 0
    window_name db 'Example Window', 0
    _static_class db 'STATIC', 0
    _static_text db 'Custom Colored Static Text', 0

section '.text' code readable executable
start:
    mov [wc.style], CS_HREDRAW or CS_VREDRAW
    mov [wc.lpfnWndProc], WindowProc
    invoke GetModuleHandle, 0
    mov [wc.hInstance], eax
    invoke LoadCursor, 0, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.hbrBackground], COLOR_WINDOW + 1
    mov [wc.lpszClassName], clas_name
    invoke RegisterClass, wc
    
    invoke CreateWindowEx, 0, clas_name, window_name,\
        WS_VISIBLE or WS_OVERLAPPEDWINDOW,\
        CW_USEDEFAULT, CW_USEDEFAULT, 350, 150,\
        0, 0, [wc.hInstance], 0
        
msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    test eax, eax
    jz end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp msg_loop
    
end_loop:
    invoke ExitProcess, [msg.wParam]
    
proc WindowProc hWnd, wMsg, wParam, lParam
    cmp [wMsg], WM_CREATE
    je .wm_create
    cmp [wMsg], WM_CTLCOLORSTATIC
    je .wm_ctlcolorstatic
    cmp [wMsg], WM_DESTROY
    je .wm_destroy
.def_wnd_proc:
    invoke DefWindowProc, [hWnd], [wMsg], [wParam], [lParam]
    ret
    
.wm_create:
    invoke CreateSolidBrush, BG_COLOR
    mov [hbr_bg], eax
    invoke CreateWindowEx, 0, _static_class, _static_text,\
        WS_CHILD or WS_VISIBLE or SS_CENTER,\
        50, 40, 230, 30,\
        [hWnd], STATIC_ID, [wc.hInstance], 0
    xor eax, eax
    ret
    
.wm_ctlcolorstatic:
    invoke SetTextColor, [wParam], TEXT_COLOR
    invoke SetBkColor, [wParam], BG_COLOR2
    ;invoke SetBkMode, [wParam], TRANSPARENT
    mov eax, [hbr_bg]
    ret
    
.wm_destroy:
    invoke DeleteObject, [hbr_bg]
    invoke PostQuitMessage, 0
    xor eax, eax
    ret
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            user32,             'user32.dll',\
            gdi32,              'gdi32.dll'
    import  kernel32,\
            GetModuleHandle,    'GetModuleHandleA',\
            ExitProcess,        'ExitProcess'
    import  user32,\
            RegisterClass,      'RegisterClassA',\
            CreateWindowEx,     'CreateWindowExA',\
            DefWindowProc,      'DefWindowProcA',\
            GetMessage,         'GetMessageA',\
            TranslateMessage,   'TranslateMessage',\
            DispatchMessage,    'DispatchMessageA',\
            LoadIcon,           'LoadIconA',\
            LoadCursor,         'LoadCursorA',\
            PostQuitMessage,    'PostQuitMessage'
    import  gdi32,\
            CreateSolidBrush,   'CreateSolidBrush',\
            SetTextColor,       'SetTextColor',\
            SetBkMode,          'SetBkMode',\
            SetBkColor,         'SetBkColor',\
            DeleteObject,       'DeleteObject'
