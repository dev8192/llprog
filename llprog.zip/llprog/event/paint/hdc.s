; ------------------------------------------------------------------------------------
; BeginPaint is defined as returning an HDC (Device Context handle).
; In the Win32 ABI (x86), this return value is placed in the EAX register.
; Simultaneously, the HDC is written into the hdc member of the PAINTSTRUCT structure. 
; ------------------------------------------------------------------------------------
format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_x       db '%x', 10, 0
    class_name  db 'WinClass', 0
    wc          WNDCLASS
    msg         MSG
    ps          PAINTSTRUCT

section '.text' code readable executable
start:
    invoke GetModuleHandle, 0
    mov [wc.hInstance], eax
    mov [wc.lpfnWndProc], WindowProc
    invoke LoadCursor, 0, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.hbrBackground], COLOR_WINDOW + 1
    mov [wc.lpszClassName], class_name
    invoke RegisterClass, wc

    invoke CreateWindowEx, 0, class_name, 0,\
        WS_VISIBLE + WS_OVERLAPPEDWINDOW,\
        CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,\
        0, 0, [wc.hInstance], 0

.msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    test eax, eax
    jle .exit_app
    invoke DispatchMessage, msg
    jmp .msg_loop

.exit_app:
    invoke ExitProcess, 0

proc WindowProc hwnd, uMsg, wParam, lParam
    cmp [uMsg], WM_PAINT
    je .wm_paint
    cmp [uMsg], WM_DESTROY
    je .wm_destroy
    invoke DefWindowProc, [hwnd], [uMsg], [wParam], [lParam]
    ret

.wm_paint:
    stdcall on_paint, [hwnd]
    ;invoke DestroyWindow, [hwnd]
    xor eax, eax
    ret

.wm_destroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    ret
endp

proc on_paint1, hwnd
    invoke BeginPaint, [hwnd], ps
    cinvoke printf, fmt_x, eax
    cinvoke printf, fmt_x, [ps.hdc]
    invoke EndPaint, [hwnd], ps
    ret
endp

proc on_paint, hwnd
    local ps:PAINTSTRUCT
    invoke BeginPaint, [hwnd], addr ps
    cinvoke printf, fmt_x, eax
    cinvoke printf, fmt_x, [ps.hdc]
    invoke EndPaint, [hwnd], addr ps
    ret
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            user32,             'user32.dll',\
            msvcrt,             'msvcrt.dll'
    import  kernel32,\
            ExitProcess,        'ExitProcess',\
            GetModuleHandle,    'GetModuleHandleA'
    import  user32,\
            BeginPaint,         'BeginPaint',\
            CreateWindowEx,     'CreateWindowExA',\
            DefWindowProc,      'DefWindowProcA',\
            DestroyWindow,      'DestroyWindow',\
            DispatchMessage,    'DispatchMessageA',\
            EndPaint,           'EndPaint',\
            GetMessage,         'GetMessageA',\
            LoadCursor,         'LoadCursorA',\
            PostQuitMessage,    'PostQuitMessage',\
            RegisterClass,      'RegisterClassA'
    import  msvcrt,\
            printf,             'printf'
