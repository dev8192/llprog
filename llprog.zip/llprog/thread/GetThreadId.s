format PE CONSOLE 4.0
entry start

include 'win32a.inc'

INFINITE = -1

section '.data' data readable writeable
    fmt1 db 'fmt1: %u', 10, 0
    fmt2 db 'fmt2: %u', 10, 0
    fmt3 db 'fmt3: %u', 10, 0
    fmt4 db 'fmt4: %u', 10, 0
    fmt5 db 'fmt5: %u', 10, 0
    hThread dd 0
    threadId dd 0

section '.text' code readable executable

proc ThreadProc, lpParameter
    invoke GetCurrentThreadId
    cinvoke printf, fmt5, eax
    xor eax, eax
    ret
endp

start:
    invoke GetCurrentThreadId
    cinvoke printf, fmt1, eax

    invoke GetCurrentThread
    invoke GetThreadId, eax
    cinvoke printf, fmt2, eax

    invoke CreateThread, 0, 0, ThreadProc, 0, 0, threadId
    mov [hThread], eax
    cinvoke printf, fmt3, [threadId]

    invoke GetThreadId, [hThread]
    cinvoke printf, fmt4, eax

    invoke WaitForSingleObject, [hThread], INFINITE
    invoke CloseHandle, [hThread]
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32,               'KERNEL32.DLL',\
            msvcrt,                 'MSVCRT.DLL'
    import  kernel32,\
            CloseHandle,            'CloseHandle',\
            CreateThread,           'CreateThread',\
            ExitProcess,            'ExitProcess',\
            GetCurrentThread,       'GetCurrentThread',\
            GetCurrentThreadId,     'GetCurrentThreadId',\
            GetThreadId,            'GetThreadId',\
            WaitForSingleObject,    'WaitForSingleObject'
    import  msvcrt,\
            printf,                 'printf'
