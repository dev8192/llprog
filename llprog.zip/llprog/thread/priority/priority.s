
invoke GetCurrentThread
invoke SetThreadPriority, eax, THREAD_PRIORITY_HIGHEST
